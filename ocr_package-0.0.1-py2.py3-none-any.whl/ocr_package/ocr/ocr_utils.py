'''
Some utility functions for working with OCR data.
'''
import Levenshtein
import jiwer
import pyarabic.araby as araby
from pathlib import Path
import os, shutil, cv2
import numpy as np
from sklearn.cluster import KMeans

def normalize_text(text):
    text = araby.strip_tashkeel(text)
    text = text.replace(araby.ALEF_MAKSURA, araby.YEH)
    text = text.replace("\n", " ")
    text = ' '.join(text.split())   # remove multiple spaces
    text = text.replace("ـ", "")    # remove tatweel char
    text = text.replace(",", araby.COMMA)
    text = text.replace(" " + araby.COMMA, araby.COMMA)
    text = text.replace(" .", ".")
    #text = araby.normalize_hamza(text)
    text = araby.normalize_teh(text)
    text = araby.normalize_alef(text)

    return text

def refine_pred_and_label_for_eval(pred):
    pred = pred.replace("\"", " ")
    pred = pred.replace(")", " ")
    pred = pred.replace("(", " ")
    pred = pred.replace("!", " ")
    pred = pred.replace(":", " ")
    pred = pred.replace("،", " ")
    pred = pred.replace(".", " ")
    pred = pred.strip()

    return pred

def get_wer_and_cer(pred, gt):
    pred_line = refine_pred_and_label_for_eval(pred)
    gt_line = refine_pred_and_label_for_eval(gt)

    gt_line = normalize_text(gt_line)
    gt_line = sanitize_arabic(gt_line)

    pred_line = normalize_text(pred_line)
    pred_line = sanitize_arabic(pred_line)

    wer = jiwer.wer(gt_line, pred_line)
    cer = Levenshtein.distance(gt_line, pred_line) / len(gt_line)

    return wer, cer

def sanitize_arabic(text, charlist_path='../../models/charlist_ara+eng_tashkeel.txt'):
    # with open(charlist_path, 'r', encoding='utf-8') as f:
    #     charlist = sorted(set(f.read().splitlines()))
    sanitized = ''
    last_char = ''
    for char in text:
        if char in ['⁒', '⸓']:
            sanitized += '%'
        # elif char == 'ـ':
        #     pass
        elif char in ['▪', '▀', '∎', '▇', '▅', '▄', '◼', '▆']:
            sanitized += '■'
        elif char in ['□', '◻']:
            sanitized += '☐'
        elif char == '【':
            sanitized += '['
        elif char == '】':
            sanitized += ']'
        elif char == '❫':
            sanitized += ')'
        elif char == '❪':
            sanitized += '('
        elif char == ' ' and last_char == ' ':
            pass
        ### normalize arabic gidits
        elif char.encode() == b'\xdb\xb0':
            sanitized += b'\xd9\xa0'.decode()
        elif char.encode() == b'\xdb\xb1':
            sanitized += b'\xd9\xa1'.decode()
        elif char.encode() == b'\xdb\xb2':
            sanitized += b'\xd9\xa2'.decode()
        elif char.encode() == b'\xdb\xb3':
            sanitized += b'\xd9\xa3'.decode()
        elif char.encode() == b'\xdb\xb4':
            sanitized += b'\xd9\xa4'.decode()
        elif char.encode() == b'\xdb\xb5':
            sanitized += b'\xd9\xa5'.decode()
        elif char.encode() == b'\xdb\xb6':
            sanitized += b'\xd9\xa6'.decode()
        elif char.encode() == b'\xdb\xb7':
            sanitized += b'\xd9\xa7'.decode()
        elif char.encode() == b'\xdb\xb8':
            sanitized += b'\xd9\xa8'.decode()
        elif char.encode() == b'\xdb\xb9':
            sanitized += b'\xd9\xa9'.decode()
        # elif char not in charlist:
        #     return ''
        else:
            sanitized += char
        last_char = char
    # for char in sanitized:
    #     if char not in charlist:
    #         oov_list.append(char)
    sanitized = sanitized.replace('⸨', '')
    sanitized = sanitized.replace('⸩', '')
    return sanitized.strip()

def sanitize_dataset(ds_path, trg_path):
    os.makedirs(trg_path)
    for file in Path(ds_path).rglob('*.gt.txt'):
        with open(file, 'r', encoding='utf-8') as f:
            text = f.read()
        sanitized = sanitize_arabic(text)
        image_path = str(file).replace('.gt.txt', '.png')
        if text != sanitized:
            print(f'Original {text}')
            print(f'Clean {sanitized}')
        if len(sanitized) == 0:
            continue
        else:
            trg_text_path = os.path.join(trg_path, file.name)
            trg_img_path = os.path.join(trg_path, Path(image_path).name)
            with open(trg_text_path, 'w', encoding='utf-8') as f:
                f.write(sanitized)
            shutil.copy(image_path, trg_img_path)

def reverse_bracket(self, char):
    if char == ')':
        return '('
    if char == '(':
        return ')'

    if char == '[':
        return ']'
    if char == ']':
        return '['

    if char == '{':
        return '}'
    if char == '}':
        return '{'

    if char == '>':
        return '<'
    if char == '<':
        return '>'

def validate_dataset(ds_path):
    for file in Path(ds_path).rglob('*.gt.txt'):
        image_path = str(file).replace('.gt.txt', '.png')
        if not os.path.exists(image_path):
            print(f'Image missing: {image_path}')
    for file in Path(ds_path).rglob('*.png'):
        gt_path = str(file).replace('.png', '.gt.txt')
        if not os.path.exists(gt_path):
            print(f'GT missing: {gt_path}')

def sort_lines_bins(page_width, article_points, titles_points, lines_points):
    rect = cv2.boundingRect(article_points)
    x, y, w, h = rect
    titles_px_per_bin = page_width // 5
    body_px_per_bin = page_width // 10
    num_bins_titles = 1 + w // titles_px_per_bin
    num_bins_body = 1 + w // body_px_per_bin
    w_margin = 10
    bins_titles = np.linspace(start=x, stop=x + w + w_margin,
                              num=num_bins_titles + 1)  # for binning lines horizontally for sorting
    bins_body = np.linspace(start=x, stop=x + w + w_margin, num=num_bins_body + 1)
    # sort according to binned y value of bottomright (in reverse), then by x value (height)
    get_sort_keys_titles = lambda line: (-int(np.digitize(int(line[1][1]), bins_titles)), line[1][0])
    get_sort_keys_body = lambda line: (-int(np.digitize(int(line[1][1]), bins_body)), line[1][0])
    titles_coords_sorted = sorted(titles_points, key=get_sort_keys_titles)
    text_coords_sorted = sorted(lines_points, key=get_sort_keys_body)
    return titles_coords_sorted, text_coords_sorted

def sort_lines_kmeans(lines_array):
    def sorted_lines(members, input_array):
        lines = []
        for i in range(len(members.keys())):
            indices_of_center = members[
                sorted(members, reverse=True)[i]]  # sort based on centers, and return indices according to this center
            sorted_indices_and_lines = sorted(
                list(zip(indices_of_center, input_array[indices_of_center][:, 1, 0].tolist())),
                key=lambda l: l[1])  # sort based on y
            indices = [member_line[0] for member_line in sorted_indices_and_lines]

            # indices = [ml[0] for ml in sorted(list(zip(members[sorted(members, reverse=True)[i]]
            #                                            , input_array[members[sorted(members, reverse=True)[i]]][:, 1,
            #                                              0].tolist()))
            #                                   , key=lambda x: x[1])]
            lines.append(input_array[indices])

        if len(lines) == 1:
            return lines[0]
        else:
            return np.concatenate(lines, axis=0)

    def find_membership(centers, points):
        # points and centers  should be list
        clusters = {}
        for c in centers:
            clusters[c] = []

        for i, p in enumerate(points):
            dis = 1000000
            for c in centers:
                dis_for_c = abs(p - c)
                if dis_for_c < dis:
                    cluster = c
                    dis = dis_for_c

            clusters[cluster].append(i)

        return clusters

    def check_dis_between_clusters(centers, max_difference_between_centers):
        if centers.shape[0] == 1:
            return centers[0].tolist()
        cc = sorted(np.squeeze(centers).tolist(), reverse=True)
        on_hands = []
        for i in range(len(cc)):
            if len(cc) == 0:
                break
            holding = cc[0]
            on_hands.append(holding)
            cc = [c for c in cc if abs(c - holding) > max_difference_between_centers]

        return on_hands

    if len(lines_array) <= 1:
        return lines_array

    X = [line_co[1][1] for line_co in lines_array]
    X = np.expand_dims(X, axis=1)
    if X.max() - X.min() == 0:
        return sorted(lines_array, key=lambda x: x[0][0])

    X_norm = (X - X.min()) / (X.max() - X.min())  # norm data
    x1_all = [line_co[0][1] for line_co in lines_array]
    x1_min = min(x1_all)
    max_difference_between_centers = X.max() - x1_min
    max_difference_between_centers = max_difference_between_centers * 0.2

    num_ks = len(X) - 1 if len(X) < 10 else 10
    y = [KMeans(n_clusters=idx, random_state=0).fit(X_norm).inertia_ for idx in list(range(1, num_ks))]
    delta = []
    for i in range(1, len(y)):
        delta.append(abs(y[i] - y[i - 1]))  # law el far2 kber h5aly el centers de, law soghyar msh ha5do fel e3tbar
    optimal_k = np.where(np.array(delta) > 0.2)[0].shape[0] + 1

    # optimal_k = np.where(np.array([abs(y[i] - y[i - 1]) for i in range(len(y)) if i > 0]) > .2)[0].shape[0] + 1
    kmeans = KMeans(n_clusters=optimal_k, random_state=0).fit(X_norm)

    centers = kmeans.cluster_centers_
    centers = (centers * (X.max() - X.min())) + X.min()
    centers = check_dis_between_clusters(centers, max_difference_between_centers)
    members = find_membership(centers, np.squeeze(X))
    return sorted_lines(members, lines_array)

def sort_lines_kmeans_restructured(lines_array, title):
    def sorted_lines(members, input_array):
        lines = []
        indices_with_lines = []
        for i in range(len(members.keys())):
            indices_of_center = members[sorted(members, reverse=True)[i]]  # sort based on centers, and return indices according to this center
            boxes = [box for box, _ in input_array[indices_of_center]]
            y_to_sort = []
            for line_box in boxes:
                box = np.sort(np.array([(xb, yb) for xb, yb in line_box], dtype=[('x', '<i4'), ('y', '<i4')]),
                              order=('y', 'x')) # sort top bottom
                y_to_sort.append(box[0][1]) # append y top, one y from 4

            # input_array[indices_of_center][:, 1, 0].tolist()
            sorted_indices_and_y = sorted(list(zip(indices_of_center, y_to_sort)),key=lambda l: l[1])  # sort based on y
            indices = [member_line[0] for member_line in sorted_indices_and_y]
            lines.append(input_array[indices])
            indices_with_lines.extend(input_array[indices])
        return indices_with_lines
        # if len(lines) == 1:
        #     return lines[0]
        # else:
        #     return np.concatenate(lines, axis=0)

    def find_membership(centers, points):
        # points and centers  should be list
        clusters = {}

        for c in centers:
            clusters[c] = []
        distances = []
        for i, p in enumerate(points):
            dis = 1000000
            for c in centers:
                dis_for_c = abs(p - c)
                if dis_for_c < dis:
                    cluster = c
                    dis = dis_for_c
            distances.append(dis)
            clusters[cluster].append(i)

        return clusters

    def check_dis_between_clusters(centers, min_difference_between_centers):
        if centers.shape[0] == 1:
            return centers[0].tolist()
        cc = sorted(np.squeeze(centers).tolist(), reverse=True)
        on_hands = []
        for i in range(len(cc)):
            if len(cc) == 0:
                break
            holding = cc[0]
            on_hands.append(holding)
            cc = [c for c in cc if abs(c - holding) > min_difference_between_centers]

        return on_hands

    if len(lines_array) <= 1:
        return list(lines_array)
    lines_coords = [line for line, _ in lines_array]

    X = []
    X1 = []
    w_all = []
    for line_box in lines_coords:
        box = np.sort(np.array([(xb, yb) for xb, yb in line_box], dtype=[('x', '<i4'), ('y', '<i4')]), order=('x', 'y')) # sort left to right to append
        X.append(box[-1][0])  # append right x only, one X from 4 ,, for sorting
        X1.append(box[0][0])  # append left x,, to get max_difference_between_centers
        w_all.append(abs(box[-1][0]-box[0][0]))

    # X = [line_co[1][1] for line_co in lines_coords]
    X = np.expand_dims(X, axis=1)
    if X.max() - X.min() == 0:
        return list(sorted(lines_array, key=lambda x: x[0][0][1]))

    X_norm = (X - X.min()) / (X.max() - X.min())  # norm data
    # x1_all = [line_co[0][1] for line_co in lines_array]
    # x1_min = min(x1_all)
    # max_difference_between_centers = (X.max() - min(X1)) * 0.2
    if title:
        min_difference_between_centers = np.min(w_all)
    else:
        min_difference_between_centers = np.median(w_all)*0.2

    num_ks = len(X) if len(X) < 10 else 10
    y = [KMeans(n_clusters=idx, random_state=0).fit(X_norm).inertia_ for idx in list(range(1, num_ks))]
    delta = []
    for i in range(1, len(y)):
        delta.append(abs(y[i] - y[i - 1]))  # law el far2 kber h5aly el centers de, law soghyar msh ha5do fel e3tbar
    optimal_k = np.where(np.array(delta) > 0.2)[0].shape[0] + 1

    # optimal_k = np.where(np.array([abs(y[i] - y[i - 1]) for i in range(len(y)) if i > 0]) > .2)[0].shape[0] + 1
    kmeans = KMeans(n_clusters=optimal_k, random_state=0).fit(X_norm)

    centers = kmeans.cluster_centers_
    centers = (centers * (X.max() - X.min())) + X.min()
    centers = check_dis_between_clusters(centers, min_difference_between_centers)
    members = find_membership(centers, np.squeeze(X))
    return sorted_lines(members, lines_array)

def sort_lines_kmeans_with_width(lines_array):
    def sorted_lines(members, input_array):
        lines = []
        indices_with_lines = []
        for i in range(len(members.keys())):
            indices_of_center = members[sorted(members, reverse=True)[i]]  # sort based on centers, and return indices according to this center
            boxes = [box for box, _ in input_array[indices_of_center]]
            y_to_sort = []
            for line_box in boxes:
                box = np.sort(np.array([(xb, yb) for xb, yb in line_box], dtype=[('x', '<i4'), ('y', '<i4')]),
                              order=('y', 'x')) # sort top bottom
                y_to_sort.append(box[0][1]) # append y top, one y from 4

            # input_array[indices_of_center][:, 1, 0].tolist()
            sorted_indices_and_y = sorted(list(zip(indices_of_center, y_to_sort)),key=lambda l: l[1])  # sort based on y
            indices = [member_line[0] for member_line in sorted_indices_and_y]

            lines.append(input_array[indices])
            indices_with_lines.append([indices,input_array[indices]])
        return indices_with_lines
        # if len(lines) == 1:
        #     return lines[0]
        # else:
        #     return np.concatenate(lines, axis=0)

    def find_membership(centers, points):
        # points and centers  should be list
        clusters = {}
        for c in centers:
            clusters[c] = []

        for i, p in enumerate(points):
            dis = 1000000
            for c in centers:
                dis_for_c = abs(p - c)
                if dis_for_c < dis:
                    cluster = c
                    dis = dis_for_c

            clusters[cluster].append(i)

        return clusters

    def check_dis_between_clusters(centers_x, centers_w, min_difference_between_centers):
        if len(centers_x) == 1:
            return centers_x
        centers_x_sorted = sorted(np.squeeze(centers_x).tolist(), reverse=True)
        on_hands = []
        for i in range(len(centers_x_sorted)):
            if len(centers_x_sorted) == 0:
                break
            holding = centers_x_sorted[0]
            on_hands.append(holding)
            centers_x_sorted = [center for center in centers_x_sorted if abs(center - holding) > 100 ]

        return on_hands

    # def check_if_cluster_above_all():


    if len(lines_array) <= 1:
        return lines_array
    lines_coords = [line for line, _ in lines_array]

    X = []
    X1 = []
    w_all = []
    for line_box in lines_coords:
        box = np.sort(np.array([(xb, yb) for xb, yb in line_box], dtype=[('x', '<i4'), ('y', '<i4')]), order=('x', 'y')) # sort left to right to append
        X.append(box[-1][0])  # append right x only, one X from 4 ,, for sorting
        X1.append(box[0][0])  # append left x,, to get max_difference_between_centers
        w_all.append(abs(box[-1][0]-box[0][0]))

    min_difference_between_centers = np.median(sorted(w_all,reverse=True))
    # X = [line_co[1][1] for line_co in lines_coords]
    # X = np.expand_dims(X, axis=1)
    # w_all = np.expand_dims(w_all, axis=1)
    if max(X) - min(X) == 0:
        return sorted(lines_array, key=lambda x: x[0][0][1])

    X_norm = (X - min(X)) / (max(X) - min(X))  # norm data
    w_all_normalization = (w_all - min(w_all)) / (max(w_all) - min(w_all))  # norm data
    # x1_all = [line_co[0][1] for line_co in lines_array]
    # x1_min = min(x1_all)
    # max_difference_between_centers = (X.max() - min(X1)) * 0.2
    # y = [KMeans(n_clusters=idx, random_state=0).fit(X_norm).inertia_ for idx in list(range(1, num_ks))]
    features = [X_norm, w_all_normalization]
    features = np.array(features).transpose()
    num_ks = len(X) - 1 if len(X) < 10 else 10
    kmeans = KMeans(n_clusters=num_ks, random_state=0).fit(features)
    cluster_centers = kmeans.cluster_centers_  # [item1, item2]   -> item1 for x, item2 for w
    delta_x = []
    delta_w = []
    for i in range(1, len(cluster_centers)):
        delta_x.append(abs(cluster_centers[i][0] - cluster_centers[i - 1][0]))  # law el far2 kber ben el centers h5aly el centers de, law soghyar msh ha5do fel e3tbar
        delta_w.append(abs(cluster_centers[i][1] - cluster_centers[i - 1][1]))  # law el far2 kber ben el centers h5aly el centers de, law soghyar msh ha5do fel e3tbar
    delta_x_indices = np.where(np.array(delta_x) > 0.2)
    delta_w_indices = np.where(np.array(delta_w) > 0.1)
    common_indices = delta_x_indices and delta_w_indices
    optimal_k = len(common_indices[0]) + 1

    # optimal_k = np.where(np.array([abs(y[i] - y[i - 1]) for i in range(len(y)) if i > 0]) > .2)[0].shape[0] + 1
    kmeans = KMeans(n_clusters=optimal_k, random_state=0).fit(features)

    centers = kmeans.cluster_centers_
    centers_x = np.array([item[0] for item in centers])
    centers_w = np.array([item[1] for item in centers])
    centers_x = (centers_x * (max(X) - min(X))) + min(X)
    centers_w = (centers_w * (max(w_all) - min(w_all))) + min(w_all)
    centers = check_dis_between_clusters(centers_x,centers_w, min_difference_between_centers)
    members = find_membership(centers, np.squeeze(X))
    sorted_lines_all = sorted_lines(members, lines_array)
    # check_if_cluster_above_all(sorted_lines_all)
    return sorted_lines_all

def convert_xywh_to_pts(line):
    y, x, w, h = line   # Here x is height and y is width
    pts = [[x, y], [x+h, y+w]] # [tl,br]
    return pts

def convert_pts_to_tl_tr_br_bl(line):
    box = np.argsort(np.array([(xb, yb) for xb, yb in line], dtype=[('x', '<i4'), ('y', '<i4')]),order=('x', 'y'))  # sort left to right
    x_left_indices = box[:2]
    x_right_indices = box[2:]
    left_points = sorted(line[x_left_indices], key=lambda p:p[1])
    y_tl = left_points[0][1]
    y_bl = left_points[1][1]
    x_tl = left_points[0][0]
    x_bl = left_points[1][0]

    right_points = sorted(line[x_right_indices], key=lambda p: p[1])
    y_tr = right_points[0][1]
    y_br = right_points[1][1]
    x_tr = right_points[0][0]
    x_br = right_points[1][0]

    new_line = [[x_tl,y_tl], [x_tr,y_tr], [x_br,y_br], [x_bl, y_bl]]
    return new_line

def extract_tl_tr_br_bl_without_rotation_to_sorting(box, add_margin, margin_val):
    if add_margin:
        box = add_margin_to_rect(box,margin_val,margin_val)  # to be dynamic
    box_x1 = box[0][0]
    box_y1 = box[0][1]
    box_x2 = box[1][0]
    box_y2 = box[1][1]
    box_x3 = box[2][0]
    box_y3 = box[2][1]
    box_x4 = box[3][0]
    box_y4 = box[3][1]

    min_x = min(box_x1, box_x2, box_x3, box_x4)
    max_x = max(box_x1, box_x2, box_x3, box_x4)
    min_y = min(box_y1, box_y2, box_y3, box_y4)
    max_y = max(box_y1, box_y2, box_y3, box_y4)

    tl = (min_x,min_y)
    tr = (max_x, min_y)
    br = (max_x, max_y)
    bl = (min_x, max_y)
    return [tl,tr,br,bl]

def convert_(point):
    point[0] = point[0][::-1]
    point[1] = point[1][::-1]
    return point

def convert_t0_2_points(points):
    if len(points) == 0:
        return points
    points = points[:, [0, 2], :]
    points = [convert_(point) for point in points]
    return points

if __name__ == '__main__':
    # input_path = Path(r"D:\ahram_annotation\batch_4\tested")
    input_path = Path(r'D:\ocr_training_data\Janna_LT_Bold.ttf')
    # output_path = "D:/ahram_annotation/batch_1/tested"
    # os.makedirs(output_path, exist_ok=True)
    # validate_dataset(input_path)
    sanitize_dataset(r'D:\annotation_data\books_annotation\batch_t1\lines', r'D:\annotation_data\books_annotation\batch_t1\sanitized')

