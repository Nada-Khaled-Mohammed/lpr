
import tensorflow.keras.backend as k
from tensorflow.keras import layers
import tensorflow as tf

from bidi.algorithm import get_display
import matplotlib.pyplot as plt
import numpy as np
import time
import cv2
import os

from data_augmentation.Aug_helpers import source_data_aug , source_data_aug_numby
from ocr_package.ocr.ocr_utils import sanitize_arabic


from CONFIG import Config
args = Config()



class OCR_data:
    def __init__( self           ,
                  FOLDERS        ,
                  dataset_wights ,
                  Charlists      ,
                  use_aug        ,
                  used_display   ,
                  from_gens      ,
                  batch_size     ,
                  img_height     ,
                  max_img_width  ,
                  model_stride    ):
        self.FOLDERS        = FOLDERS
        self.dataset_wights = dataset_wights
        self.Charlists      = Charlists
        self.use_aug        = use_aug
        self.used_display   = used_display
        self.from_gens      = from_gens
        self.batch_size     = batch_size
        
        self.img_height        = img_height
        self.max_img_width     = max_img_width
        self.model_stride      = model_stride 
    
    
    def _image_resize(self , image):
        image  = image.numpy() * 255
        image  = image.astype('uint8')
        image  = image[:, :, 0]
        (h, w) = image.shape[:2]
        r      = self.img_height / float(h)
        dim    = (min(int(w * r), self.max_img_width), self.img_height)
        if dim[0] != self.max_img_width : # trying to make the input width can be divided over 8 .
            rem = dim[0] % 8 
            dim = (dim[0] + (8 - rem) , dim[1]) if rem != 0  else dim

        image = cv2.resize(image, dim, interpolation=cv2.INTER_AREA)
        image = cv2.resize(image, (self.max_img_width , image.shape[0]), interpolation=cv2.INTER_AREA) if image.shape[1] > self.max_img_width else image 


        """
        back_ = np.zeros((img_height , max_img_width))


        back_[:image.shape[0] , :image.shape[1]] = image

        image = back_

        """

        image = image.reshape([image.shape[0], image.shape[1], 1])
        image = tf.convert_to_tensor(image / 255, dtype=tf.float32)

        return image
    
    
    def _prepare_bidi_training_text( self , label):
        text = label.numpy().decode('utf-8')
        text = sanitize_arabic(text)
        text = tf.convert_to_tensor(text, dtype=tf.string)
        return text
    
    
    def _apply_data_formatting( self , in_dict):
        image           = in_dict['image']
        label           = in_dict['label']

        def tf_image_resize(image):
            im_shape   = image.shape
            [image , ] = tf.py_function(self._image_resize, [image], [tf.float32  ])
            image.set_shape(im_shape)

            return image

        image = tf_image_resize(image)
        image = tf.transpose(image, perm=[1, 0, 2])  # We want width first as the sequence dim for our model

        def tf_prepare_rtl_text(label):
            shape = label.shape
            [label, ] = tf.py_function(self._prepare_bidi_training_text, [label], [tf.string])
            label.set_shape(shape)
            return label

        label     = tf_prepare_rtl_text(label)
        label     = self.char_to_num(tf.strings.unicode_split(label         , input_encoding="UTF-8"))



        return {"image" : image,  "label" : label }
    
    
    def _prepare_single_sample_gen( self , image  , label  ):

        image     = tf.image.convert_image_dtype(image / 255, tf.float32)


        return {"image"  : image,  "label"  : label }

        
        
    
    
    def Generate_Tokenizer(self, charlist_path):
        with open(charlist_path , 'r', encoding='utf-8') as f:
            charlist_ = sorted(set(f.read().splitlines()))

        char_to_num = layers.experimental.preprocessing.StringLookup( vocabulary = list(charlist_) ,
                                                                      mask_token = None )


        num_to_char = layers.experimental.preprocessing.StringLookup( vocabulary  = char_to_num.get_vocabulary() ,
                                                                      mask_token  = None                         ,
                                                                      invert      = True )

        return char_to_num , num_to_char , charlist_ 
    
    
    def DATASET( self):
    
        self.char_to_num     , self.num_to_char     ,charlist_      = self.Generate_Tokenizer(self.Charlists[0]) # only one model for now 
        VOCABS           = [len(charlist_)  + 2 ]  # only one model for now  

        generators       =  [ GENERATOR(        FOLDER        = self.FOLDERS[i]              ,
                                                CharList      = self.Charlists[i]            ,
                                                use_aug       = self.use_aug                    ,
                                                used_display  = self.used_display[i]                   ,
                                                from_gen      = self.from_gens[i] ,
                                                model_stride  = self.model_stride ,
                                                img_height    = self.img_height ,
                                                max_img_width = self.max_img_width)  for i in range(len(self.FOLDERS)) ]



        gen_weights = self.dataset_wights
        return self.tensorflow_DATA(generators , gen_weights  , self.batch_size ) , VOCABS 
    
    
    
    def tensorflow_DATA(self , generators , gen_weights  , batch_size = 8):
        if generators is not None:
            gen_datasets = []
            for gen in generators:
                gen_datasets.append(tf.data.Dataset.from_generator(
                                                                    gen.generate_samples, output_types = ( tf.float32 ,
                                                                                                           tf.string   ),
                    output_shapes=(
                                    tf.TensorShape([None, None, 1]) , 
                                    tf.TensorShape([]) 
                                                        ))  )



        gen_dataset = tf.data.experimental.sample_from_datasets(gen_datasets ,
                                                                weights  = gen_weights)

        gen_dataset = gen_dataset.map( self._prepare_single_sample_gen ,
                                       num_parallel_calls = tf.data.experimental.AUTOTUNE)

        gen_dataset = gen_dataset.map( self._apply_data_formatting ,
                                       num_parallel_calls = tf.data.experimental.AUTOTUNE)

        gen_dataset = gen_dataset.padded_batch(batch_size).prefetch(buffer_size = tf.data.experimental.AUTOTUNE)

        return gen_dataset
    
    
class GENERATOR:
    def __init__(self                                ,
                 FOLDER                              ,
                 used_display  = False               , 
                 use_aug       = False               ,
                 CharList      = "charlist_v3.txt"   ,
                 from_gen      = True                ,
                 model_stride  = 2                   ,
                 img_height    = 32                  ,
                 max_img_width = 900 ):
        
        """
        FOLDER       : path of data to sample from .
        used_display : flag to use display or not .
        CharList     : path to the txt file in which all the chars classes u want the model to predict .
        from_gen     : data from generator or from data annotation .
        
        """
        
        self.folder_path    = FOLDER
        self.used_display   = used_display
        self.use_aug        = use_aug
        self.char_list_path = CharList
        self.from_gen       = from_gen
        
        
        self.model_stride  = model_stride
        self.img_height    = img_height 
        self.max_img_width = max_img_width
        
        
        self.chars = self.read_charList(self.char_list_path )
        
    def sort_gt(self , src_path ):
        
        text_names  = [name for name in os.listdir(src_path ) if name.endswith(".txt")]
        image_names = [name for name in os.listdir(src_path ) if name.endswith(".png")]
        
        text_names    = list(sorted(text_names) )
        text_names    = [os.path.join(src_path , name) for name in text_names ]

        image_names   = list(sorted(image_names) )
        image_names   = [os.path.join(src_path , name) for name in image_names ]
        
        return image_names , text_names
    
    
    
    def read_image_and_text(self , image_name , text_name , charlist_ ):
        image   = cv2.imread(image_name)
        image   = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        image   = np.expand_dims(image , axis = 2)
        
        with open(text_name , "r" , encoding= "utf-8") as f :
            text = f.read()
        
        text = "".join([ch for ch in text if ch in charlist_ ]) # filter the chars not exist in the charlist .
        
        return image ,  text
    
    
    def read_charList(self , char_list_path):
        with open(char_list_path , "r" ,encoding= "utf-8") as f :
            char = f.read()
        return char.replace("\n" , "")
        
        
    def generate_samples(self ):
        image_names , text_names = self.sort_gt(self.folder_path )
        data                   = list(zip(image_names , text_names))
        
        print(f"found {len(data)} sample in {self.folder_path}")
        
        while True :

            
            idx                     = np.random.randint(0 , len(data) )
            image_name , text_name  = data[idx]
            
            try :
                image , text =self.read_image_and_text(image_name , text_name , self.chars)
                
            except :
                print("here is an error in loading images and text files ..... ")
                continue
            
            
            text    = sanitize_arabic(text)
            text    = get_display(text) if self.used_display == True else text
            
            if len(text) > 0     :
                try :
                    image = source_data_aug_numby(image , self.from_gen) if  self.use_aug else image
                    image = np.squeeze(image , axis= -1) if len(image.shape) == 4 else image 


                    # to avoid ctc loss issues ..... 
                    h , w  = image.shape[:2]
                    if len(text) < (self.max_img_width // (self.model_stride * 2)) :
                        r      = self.img_height / float(h)
                        new_w  = min(int(w * r), self.max_img_width)

                        if (len(text) + 2  ) * 2 > ( (new_w // self.model_stride)   - (self.model_stride * 2 ) ) :

                            new_width = int( ( (len(text) + 2 ) * 2) * self.model_stride  + (self.model_stride * 2 ))
                            new_width = int(new_width / r)


                            back = np.zeros((h ,  new_width  , 1 ))
                            if back.shape[1] > w :
                                back[: , :w] = image
                                image        = back

                    yield (image , text  )

                except :
                    print("error at GEN_Class")
                    pass
    
        

if __name__ =="__main__":
    from CONFIG import Config
    args = Config()
    from decode import *
    
    


    ocr_data = OCR_data(FOLDERS        = args.FOLDERS ,
                        dataset_wights = args.dataset_wights,
                        Charlists      = args.Charlists,
                        use_aug        = args.use_aug,
                        used_display   = args.used_display,
                        from_gens      = args.from_gens,
                        batch_size     = args.BATCH_SIZE,
                        img_height     = args.img_height,
                        max_img_width  = args.max_img_width,
                        model_stride   = args.model_stride)


    gen_dataset  , VOCABS = ocr_data.DATASET()

    
    for batch in gen_dataset:
        break
    
    image  , labels  = batch['image'] , batch['label'] 

    image  , labels = image.numpy()   , labels.numpy() 
    
    for i , im in enumerate(image) :
        display(im)

        text = [decode_(res , ocr_data.num_to_char ) for res in labels[i] ]
        print("Text")
        for ch in text :
            print("CH : " , ch )



        print("label")
        for ch in labels[i] :
            print("CH : " , ch )
    