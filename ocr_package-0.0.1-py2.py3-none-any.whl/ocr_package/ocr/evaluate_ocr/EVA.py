#!/usr/bin/env python
# coding: utf-8

# In[1]:


import sys , os , cv2 , jiwer , Levenshtein , shutil
import pandas as pd
import matplotlib.pyplot as plt
from ocr_package.ocr.ocr_utils import normalize_text, sanitize_arabic
from pathlib import Path

GT = True
import tensorflow as tf
import numpy as np
from bidi.algorithm import get_display
# from OCR_ENG import OCR_eng
from decode import * 
from OCR.ocr_engine_v2 import OCR_engine

# path = rD:\Cyshield_projects\ocr_projects\OCR_Thabet_Final_21-02-2022\1_Mosawer_batches\60es\60es_lines"
# dst = r"D:\Cyshield_projects\ocr_projects\OCR_Thabet_Final_21-02-2022\1_Mosawer_batches\mos-t2\60es_lines"
#
# for img in os.listdir(path):
#     if img.startswith("196"):
#         shutil.copyfile(f"{os.path.join(path,img)}",f"{os.path.join(dst,img)}")


def test_cy_ocr(ocr_engine, dir_name , inspect_output=False, save_output=True, type='newspaper'  ):
    
    def refine_pred_and_label_for_eva(pred):
                    
        pred = pred.replace("\"" ," ")
        pred = pred.replace(")" ," ")
        pred = pred.replace("(" ," ")
        pred = pred.replace("!" ," ")
        pred = pred.replace(":" ," ")
        pred = pred.replace("،" ," ")
        pred = pred.replace("." ," ")
        pred = pred.replace("-", " ")
        pred = pred.replace("ـ", "")
        pred = pred.replace("_", " ")
        pred = pred.strip()

        return pred
    
    
    
    
    ocr              = ocr_engine
    lines            = []
    labels           = []
    wer_scores       = []
    cer_scores       = []
    filenames        = []
    char_lengths     = []
    word_lengths     = []
    total_char_count = 0
    total_word_count = 0
    predictions      = []
    
    dataset = ocr.prepare_datasets(src_paths=[dir_name] , quality_matrix = True )
    
    num_of_batches = len([name for name in os.listdir(dir_name) if name.endswith(".png")]) // ocr.batch_size
    j , ss = 0 ,  0
    for batch in dataset.take(num_of_batches):
        j += 1
        batch_images  , batch_labels , label_path = batch["image"] , batch["label"] , batch["label_path"].numpy() 


        #preds      = ocr.prediction_model.predict(batch_images)
        preds      = ocr.model.predict(batch_images  )
        pred_texts = decode_batch_predictions_to_print(preds , ocr.num_to_char , eval_ = True )
        for i in range(ocr.batch_size):
            label = tf.strings.reduce_join(ocr.num_to_char(batch_labels[i])).numpy().decode("utf-8")
            label = label.replace('[UNK]', '')

            if len(label) > 0:

                file_name = label_path[i].decode("utf-8")
                basename, ext = os.path.splitext(file_name)
                basename = basename.split("\\")[-1]
                basename = basename.split(".")[0]

                filenames.append(basename)
                image = batch_images[i].numpy()
                image = np.transpose(image, [1, 0, 2])
                
                predictions.append(get_display(pred_texts[i]))
                labels.append(get_display(label))

                #char_lengths.append(len(label))
                #word_lengths.append(len(label.split()))

                label_before_norm = label

                pred_hy = pred_texts[i]

                
                pred_hy = refine_pred_and_label_for_eva(pred_hy)

                label   = refine_pred_and_label_for_eva(label)
                
                label = normalize_text(label)
                label = sanitize_arabic(label)
                
                pred_hy   = normalize_text(pred_hy)
                pred_hy   = sanitize_arabic(pred_hy)
                

                wer   = jiwer.wer(label, pred_hy)
                cer   = Levenshtein.distance(label, pred_hy) / len(label)


                wer_scores.append(wer)
                cer_scores.append(cer)
#                 predictions.append(pred_hy)
#                 labels.append(label)
                char_lengths.append(len(get_display(label)))
                word_lengths.append(len(get_display(label).split()))
                lines.append(image)
    


    results = list(zip(filenames, predictions , labels, cer_scores, wer_scores, char_lengths, word_lengths, lines))
    #results = list(zip(filenames, predictions , labels, cer_scores, char_lengths, word_lengths, lines))
    results_sorted = sorted(results, key=lambda x : x[3], reverse=True) # sort based on cer score
    columns = ['filenames', 'preds', 'labels', 'cer_scores', 'wer_scores', 'char_lengths', 'word_lengths', 'lines']
    #columns = ['filenames', 'preds', 'labels', 'cer_scores', 'char_lengths', 'word_lengths', 'lines']
    df = pd.DataFrame(results_sorted, columns=columns)
    #print(df['char_lengths'])
    mean_cer = 100 * (df['cer_scores'] * df['char_lengths']).sum() / df['char_lengths'].sum()
    mean_wer = 100 * (df['wer_scores'] * df['word_lengths']).sum() / df['word_lengths'].sum()
    print(f"Mean CER: {mean_cer} \t Mean WER: {mean_wer}")

    os.makedirs(save_path, exist_ok=True)
    with open(os.path.join(save_path, "CER_and_WER.txt"), 'w', encoding='utf=8') as f:
        f.write(f"Mean CER: {mean_cer} \t Mean WER: {mean_wer}")

    pd.set_option('display.max_columns', None)
    pd.set_option('display.width', None)

    #print(df.drop('lines').head(10))
    if save_output:
        for ind in df.index:
            img = df['lines'][ind]*255
            os.makedirs(save_lines_path, exist_ok=True)
            os.makedirs(save_gt_path, exist_ok=True)
            os.makedirs(save_ocr_path, exist_ok=True)
            org_path = dir_name + "/" + f"{df['filenames'][ind]}.png"
            org_image = cv2.imread(org_path)
            #print(org_path)
            #print(org_image)
            cv2.imwrite(os.path.join(save_lines_path, f"{ind}_{df['filenames'][ind]}.png"), org_image)
            #cv2.imwrite(os.path.join(save_lines_path, f"{ind}_{df['filenames'][ind]}.png"), img)
            with open(os.path.join(save_gt_path, f"{ind}_{df['filenames'][ind]}.gt.txt"), 'w', encoding='utf=8') as f:
                f.write(df['labels'][ind])
            with open(os.path.join(save_ocr_path, f"{ind}_{df['filenames'][ind]}.txt"), 'w', encoding='utf=8') as f:
                f.write(df['preds'][ind])
        with open(os.path.join(save_path, f"cer_scores.txt"), 'w', encoding='utf=8') as f:
            f.writelines([df['filenames'][ind] + '\t' + '{:.2f}%'.format(df['cer_scores'][ind]*100) + '\n' for ind in df.index])
        if type == 'book':
            df['book_name'] = df.loc[:, 'filenames'].apply(lambda x: int(x.split('_')[0]))
            df['page_name'] = df.loc[:, 'filenames'].apply(lambda x: ''.join(x.split('_')[0:1]))
            books_df = pd.DataFrame(columns=['book_name', 'CER', 'WER'])
            for book_name, book_df in df.groupby('book_name'):
                mean_cer = 100 * (book_df['cer_scores'] * book_df['char_lengths']).sum() / book_df['char_lengths'].sum()
                mean_wer = 100 * (book_df['wer_scores'] * book_df['word_lengths']).sum() / book_df['word_lengths'].sum()
                books_df = books_df.append({'book_name': book_name, 'CER': mean_cer, 'WER': mean_wer}, ignore_index=True)
            books_df['book_name'] = books_df['book_name'].apply(int)

            pages_df = pd.DataFrame(columns=['page_name', 'CER', 'WER'])
            for book_name, book_df in df.groupby('page_name'):
                mean_cer = 100 * (book_df['cer_scores'] * book_df['char_lengths']).sum() / book_df['char_lengths'].sum()
                mean_wer = 100 * (book_df['wer_scores'] * book_df['word_lengths']).sum() / book_df['word_lengths'].sum()
                pages_df = pages_df.append({'page_name': book_name, 'CER': mean_cer, 'WER': mean_wer}, ignore_index=True)
            books_df.to_csv(os.path.join(save_path, f"cer_scores_books.csv"), index=False)

        elif type == 'newspaper':
            df['page_id'] = df.loc[:, 'filenames'].apply(lambda x: '_'.join(x.replace('-', '_').split('_'))[0:x.index("line") - 1])
            #df['page_id'] = df.loc[:, 'filenames'].apply(lambda x: x.replace('-', '_').split('.')[0])
            df['year'] = df.loc[:, 'filenames'].apply(lambda x: int(x.replace('-', '_').split('_')[0]))
            df['month'] = df.loc[:, 'filenames'].apply(lambda x: int(x.replace('-', '_').split('_')[1]))
            df['day'] = df.loc[:, 'filenames'].apply(lambda x: int(x.replace('-', '_').split('_')[2]))
            df['issue'] = df.loc[:, 'filenames'].apply(lambda x: int(x.replace('-', '_').split('_')[3]))
            df['page'] = df.loc[:, 'filenames'].apply(lambda x: '_'.join(x.replace('-', '_')[0:x.index("line") - 1].split('_')[4:]))
            pages_df = pd.DataFrame(columns=['page_id', 'CER', 'WER'])
            for page_id, page_df in df.groupby('page_id'):
                mean_cer = 100 * (page_df['cer_scores'] * page_df['char_lengths']).sum() / page_df['char_lengths'].sum()
                mean_wer = 100 * (page_df['wer_scores'] * page_df['word_lengths']).sum() / page_df['word_lengths'].sum()
                pages_df = pages_df.append({'page_id': page_id, 'CER': mean_cer, 'WER': mean_wer}, ignore_index=True)
            pages_df.to_csv(os.path.join(save_path, f"cer_scores_pages_{model_name}.csv"), index=False)

            years_df = pd.DataFrame(columns=['year', 'CER', 'WER'])
            for year, year_df in df.groupby('year'):
                mean_cer = 100 * (year_df['cer_scores'] * year_df['char_lengths']).sum() / year_df['char_lengths'].sum()
                mean_wer = 100 * (year_df['wer_scores'] * year_df['word_lengths']).sum() / year_df['word_lengths'].sum()
                years_df = years_df.append({'year': year, 'CER': mean_cer, 'WER': mean_wer},
                                           ignore_index=True)
            years_df['year'] = years_df['year'].apply(int)
            years_df.to_csv(os.path.join(save_path, f"cer_scores_years_{model_name}.csv"), index=False)

        lines_df = df[['filenames', 'cer_scores', 'wer_scores', 'char_lengths', 'word_lengths']]
        lines_df.to_csv(os.path.join(save_path, f"cer_scores_lines_{model_name}.csv"), index=False)


    if inspect_output:
        for ind in df.index:
            print(f"Filename: {df['filenames'][ind]}")
            print(f"Predicted:\n {df['preds'][ind]}")
            print(f"GT:\n {df['labels'][ind]}")
            print(f"CER: {df['cer_scores'][ind]} \t WER: {df['wer_scores'][ind]}")
            img = df['lines'][ind]
            plt.figure()
            plt.imshow(img, cmap='gray')
            plt.show()


# In[ ]:
if __name__ == "__main__":
    # dir_name = r'D:\annotation_data\ahram_annotation\ahram_testing_data\lines'
    model_path = Path(r"D:\gitlab_updated\ocr\models\october_final_models\ocr\7_lines_new_6_.h5")
    model_name = model_path.name[:-3]
    print(model_name)
    
    # path of the test dara u want to eval .
    dir_name        = r"C:\Users\nourhan.emad\Desktop\abdullaah\ground_truth\2000_07_07_0008"
    save_path       = r"C:\Users\nourhan.emad\Desktop\abdullaah\ocr\{}".format(model_name)
    save_lines_path = os.path.join(save_path, 'lines')
    save_gt_path    = os.path.join(save_path, 'lines')
    save_ocr_path   = os.path.join(save_path, 'lines')

    # ocr = OCR_eng( img_height    = 32 ,
    #                       max_img_width = 900,
    #                       charlist_path = r"charlist_v3.txt", rtl = True ,
    #                       model_path    = model_path)
    ocr = OCR_engine(line_height=32, model_path=os.path.join(r"D:\gitlab_updated\ocr\models\october_final_models\ocr",
                                                             '7_lines_new_6_.h5'),
                     charlist_path=os.path.join(r"D:\gitlab_updated\ocr\models\october_final_models\ocr",
                                                'charlist_v3.txt'), rtl=True)

    test_cy_ocr(ocr_engine=ocr, inspect_output=False, save_output=True, type='newspaper',dir_name=dir_name)




