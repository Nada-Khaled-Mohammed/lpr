import os
import cv2
import pytesseract

ds_path = r"C:\Users\nourhan.emad\Desktop\abdullaah\ground_truth"
save_path = r"C:\Users\nourhan.emad\Desktop\abdullaah\predicted_ocr_tesseract"
images = []

pytesseract.pytesseract.tesseract_cmd = r'tesseract\tesseract.exe'
custom_config = r'-l ara-amiri-3000 --psm 4'
for folder in os.listdir(ds_path):
    for file in os.listdir(os.path.join(ds_path,folder)):
        if ".txt" in file:
            img = cv2.imread(os.path.join(ds_path,folder,file.split('.')[0]+".png"),0)
            text = pytesseract.image_to_string(img, config=custom_config)
            text = text.strip()
            # print(text)
            os.makedirs(os.path.join(save_path,folder), exist_ok=True)
            with open(os.path.join(save_path,folder, file.split('.')[0]+".txt"), 'w', encoding='utf=8') as f:
                f.write(text)
