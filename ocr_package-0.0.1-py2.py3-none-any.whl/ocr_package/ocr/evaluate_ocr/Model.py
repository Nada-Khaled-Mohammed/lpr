from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, ReduceLROnPlateau
from tensorflow.keras.optimizers import Adam , RMSprop
from tensorflow.keras.models import Model, load_model
import tensorflow.keras.backend as k
from tensorflow.keras import layers
import tensorflow as tf

from layers import *


def _create_model(args , vocab  , depth = 1 ):  
    
    
    width , height , vocab_names  = args.img_width , args.img_height  , args.VOCABS_names
    
    input_img  = layers.Input(shape = (width , height , depth ) , name  = "image_ara" , dtype = "float32")    
    cnn        = layers.Conv2D(filters = 64 , kernel_size=(3, 3), strides=(1, 1), padding="same", kernel_initializer="he_uniform")(input_img)
    cnn        = layers.BatchNormalization(renorm=True)(cnn)
    cnn        = layers.ReLU()(cnn)
    
    cnn        = res_block_2d(cnn , (3,3)   , 64  , use_full_gate = False  , depth  = 3)
    cnn        = res_block_2d(cnn , (3,3)   , 128 , use_full_gate = False  , depth  = 2) 
    cnn        = res_block_2d(cnn , (3,3)   , 128 , use_full_gate = False  , depth  = 1)
    
    cnn        =  FULL_GATE(cnn   , 128     , (3,3)   , (2, 2) , "same" ) # down_0 32
    #cnn        = layers.MaxPooling2D(pool_size = (2, 2) , strides=(2 , 2 ), padding="same")(cnn)
    

    
    
    
    cnn        = res_block_2d(cnn , (3,3)  , 256  , use_full_gate  = False , depth    = 1)
    cnn        = res_block_2d(cnn , (3,3)  , 256  , use_full_gate  = False , depth    = 1)
    cnn        = res_block_2d(cnn , (1,1)  , 256  , use_full_gate  = False , depth    = 2) 
    
    

    cnn        =  FULL_GATE(cnn     , 256 , (3,3)  , (1, 2) , "same") # down_2 8
    
    
    
    cnn        = res_block_2d(cnn , (3,3)  , 256 , use_full_gate = False  , depth = 1)
    cnn        = res_block_2d(cnn , (3,3)  , 512 , use_full_gate = False  , depth = 1)
    cnn        = res_block_2d(cnn , (1,1)  , 512 , use_full_gate = False  , depth = 2)
    
    
    
    cnn        = CONV2D(cnn    , 512    , (3,3)        , (1 , 2) , "same") # down_3 4
    
    
    cnn        = res_block_2d(cnn , (3,3)  , 512 , use_full_gate = False  , depth  = 1)
    cnn        = res_block_2d(cnn , (3,3)  , 512 , use_full_gate = False  , depth  = 1)
    cnn        = res_block_2d(cnn , (1,1)  , 512 , use_full_gate = False  , depth  = 2)
    
    
    
    cnn        = CONV2D(cnn      , 1024 , (2,2)        , (1, 2) , "same") # down_4 2
    #cnn        = layers.MaxPooling2D(pool_size = (2, 2) , strides=(2 , 2 ), padding="same")(cnn)
    
    
    
    cnn        = res_block_2d(cnn , (2,2)  , 1024 , use_full_gate = False  , depth = 1)
    cnn        = res_block_2d(cnn , (1,1)  , 1024 , use_full_gate = False  , depth = 1)
    cnn        = res_block_2d(cnn , (1,1)  , 1024 , use_full_gate = False  , depth = 2)
    
    
    cnn        = res_block_2d(cnn , (1,1)  , 1024  , use_full_gate = False  , depth = 1)
    cnn        = CONV2D(cnn       , 1024   , (2,2) , (1, 2) , "same")
    
    
    Model_Outputs = []
    for i in range(len(vocab)):
        Model_Outputs.append(TIME_BLOCK( cnn                                  ,  
                                         512                                  ,
                                         vocab[i]                             ,
                                         vocab_names[i]                       ,
                                         max_input_width = args.max_img_width ,
                                         model_stride    = args.model_stride      ))

    
    model = Model(inputs= input_img , outputs = Model_Outputs  , name = "ocr_model")
    
    return model