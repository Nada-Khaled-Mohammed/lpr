#from ocr.layers import *
import cv2
import os
import numpy as np
from bidi.algorithm import get_display
from ocr_utils import sanitize_arabic
from ocr_package.ocr.evaluate_ocr.data import OCR_data
from decode import *
from layers import *
from Model import _create_model




    
class OCR_eng:
    def __init__( self                    ,
                  model_path              ,
                  max_img_width  = 480    ,
                  img_height     = 32     ,
                  charlist_path  = r""    ,
                  rtl            = False  , 
                  args           = None   ,
                  phase          = "testing" # this param takses only 2 values {testing , training }
                                            ):
        
        self.max_img_width = max_img_width 
        self.img_height    = img_height  
        self.charlist_path = charlist_path 
        self.batch_size    = 16 
        self.rtl           = rtl
        self.args          = args
        self.phase         = phase
        if model_path is not None :
            self.model         = load_model( model_path  ,
                                             custom_objects = { 'FullGatedConv2D' :  FullGatedConv2D ,
                                                                "PatchEncoder"    :  PatchEncoder })
            
            
            if self.phase == "training":
                print("defining Data set  ......... 👷‍♀️👷‍♂️👷‍♀️👷‍ ")
                ocr_data = OCR_data(FOLDERS        = args.FOLDERS ,
                                    dataset_wights = args.dataset_wights,
                                    Charlists      = args.Charlists,
                                    use_aug        = True if args.num_of_epochs_to_start_using_augmentation == 0 else False ,
                                    used_display   = args.used_display,
                                    from_gens      = args.from_gens,
                                    batch_size     = args.BATCH_SIZE,
                                    img_height     = args.img_height,
                                    max_img_width  = args.max_img_width,
                                    model_stride   = args.model_stride)


                self.gen_dataset  , VOCABS = ocr_data.DATASET()
                
                self.optimizer        = Adam(learning_rate = args.learning_rate  )
                 
                 
                 
        
        else :
            # create new model 
            print("defining Data set  ......... 👷‍♀️👷‍♂️👷‍♀️👷‍ ")
            ocr_data = OCR_data(FOLDERS        = args.FOLDERS ,
                                dataset_wights = args.dataset_wights,
                                Charlists      = args.Charlists,
                                use_aug        = True if args.num_of_epochs_to_start_using_augmentation == 0 else False ,
                                used_display   = args.used_display,
                                from_gens      = args.from_gens,
                                batch_size     = args.BATCH_SIZE,
                                img_height     = args.img_height,
                                max_img_width  = args.max_img_width,
                                model_stride   = args.model_stride)


            self.gen_dataset  , VOCABS = ocr_data.DATASET()
            self.optimizer        = Adam(learning_rate = args.learning_rate  )
                 
                 
                 
            print("creating Model ......... 👷‍♀️👷‍♂️👷‍♀️👷‍♀️")
            self.model = _create_model(self.args  , VOCABS )
            self.model.summary()
            
        
        
        
            
        
        
        self.char_to_num     , self.num_to_char     ,self.charlist_      = self.Generate_Tokenizer(self.charlist_path) # only one model for now
        
        
        
    
    def sort_gt(self , src_path):
        text_names  = [name for name in os.listdir(src_path ) if name.endswith(".gt.txt")]
        image_names = [name for name in os.listdir(src_path ) if name.endswith(".png")]

        text_names  = [name for name in text_names if (name[:-6]  + "png"    ) in  image_names ]
        image_names = [name for name in image_names if (name[:-3] + "gt.txt" ) in  text_names  ]

        text_names   = list(sorted(text_names) )
        text_names   = [os.path.join(src_path , name) for name in text_names ]

        image_names   = list(sorted(image_names) )
        image_names   = [os.path.join(src_path , name) for name in image_names ]


        return image_names , text_names
    
    
    
    def Generate_Tokenizer(self , charlist_path):
        with open(charlist_path , 'r', encoding='utf-8') as f:
            charlist_ = sorted(set(f.read().splitlines()))

        char_to_num = layers.experimental.preprocessing.StringLookup( vocabulary = list(charlist_) ,
                                                                      mask_token = None )


        num_to_char = layers.experimental.preprocessing.StringLookup( vocabulary  = char_to_num.get_vocabulary() ,
                                                                      mask_token  = None                         ,
                                                                      invert      = True )

        return char_to_num , num_to_char , charlist_ 
    
    
    
            
    
    def read_image(self , image_path , gray = False):
        image   = cv2.imread(image_path)
        image   = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if gray else image
        return image 
    
    def _image_resize(self , image):
        image  = image.numpy() * 255
        image  = image.astype('uint8')
        image  = image[:, :, 0]
        (h, w) = image.shape[:2]
        r      = self.img_height / float(h)
        dim    = (min(int(w * r), self.max_img_width), self.img_height)
        if dim[0] != self.max_img_width : # trying to make the input width can be divided over 8 .
            rem = dim[0] % 8 
            dim = (dim[0] + (8 - rem) , dim[1]) if rem != 0  else dim

        image = cv2.resize(image, dim, interpolation=cv2.INTER_AREA)
        image = cv2.resize(image, (self.max_img_width , image.shape[0]), interpolation=cv2.INTER_AREA) if image.shape[1] > self.max_img_width else image 


        #"""
        if self.phase == "testing":
            back_ = np.zeros((self.img_height , self.max_img_width))


            back_[:image.shape[0] , :image.shape[1]] = image

            image = back_

        #"""

        image = image.reshape([image.shape[0], image.shape[1], 1])
        image = tf.convert_to_tensor(image / 255, dtype=tf.float32)

        return image
            
    
    
    def perform_ocr(self ,  img_list: list   , batch_size = 1) -> list:
        
        def prepare_image(image , max_img_width  = self.max_img_width , img_height = self.img_height ):
            (h, w) = image.shape[:2]
            r      = img_height / float(h)

            dim = (min(int(w  *  r), max_img_width), img_height)

            image = cv2.resize(image, dim, interpolation=cv2.INTER_NEAREST)

            back_ = image
            back_ = np.zeros((img_height , max_img_width))
            back_[:image.shape[0] , :image.shape[1]] = image
            back_ = (back_ / 255).astype('float32').reshape(back_.shape[0], back_.shape[1], 1)

            #display(back_)
            back_ = np.transpose(back_, [1, 0, 2])

            return back_ 

        dataset = (tf.data.Dataset.from_generator(lambda: map(prepare_image, img_list), output_types=tf.float32,
                                                  output_shapes=tf.TensorShape([None, self.img_height, 1]))
                   .padded_batch(batch_size)
                   .prefetch(buffer_size=tf.data.experimental.AUTOTUNE))

        pred_texts = []
        for batch in dataset.take(-1):
            preds = self.model.predict(batch)
            #print(preds)
            pred_text  = decode_batch_predictions_to_print(preds     , self.num_to_char     , 256 , rtl = self.rtl )
            pred_texts.extend(pred_text)

        return pred_texts
    
    

                 
                 
    def test_from_folder(self , test_folder , save_folder = "test_output"):
        make_folder(save_folder)
        names       = os.listdir(test_folder) 
        for name in names :
            test_image = read_image(os.path.join(test_folder , name ) , gray= True )
            text       = self.perform_ocr( [test_image] )

            text_file_path = os.path.join(save_folder , name + ".txt" )
            file1          = open(text_file_path,"w" , encoding= "utf-8")
            file1.writelines(text[0])
            file1.close()

            cv2.imwrite(os.path.join(save_folder , name  ), test_image )
    
    # this part for preparing dataset for evaluation .
    
    def _prepare_single_sample_quality_matrix(self , img_path , label_path ): # me
        # Read image
        img = tf.io.read_file(img_path)
        # Decode and convert to grayscale
        img = tf.io.decode_png(img, channels=1)
        # Convert to float32 in [0, 1] range
        img = tf.image.convert_image_dtype(img, tf.float32)

        label = tf.io.read_file(label_path)

        # Return a dict as our model is expecting two inputs
        return {"image": img, "label": label , "label_path" : label_path}
    
    def _apply_data_formatting_quality_matrix(self, in_dict):
        img  , label ,label_path   = in_dict['image'] , in_dict['label'] , in_dict["label_path"] 

        def tf_image_resize(image):
            im_shape  = image.shape
            [image, ] = tf.py_function(self._image_resize, [image], [tf.float32])
            image.set_shape(im_shape)
            return image

        img = tf_image_resize(img)
        img = tf.transpose(img, perm=[1, 0, 2])  # We want width first as the sequence dim for our model

        def tf_prepare_rtl_text(label):
            shape = label.shape
            [label, ] = tf.py_function(self._prepare_bidi_training_text_source_data, [label], [tf.string])
            label.set_shape(shape)
            return label

        label = tf_prepare_rtl_text(label)
        label = self.char_to_num(tf.strings.unicode_split(label, input_encoding="UTF-8"))

        return {"image": img, "label": label , "label_path" : label_path}
    
    def _prepare_bidi_training_text_source_data(self, label):
        '''
            Prepares bidi (arabic or bilingual) text line for use in training the OCR engine
            by reversing stretches of arabic characters as they would read from left to right.
        '''
        text = label.numpy().decode('utf-8')
        text = sanitize_arabic(text)
        try :
            text = get_display(text)
        except :
            pass
        #text = text[::-1]
        text = tf.convert_to_tensor(text, dtype=tf.string)
        return text

    
                 
                 
    # preparing pipline data for eval phase . "this part only is used at eval phase "
    def prepare_datasets( self                    ,
                      src_paths      = None   ,
                      quality_matrix = False   ):
    
    
        
        if src_paths is not None:
            images , labels  = [] , [] 
            data_sets        = []
            for i , src_path in enumerate(src_paths):
                ds_imgs , lbs = self.sort_gt(src_path)
                images += ds_imgs
                labels += lbs
                print(f'Found {len(ds_imgs)} training samples in {src_path}.')
            data_sets.append(tf.data.Dataset.from_tensor_slices((images , labels )))
            print(f'Found a total of {len(images)} training samples.')

            src_dataset = data_sets[0]
            
            
            if quality_matrix :
                src_dataset = src_dataset.map(self._prepare_single_sample_quality_matrix, num_parallel_calls=tf.data.experimental.AUTOTUNE)
            
        
            
        
        if src_paths is not None:
            dataset = src_dataset
        
            
        if quality_matrix :
            dataset = dataset.map(self._apply_data_formatting_quality_matrix, num_parallel_calls=tf.data.experimental.AUTOTUNE) \
                        .padded_batch(self.batch_size).prefetch(buffer_size=tf.data.experimental.AUTOTUNE)


        return dataset
                 
                 
    
                 
    def training_step( self                                   ,
                       batch                                  ,
                       num_of_epoch_to_start_filter_outliers  , 
                       num_of_epoch_to_start_using_power      , 
                       epoch ):
        
        """
        compute loss of only one batch images and labels .
        """

        image  , labels  = batch['image'] , batch['label']   
        IMAGES , LABELS  = [image ]       , [labels ] 
        batch_loss       = []

        for i , (IM , L ) in enumerate(list(zip(IMAGES , LABELS  ))):
            with tf.GradientTape() as tape:
                OUTPUT     = self.model(IM)
                b_loss     = []

                sample_loss     = self.compute_loss( L      , 
                                                     OUTPUT , 
                                                     num_of_epoch_to_start_filter_outliers   = num_of_epoch_to_start_filter_outliers ,
                                                     num_of_epoch_to_start_using_power       = num_of_epoch_to_start_using_power     , 
                                                     epoch                                   = epoch  )
                if sample_loss is not None :
                    b_loss.append(sample_loss)

                if len(b_loss) > 0 :
                    b_loss     = tf.reduce_mean(b_loss) 
                    batch_loss.append(b_loss.numpy())
                else :
                    b_loss = None

            if b_loss is not None :
                grads = tape.gradient(b_loss , self.model.trainable_weights )
                self.optimizer.apply_gradients(zip(grads, self.model.trainable_weights))


        return  batch_loss  
    
    
    
    def compute_loss(    self   , 
                         y_true ,
                         y_pred ,
                         num_of_epoch_to_start_filter_outliers  = 10 ,
                         num_of_epoch_to_start_using_power      = 25 ,
                         epoch                                  = 0 ):

        y_true       = tf.squeeze(y_true) if len(y_true.shape) > 2 else y_true
        input_length = tf.math.reduce_sum(y_pred       , axis=-1 , keepdims=False)
        input_length = tf.math.reduce_sum(input_length , axis=-1 , keepdims=True)
        label_length = tf.math.count_nonzero(y_true    , axis=-1 , keepdims=True, dtype="int64")

        if tf.reduce_any((2 * label_length + 1 )  >= tf.cast(input_length , tf.int64)) :
            loss = None  
            print("loss is None for that batch .... ")
            print("input_length : "   , input_length)
            print("label_length : " , label_length)
        else:

            loss           = k.ctc_batch_cost(y_true, y_pred, input_length, label_length)
            filter_outlier = True if  min(1 , int(epoch / num_of_epoch_to_start_filter_outliers  ) )  == 1 else False
            use_power      = True if  min(1 , int(epoch / num_of_epoch_to_start_using_power  ) )      == 1 else False


            if filter_outlier and not use_power :
                if num_of_epoch_to_start_filter_outliers == epoch :
                    print("staring filtering outliers 🧐🧐 ......... ")

                initial_thr = 100.0
                max_thr     = initial_thr - (epoch - num_of_epoch_to_start_filter_outliers) * 0.5 


                loss         = tf.where(loss > max_thr  , 0.0 , loss)

            if use_power :
                if num_of_epoch_to_start_using_power == epoch :
                    print("staring using power 😈👿  ......... ")

                initial_thr = 75.0
                if num_of_epoch_to_start_filter_outliers < num_of_epoch_to_start_using_power :
                    max_thr     = initial_thr - (epoch - num_of_epoch_to_start_filter_outliers) * 0.5 
                else :
                    max_thr     = initial_thr - (epoch - num_of_epoch_to_start_using_power) * 0.5 

                loss         = tf.where(loss > max_thr  , 0.0 , loss)
                loss         = (0.98 * loss) ** 1.25  

        return loss
    
    
    
    def ReduceLROnPlateau_(self , optimizer , data_monitor , patient_num_epoch , reduction_factor = 0.1):
        if ((len(data_monitor) - 1 ) - np.argmin(data_monitor)) >= patient_num_epoch :
            if ((len(data_monitor) - 1 ) - np.argmin(data_monitor)) %  patient_num_epoch == 0  :
                message                 = f"reducing optimizer  learning rate from {optimizer.learning_rate.numpy()}"
                optimizer.learning_rate = optimizer.learning_rate *  reduction_factor
                message                += f" to {optimizer.learning_rate.numpy()}"
                print(message)
                return optimizer
            else :
                return optimizer

        else :
            return optimizer
    
    
    def EarlyStopping_(self , model , data_monitor , patient_num_epoch , model_save_path = r""):
        current_loss = np.min(data_monitor)

        if ((len(data_monitor) - 1 ) - np.argmin(data_monitor)) == patient_num_epoch :
            # stop_training_now

            print(f"Training stop (EarlyStopping .... ) min loss is : {np.min(data_monitor)}")
            return True

        elif ((len(data_monitor) - 1 ) - np.argmin(data_monitor)) == 0 :
            # save ur model
            model.save(model_save_path)
            print(f"Model saved successfully at {model_save_path}")

        return False
    
    
    
    def Train(self):
        epoch , step  ,  t_0  = 0 , 0 , time.time()

        for num_data in range(2):
            ALL_EPOCHS_LOSS   , training_stopped = [] , False 

            if epoch == self.args.EPOCHS  or training_stopped :
                break 

            for batch in self.gen_dataset:
                if step == 0 :
                    epoch_loss_total , epoch_loss   = [] , []



                batch_loss = self.training_step( batch ,
                                                         self.args.num_of_epoch_to_start_filter_outliers ,
                                                         self.args.num_of_epoch_to_start_using_power     , 
                                                         epoch                   )

                if len(batch_loss) > 0 :
                    epoch_loss_total.append(np.sum(batch_loss))
                    epoch_loss.append(batch_loss[0])

                step +=1
                if step % 200  == 0:
                    print(step)
                if step == self.args.num_of_steps_each_epoch :
                    time_of_epoch = time.time() - t_0

                    step  , t_0 = 0 , time.time()
                    #TEST_BATCH(model , batch['image'])
                    if self.args.test_images_folder is not None :
                        print("testing on given folder .... ")
                        self.test_from_folder(self.args.test_images_folder )

                    ALL_EPOCHS_LOSS.append(np.mean(epoch_loss_total))

                    #print(f"Epoch : {epoch}  :: total_loss   : {np.mean(epoch_loss_total)} ")
                    print(f"Epoch : {epoch}  :: loss   : {np.mean(epoch_loss)} ")
                    print(f"max loss in this epoch was {np.max(epoch_loss_total)} ")
                    print("Time is : " , time_of_epoch / 60  , " min ")
                    print(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
                    epoch += 1
                    training_stopped = self.EarlyStopping_( self.model , 
                                                       ALL_EPOCHS_LOSS  ,
                                                       self.args.EarlyStopping_patient ,
                                                       self.args.save_model_path)
                    
                    
                    
                    self.optimizer        = self.ReduceLROnPlateau_( self.optimizer              ,
                                                                ALL_EPOCHS_LOSS             , 
                                                                self.args.Learning_rate_patient  , 
                                                                self.args.Learning_rate_reduction_factor )

                    if epoch == self.args.EPOCHS  or training_stopped  or epoch == self.args.num_of_epochs_to_start_using_augmentation:
                        break 





            if num_data == 0 :
                print("defining data using data augmentation ............... ✨✨✨")
                print(f"reducing Learning rate .... from {self.optimizer.learning_rate}")
                self.optimizer.learning_rate = self.optimizer.learning_rate *  0.5
                print(f"to {self.optimizer.learning_rate}")
                ocr_data = OCR_data(FOLDERS        = self.args.FOLDERS ,
                                    dataset_wights = self.args.dataset_wights,
                                    Charlists      = self.args.Charlists,
                                    use_aug        = True  ,
                                    used_display   = self.args.used_display,
                                    from_gens      = self.args.from_gens,
                                    batch_size     = self.args.BATCH_SIZE,
                                    img_height     = self.args.img_height,
                                    max_img_width  = self.args.max_img_width,
                                    model_stride   = self.args.model_stride)


                self.gen_dataset  , _ = ocr_data.DATASET()

                print("Done 💪💪💪")
