#!/usr/bin/env python
# coding: utf-8

# In[ ]:




class Config:
    def __init__(self):
        #model 
        self.model                                     = None     # None to create new model or the path of fine tuning model 
        self.img_height                                = 32 
        self.img_width                                 = None
        self.max_img_width                             = 900  
        self.model_stride                              = 2
        
        
        self.learning_rate                             = 0.00001
        self.Learning_rate_reduction_factor            = 0.5
        self.Learning_rate_patient                     = 2
        self.EarlyStopping_patient                     = 6
        self.num_of_epochs_to_start_using_augmentation = 5
        self.num_of_epoch_to_start_filter_outliers     = 100000
        self.num_of_epoch_to_start_using_power         = 100000
        self.EPOCHS                                    = 300 
        self.num_of_steps_each_epoch                   = 100
        self.save_model_path                           = r"Mos_v4.h5"
        self.BATCH_SIZE                                = 2


        # DATA 
        self.Charlists    = [r'charlist_v3.txt' , r'charlist_v3.txt' ,  r'charlist_v3.txt' , r'charlist_v3.txt'    ]
        #self.Charlists    = [r'charlist_v3.txt' , r'charlist_v3.txt'    ]
        
        
        self.FOLDERS = [r"D:\Cyshield_projects\ocr_projects\ahram_OCR\dataset\all_lines" ,
                        r"D:\Cyshield_projects\ocr_projects\ahram_OCR\dataset\all_oct_ahram_titles" ,
                        r"D:\Cyshield_projects\ocr_projects\ahram_OCR\dataset\lines_cleaned_train_80" ,
                        r"D:\Cyshield_projects\ocr_projects\ahram_OCR\dataset\from_generator_2" ]
                        
        
        
#         self.FOLDERS        = [r"/home/administrator/ocr_training_data/all_mos_lines/" , 
#                                 r"/home/administrator/Agamy/OCR_3-4-2023/lines/"  ,
#                                 "/home/administrator/ocr_training_data/Mos_titles/titles_cleaned_train_95/",
#                                  r"/home/administrator/Agamy/OCR_3-4-2023/from_gen"  ,
                                 
#                                  #r"/home/administrator/ocr_training_data/Annotation_training_data/Mosawer/1963_09_20_2032/lines_cleaned_train_50/"  ,
#                                  #r"/home/administrator/ocr_training_data/Annotation_training_data/Mosawer/old_batches/lines_cleaned/"  ,
#                                  ]
        #self.FOLDERS        = [r"dataset\all_oct_ahram_lines" , r"dataset\all_oct_ahram_titles"   ]
        self.from_gens      = [False  , False , False ,  True ] # this helps when using data augmentation only 
        #self.from_gens      = [False  , False  ] # this helps when using data augmentation only 
        self.used_display   = [True   , True  , True  ,  False ]
        #self.used_display   = [True   , True   ]
        self.dataset_wights = [0.25    , 0.25  , 0.2, 0.3   ] 
        self.VOCABS_names = ["bio"]
        
        
        self.use_aug      = False 
        
        self.test_images_folder = r"test_folder/ocr_test_samples"

        
        



