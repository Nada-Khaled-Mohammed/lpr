'''
Some utility functions for working with OCR data.
'''

import pyarabic.araby as araby
from pathlib import Path
import os, shutil, cv2
import numpy as np
from sklearn.cluster import KMeans

def normalize_text(text):
    text = araby.strip_tashkeel(text)
    text = text.replace(araby.ALEF_MAKSURA, araby.YEH)
    text = text.replace("\n", " ")
    text = ' '.join(text.split())   # remove multiple spaces
    text = text.replace("ـ", "")    # remove tatweel char
    text = text.replace(",", araby.COMMA)
    text = text.replace(" " + araby.COMMA, araby.COMMA)
    text = text.replace(" .", ".")
    #text = text.replace(". ", ".")
    #text = araby.normalize_hamza(text)
    text = araby.normalize_teh(text)
    text = araby.normalize_alef(text)

    return text

def sanitize_arabic(text, charlist_path='../../models/charlist_ara+eng_tashkeel.txt'):
    # with open(charlist_path, 'r', encoding='utf-8') as f:
    #     charlist = sorted(set(f.read().splitlines()))
    sanitized = ''
    last_char = ''
    for char in text:
        if char in ['⁒', '⸓']:
            sanitized += '%'
        # elif char == 'ـ':
        #     pass
        elif char in ['▪', '▀', '∎', '▇', '▅', '▄', '◼', '▆']:
            sanitized += '■'
        elif char in ['□', '◻']:
            sanitized += '☐'
        elif char == '【':
            sanitized += '['
        elif char == '】':
            sanitized += ']'
        elif char == '❫':
            sanitized += ')'
        elif char == '❪':
            sanitized += '('
        elif char == ' ' and last_char == ' ':
            pass
        ### normalize arabic gidits
        elif char.encode() == b'\xdb\xb0':
            sanitized += b'\xd9\xa0'.decode()
        elif char.encode() == b'\xdb\xb1':
            sanitized += b'\xd9\xa1'.decode()
        elif char.encode() == b'\xdb\xb2':
            sanitized += b'\xd9\xa2'.decode()
        elif char.encode() == b'\xdb\xb3':
            sanitized += b'\xd9\xa3'.decode()
        elif char.encode() == b'\xdb\xb4':
            sanitized += b'\xd9\xa4'.decode()
        elif char.encode() == b'\xdb\xb5':
            sanitized += b'\xd9\xa5'.decode()
        elif char.encode() == b'\xdb\xb6':
            sanitized += b'\xd9\xa6'.decode()
        elif char.encode() == b'\xdb\xb7':
            sanitized += b'\xd9\xa7'.decode()
        elif char.encode() == b'\xdb\xb8':
            sanitized += b'\xd9\xa8'.decode()
        elif char.encode() == b'\xdb\xb9':
            sanitized += b'\xd9\xa9'.decode()
        # elif char not in charlist:
        #     return ''
        else:
            sanitized += char
        last_char = char
    # for char in sanitized:
    #     if char not in charlist:
    #         oov_list.append(char)
    sanitized = sanitized.replace('⸨', '')
    sanitized = sanitized.replace('⸩', '')
    return sanitized.strip()

def sanitize_dataset(ds_path, trg_path):
    os.makedirs(trg_path)
    for file in Path(ds_path).rglob('*.gt.txt'):
        with open(file, 'r', encoding='utf-8') as f:
            text = f.read()
        sanitized = sanitize_arabic(text)
        image_path = str(file).replace('.gt.txt', '.png')
        if text != sanitized:
            print(f'Original {text}')
            print(f'Clean {sanitized}')
        if len(sanitized) == 0:
            continue
        else:
            trg_text_path = os.path.join(trg_path, file.name)
            trg_img_path = os.path.join(trg_path, Path(image_path).name)
            with open(trg_text_path, 'w', encoding='utf-8') as f:
                f.write(sanitized)
            shutil.copy(image_path, trg_img_path)

def reverse_bracket(self, char):
    if char == ')':
        return '('
    if char == '(':
        return ')'

    if char == '[':
        return ']'
    if char == ']':
        return '['

    if char == '{':
        return '}'
    if char == '}':
        return '{'

    if char == '>':
        return '<'
    if char == '<':
        return '>'

def validate_dataset(ds_path):
    for file in Path(ds_path).rglob('*.gt.txt'):
        image_path = str(file).replace('.gt.txt', '.png')
        if not os.path.exists(image_path):
            print(f'Image missing: {image_path}')
    for file in Path(ds_path).rglob('*.png'):
        gt_path = str(file).replace('.png', '.gt.txt')
        if not os.path.exists(gt_path):
            print(f'GT missing: {gt_path}')

def sort_lines_bins(page_width, article_points, titles_points, lines_points):
    rect = cv2.boundingRect(article_points)
    x, y, w, h = rect
    titles_px_per_bin = page_width // 5
    body_px_per_bin = page_width // 10
    num_bins_titles = 1 + w // titles_px_per_bin
    num_bins_body = 1 + w // body_px_per_bin
    w_margin = 10
    bins_titles = np.linspace(start=x, stop=x + w + w_margin,
                              num=num_bins_titles + 1)  # for binning lines horizontally for sorting
    bins_body = np.linspace(start=x, stop=x + w + w_margin, num=num_bins_body + 1)
    # sort according to binned y value of bottomright (in reverse), then by x value (height)
    get_sort_keys_titles = lambda line: (-int(np.digitize(int(line[1][1]), bins_titles)), line[1][0])
    get_sort_keys_body = lambda line: (-int(np.digitize(int(line[1][1]), bins_body)), line[1][0])
    titles_coords_sorted = sorted(titles_points, key=get_sort_keys_titles)
    text_coords_sorted = sorted(lines_points, key=get_sort_keys_body)
    return titles_coords_sorted, text_coords_sorted


def sort_lines_kmeans(lines_array):
    def sorted_lines(members, input_array):
        lines = []
        for i in range(len(members.keys())):
            indices = [ml[0] for ml in sorted(list(zip(members[sorted(members, reverse=True)[i]]
                                                       , input_array[members[sorted(members, reverse=True)[i]]][:, 1,
                                                         0].tolist()))
                                              , key=lambda x: x[1])]
            lines.append(input_array[indices])

        if len(lines) == 1:
            return lines[0]
        else:
            return np.concatenate(lines, axis=0)

    def find_membership(centers, points):
        # points and centers  should be list
        clusters = {}
        for c in centers:
            clusters[c] = []

        for i, p in enumerate(points):
            dis = 1000000
            for c in centers:
                dis_for_c = abs(p - c)
                if dis_for_c < dis:
                    cluster = c
                    dis = dis_for_c

            clusters[cluster].append(i)

        return clusters

    def check_dis_between_clusters(centers, max_difference_between_centers):
        if centers.shape[0] == 1:
            return centers[0].tolist()
        cc = sorted(np.squeeze(centers).tolist(), reverse=True)
        on_hands = []
        for i in range(len(cc)):
            if len(cc) == 0:
                break
            holding = cc[0]
            on_hands.append(holding)
            cc = [c for c in cc if abs(c - holding) > max_difference_between_centers]

        return on_hands
    if len(lines_array)<=1:
        return lines_array

    if len(lines_array) <= 1:
        return lines_array

    X = [line_co[1][1] for line_co in lines_array]
    X = np.expand_dims(X, axis=1)
    if X.max() - X.min() == 0:
        return sorted(lines_array, key=lambda x: x[0][0])

    X_norm = (X - X.min()) / (X.max() - X.min())  # norm data
    x1_all = [line_co[0][1] for line_co in lines_array]
    x1_min = min(x1_all)
    max_difference_between_centers = X.max() - x1_min
    max_difference_between_centers= max_difference_between_centers*0.2

    num_ks = len(X) - 1 if len(X) < 10 else 10
    y = [KMeans(n_clusters=idx, random_state=0).fit(X_norm).inertia_ for idx in list(range(1, num_ks))]
    optimal_k = np.where(np.array([abs(y[i] - y[i - 1]) for i in range(len(y)) if i > 0]) > .2)[0].shape[0] + 1
    kmeans = KMeans(n_clusters=optimal_k, random_state=0).fit(X_norm)

    centers = kmeans.cluster_centers_
    centers = (centers * (X.max() - X.min())) + X.min()
    centers = check_dis_between_clusters(centers, max_difference_between_centers)
    return sorted_lines(find_membership(centers, np.squeeze(X)), lines_array)
    
def extract_article_img(img, points, return_full_page=True):
    points = np.array(points).astype(int)
    for p in points:
        p[0] = np.clip(p[0], 0, img.shape[1])
        p[1] = np.clip(p[1], 0, img.shape[0])
    if return_full_page:
        mask = np.zeros_like(img)  # Create mask where white is what we want, black otherwise
        cv2.drawContours(mask, [points], -1, 255, thickness=-1)
        out = np.copy(img)  # Extract out the object and place into output image
        out = out * 0.5
        out[mask == 255] = img[mask == 255]
    else:
        rect = cv2.boundingRect(points)
        x, y, w, h = rect
        cropped = img[y:y + h, x:x + w].copy()

        pts = points - points.min(axis=0)

        mask = np.zeros(cropped.shape[:2], np.uint8)
        cv2.drawContours(mask, [pts], -1, (255, 255, 255), -1, cv2.LINE_AA)
        dst = cv2.bitwise_and(cropped, cropped, mask=mask)
        return dst
    return out


def extract_line_img(img, line):
    # x is vertical dim, y is horizontal dim
    tl, br = line
    min_x = tl[0]
    max_x = br[0]
    min_y = tl[1]
    max_y = br[1]
    height = max_x - min_x
    width = max_y - min_y
    l_margin = int(0.02 * width)
    r_margin = int(0.05 * width)
    t_margin = int(0.06 * height)
    b_margin = int(0.06 * height)
    t = max(0, min_x-t_margin)
    b = min(img.shape[0], max_x+b_margin)
    l = max(0, min_y-l_margin)
    r = min(img.shape[1], max_y+r_margin)
    out = img[t:b, l:r]
    return out


def convert_xywh_to_pts(line):
    y, x, w, h = line   # Here x is height and y is width
    pts = [[x, y], [x+h, y+w]] # [tl,br]
    return pts

if __name__ == '__main__':
    # input_path = Path(r"D:\ahram_annotation\batch_4\tested")
    input_path = Path(r'D:\ocr_training_data\Janna_LT_Bold.ttf')
    # output_path = "D:/ahram_annotation/batch_1/tested"
    # os.makedirs(output_path, exist_ok=True)
    # validate_dataset(input_path)
    sanitize_dataset(r'D:\annotation_data\books_annotation\batch_t1\lines', r'D:\annotation_data\books_annotation\batch_t1\sanitized')
