from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, ReduceLROnPlateau
from tensorflow.keras.optimizers import Adam , RMSprop
from tensorflow.keras.models import Model, load_model
import tensorflow.keras.backend as k
from tensorflow.keras import layers
import tensorflow as tf


from bidi.algorithm import get_display
import matplotlib.pyplot as plt
import numpy as np
import time
import cv2
import os

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
import logging
tf.get_logger().setLevel(logging.ERROR)

from decode import *
from ocr_package.ocr.OCR_ENG import OCR_eng



if __name__ == "__main__":
    ocr = OCR_eng( img_height    = 32                ,
                   max_img_width = 900               ,
                   charlist_path = r"charlist_v3.txt",
                   rtl           = True              ,
                   model_path    = r"Mos_v4.h5")  
    
    
    test_folder     = r"D:\Cyshield_projects\ocr_projects\ahram_OCR\OCR_30_4_2023\test_folder\ocr_test_samples"
    save_out_folder = r"test_output" 
    
    ocr.test_from_folder(test_folder , save_folder= save_out_folder)