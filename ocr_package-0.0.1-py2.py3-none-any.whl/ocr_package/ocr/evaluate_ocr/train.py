from tensorflow.keras import layers
import tensorflow as tf

import matplotlib.pyplot as plt
import numpy as np
import time
import os



# to set warning messages from tensorflow off 
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
import logging
tf.get_logger().setLevel(logging.ERROR)

from CONFIG import Config
args = Config()

from decode import *

from ocr_package.ocr.OCR_ENG import OCR_eng




if __name__ == "__main__":
    ocr = OCR_eng(args.model , args.max_img_width , args.img_height , charlist_path = r"charlist_v3.txt" , args = args , phase = "training")
    ocr.Train()