from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, ReduceLROnPlateau
from tensorflow.keras.optimizers import Adam, RMSprop
from tensorflow.keras.models import Model, load_model
import tensorflow.keras.backend as k
from tensorflow.keras import layers
import tensorflow as tf
from ocr_package.ocr.layers import *
import cv2
import os
import numpy as np
import matplotlib.pyplot as plt
from bidi.algorithm import get_display
from ocr_package.ocr.ocr_utils import sanitize_arabic


# os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
# # List available GPUs (if any)
# gpus = tf.config.experimental.list_physical_devices('GPU')
# if gpus:
#     # Set a limit to allocate only 2GB of GPU memory for each GPU
#     for gpu in gpus:
#         tf.config.experimental.set_virtual_device_configuration(gpu, [tf.config.experimental.VirtualDeviceConfiguration(memory_limit=2048)])
# else:
#     print("No GPUs available, running on CPU.")



class OCR_eng:
    def __init__(self, model_path, max_img_width=480, img_height=32, charlist_path=r"", rtl=False):
        self.max_img_width = max_img_width
        self.img_height = img_height
        self.charlist_path = charlist_path
        self.batch_size = 1
        self.rtl = rtl
        # with tf.device('/cpu:0'):
            # model = tf.keras.models.load_model('models/resnet50_untrained.h5', compile=False)
        self.model = load_model(model_path,
                                custom_objects={'FullGatedConv2D': FullGatedConv2D,
                                                "PatchEncoder": PatchEncoder})

        self.char_to_num, self.num_to_char, self.charlist_ = self.Generate_Tokenizer(
            self.charlist_path)  # only one model for now

    def sort_gt(self, src_path):
        text_names = [name for name in os.listdir(src_path) if name.endswith(".gt.txt")]
        image_names = [name for name in os.listdir(src_path) if name.endswith(".png")]

        text_names = [name for name in text_names if (name[:-6] + "png") in image_names]
        image_names = [name for name in image_names if (name[:-3] + "gt.txt") in text_names]

        text_names = list(sorted(text_names))
        text_names = [os.path.join(src_path, name) for name in text_names]

        image_names = list(sorted(image_names))
        image_names = [os.path.join(src_path, name) for name in image_names]

        return image_names, text_names

    def Generate_Tokenizer(self, charlist_path):
        with open(charlist_path, 'r', encoding='utf-8') as f:
            charlist_ = sorted(set(f.read().splitlines()))

        char_to_num = layers.experimental.preprocessing.StringLookup(vocabulary=list(charlist_),
                                                                     mask_token=None)

        num_to_char = layers.experimental.preprocessing.StringLookup(vocabulary=char_to_num.get_vocabulary(),
                                                                     mask_token=None,
                                                                     invert=True)

        return char_to_num, num_to_char, charlist_

    def ctc_decode(self, pred, max_length=256):
        input_len = np.ones(pred.shape[0]) * pred.shape[1]
        return k.ctc_decode(pred, input_length=input_len, greedy=True, beam_width=10)[0][0][:, :max_length]

    def decode_(self, label, num_to_char):
        return tf.strings.reduce_join(num_to_char(label)).numpy().decode("utf-8").replace('[UNK]', '')

    def decode_batch_predictions_to_print(self, pred, num_to_char, max_length=128, eval_=False):
        output_text = [self.decode_(res, num_to_char) for res in self.ctc_decode(pred, max_length)]
        if eval_:
            pass
        else:
            dir = 'R' if self.rtl else 'L'
            output_text = [get_display(res, base_dir=dir) for res in output_text]
        return output_text

    def print_prediction(self, pred_, type_="arabic"):
        print(f"{type_} prediction is : ", pred_)
        for ch in pred_:
            print("CH : ", ch)

    def read_image(self, image_path, gray=False):
        image = cv2.imread(image_path)
        image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if gray else image
        return image

    def _image_resize(self, image):
        image = image.numpy() * 255
        image = image.astype('uint8')
        image = image[:, :, 0]
        (h, w) = image.shape[:2]
        r = self.img_height / float(h)
        dim = (min(int(w * r), self.max_img_width), self.img_height)
        if dim[0] != self.max_img_width:  # trying to make the input width can be divided over 8 .
            rem = dim[0] % 8
            dim = (dim[0] + (8 - rem), dim[1]) if rem != 0 else dim

        image = cv2.resize(image, dim, interpolation=cv2.INTER_AREA)
        image = cv2.resize(image, (self.max_img_width, image.shape[0]), interpolation=cv2.INTER_AREA) if image.shape[
                                                                                                             1] > self.max_img_width else image

        # """
        back_ = np.zeros((self.img_height, self.max_img_width))

        back_[:image.shape[0], :image.shape[1]] = image

        image = back_

        # """

        image = image.reshape([image.shape[0], image.shape[1], 1])
        image = tf.convert_to_tensor(image / 255, dtype=tf.float32)

        return image

    def perform_ocr(self, img_list: list, batch_size=8) -> list:

        def prepare_image(image, max_img_width=self.max_img_width, img_height=self.img_height):
            (h, w) = image.shape[:2]
            r = img_height / float(h)

            dim = (min(int(w * r), max_img_width), img_height)

            image = cv2.resize(image, dim, interpolation=cv2.INTER_NEAREST)

            back_ = image
            back_ = np.zeros((img_height, max_img_width))
            back_[:image.shape[0], :image.shape[1]] = image
            back_ = (back_ / 255).astype('float32').reshape(back_.shape[0], back_.shape[1], 1)

            # display(back_)
            back_ = np.transpose(back_, [1, 0, 2])

            return back_

        dataset = (tf.data.Dataset.from_generator(lambda: map(prepare_image, img_list), output_types=tf.float32,
                                                  output_shapes=tf.TensorShape([None, self.img_height, 1]))
                   .padded_batch(batch_size)
                   .prefetch(buffer_size=tf.data.experimental.AUTOTUNE))

        pred_texts = []
        for batch in dataset.take(-1):
            preds = self.model.predict(batch)
            # print(preds)
            pred_text = self.decode_batch_predictions_to_print(preds, self.num_to_char, 256)
            pred_texts.extend(pred_text)

        return pred_texts

    def test_from_folder(self, test_folder):
        names = os.listdir(test_folder)
        names = [name for name in names if ".txt" not in name]
        for name in names:
            test_image = self.read_image(os.path.join(test_folder, name), gray=True)
            text = self.perform_ocr([test_image])
            print_prediction(text[0], "OCR_bio")

    # this part for preparing dataset for evaluation .

    def _prepare_single_sample_quality_matrix(self, img_path, label_path):  # me
        # Read image
        img = tf.io.read_file(img_path)
        # Decode and convert to grayscale
        img = tf.io.decode_png(img, channels=1)
        # Convert to float32 in [0, 1] range
        img = tf.image.convert_image_dtype(img, tf.float32)

        label = tf.io.read_file(label_path)

        # Return a dict as our model is expecting two inputs
        return {"image": img, "label": label, "label_path": label_path}

    def _apply_data_formatting_quality_matrix(self, in_dict):
        img, label, label_path = in_dict['image'], in_dict['label'], in_dict["label_path"]

        def tf_image_resize(image):
            im_shape = image.shape
            [image, ] = tf.py_function(self._image_resize, [image], [tf.float32])
            image.set_shape(im_shape)
            return image

        img = tf_image_resize(img)
        img = tf.transpose(img, perm=[1, 0, 2])  # We want width first as the sequence dim for our model

        def tf_prepare_rtl_text(label):
            shape = label.shape
            [label, ] = tf.py_function(self._prepare_bidi_training_text_source_data, [label], [tf.string])
            label.set_shape(shape)
            return label

        label = tf_prepare_rtl_text(label)
        label = self.char_to_num(tf.strings.unicode_split(label, input_encoding="UTF-8"))

        return {"image": img, "label": label, "label_path": label_path}

    def _prepare_bidi_training_text_source_data(self, label):
        '''
            Prepares bidi (arabic or bilingual) text line for use in training the OCR engine
            by reversing stretches of arabic characters as they would read from left to right.
        '''
        text = label.numpy().decode('utf-8')
        text = sanitize_arabic(text)
        try:
            text = get_display(text)
        except:
            pass
        # text = text[::-1]
        text = tf.convert_to_tensor(text, dtype=tf.string)
        return text

    def prepare_datasets(self,
                         src_paths=None,
                         quality_matrix=False):

        if src_paths is not None:
            images, labels = [], []
            data_sets = []
            for i, src_path in enumerate(src_paths):
                ds_imgs, lbs = self.sort_gt(src_path)
                images += ds_imgs
                labels += lbs
                print(f'Found {len(ds_imgs)} training samples in {src_path}.')
            data_sets.append(tf.data.Dataset.from_tensor_slices((images, labels)))
            print(f'Found a total of {len(images)} training samples.')

            src_dataset = data_sets[0]

            if quality_matrix:
                src_dataset = src_dataset.map(self._prepare_single_sample_quality_matrix,
                                              num_parallel_calls=tf.data.experimental.AUTOTUNE)

        if src_paths is not None:
            dataset = src_dataset

        if quality_matrix:
            dataset = dataset.map(self._apply_data_formatting_quality_matrix,
                                  num_parallel_calls=tf.data.experimental.AUTOTUNE) \
                .padded_batch(self.batch_size).prefetch(buffer_size=tf.data.experimental.AUTOTUNE)

        return dataset
