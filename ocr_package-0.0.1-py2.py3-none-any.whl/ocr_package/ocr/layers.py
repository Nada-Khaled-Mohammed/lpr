from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, ReduceLROnPlateau
from tensorflow.keras.optimizers import Adam , RMSprop
from tensorflow.keras.models import Model, load_model
import tensorflow.keras.backend as k
from tensorflow.keras import layers
import tensorflow as tf
import numpy as np



@tf.keras.utils.register_keras_serializable()
class CTCLayer(layers.Layer):
    def __init__(self, name=None, **kwargs):
        super(CTCLayer, self).__init__(name=name)
        self.loss_fn = k.ctc_batch_cost
        self.n = name
        super(CTCLayer, self).__init__(**kwargs)
        
        self.loss_range = np.arange(0 , 10 ,0.5)
        self.loss_w     = self.loss_range  ** 0.2
        self.loss_w     = self.loss_w / np.sum(self.loss_w)
        self.loss_w     = self.loss_w * 8

    def call(self, y_true, y_pred):
        # Compute the training-time loss value and add it
        # to the layer using `self.add_loss()`.
#         batch_len = tf.cast(tf.shape(y_true)[0], dtype="int64")
#         input_length = tf.cast(tf.shape(y_pred)[1], dtype="int64")
#         label_length = tf.cast(tf.shape(y_true)[1], dtype="int64")

#         input_length = input_length * tf.ones(shape=(batch_len, 1), dtype="int64")
#         label_length = label_length * tf.ones(shape=(batch_len, 1), dtype="int64")

#         loss = self.loss_fn(y_true, y_pred, input_length, label_length)
        if len(y_true.shape) > 2:
            y_true = tf.squeeze(y_true)

        # y_pred.shape = (batch_size, string_length, alphabet_size_1_hot_encoded)
        # output of every model is softmax
        # so sum across alphabet_size_1_hot_encoded give 1
        #               string_length give string length
        input_length = tf.math.reduce_sum(y_pred, axis=-1, keepdims=False)
        input_length = tf.math.reduce_sum(input_length, axis=-1, keepdims=True)
        

        # y_true strings are padded with 0
        # so sum of non-zero gives number of characters in this string
        label_length = tf.math.count_nonzero(y_true, axis=-1, keepdims=True, dtype="int64")
        #com_length   = label_length > tf.cast(.5 * input_length , tf.int64)
        
        
        
        #if tf.reduce_any(com_length == True ) :
            #loss = 0.0
        #else :
        loss =self.loss_fn(y_true, y_pred, input_length, label_length)
        # average loss across all entries in the batch
        
#         loss_r = loss[tf.greater_equal(loss , 7.2)]
#         loss_r = loss_r[tf.less(loss_r , 30)]
#         loss_r = tf.reduce_mean(loss_r) if len(loss_r) > 0 else 0.0 
#         Loss_ = 0.0
#         for i in range(len(self.loss_range  ) -1 ):
#             min_loss    = self.loss_range[i]
#             max_loss    = self.loss_range[i + 1 ]
#             loss_weight = self.loss_w[i+1]
            
#             Loss_ += loss_interval(loss , min_loss , max_loss  ) * loss_weight 
        
        
        
        
#         loss_r = loss[tf.greater_equal(loss , self.loss_range[-1] )]
#         loss_r = tf.reduce_mean(loss_r) if len(loss_r) > 0 else 0.0
        
#         Loss_ +=loss_r
        
#         loss = Loss_
        
        
        
        
        
        
        
        
        #loss = tf.where(loss >= 25.0  , 0.0 , loss )
        if len(loss) > 0 :
            loss = 1.0 * loss ** 1.0
            loss = tf.reduce_mean(loss)
        else :
            loss = 0.0



    
        self.add_loss(loss)

        # At test time, just return the computed predictions
        return y_pred

    def get_config(self):
        config = super(CTCLayer, self).get_config()
        config.update({"name": self.n})
        return config



@tf.keras.utils.register_keras_serializable()
class FullGatedConv2D(layers.Conv2D):
    def __init__(self, filters, **kwargs):
        super(FullGatedConv2D, self).__init__(filters = filters * 2, **kwargs)
        self.nb_filters = filters
        
    def call(self , inputs):
        output  = super(FullGatedConv2D, self).call(inputs)
        linear  = layers.Activation("linear")(output[:, :, :, :self.nb_filters])
        sigmoid = layers.Activation("sigmoid")(output[:, :, :, self.nb_filters:])
        return layers.Multiply()([linear, sigmoid])
    
    def compute_output_shape(self, input_shape):
        output_shape = super(FullGatedConv2D, self).compute_output_shape(input_shape)
        return tuple(output_shape[:3]) + (self.nb_filters * 2,)
    
    def get_config(self):
        config = super(FullGatedConv2D, self).get_config()
        config.update({"filters": self.nb_filters})
        return config
    
    
@tf.keras.utils.register_keras_serializable()
class _Attention(tf.keras.layers.Layer):
    
    def __init__(self, data_format = 'channels_last', **kwargs):
        super(_Attention, self).__init__(**kwargs)
        self.data_format = data_format
        
    def build(self, input_shapes):
        self.gamma = self.add_weight(self.name + '_gamma'      ,
                                     shape       = ()          ,
                                     initializer = tf.initializers.Zeros)
    
    def call(self, inputs):
        if len(inputs) != 4:
            raise Exception('an attention layer should have 4 inputs')

        query_tensor = inputs[0]
        key_tensor   = inputs[1]
        value_tensor = inputs[2]
        origin_input = inputs[3]
        
        input_shape = tf.shape(query_tensor)
        
        if self.data_format == 'channels_first':
            height_axis = 2
            width_axis  = 3
        else:
            height_axis = 1
            width_axis  = 2
        
        batchsize = input_shape[0]
        height    = input_shape[height_axis]
        width     = input_shape[width_axis]
        
        if self.data_format == 'channels_first':
            proj_query = tf.transpose( tf.reshape(query_tensor , (batchsize , -1 , height*width)) , (0, 2, 1) )
            proj_key   = tf.reshape(key_tensor, (batchsize, -1, height*width))
            proj_value = tf.reshape(value_tensor, (batchsize, -1, height*width))
        else:
            proj_query = tf.reshape(query_tensor, (batchsize   , height * width , -1))
            proj_key   = tf.transpose( tf.reshape(key_tensor   , (batchsize , height * width , -1)) , (0, 2, 1))
            proj_value = tf.transpose( tf.reshape(value_tensor , (batchsize , height * width , -1)) , (0, 2, 1))

        energy    = tf.matmul(proj_query, proj_key)
        attention = tf.nn.softmax(energy)
        out       = tf.matmul(proj_value , tf.transpose(attention, (0, 2, 1)))
        
        if self.data_format == 'channels_first':
            out = tf.reshape(out, (batchsize, -1, height, width))
        else:
            out = tf.reshape( tf.transpose(out, (0, 2, 1)), ( batchsize , height , width , -1))
        
    
        return tf.add( tf.multiply(out , self.gamma ) , origin_input) , attention
    
    def get_config(self):
        config = super(_Attention, self).get_config()
        #config['nb_filters'] = self.nb_filters
        config.update({"data_format": self.data_format})
        #del config['filters']
        return config
    

    
@tf.keras.utils.register_keras_serializable() 
class PatchEncoder(tf.keras.layers.Layer):
    def __init__(self, num_patches , projection_dim  , **kwargs ):
        super().__init__(**kwargs)
        self.num_patches        = num_patches
        self.projection_dim     = projection_dim 
        
        
        
        self.projection         = layers.Dense(units = self.projection_dim)
        self.position_embedding = layers.Embedding(
                                                    input_dim  = self.num_patches    ,
                                                    output_dim = self.projection_dim )

    # Override function to avoid error while saving model
    def get_config(self):
        config = super(PatchEncoder , self).get_config()
        config.update(
            {
                "num_patches"         : self.num_patches        ,
                "projection_dim"      : self.projection_dim     ,
            }
        )
        return config

    def call(self, patch):
        positions = tf.range(start = 0 , limit = tf.shape(patch)[-2] , delta = 1)
        encoded   = self.projection(patch) + self.position_embedding(positions)
        return encoded
    
    

def FULL_GATE(cnn , filters , kernel_size , strides , padding = "same"):
    cnn        = FullGatedConv2D(filters     = filters,
                                 kernel_size = kernel_size,
                                 strides     = strides ,
                                 padding     = padding )(cnn) # 2
    
    
    cnn        = layers.BatchNormalization(renorm = True)(cnn)
    cnn        = layers.ReLU()(cnn)
    
    return cnn 


def SelfAttnModel(inputs , input_dims ):
    attn       = _Attention(data_format='channels_last')
    query_conv = tf.keras.layers.Conv2D(        filters     = input_dims // 2 , 
                                                kernel_size = 1 )

    key_conv   = tf.keras.layers.Conv2D(        filters     = input_dims // 2,
                                                kernel_size = 1 )

    value_conv = tf.keras.layers.Conv2D(        filters     = input_dims,
                                                kernel_size = 1)
    
    
    
    q = query_conv(inputs)
    k = key_conv(inputs)
    v = value_conv(inputs)
    
    
    return attn([q, k, v, inputs])




def CONV2D(cnn , filters , kernel_size , strides , padding = "same" , use_activation = True):
    cnn        = layers.Conv2D(filters            = filters,
                               kernel_size        = kernel_size,
                               strides            = strides,
                               padding            = padding,
                               kernel_initializer = "he_uniform")(cnn)
    
    cnn        = layers.BatchNormalization()(cnn)
    if use_activation :
        cnn        = layers.ReLU()(cnn)
    
    return cnn


def CONV1D(x , num_filters , filter_size , padding ,dilation_rate  , use_act = True):
    x = layers.Conv1D( num_filters ,
                      filter_size ,
                      kernel_initializer = "he_normal" ,
                      padding            = padding     ,
                      dilation_rate      = dilation_rate  )(x)
    
    x = layers.BatchNormalization()(x)
    
    if use_act :
        x = layers.Activation('relu')(x)
    
    return x


def TIME_BLOCK(cnn , units  , voc , name ):
    #cnn      = trasformer_Block(cnn = cnn , units =  units              , num_heads = 8   , num_of_layers = 1 )
    cnn        = CONV1D(cnn , units  , 1  , "same" , 1 )
    cnn        = res_block_1d(cnn    , 1 ,  units , [1 , 1 ])
    
    shape      = cnn.get_shape()
    cnn        = layers.Reshape((-1 , shape[2] * shape[3]))(cnn) if len(shape) == 4 else cnn # (batch_size , 1 , depth_of_feature_vector)
    
    cnn        = PatchEncoder((args.max_img_width // args.model_stride) + 1 , units )(cnn)
    
    
    
    
    cnn      = trasformer_Block(cnn = cnn , units =  units          , num_heads = 4  , num_of_layers = 2 )
    #cnn      = trasformer_Block(cnn = cnn , units =  units          , num_heads = 4  , num_of_layers = 1 )
    #cnn      = trasformer_Block(cnn = cnn , units =  units          , num_heads = 2  , num_of_layers = 1 )
    #cnn      = trasformer_Block(cnn = cnn , units =  units        , num_heads = 8  , num_of_layers = 4 )
    #cnn      = trasformer_Block(cnn = cnn , units =  192          , num_heads = 4  , num_of_layers = 2 )
    cnn      = layers.Dense(units = units // 2    )(cnn)
    cnn      = layers.Activation('relu')(cnn)
    out        = layers.Dense(units=voc, activation="softmax" , name = name )(cnn)
    
    return out




def SELF_ATTENTION(cnn , units , num_heads ,  training = True ):
    enc           = layers.LayerNormalization()(cnn)
    enc           = layers.Dense(units, activation="relu")(enc)
    enc_att       = layers.MultiHeadAttention( num_heads = num_heads , key_dim = units , dropout = 0.12 )(
                                                                                                          query          = enc,
                                                                                                          value          = enc,
                                                                                                          key            = enc,
                                                                                                          attention_mask = None,
                                                                                                          training       = training, )
    
    enc            = layers.LayerNormalization()(enc + enc_att)
    
    return enc


def trasformer_Block(cnn , units , num_heads  , training = True , num_of_layers = 3 ):
    
    shape      = cnn.get_shape()
    cnn        = layers.Reshape((-1, shape[2] * shape[3]))(cnn) if len(shape) == 4 else cnn
    for _ in range(num_of_layers):
        cnn        = SELF_ATTENTION(cnn   , units , num_heads , training )
        cnn        = res_block_1d(cnn , 3 ,  units , [1 , 1 ])
        cnn        = res_block_1d(cnn , 2 ,  units , [1 , 1 ])
        cnn        = res_block_1d(cnn , 1 ,  units , [1 , 1 ])
    
    return cnn






def res_block_2d(cnn, filter_size = (3,3), num_filters=128 , use_full_gate = False  , depth = 1):
    res1 = cnn  # skip connection

    
    if use_full_gate :
        
        if depth == 1 :
            cnn_1        = FULL_GATE(cnn     , num_filters   , filter_size     , (1, 1) , "same")
            
            cnn = cnn_1
        elif depth == 2 :
            cnn_1        = FULL_GATE(cnn     , num_filters   , filter_size     , (1, 1) , "same")
            
            cnn_2        = FULL_GATE(cnn        , num_filters   , filter_size     , (1, 1) , "same")
            cnn_2        = FULL_GATE(cnn_2      , num_filters   , filter_size     , (1, 1) , "same")
            
            cnn = cnn_1 + cnn_2
        
        else :
            cnn_1        = FULL_GATE(cnn     , num_filters   , filter_size     , (1, 1) , "same")

            cnn_2        = FULL_GATE(cnn        , num_filters   , filter_size     , (1, 1) , "same")
            cnn_2        = FULL_GATE(cnn_2      , num_filters   , filter_size     , (1, 1) , "same")

            cnn_3        = FULL_GATE(cnn     , num_filters   , filter_size     , (1, 1) , "same")
            cnn_3        = FULL_GATE(cnn_3   , num_filters   , filter_size     , (1, 1) , "same")
            cnn_3        = FULL_GATE(cnn_3   , num_filters   , filter_size     , (1, 1) , "same")

            cnn          = cnn_1 + cnn_2 + cnn_3 
        

        if cnn.get_shape()[-1] != res1.get_shape()[-1] :
            res1       = FULL_GATE(res1 , num_filters , (1,1)       , (1, 1) , "same")
    else :
        if depth == 1 :
            cnn_1        = CONV2D(cnn     , num_filters   , filter_size     , (1, 1) , "same")
            
            cnn = cnn_1
        elif depth == 2 :
            cnn_1        = CONV2D(cnn     , num_filters   , filter_size     , (1, 1) , "same")
            
            cnn_2        = CONV2D(cnn        , num_filters   , filter_size     , (1, 1) , "same")
            cnn_2        = CONV2D(cnn_2      , num_filters   , filter_size     , (1, 1) , "same")
            
            cnn = cnn_1 + cnn_2
        
        else :
            cnn_1        = CONV2D(cnn     , num_filters   , filter_size     , (1, 1) , "same")

            cnn_2        = CONV2D(cnn        , num_filters   , filter_size     , (1, 1) , "same")
            cnn_2        = CONV2D(cnn_2      , num_filters   , filter_size     , (1, 1) , "same")

            cnn_3        = CONV2D(cnn     , num_filters   , filter_size     , (1, 1) , "same")
            cnn_3        = CONV2D(cnn_3   , num_filters   , filter_size     , (1, 1) , "same")
            cnn_3        = CONV2D(cnn_3   , num_filters   , filter_size     , (1, 1) , "same")

            cnn          = cnn_1 + cnn_2 + cnn_3 
        
        if cnn.get_shape()[-1] != res1.get_shape()[-1] :
            res1       = CONV2D(res1 , num_filters    , (1,1)       , (1, 1) , "same")
    
    
    x = layers.Add()([cnn, res1])  # add residual
    x = layers.Activation('relu')(x)

    return x


def res_block_1d(x, filter_size = 3, num_filters = 64, dilation=[1, 1]):
    res1 = x  # skip connection
    
    x    = CONV1D(x , num_filters , filter_size  , "same" , dilation[0] )
    x    = CONV1D(x , num_filters , filter_size  , "same" , dilation[1] , use_act = False )

    x    = layers.Add()([x, res1])  # add residual
    x    = layers.Activation('relu')(x)

    return x




def AVERAGEPOOL(cnn , pool_size  , strides = None  , padding = "same"):
    cnn = layers.AveragePooling2D( pool_size = pool_size , strides = strides , padding = padding )(cnn)
    cnn = FULL_GATE(cnn      ,  cnn.get_shape()[-1]  , (1,1)        , (1, 1) , "same")
    return cnn





def MERGE_BLOCK(cnns , num_of_filters   , use_self_attention = False ):
    """
    cnns : list of cnn heat map comes from differst parts of the network .
    
    """
    
    merged_list = []
    
    for i in range(len(cnns)):
        merged_list.append(CONV2D(cnns[i]      , num_of_filters , (1,1)        , (1, 1) , "same"  , use_activation = False )) 
        
    
    
    cnn = layers.Add()(merged_list)  
    cnn = layers.Activation('relu')(cnn)
        
    #cnn        = tf.concat(cnns , axis = -1) # i see we could use self attention here 
    cnn        = res_block_2d(cnn , (1,1)  , num_of_filters , use_full_gate = False , depth = 1)
    
    if use_self_attention :
        cnn    , _ = SelfAttnModel(cnn , num_of_filters)
    
    return cnn 
    
    
    
