import tensorflow.keras.backend as k
import tensorflow as tf

from bidi.algorithm import get_display
import matplotlib.pyplot as plt
import numpy as np
import time
import cv2
import os


def ctc_decode(pred , max_length = 128 ):
    input_len   = np.ones(pred.shape[0]) * pred.shape[1]
    return   k.ctc_decode(pred, input_length = input_len, greedy = True , beam_width=10)[0][0][:, :max_length]

def decode_(label , num_to_char):
    return tf.strings.reduce_join(num_to_char( label )).numpy().decode("utf-8").replace('[UNK]', '')

# def decode_batch_predictions_to_print(pred ,  num_to_char ,  max_length  = 128):
#     output_text = [decode_(res , num_to_char ) for res in ctc_decode(pred , max_length ) ]
#     return output_text


def decode_batch_predictions_to_print( pred ,  num_to_char ,  max_length  = 128 , rtl = False  , eval_ = False ):
    output_text = [decode_(res , num_to_char ) for res in ctc_decode(pred , max_length ) ]
    if eval_:
        pass
    else :
        dir         = 'R' if rtl else 'L'
        output_text = [get_display(res, base_dir=dir) for res in output_text ]
    return output_text

def print_prediction(pred_ , type_ = "arabic"):
    print(f"{type_} prediction is : " , pred_ )
    for ch in pred_ :
        print("CH : " , ch )
        

def display(image):
    plt.figure(figsize=(10,10))
    plt.imshow(image , "gray")
    plt.show()
def read_image(image_path , gray = False):
    image   = cv2.imread(image_path)
    image   = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY) if gray else image
    return image

def make_folder(path):
    if not os.path.exists( path ) :
        os.makedirs(path)