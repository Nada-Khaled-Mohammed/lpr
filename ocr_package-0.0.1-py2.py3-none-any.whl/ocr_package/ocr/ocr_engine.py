#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
import matplotlib.pyplot as plt
import os
import cv2
import tensorflow as tf
from tensorflow.keras.models import Model, load_model
import tensorflow.keras.backend as k
from tensorflow.keras import layers
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, ReduceLROnPlateau
from tensorflow.keras.optimizers import Adam
from pathlib import Path
from ocr_package.image_utils.add_noise import add_noise
from ocr_package.ocr.ocr_utils import sanitize_arabic
#import jiwer
import Levenshtein
from skimage.util import random_noise
from bidi.algorithm import get_display
SEED = 1
#from augmentation_functions_me import augmentation
#from tensorflow.keras.constraints import MaxNorm



# In[2]:


def sort_gt(src_path):
    text_names  = [name for name in os.listdir(src_path ) if name.endswith(".gt.txt")]
    image_names = [name for name in os.listdir(src_path ) if name.endswith(".png")]
    
    text_names  = [name for name in text_names if (name[:-6] +"png") in  image_names ]
    image_names = [name for name in image_names if (name[:-3] +"gt.txt") in  text_names ]
    
    text_names   = list(sorted(text_names) )
    text_names   = [os.path.join(src_path , name) for name in text_names ]
    
    image_names   = list(sorted(image_names) )
    image_names   = [os.path.join(src_path , name) for name in image_names ]
    
    
    return image_names , text_names



def res_block_2d(cnn, filter_size=(3,3), num_filters=128):
    res1 = cnn  # skip connection

    cnn        = layers.Conv2D(filters=num_filters, kernel_size=filter_size, strides=(1, 1), padding="same", kernel_initializer="he_uniform")(cnn)
    cnn        = layers.BatchNormalization()(cnn)
    cnn        = layers.ReLU()(cnn)


    cnn        = layers.Conv2D(filters=num_filters, kernel_size=filter_size, strides=(1, 1), padding="same", kernel_initializer="he_uniform")(cnn)
    cnn        = layers.BatchNormalization(renorm=True)(cnn)
    cnn        = layers.ReLU()(cnn)


    x = layers.Add()([cnn, res1])  # add residual
    x = layers.Activation('relu')(x)

    return x


def res_block_1d(x, filter_size=3, num_filters=64, dilation=[1, 1]):
    res1 = x  # skip connection

    x = layers.Conv1D(
        num_filters,
        filter_size,
        kernel_initializer="he_normal",
        padding="same",
        dilation_rate=dilation[0]
    )(x)
    
    x = layers.BatchNormalization()(x)
    x = layers.Activation('relu')(x)

    x = layers.Conv1D(
        num_filters,
        filter_size,
        kernel_initializer="he_normal",
        padding="same",
        dilation_rate=dilation[1]
    )(x)
    x = layers.BatchNormalization()(x)
    x = layers.Add()([x, res1])  # add residual
    x = layers.Activation('relu')(x)

    return x


def _create_model(vocab , shape_input = (1000 , 64 , 1)):
    
    
    input_img = layers.Input(shape=shape_input, name="image", dtype="float32")
    labels    = layers.Input(name="label", shape=(None,), dtype="float32")
    
    cnn        = layers.Conv2D(filters=128, kernel_size=(3, 3), strides=(1, 1), padding="same", kernel_initializer="he_uniform")(input_img)
    cnn        = layers.BatchNormalization(renorm=True)(cnn)
    cnn        = layers.ReLU()(cnn)
    
    
    cnn        = res_block_2d(cnn , (3,3)  , 128 )
    

    cnn        = FullGatedConv2D(filters=128, kernel_size=(3,3), strides=(1, 2) ,  padding= "same" )(cnn)  # 16
    cnn        = layers.BatchNormalization(renorm=True)(cnn)
    cnn        = layers.ReLU()(cnn)
    
    
    
    cnn        = res_block_2d(cnn , (2,2)  , 128)
    
    
    cnn        = FullGatedConv2D(filters=128, kernel_size=(3,3), strides=(1, 2) ,  padding="same")(cnn) # 8
    cnn        = layers.BatchNormalization(renorm=True)(cnn)
    cnn        = layers.ReLU()(cnn)


    cnn        = res_block_2d(cnn , (2,2)  , 128 )

    
    cnn        = FullGatedConv2D(filters=128, kernel_size=(3,3),  strides=(1, 2) , padding= "same" )(cnn) # 4
    cnn        = layers.BatchNormalization(renorm=True)(cnn)
    cnn        = layers.ReLU()(cnn)
    
    cnn        = res_block_2d(cnn , (1,1)  , 128  )
    #cnn        = tf.keras.layers.Dropout(.25)(cnn)
    
    
    cnn        = FullGatedConv2D(filters=256, kernel_size=(2,2),  strides=(1, 2) ,padding= "same" )(cnn) # 2
    cnn        = layers.BatchNormalization(renorm=True)(cnn)
    cnn        = layers.ReLU()(cnn)
    
    
    cnn        = res_block_2d(cnn , (1,1)  , 256  )
    


    shape      = cnn.get_shape()
    bgru       = layers.Reshape((-1, shape[2] * shape[3]))(cnn)
    bgru       = layers.Conv1D(512 , 3 , kernel_initializer = "he_normal" , padding = "same")(bgru)
    
    bgru       = res_block_1d(bgru , 3 ,  512 , [1 , 2 ])


    
    bgru       = layers.Bidirectional(layers.LSTM(units=128, return_sequences=True  ))(bgru)
    bgru       = layers.Dense(units=256 )(bgru)
    

    bgru        = layers.Bidirectional(layers.LSTM(units=128, return_sequences=True   ))(bgru)
    output_data = layers.Dense(units=vocab, activation="softmax" , name = "dense2")(bgru)
    
    output = CTCLayer(name="ctc_loss")(labels, output_data)
    model = Model(inputs=[input_img, labels], outputs=output, name="ocr_model")
    
    return model



@tf.keras.utils.register_keras_serializable()
class FullGatedConv2D(layers.Conv2D):
    def __init__(self, filters, **kwargs):
        super(FullGatedConv2D, self).__init__(filters = filters * 2, **kwargs)
        self.nb_filters = filters
        
    def call(self , inputs):
        output = super(FullGatedConv2D, self).call(inputs)
        linear = layers.Activation("linear")(output[:, :, :, :self.nb_filters])
        sigmoid = layers.Activation("sigmoid")(output[:, :, :, self.nb_filters:])
        return layers.Multiply()([linear, sigmoid])
    
    def compute_output_shape(self, input_shape):
        output_shape = super(FullGatedConv2D, self).compute_output_shape(input_shape)
        return tuple(output_shape[:3]) + (self.nb_filters * 2,)
    
    def get_config(self):
        config = super(FullGatedConv2D, self).get_config()
        #config['nb_filters'] = self.nb_filters
        config.update({"filters": self.nb_filters})
        #del config['filters']
        return config
    
def calc_ctc(y_true, y_pred):
    if len(y_true.shape) > 2:
        y_true = tf.squeeze(y_true)

    # y_pred.shape = (batch_size, string_length, alphabet_size_1_hot_encoded)
    # output of every model is softmax
    # so sum across alphabet_size_1_hot_encoded give 1
    #               string_length give string length
    input_length = tf.math.reduce_sum(y_pred, axis=-1, keepdims=False)
    input_length = tf.math.reduce_sum(input_length, axis=-1, keepdims=True)

    # y_true strings are padded with 0
    # so sum of non-zero gives number of characters in this string
    label_length = tf.math.count_nonzero(y_true, axis=-1, keepdims=True, dtype="int64")
    if tf.reduce_any(label_length == 0 ) :
        loss = 0
    else :
        loss =k.ctc_batch_cost(y_true, y_pred, input_length, label_length)

    # average loss across all entries in the batch
    #loss = tf.reduce_mean(loss)
    return loss


@tf.keras.utils.register_keras_serializable()
class CTCLayer(layers.Layer):
    def __init__(self, name=None, **kwargs):
        super(CTCLayer, self).__init__(name=name)
        self.loss_fn = k.ctc_batch_cost
        self.n = name
        super(CTCLayer, self).__init__(**kwargs)

    def call(self, y_true, y_pred):
        # Compute the training-time loss value and add it
        # to the layer using `self.add_loss()`.
#         batch_len = tf.cast(tf.shape(y_true)[0], dtype="int64")
#         input_length = tf.cast(tf.shape(y_pred)[1], dtype="int64")
#         label_length = tf.cast(tf.shape(y_true)[1], dtype="int64")

#         input_length = input_length * tf.ones(shape=(batch_len, 1), dtype="int64")
#         label_length = label_length * tf.ones(shape=(batch_len, 1), dtype="int64")

#         loss = self.loss_fn(y_true, y_pred, input_length, label_length)
        if len(y_true.shape) > 2:
            y_true = tf.squeeze(y_true)

        # y_pred.shape = (batch_size, string_length, alphabet_size_1_hot_encoded)
        # output of every model is softmax
        # so sum across alphabet_size_1_hot_encoded give 1
        #               string_length give string length
        input_length = tf.math.reduce_sum(y_pred, axis=-1, keepdims=False)
        input_length = tf.math.reduce_sum(input_length, axis=-1, keepdims=True)

        # y_true strings are padded with 0
        # so sum of non-zero gives number of characters in this string
        label_length = tf.math.count_nonzero(y_true, axis=-1, keepdims=True, dtype="int64")

        loss =self.loss_fn(y_true, y_pred, input_length, label_length)

        # average loss across all entries in the batch
        loss = tf.reduce_mean(loss)

       






        self.add_loss(loss)

        # At test time, just return the computed predictions
        return y_pred

    def get_config(self):
        config = super(CTCLayer, self).get_config()
        config.update({"name": self.n})
        return config

    
    


class OCR_engine:
    def __init__(self, model_path=None, line_height=64, charlist_path='../../models/charlist_v3.txt', rtl=True):
        self.img_height = line_height
        self.max_img_width = 1200
        self.batch_size = 1
        self.max_length = 128
        self.rtl = rtl
        self.use_augmentation = False
        self.prediction_model = None
        self.gated_filters = 64
        with open(charlist_path, 'r', encoding='utf-8') as f:
            self.charlist = sorted(set(f.read().splitlines()))

        # Mapping characters to integers
        self.char_to_num = layers.experimental.preprocessing.StringLookup(
            vocabulary=list(self.charlist), mask_token=None
        )

        # Mapping integers back to original characters
        self.num_to_char = layers.experimental.preprocessing.StringLookup(
            vocabulary=self.char_to_num.get_vocabulary(), mask_token=None, invert=True
        )
        if model_path is not None:
            
            
            
            
            self.model = load_model(model_path , custom_objects= {'FullGatedConv2D' :  FullGatedConv2D})
            # full_gated_7 = self.model.get_layer(name = "full_gated_conv2d_1")
        else:
            #self.model = self._create_model()
            self.model = _create_model(len(self.char_to_num.get_vocabulary()) + 1 , (1000 , self.img_height , 1))
        try:    # New models use layer name "output"
            self.prediction_model = Model(self.model.get_layer(name="image").input,
                                            self.model.get_layer(name="output").output)
        except ValueError as e: # backwards compat for older models that use layer name "dense2"
            self.prediction_model = Model(self.model.get_layer(name="image").input,
                                          self.model.get_layer(name="dense2").output)
        # self.model.summary()

    def create_char_list(self, path):
        # Path to the data directory
        data_dir = Path(path)

        # Get list of all the gt text files
        gt_files = sorted(list(map(str, list(data_dir.rglob("*.gt.txt")))))
        charset = set()
        max_len = 0
        for gt_file in gt_files:
            with open(gt_file, 'r', encoding='utf-8') as f:
                text = f.read()
            if max_len < len(text):
                max_len = len(text)
                max_file = gt_file
            charset = charset.union(set(text))

        print("Number of unique characters: ", len(charset))
        print("Maximum sequence length: ", max_len)
        print("Characters present: ", charset)
        print("Largest line: ", max_file)
        charset = sorted(charset)
        with open('../../models/charlist.txt', 'w', encoding='utf-8') as f:
            f.writelines([char + '\n' for char in list(charset)])

    

    def prepare_datasets(self, src_paths=None, generators=None, gen_weights=None, use_augmentation=True , quality_matrix = False):
        if generators is not None and gen_weights is not None:
            assert len(generators) == len(gen_weights), f"{len(gen_weights)} =  must be equal to {len(generators)} "
        if src_paths is not None:
            images = []
            labels = []
            data_sets = []
            for i , src_path in enumerate(src_paths):
                #ds_imgs = sorted(list(map(str, list(Path(src_path).rglob("*.png")))))[:]
                #images += ds_imgs
                ds_imgs , lbs = sort_gt(src_path)
                #images.append(ds_imgs[:70000])
                images += ds_imgs
                labels += lbs
                print(f'Found {len(ds_imgs)} training samples in {src_path}.')
                #labels = sorted(list(map(str, list(Path(src_path).rglob("*.gt.txt")))))[:]
                #labels.append(lbs[:70000])
                #labels += lbs[:70000] if i == 1 else lbs[:70000]
            data_sets.append(tf.data.Dataset.from_tensor_slices((images , labels )))
            print(f'Found a total of {len(images)} training samples.')

            #src_dataset = tf.data.Dataset.from_tensor_slices((images, labels))
            if len(data_sets) > 1 :
                src_dataset = tf.data.experimental.sample_from_datasets(data_sets , weights=[.35 , .25 , .25 , .075 , 0.075])
            else :
                src_dataset = data_sets[0]
            
            
            if quality_matrix :
                src_dataset = src_dataset.map(self._prepare_single_sample_quality_matrix, num_parallel_calls=tf.data.experimental.AUTOTUNE)
            else :
                src_dataset = src_dataset.shuffle(45000 , reshuffle_each_iteration=True) \
                    .map(self._prepare_single_sample_train, num_parallel_calls=tf.data.experimental.AUTOTUNE)
                
                
                if use_augmentation:
                    src_dataset = src_dataset.map(self._apply_augmentation, num_parallel_calls=tf.data.experimental.AUTOTUNE)
                
                
                src_dataset = src_dataset.map(self._apply_data_formatting_source_data , num_parallel_calls=tf.data.experimental.AUTOTUNE).repeat()
                
            
                
            #src_dataset = src_dataset.map(self.tf_prepare_rtl_text_source_path, num_parallel_calls=tf.data.experimental.AUTOTUNE) \
                        #.repeat()

        if generators is not None:
            gen_datasets = []
            for gen in generators:
                gen_datasets.append(tf.data.Dataset.from_generator(
                    gen.generate_samples, output_types=(tf.float32, tf.string),
                    output_shapes=(
                        tf.TensorShape([None, None, 1]), tf.TensorShape([])))
                )
            gen_dataset = tf.data.experimental.sample_from_datasets(gen_datasets, weights=gen_weights)
            gen_dataset = gen_dataset.map(
                self._prepare_single_sample_gen, num_parallel_calls=tf.data.experimental.AUTOTUNE)
            
            
#             if use_augmentation:
#                 gen_dataset = gen_dataset.map(self._apply_augmentation, num_parallel_calls=tf.data.experimental.AUTOTUNE)
            
            gen_dataset = gen_dataset.map(self._apply_data_formatting , num_parallel_calls=tf.data.experimental.AUTOTUNE)
            
        if src_paths is not None and generators is not None:
            dataset = tf.data.experimental.sample_from_datasets([src_dataset, gen_dataset], weights=[0.6 , 0.4])
        elif src_paths is not None:
            dataset = src_dataset
        elif generators is not None:
            dataset = gen_dataset

#         if use_augmentation:
#             dataset = dataset.map(self._apply_augmentation, num_parallel_calls=tf.data.experimental.AUTOTUNE)
            
        if quality_matrix :
            dataset = dataset.map(self._apply_data_formatting_quality_matrix, num_parallel_calls=tf.data.experimental.AUTOTUNE) \
                        .padded_batch(self.batch_size).prefetch(buffer_size=tf.data.experimental.AUTOTUNE)
        else :
#             dataset = dataset.map(self._apply_data_formatting, num_parallel_calls=tf.data.experimental.AUTOTUNE) \
#                 .padded_batch(self.batch_size).prefetch(buffer_size=tf.data.experimental.AUTOTUNE)
            dataset = dataset.padded_batch(self.batch_size).prefetch(buffer_size=tf.data.experimental.AUTOTUNE)

        return dataset

    def process_image(self, img):
        if isinstance(img, str):
            img = cv2.imread(img)
        img = img.reshape((img.shape[0], img.shape[1], 1))
        original_height, original_width = img.shape[0:2]
        # find vertical scaling factor
        v_factor = self.img_height / original_height
        img = cv2.resize(img, (0, 0), fx=v_factor, fy=v_factor, interpolation=cv2.INTER_AREA)
        img = img[:, :, np.newaxis]
        resized_height, resized_width = img.shape[0:2]
        processed = np.ones((self.img_height, self.max_img_width, 1))
        processed[0:resized_height, -resized_width:, :] = img
        return processed

    def train(self, train_paths=None, val_paths=None, generators=None, gen_weights=None, lr=0.001, use_augmentation=True):
        train_dataset = self.prepare_datasets(src_paths=train_paths, generators=generators,
                                              gen_weights=gen_weights, use_augmentation=use_augmentation)
        if val_paths is not None:
            validation_dataset = self.prepare_datasets(src_paths=val_paths, use_augmentation=False)

        es_callback = EarlyStopping(monitor='val_loss' if val_paths is not None else 'loss', patience=30, verbose=1)
        cp_callback = ModelCheckpoint(monitor="val_loss" if val_paths is not None else "loss",
                                      filepath='models/oct_agamy_v2.h5', verbose=1, save_best_only=True)
        lr_callback = ReduceLROnPlateau(monitor='loss', factor=0.5, patience=3, min_lr=1e-11, verbose=1)
        callbacks = [cp_callback, lr_callback, es_callback]
        #callbacks = [lr_callback, es_callback]

        self.model.compile(Adam(lr))
        self.model.summary()
       # try:
        if val_paths is not None:
#             for i in range(2):
#                 try :
            history = self.model.fit(train_dataset, validation_data=validation_dataset, epochs=100,
                                             steps_per_epoch=200  , validation_steps= 32 , verbose=1, callbacks=callbacks)
#                 except :
#                     print(f"training _function error num  {i}")
#                     pass
            
#             history = self.model.fit(train_dataset, validation_data=validation_dataset, epochs=100,
#                                        verbose=1, callbacks=callbacks)
        else:
            for i in range(100):
                try :
                    history = self.model.fit(train_dataset, epochs=1000,
                         steps_per_epoch=350, verbose=1, callbacks=callbacks)
                except :
                    print("some error ocures .... ")
        epoch_loss = history.history['loss']

        plt.figure(figsize=(20, 6))
        plt.subplot(1, 2, 1)
        plt.plot(range(0, len(epoch_loss)), epoch_loss, 'b-', linewidth=2, label='Train Loss')
        if val_paths is not None:
            epoch_val_loss = history.history['val_loss']
            plt.plot(range(0, len(epoch_val_loss)), epoch_val_loss, 'r-', linewidth=2, label='Val Loss')
        plt.title('Evolution of loss on train & validation datasets over epochs')
        plt.legend(loc='best')

        plt.show()
       # finally:
           # self.model.save(r'models/ocr_last.h5')

    def _prepare_single_sample_train(self, img_path, label_path):
        # Read image
        img = tf.io.read_file(img_path)
        # Decode and convert to grayscale
        img = tf.io.decode_png(img, channels=1)
        # Convert to float32 in [0, 1] range
        img = tf.image.convert_image_dtype(img, tf.float32)

        label = tf.io.read_file(label_path)

        # Return a dict as our model is expecting two inputs
        return {"image": img, "label": label}
    
    
    def _prepare_single_sample_quality_matrix(self, img_path, label_path): # me
        # Read image
        img = tf.io.read_file(img_path)
        # Decode and convert to grayscale
        img = tf.io.decode_png(img, channels=1)
        # Convert to float32 in [0, 1] range
        img = tf.image.convert_image_dtype(img, tf.float32)

        label = tf.io.read_file(label_path)

        # Return a dict as our model is expecting two inputs
        return {"image": img, "label": label , "label_path" : label_path}
    
    

    def _prepare_single_sample_gen(self, img, label):
        # Convert to float32 in [0, 1] range
        img = tf.image.convert_image_dtype(img / 255, tf.float32)
        # Return a dict as our model is expecting two inputs
        return {"image": img, "label": label}

    def _apply_augmentation(self, in_dict):
        img = in_dict['image']
        label = in_dict['label']

        def tf_augment_image(image):
            im_shape = image.shape
            
            #if tf.random.normal(shape=(1,))[0] >10 :
                
            #[image, ] = tf.py_function(self._augment_image, [image], [tf.float32])
            [image, ] = tf.py_function(source_data_aug, [image], [tf.float32])
            #else :
                
                #[image, ] = tf.py_function(augmentation, [image ,.75 , 0.05 , 0.025 , 0.05 , 5 , 3  , h_pattern_path , v_pattern_path], [tf.float32])
            
            #print(image.shape  , "test >>>>>>>>>>>>>>>>>>>")
            image.set_shape(im_shape)
#             plt.figure(figsize= (20,20))
#             plt.imshow(image.numpy())
#             plt.show()
            
            return image
        
        #try :
        img = tf_augment_image(img) 
#         if tf.random.normal(shape=(1,))[0] > 10 :
        #brightness_factor = tf.random.uniform(shape=[], minval=-0.3, maxval=0.3)
        #img = tf.image.adjust_brightness(img, brightness_factor)
        #img = tf.image.random_contrast(img, lower=0.5, upper=1.5, seed=SEED)
        img = tf.clip_by_value(img, 0, 1)
        #except :
            #img = in_dict['image']
            
        return {"image": img, "label": label}
    
    
    def tf_prepare_rtl_text_source_path(self , in_dict): # me
        img   = in_dict['image']
        label = in_dict['label']
        shape = label.shape
        [label, ] = tf.py_function(self._prepare_bidi_training_text, [label], [tf.string])
        label.set_shape(shape)
        return {"image": img, "label": label}
    
    def tf_prepare_rtl_text_testing(label): #me
            shape = label.shape
            [label, ] = tf.py_function(self._prepare_bidi_training_text, [label], [tf.string])
            label.set_shape(shape)
            return label
        
    def _apply_data_formatting_quality_matrix(self, in_dict):
        img        = in_dict['image']
        label      = in_dict['label']
        label_path = in_dict["label_path"]
            

        def tf_image_resize(image):
            im_shape = image.shape
            [image, ] = tf.py_function(self._image_resize, [image], [tf.float32])
            image.set_shape(im_shape)
            return image

        img = tf_image_resize(img)
        img = tf.transpose(img, perm=[1, 0, 2])  # We want width first as the sequence dim for our model

        def tf_prepare_rtl_text(label):
            shape = label.shape
            [label, ] = tf.py_function(self._prepare_bidi_training_text_source_data, [label], [tf.string])
            label.set_shape(shape)
            return label

        label = tf_prepare_rtl_text(label)
        #print(label)
        label = self.char_to_num(tf.strings.unicode_split(label, input_encoding="UTF-8"))

        return {"image": img, "label": label , "label_path" : label_path}

    def _apply_data_formatting(self, in_dict):
        img = in_dict['image']
        label = in_dict['label']

        def tf_image_resize(image):
            im_shape = image.shape
            [image, ] = tf.py_function(self._image_resize, [image], [tf.float32])
            image.set_shape(im_shape)
            return image

        img = tf_image_resize(img)
        img = tf.transpose(img, perm=[1, 0, 2])  # We want width first as the sequence dim for our model

        def tf_prepare_rtl_text(label):
            shape = label.shape
            [label, ] = tf.py_function(self._prepare_bidi_training_text, [label], [tf.string])
            label.set_shape(shape)
            return label

        label = tf_prepare_rtl_text(label)
        #print(label)
        label = self.char_to_num(tf.strings.unicode_split(label, input_encoding="UTF-8"))

        return {"image": img, "label": label}
    
    
    def _apply_data_formatting_source_data(self, in_dict):
        img = in_dict['image']
        label = in_dict['label']

        def tf_image_resize(image):
            im_shape = image.shape
            [image, ] = tf.py_function(self._image_resize, [image], [tf.float32])
            image.set_shape(im_shape)
            return image

        img = tf_image_resize(img)
        img = tf.transpose(img, perm=[1, 0, 2])  # We want width first as the sequence dim for our model

        def tf_prepare_rtl_text(label):
            shape = label.shape
            [label, ] = tf.py_function(self._prepare_bidi_training_text_source_data, [label], [tf.string])
            label.set_shape(shape)
            return label

        label = tf_prepare_rtl_text(label)
        #print(label)
        label = self.char_to_num(tf.strings.unicode_split(label, input_encoding="UTF-8"))

        return {"image": img, "label": label}

    def decode_batch_predictions(self, pred):
        input_len = np.ones(pred.shape[0]) * pred.shape[1]
        # Use greedy search. For complex tasks, you can use beam search
        results = k.ctc_decode(pred, input_length=input_len, greedy=True, beam_width=10)[0][0][:, :self.max_length]
        # Iterate over the results and get back the text
        output_text = []
        for res in results:
            res = tf.strings.reduce_join(self.num_to_char(res)).numpy().decode("utf-8")
            res = res.replace('[UNK]', '')
            dir = 'R' if self.rtl else 'L'
            res = get_display(res, base_dir=dir)
            output_text.append(res)
        return output_text
    
    def decode_batch_predictions_to_print(self, pred):
        input_len = np.ones(pred.shape[0]) * pred.shape[1]
        # Use greedy search. For complex tasks, you can use beam search
        results = k.ctc_decode(pred, input_length=input_len, greedy=True, beam_width=10)[0][0][:, :self.max_length]
        # Iterate over the results and get back the text
        output_text = []
        for res in results:
            res = tf.strings.reduce_join(self.num_to_char(res)).numpy().decode("utf-8")
            res = res.replace('[UNK]', '')
#             dir = 'R' if self.rtl else 'L'
#             res = get_display(res, base_dir=dir)
            output_text.append(res)
        return output_text

    def _image_resize(self, image):
        image = image.numpy() * 255
        image = image.astype('uint8')
        image = image[:, :, 0]
        # initialize the dimensions of the image to be resized and
        # grab the image size
        (h, w) = image.shape[:2]
        r = self.img_height / float(h)
        #if image.shape[0] > self.img_height :
        dim = (min(int(w * r), self.max_img_width), self.img_height)

        # resize the image
        image = cv2.resize(image, dim, interpolation=cv2.INTER_AREA)
        
        if image.shape[1] > self.max_img_width :
            image = cv2.resize(image, (self.max_img_width , image.shape[0]), interpolation=cv2.INTER_AREA)
            
        
        back_ = np.zeros((self.img_height , self.max_img_width))
        

        back_[:image.shape[0] , :image.shape[1]] = image
        
        image = back_

        # return the resized image
        #image = image.reshape([dim[1], dim[0], 1])
        image = image.reshape([image.shape[0], image.shape[1], 1])
        image = tf.convert_to_tensor(image / 255, dtype=tf.float32)
        return image

#     def _augment_image(self, image):
#         def add_v_pattern(pattern_path , image ):
#             bg_value = np.argmax(np.bincount(image.reshape(-1,).astype(np.int64)))
#             pattern         = cv2.imread(os.path.join( pattern_path , np.random.choice(os.listdir(pattern_path) , size = 1)[0]), cv2.IMREAD_GRAYSCALE)
#             pattern = cv2.threshold(pattern, 0, bg_value, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]

#             v_rattio        = np.random.uniform(.1 ,.15 )
#             extra_part_size = int(image.shape[1] * v_rattio)
#             extra_part_size = max(extra_part_size , 1)
#             pattern         = cv2.resize(pattern, (extra_part_size, image.shape[0]),  interpolation=cv2.INTER_NEAREST)
#             #pattern         = np.expand_dims(pattern , axis = 2)
#             back            = np.ones((image.shape[0] , image.shape[1] + int(image.shape[1] * (v_rattio  )  ) )) * 255
#             if np.random.rand() <.5 :
#                 back[:image.shape[0] , :image.shape[1]] = image
#                 back[:image.shape[0] , -extra_part_size:] = pattern
#             else :
#                 back[:image.shape[0] , -image.shape[1]:] = image
#                 back[:image.shape[0] , :extra_part_size] = pattern

#             return back


#         def add_h_pattern(pattern_path , image ):
#             bg_value = np.argmax(np.bincount(image.reshape(-1,).astype(np.int64)))
#             pattern         = cv2.imread(os.path.join( pattern_path , np.random.choice(os.listdir(pattern_path) , size = 1)[0]), cv2.IMREAD_GRAYSCALE)
#             pattern = cv2.threshold(pattern, 0, bg_value, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
#             h_rattio        = np.random.uniform(.05 ,.08 )
#             extra_part_size = int(image.shape[0] * h_rattio)
#             extra_part_size = max(extra_part_size , 1)
#             pattern         = cv2.resize(pattern, (image.shape[1] ,extra_part_size),  interpolation=cv2.INTER_NEAREST)
#             #pattern         = np.expand_dims(pattern , axis = 2)
#             back            = np.ones(( image.shape[0] + int(image.shape[0] * (h_rattio  )) , image.shape[1]  ) ) * 255
#             if np.random.rand() <.5 :
#                 back[:image.shape[0] , :image.shape[1]] = image
#                 back[-extra_part_size:, :image.shape[1]] = pattern
#             else :
#                 back[-image.shape[0]: , :image.shape[1]] = image
#                 back[:extra_part_size , :image.shape[1]] = pattern

#             return back
        
#         def apply_affine_transformation(imgs , width_shift , height_shift ,  rotation_angle , scale , w , h  ):
    
#             # out_size  >>> (w , h)
#             trans_map     = np.float32([[1, 0, width_shift * w], [0, 1, height_shift * h]])
#             rot_map       = cv2.getRotationMatrix2D((w // 2, h // 2), rotation_angle, scale)
#             trans_map_aff = np.r_[trans_map, [[0, 0, 1]]]
#             rot_map_aff   = np.r_[rot_map, [[0, 0, 1]]]
#             affine_mat    = rot_map_aff.dot(trans_map_aff)[:2, :]

#             new_images = []
#             for i in range(len(imgs)):
#                 new_w  = int(affine_mat[0][0] * w + affine_mat[0][1] * h  + affine_mat[0][2] )
#                 new_h  = int(affine_mat[1][0] * w + affine_mat[1][1] * h  + affine_mat[1][2] )
#                 top    = abs(h - new_h)
#                 bottom = abs(h - new_h) 
#                 left   = abs(w - new_w) 
#                 right  = abs(w - new_w) 

#                 in_image = cv2.copyMakeBorder(imgs[i], top, bottom, left, right,  cv2.BORDER_CONSTANT, None, 255)
#                 out      = cv2.warpAffine(in_image, affine_mat, (in_image.shape[1] , in_image.shape[0]) , flags=cv2.INTER_NEAREST, borderValue=255)
                
#                 bg_value = np.argmax(np.bincount(out.reshape(-1,).astype(np.int64)))
#                 if bg_value > 0 :
#                     out      = out / bg_value
#                     out      = np.clip(out , 0 , 1)
#                     out      = out * 255
                
#                 new_images.append(out)
#             return new_images

#         def normalization(img): # out image values  is from 0  to 1
#             """Normalize list of images"""
#             img = np.asarray(img).astype(np.float32)
#             max_v = img.max()
#             min_v = img.min()
#             img = img / max_v

#             img = np.expand_dims(img, axis=-1)
#             return img
        
        
        
        
#         def add_random_black_lines(images):
#             out_images = []
#             for im in images :
#                 if np.random.random() <= 0.5:
#                     for _ in range(np.random.randint(1,2)):
#                             idx = np.random.randint(0 , im.shape[0])
#                             im[idx , : ] = 0

# #                 if np.random.random() <= 0.5:
# #                     for _ in range(np.random.randint(1,2)):
# #                         idx = np.random.randint(0 , im.shape[1])
# #                         im[: , idx ] = 0

#                 out_images.append(im)
#             return out_images
        
        
#         def add_random_white_lines(images):
    
#             out_images = []
#             for im in images :
#                 if np.random.random() <= 0.5:
#                     for _ in range(np.random.randint(1,2)):
#                             idx = np.random.randint(0 , im.shape[0])
#                             im[idx , : ] = 255

# #                 if np.random.random() <= 0.5:
# #                     for _ in range(np.random.randint(1,2)):
# #                         idx = np.random.randint(0 , im.shape[1])
# #                         im[: , idx ] = 255

#                 out_images.append(im)
#             return out_images
        
#         def add_lines(image):
#             h , w = image.shape[:2]

# #             num_of_lines = w//10
# #             for i in range(1 , num_of_lines) :
# #                 if np.random.rand() < .1 :
# #                     image[:,i * 10]  = 255 

#             num_of_lines = h//10
#             for i in range(1 , num_of_lines) :
#                 if np.random.rand() < .1 :
#                     image[i * 10 , :]  = 255

#             return image

        
        
#         def add_white_dots(image):
#             # 20 % of the area of the image 
#             h , w = image.shape[:2]
#             area = h * w

#             r = np.random.uniform(.01 , .05)
#             num_of_points = int(.2 * area )
#             ys = np.random.randint(0 , h , int(r * area ) )
#             xs = np.random.randint(0 , w , int(r * area ) )

#             for y ,x in zip(ys , xs) :
#                 if np.random.rand() < .5 :
#                     image[y,x] = 255 

#             return image
        
        
#         def add_black_dots(image):
#             # 20 % of the area of the image 
#             h , w = image.shape[:2]
#             area = h * w

#             r = np.random.uniform(.01 , .05)
#             num_of_points = int(.2 * area )
#             ys = np.random.randint(0 , h , int(r * area ) )
#             xs = np.random.randint(0 , w , int(r * area ) )

#             for y ,x in zip(ys , xs) :
#                 if np.random.rand() < .5 :
#                     image[y,x] = 0 

#             return image
        
        
        
#         image = image.numpy() * 255
#         image = image.astype('uint8')
#         image = image[:, :, 0]

#         dims = image.shape
        
        
        
#         if  np.random.random() <= .2:
#             height_shift    = np.random.uniform(-0.025, 0.025)
#             rotation_angle  = np.random.uniform(-1.5, 1.5)
#             scale           = np.random.uniform(1 - 0.05, 1)
#             width_shift     = np.random.uniform(-0.05, 0.05)
        
        
#             image = apply_affine_transformation(  [image] , width_shift , height_shift , rotation_angle , scale , dims[1] , dims[0])[0]   
         
#         try :
#             image = add_h_pattern(h_pattern_path , image) if  np.random.random() <= 0.3 else image
#             image = add_v_pattern(v_pattern_path , image) if  np.random.random() <= 0.3 else image
#         except :
#             pass 
        
#         image = add_random_black_lines([image])[0] if  np.random.random() <= 0.4 else image
#         image = add_random_white_lines([image])[0] if  np.random.random() <= 0.4 else image
        
#         image = image.astype('uint8')
        
        
#         image = cv2.bitwise_not(image) if np.random.random() <= 0.3 else image 
        
        
#         image = add_lines(image)                   if  np.random.random() <= 0.4 else image
#         image = add_white_dots(image)              if  np.random.random() <= 0.3 else image
#         image = add_black_dots(image)              if  np.random.random() <= 0.3 else image
        

#         if np.random.random() <= 0.3:
#             filter_size = np.random.choice([5])
#             image = cv2.GaussianBlur(image, (filter_size, filter_size), 0)
# #         if np.random.random() <= 0.5:
# #             border_size_top = np.random.randint(0, max(dims[0] // 8, 1))
# #             border_size_bot = np.random.randint(0, max(dims[0] // 8, 1))
# #             border_size_left = np.random.randint(0, max(dims[1] // 8, 1))
# #             border_size_right = np.random.randint(0, max(dims[1] // 8, 1))
# #             border_color = np.random.randint(0, 255)
        
            
            
            
# # #             if np.random.random() <= 0.5:
# # #                 image = cv2.copyMakeBorder(image, top=border_size_top, bottom=border_size_bot, left=border_size_left,
# # #                                            right=border_size_right,
# # #                                            borderType=cv2.BORDER_REPLICATE, value=border_color)

        
# #             if np.random.random() <= 0.2:
# #                 image = cv2.copyMakeBorder(image, top=border_size_top, bottom=border_size_bot, left=border_size_left,
# #                                            right=border_size_right,
# #                                            borderType=cv2.BORDER_CONSTANT, value=border_color)
                                           
        


# #             else: # crop randomly
# #                 border_size_top = np.random.randint(0, 5)
# #                 border_size_bot = np.random.randint(0, 5)
# #                 border_size_left = np.random.randint(0, 5)
# #                 border_size_right = np.random.randint(0, 5)
# #                 image = image[border_size_top:image.shape[0]-border_size_bot, border_size_left:image.shape[1]-border_size_right]
# #             image = image[..., np.newaxis]
# #             image = tf.keras.preprocessing.image.random_rotation(
# #                 image, 1, row_axis=1, col_axis=0, channel_axis=2,
# #                 fill_mode='nearest', cval=0.0, interpolation_order=1)
# #             image = image[:, :, 0]
        
        



# #         if np.random.random() <= 0.2:
# #             image = cv2.threshold(image, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
#         # Add salt and pepper noise
        
#         if np.random.random() <= 0.5:
#             image = add_noise(image)
#         # Stretch/squeeze horizontally and vertically
# #         if np.random.random() <= 0.2:
# #             scale_x = np.random.normal(1, 0.2)
# #             scale_y = np.random.normal(1, 0.2)
# #             image = cv2.resize(image, (0, 0), fx=scale_x, fy=scale_y)
        
#         # Downsample without smoothing for pixelation effect
#         if np.random.random() <= 0.3:
#             image = cv2.resize(image, (0, 0), fx=0.5, fy=0.5, interpolation=cv2.INTER_NEAREST)
#             # image = cv2.resize(image, (0, 0), fx=2.0, fy=2.0, interpolation=cv2.INTER_NEAREST)
#         # if np.random.random() <= 0.5:
#         #     filter_size = np.random.choice([3])
#         #     image = cv2.GaussianBlur(image, (filter_size, filter_size), 0)
#         if np.random.random() <= 0.3:
#             image = random_noise(image, 'poisson') * 255
#         elif np.random.random() <= 0.2:
#             image = random_noise(image, 'gaussian') * 255
        
#         image = image.astype('uint8')
#         image = cv2.bitwise_not(image) if np.random.random() <= 0.3 else image 
        

#         image = image[..., np.newaxis]
        
        
#         image = tf.convert_to_tensor(image / 255, dtype=tf.float32)
#         return image

    def _augment_image(self, image):
        def add_random_black_lines(images):
            out_images = []
            for im in images :
                if np.random.random() <= 0.5:
                    for _ in range(np.random.randint(1,2)):
                            idx = np.random.randint(0 , im.shape[0])
                            im[idx , : ] = 0

#                 if np.random.random() <= 0.5:
#                     for _ in range(np.random.randint(1,2)):
#                         idx = np.random.randint(0 , im.shape[1])
#                         im[: , idx ] = 0

                out_images.append(im)
            return out_images
        
        
        def add_h_pattern(pattern_path , image ):
            bg_value = np.argmax(np.bincount(image.reshape(-1,).astype(np.int64)))
            pattern         = cv2.imread(os.path.join( pattern_path , np.random.choice(os.listdir(pattern_path) , size = 1)[0]), cv2.IMREAD_GRAYSCALE)
            pattern = cv2.threshold(pattern, 0, bg_value, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
            h_rattio        = np.random.uniform(.05 ,.08 )
            extra_part_size = int(image.shape[0] * h_rattio)
            extra_part_size = max(extra_part_size , 1)
            pattern         = cv2.resize(pattern, (image.shape[1] ,extra_part_size),  interpolation=cv2.INTER_NEAREST)
            #pattern         = np.expand_dims(pattern , axis = 2)
            back            = np.ones(( image.shape[0] + int(image.shape[0] * (h_rattio  )) , image.shape[1]  ) ) * 255
            if np.random.rand() <.5 :
                back[:image.shape[0] , :image.shape[1]] = image
                back[-extra_part_size:, :image.shape[1]] = pattern
            else :
                back[-image.shape[0]: , :image.shape[1]] = image
                back[:extra_part_size , :image.shape[1]] = pattern

            return back
        
        def add_v_pattern(pattern_path , image ):
            bg_value = np.argmax(np.bincount(image.reshape(-1,).astype(np.int64)))
            pattern         = cv2.imread(os.path.join( pattern_path , np.random.choice(os.listdir(pattern_path) , size = 1)[0]), cv2.IMREAD_GRAYSCALE)
            pattern = cv2.threshold(pattern, 0, bg_value, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]

            v_rattio        = np.random.uniform(.1 ,.15 )
            extra_part_size = int(image.shape[1] * v_rattio)
            extra_part_size = max(extra_part_size , 1)
            pattern         = cv2.resize(pattern, (extra_part_size, image.shape[0]),  interpolation=cv2.INTER_NEAREST)
            #pattern         = np.expand_dims(pattern , axis = 2)
            back            = np.ones((image.shape[0] , image.shape[1] + int(image.shape[1] * (v_rattio  )  ) )) * 255
            if np.random.rand() <.5 :
                back[:image.shape[0] , :image.shape[1]] = image
                back[:image.shape[0] , -extra_part_size:] = pattern
            else :
                back[:image.shape[0] , -image.shape[1]:] = image
                back[:image.shape[0] , :extra_part_size] = pattern

            return back




        image = image.numpy() * 255
        image = image.astype('uint8')
        image = image[:, :, 0]

        dims = image.shape
        image = add_random_black_lines([image])[0] if  np.random.random() <= 0.4 else image
        try :
            image = add_h_pattern(h_pattern_path , image) if  np.random.random() <= 0.1 else image
            image = add_v_pattern(v_pattern_path , image) if  np.random.random() <= 0.1 else image
        except :
            pass 
        
        
        image = image.astype('uint8')
        if np.random.random() <= 0.3:
            filter_size = np.random.choice([5])
            image = cv2.GaussianBlur(image, (filter_size, filter_size), 0)
        if np.random.random() <= 0.3:
            border_size_top = np.random.randint(0, max(dims[0] // 8, 1))
            border_size_bot = np.random.randint(0, max(dims[0] // 8, 1))
            border_size_left = np.random.randint(0, max(dims[1] // 8, 1))
            border_size_right = np.random.randint(0, max(dims[1] // 8, 1))
            border_color = np.random.randint(0, 255)
            if np.random.random() <= 0.5:
                image = cv2.copyMakeBorder(image, top=border_size_top, bottom=border_size_bot, left=border_size_left,
                                           right=border_size_right,
                                           borderType=cv2.BORDER_REPLICATE, value=border_color)
            elif np.random.random() <= 0.2:
                image = cv2.copyMakeBorder(image, top=border_size_top, bottom=border_size_bot, left=border_size_left,
                                           right=border_size_right,
                                           borderType=cv2.BORDER_CONSTANT, value=border_color)
#             else: # crop randomly
#                 border_size_top = np.random.randint(0, 5)
#                 border_size_bot = np.random.randint(0, 5)
#                 border_size_left = np.random.randint(0, 5)
#                 border_size_right = np.random.randint(0, 5)
#                 image = image[border_size_top:image.shape[0]-border_size_bot, border_size_left:image.shape[1]-border_size_right]
            image = image[..., np.newaxis]
            image = tf.keras.preprocessing.image.random_rotation(
                image, .85, row_axis=1, col_axis=0, channel_axis=2,
                fill_mode='nearest', cval=0.0, interpolation_order=1)
            image = image[:, :, 0]
#         if np.random.random() <= 0.2:
#             image = cv2.threshold(image, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
        # Add salt and pepper noise
        if np.random.random() <= 0.5:
            image = add_noise(image)
        # Stretch/squeeze horizontally and vertically
        if np.random.random() <= 0.2:
            scale_x = np.random.normal(1, 0.2)
            scale_y = np.random.normal(1, 0.2)
            image = cv2.resize(image, (0, 0), fx=scale_x, fy=scale_y)
        # invert
        if np.random.random() <= 0.1:
            image = cv2.bitwise_not(image)
        # Downsample without smoothing for pixelation effect
        if np.random.random() <= 0.3:
            try :
                image = cv2.resize(image, (0, 0), fx=0.5, fy=0.5, interpolation=cv2.INTER_NEAREST)
            except :
                pass
            # image = cv2.resize(image, (0, 0), fx=2.0, fy=2.0, interpolation=cv2.INTER_NEAREST)
        # if np.random.random() <= 0.5:
        #     filter_size = np.random.choice([3])
        #     image = cv2.GaussianBlur(image, (filter_size, filter_size), 0)
        if np.random.random() <= 0.3:
            try :
                image = random_noise(image, 'poisson') * 255
            except :
                pass
        elif np.random.random() <= 0.2:
            try :
                image = random_noise(image, 'gaussian') * 255
            except :
                pass

        image = image[..., np.newaxis]

        image = tf.convert_to_tensor(image / 255, dtype=tf.float32)
        return image


    def _prepare_bidi_training_text(self, label):
        '''
            Prepares bidi (arabic or bilingual) text line for use in training the OCR engine
            by reversing stretches of arabic characters as they would read from left to right.
        '''
        text = label.numpy().decode('utf-8')
        text = sanitize_arabic(text)
        #text = get_display(text)
        #text = text[::-1]
        text = tf.convert_to_tensor(text, dtype=tf.string)
        return text
    
    def _prepare_bidi_training_text_source_data(self, label):
        '''
            Prepares bidi (arabic or bilingual) text line for use in training the OCR engine
            by reversing stretches of arabic characters as they would read from left to right.
        '''
        text = label.numpy().decode('utf-8')
        text = sanitize_arabic(text)
        try :
            text = get_display(text)
        except :
            pass
        #text = text[::-1]
        text = tf.convert_to_tensor(text, dtype=tf.string)
        return text

    def test(self, src_paths=None, generators=None, gen_weights=None, use_augmentation=True, save_path=None):
        dataset = self.prepare_datasets(src_paths=src_paths, generators=generators,
                                        gen_weights=gen_weights, use_augmentation=use_augmentation)
        for batch in dataset.take(5):
            batch_images = batch["image"]
            batch_labels = batch["label"]

            preds = self.prediction_model.predict(batch_images)
            ctc = calc_ctc(batch_labels, preds)
            pred_texts = self.decode_batch_predictions(preds)

            plt.figure()
            for i in range(self.batch_size):
                img = (batch_images[i] * 255).numpy().astype("uint8")
                img = np.transpose(img, [1, 0, 2])
                label = tf.strings.reduce_join(self.num_to_char(batch_labels[i])).numpy().decode("utf-8")
                label = label.replace('[UNK]', '')
                label = get_display(label)
                wer = jiwer.wer(label, pred_texts[i])
                cer = Levenshtein.distance(label, pred_texts[i]) / len(label)

                print('gt:\n', label)
                print('pred_text:\n', pred_texts[i])

                print(f'ctc: {ctc[i].numpy()}, {cer:.2f},  {wer:.2f}', )
                if save_path is not None:
                    cv2.imwrite(os.path.join(save_path, f"test_img_{i}.png"), img)
                plt.imshow(img, cmap='gray')
                plt.show()

    def perform_ocr(self, img_list: list, inspect_data: bool = False) -> list:
        self.use_augmentation = False
        
#         plt.figure()
#         plt.imshow(img_list[0], cmap='gray')
#         plt.show()

        def prepare_image(image):
            (h, w) = image.shape[:2]
            r = self.img_height / float(h)

            #if image.shape[0] >  self.img_height : 
            dim = (min(int(w  *  r), self.max_img_width), self.img_height)
            #dim = (w, self.img_height)

            # resize the image
            image = cv2.resize(image, dim, interpolation=cv2.INTER_AREA)

        
            back_ = np.zeros((self.img_height , self.max_img_width))
            back_[:image.shape[0] , :image.shape[1]] = image
            back_ = (back_ / 255).astype('float32').reshape(back_.shape[0], back_.shape[1], 1)

            # display(back_)
            back_ = np.transpose(back_, [1, 0, 2])

            return back_

        dataset = (tf.data.Dataset.from_generator(lambda: map(prepare_image, img_list), output_types=tf.float32,
                                                  output_shapes=tf.TensorShape([None, self.img_height, 1]))
                   .padded_batch(self.batch_size)
                   .prefetch(buffer_size=tf.data.experimental.AUTOTUNE))

        pred_texts = []
        for batch in dataset.take(-1):
            preds = self.prediction_model.predict(batch, batch_size=self.batch_size)
            #print(preds)
            pred_text = self.decode_batch_predictions(preds)
            pred_texts.extend(pred_text)
            if inspect_data:
                for i in range(batch.shape[0]):
                    img = (batch[i] * 255).numpy().astype("uint8")
                    print(img.shape)
                    img = np.transpose(img, [1, 0, 2])
                    plt.figure()
                    plt.imshow(img, cmap='gray')
                    plt.show()

        return pred_texts

    def inspect_dataset(self, src_paths=None, generators=None, gen_weights=None, use_augmentation=True):
        dataset = self.prepare_datasets(src_paths=src_paths, generators=generators,
                                        gen_weights=gen_weights, use_augmentation=use_augmentation)
        for batch in dataset.take(5):
            batch_images = batch["image"]
            batch_labels = batch["label"]

            plt.figure()
            for i in range(self.batch_size):
                img = (batch_images[i] * 255).numpy().astype("uint8")
                img = np.transpose(img, [1, 0, 2])
                label = tf.strings.reduce_join(self.num_to_char(batch_labels[i])).numpy().decode("utf-8")
                label = label.replace('[UNK]', '')
                label = get_display(label)

                print('gt:\n', label)
                print(f'{img.shape}')
                plt.imshow(img, cmap='gray')
                plt.show()


# In[3]:


#ocr = OCR_engine(line_height= 32 ,  charlist_path='charlist_v3.txt' ,  rtl=True ,  model_path = r"models\oct_agamy_v1.h5" )  # Training from scratch


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




