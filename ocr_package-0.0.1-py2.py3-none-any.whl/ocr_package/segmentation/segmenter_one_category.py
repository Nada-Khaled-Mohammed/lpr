"""
This script train pages with appropriate segmentation map (text, ads, ...) using dice coefeceint loss
Not for article segmentation, for any type else
"""

import numpy as np
import matplotlib.pyplot as plt
import os
import cv2
import tensorflow as tf

from tensorflow.keras.models import Model, load_model
from tensorflow.keras import layers
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Input, AveragePooling2D
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, ReduceLROnPlateau
from tensorflow.keras.optimizers import Adam
from PIL import Image
from pathlib import Path
import random as pyrandom
from ocr_package.segmentation.losses import dice_coef_loss
import tensorflow_addons as tfa
from ocr_package.image_utils.add_noise import add_noise
from src.segmentation.article_extractor import ArticleExtractor
from ocr_package.segmentation.segmentation_utils import resize_seg_maps
from load_models import *


SEED = 1
np.random.seed(SEED)
pyrandom.seed(SEED)


class DSV:
    def __init__(self, scale_factor=1, use_classes=False):
        self.scale_factor = scale_factor
        if use_classes:
            self.classes = 4
        else:
            self.classes = 32

    def upsample_layer(self, inputs):
        # self.conv = tf.keras.layers.Conv2D(self.classes, kernel_size=1, padding="same",kernel_initializer="he_uniform")
        # self.upsample = tf.keras.layers.UpSampling2D([self.scale_factor, 1])
        # x = self.conv(inputs)
        # x = tf.keras.layers.Conv2D(self.classes, kernel_size=1, padding="same",kernel_initializer="he_uniform")(inputs)
        x = tf.keras.layers.UpSampling2D([self.scale_factor, 1])(inputs)
        return x


class Segmenter_One_Category:
    def __init__(self, model_path=None, img_height=512, img_width=384):
        self.img_height = img_height
        self.img_width = img_width
        self.batch_size = 6
        if model_path is not None:
            self.model = load_model(model_path)
        else:
            self.model = self._create_model()
            # self.model = self._create_model_scAG()
        # self.model.summary()

    def _create_model(self):
        def conv_block(x, num_filters=64, name=None):
            # Second conv block
            x = layers.Conv2D(
                num_filters,
                (3, 3),
                kernel_initializer="he_normal",
                padding="same",
                name=name + 'conv1'
            )(x)
            x = tfa.layers.InstanceNormalization(axis=3,
                                                 center=True,
                                                 scale=True,
                                                 beta_initializer="random_uniform",
                                                 gamma_initializer="random_uniform")(x)
            x = layers.Activation('relu')(x)
            # x = Dropout(0.2)(x)
            # Third conv block
            x = layers.Conv2D(
                num_filters,
                (3, 3),
                kernel_initializer="he_normal",
                padding="same",
                name=name + 'conv2'
            )(x)
            x = tfa.layers.InstanceNormalization(axis=3,
                                                 center=True,
                                                 scale=True,
                                                 beta_initializer="random_uniform",
                                                 gamma_initializer="random_uniform")(x)
            x = layers.Activation('relu', name=name + 'last_activation')(x)
            # x = Dropout(0.2)(x)
            return x

        input_layer = Input(shape=(None, None, 1), name='page_in')
        x = input_layer
        # encoding
        residuals = []
        for num_filters in [32, 64, 128, 256]:
            x = conv_block(x, num_filters=num_filters, name='down_path' + str(num_filters))
            residuals.append(x)
            x = MaxPooling2D((2, 2), padding='same')(x)

        x = conv_block(x, num_filters=512, name='bottleneck' + str(512))

        for num_filters in [256, 128, 64]:
            x = layers.Conv2DTranspose(num_filters, (3, 3), strides=(2, 2), padding='same')(x)
            x = layers.Concatenate()([x, residuals.pop()])
            x = conv_block(x, num_filters=num_filters, name='up_path' + str(num_filters))
        x = layers.Conv2DTranspose(32, (3, 3), strides=(2, 2), padding='same', name='last_upsample')(x)
        x = layers.Concatenate(name='last_concat')([x, residuals.pop()])
        # output heads
        seg_map_output = conv_block(x, num_filters=32, name='seg_map_head')
        seg_map_output = Conv2D(1, (1, 1), padding='same', activation='sigmoid', name='seg_map')(seg_map_output)

        model = Model(inputs=[input_layer], outputs=seg_map_output)
        return model

    def _create_model_scAG(self):
        def conv_block(x, num_filters=64, name=None):
            # Second conv block
            x = layers.Conv2D(
                num_filters,
                (3, 3),
                kernel_initializer="he_normal",
                padding="same",
                name=name + 'conv1'
            )(x)
            x = tfa.layers.InstanceNormalization(axis=3,
                                                 center=True,
                                                 scale=True,
                                                 beta_initializer="random_uniform",
                                                 gamma_initializer="random_uniform")(x)

            x = layers.Activation('relu')(x)

            # Third conv block
            x = layers.Conv2D(
                num_filters,
                (3, 3),
                kernel_initializer="he_normal",
                padding="same",
                name=name + 'conv2'
            )(x)
            x = tfa.layers.InstanceNormalization(axis=3,
                                                 center=True,
                                                 scale=True,
                                                 beta_initializer="random_uniform",
                                                 gamma_initializer="random_uniform")(x)
            x = layers.Activation('relu', name=name + 'last_activation')(x)

            return x

        def sAG(x):
            avg_pool = AveragePooling2D((1, 1), padding='same')(x)
            max_pool = MaxPooling2D((1, 1), padding='same')(x)
            conv_layer = Conv2D(1, (1, 1), kernel_initializer="he_normal", padding="same", )(x)
            concat = layers.Concatenate()([avg_pool, max_pool, conv_layer])
            output = Conv2D(1, (7, 7), strides=1, padding='same',
                            kernel_initializer='he_normal')(concat)  # use bias = False

            return output

        def cAG(x, num_filters):
            shared_layer_one = Conv2D(num_filters // 16, 1, activation='relu')
            shared_layer_two = Conv2D(num_filters, 1)
            avg_pool = AveragePooling2D((1, 1), padding='same')(x)
            max_pool = MaxPooling2D((1, 1), padding='same')(x)
            avg_pool = shared_layer_one(avg_pool)
            avg_pool = shared_layer_two(avg_pool)
            max_pool = shared_layer_one(max_pool)
            max_pool = shared_layer_two(max_pool)
            output_shared = layers.Add()([avg_pool, max_pool])
            # output_shared = layers.Activation('sigmoid')(output_shared)
            # return layers.Multiply()([output_shared,x])
            return output_shared

        def scAG(x, num_filters):
            x_s = sAG(x)
            x_c = cAG(x, num_filters)
            return layers.Multiply()([x_s, x_c])

        input_layer = Input(shape=(None, None, 1), name='page_in')
        x = input_layer
        # encoding
        # residuals = []
        gate_output = []
        dsv_outputs = []
        for num_filters in [32, 64, 128, 256]:
            x = conv_block(x, num_filters=num_filters, name='down_path' + str(num_filters))
            gate_output.append(scAG(x, num_filters))
            # residuals.append(x)
            x = MaxPooling2D((2, 2), padding='same')(x)

        x = conv_block(x, num_filters=512, name='bottleneck' + str(512))

        # decoding
        filters = [256, 128, 64]
        for i, num_filters in enumerate(filters):
            x = layers.Conv2DTranspose(num_filters, (3, 3), strides=(2, 2), padding='same')(x)
            x = layers.Concatenate()([x, gate_output.pop()])
            x = conv_block(x, num_filters=num_filters, name='up_path' + str(num_filters))
            x_dsv = x
            for j in range(len(filters) - i - 1):
                # x_dsv = tf.keras.layers.UpSampling2D([256 // filters[j+i+1], 1])(x_dsv)
                x_dsv = layers.Conv2DTranspose(filters[j + i + 1], (3, 3), strides=(2, 2), padding='same')(x_dsv)
            # x_dsv = DSV(scale_factor=num_filters).upsample_layer(x)
            # x_dsv = layers.Conv2DTranspose(32, (3, 3), strides=(2, 2), padding='same')(x)
            # x_dsv = tf.keras.layers.UpSampling2D([256//num_filters, 1])(x)
            # x_dsv = tf.keras.layers.UpSampling3D(size=(1, 1,256//num_filters))(x)
            x_dsv = layers.Conv2DTranspose(32, (3, 3), strides=(2, 2), padding='same')(x_dsv)
            dsv_outputs.append(x_dsv)

        x = layers.Conv2DTranspose(32, (3, 3), strides=(2, 2), padding='same', name='last_upsample')(x)
        x = layers.Add(name='last_concat')([x, gate_output.pop()])
        concat_layer = tf.keras.layers.Add()(dsv_outputs)
        # concat_layer = layers.Conv2DTranspose(32, (3, 3), strides=(2, 2), padding='same')(concat_layer)
        x = conv_block(x, num_filters=32, name='fusion_module')
        x = tf.keras.layers.Concatenate()([concat_layer, x])
        # output heads
        seg_map_output = conv_block(x, num_filters=32, name='seg_map_head')
        seg_map_output = Conv2D(1, (1, 1), padding='same', activation='sigmoid', name='seg_map')(seg_map_output)

        model = Model(inputs=[input_layer], outputs=seg_map_output)
        return model

    def _compile_model(self, lr=0.001, freeze_core_model=False):
        optimizer = Adam(lr=lr)
        if freeze_core_model:
            for layer in self.model.layers:
                # core_model = Model(self.model.get_layer('page_in'), self.model.get_layer('core_model_out'))
                # core_model.trainable = False
                layer.trainable = True

        self.model.compile(optimizer=optimizer, loss=dice_coef_loss)
        self.model.summary()

    def _segment(self, img):
        if isinstance(img, str):
            img = self.process_image(img)
        if len(img.shape) < 4:
            img = img[np.newaxis, :, :]
        input = img.reshape((-1, self.img_height, self.img_width, 1))
        out = self.model.predict(input, batch_size=8)
        return out

    def process_image(self, path):
        if isinstance(path, str):
            # img = cv2.imread(path,0)
            # img = cv2.resize(img, (self.img_width, self.img_height), interpolation=cv2.INTER_AREA)
            img = Image.open(path)
            img = img.convert(mode='L')
            img = img.resize((self.img_width, self.img_height), resample=Image.LANCZOS)
            img = np.array(img, dtype="float32")
        else:
            img = cv2.resize(path, (self.img_width, self.img_height), interpolation=cv2.INTER_AREA)
        if len(img.shape) == 3:
            img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        img = img / 255.0
        img = img.reshape((img.shape[0], img.shape[1], 1))
        return img

    def _prepare_single_sample_train(self, page_path, seg_maps_path):

        def read_prep_image(img_path):
            img = tf.io.read_file(img_path)
            img = tf.io.decode_png(img, channels=1)
            img = tf.image.convert_image_dtype(img, tf.float32)
            img = tf.image.resize(img, [self.img_height, self.img_width], method=tf.image.ResizeMethod.AREA)
            return img

        page = read_prep_image(page_path)
        seg_map = read_prep_image(seg_maps_path)

        return page, seg_map

    def _apply_augmentation(self, page, seg_map):
        def tf_augment_image(image):
            im_shape = image.shape
            [image, ] = tf.py_function(self._augment_image, [image], [tf.float32])
            image.set_shape(im_shape)
            return image

        # augmentation ops that run on just the page input
        brightness_factor = tf.random.uniform(shape=[], minval=-0.3, maxval=0.3)
        page = tf.image.adjust_brightness(page, brightness_factor)
        page = tf.image.random_contrast(page, lower=0.5, upper=1.5, seed=SEED)
        page = tf.clip_by_value(page, 0, 1)
        # perform augmentation ops that run on outputs as well
        all_stacked = tf.stack([tf.squeeze(page),
                                tf.squeeze(seg_map)], axis=-1)
        all_stacked = tf_augment_image(all_stacked)
        all_stacked = tf.image.resize(all_stacked, [self.img_height, self.img_width],
                                      method=tf.image.ResizeMethod.AREA)
        all_stacked = tf.image.random_flip_left_right(all_stacked, seed=SEED)

        page = tf.expand_dims(all_stacked[..., 0], axis=-1)
        seg_map = tf.expand_dims(all_stacked[..., 1], axis=-1)
        return page, seg_map

    def _augment_image(self, all_stacked):
        all_stacked = all_stacked.numpy() * 255
        all_stacked = all_stacked.astype('uint8')
        if np.random.random() <= 0.1:
            page = add_noise(all_stacked[:, :, 0])
            all_stacked[:, :, 0] = page

        # Add white borders of random length in each direction
        # if np.random.random() <= 0.3:
        #     base_border_size = np.random.randint(0, 20)
        #     border_range = 5
        #     top_border = max(0, np.random.randint(base_border_size - border_range, base_border_size + border_range))
        #     bottom_border = max(0, np.random.randint(base_border_size - border_range, base_border_size + border_range))
        #     left_border = max(0, np.random.randint(base_border_size - border_range, base_border_size + border_range))
        #     right_border = max(0, np.random.randint(base_border_size - border_range, base_border_size + border_range))
        #     all_stacked = cv2.copyMakeBorder(all_stacked, top_border, bottom_border, left_border, right_border, cv2.BORDER_REPLICATE, 0)
        if np.random.random() <= 0.5:
            all_stacked = tf.keras.preprocessing.image.random_shift(
                all_stacked, 0.02, 0.03, row_axis=1, col_axis=0, channel_axis=2,
                fill_mode='nearest', cval=0.0, interpolation_order=1
            )
        else:
            all_stacked = tf.keras.preprocessing.image.random_rotation(
                all_stacked, 1, row_axis=1, col_axis=0, channel_axis=2,
                fill_mode='nearest', cval=0.0, interpolation_order=1
            )

        # if np.random.random() <= 0.3:
        #     filter_size = np.random.choice([3, 5, 7])
        #     articles = cv2.GaussianBlur(all_stacked[:, :, 1], (filter_size, filter_size), 0)
        #     all_stacked[:, :, 1] = articles

        # else:
        #     image = cv2.adaptiveThreshold(image, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2)
        # image = image[..., np.newaxis]
        image = tf.convert_to_tensor(all_stacked / 255, dtype=tf.float32)
        return image

    def prepare_datasets(self, src_paths, label, use_augmentation=True):
        pages = []
        for src_path in src_paths:
            pages_path = Path(os.path.join(src_path, 'pages'))
            ds_pages = sorted(list(map(str, list(pages_path.rglob("*.jpg")))))
            pages += ds_pages
            print(f'Found {len(ds_pages)} samples in {src_path}.')
        print(f'Found a total of {len(pages)} samples.')

        def split_data(images, train_size=0.9, shuffle=True):
            # 1. Get the total size of the dataset
            size = len(images)
            # 2. Make an indices array and shuffle it, if required
            indices = np.arange(size)
            if shuffle:
                np.random.seed(SEED)
                np.random.shuffle(indices)
            # 3. Get the size of training samples
            train_samples = int(size * train_size)
            # 4. Split data into training and validation sets
            x_train = images[indices[:train_samples]]
            x_valid = images[indices[train_samples:]]
            return x_train, x_valid

        # Splitting data into training and validation sets
        pages_train, pages_val = split_data(np.array(pages))
        seg_maps_train = [page.replace('pages', label) for page in pages_train]
        seg_maps_val = [page.replace('pages', label) for page in pages_val]

        train_dataset = tf.data.Dataset.from_tensor_slices(
            (pages_train, seg_maps_train))
        train_dataset = train_dataset.shuffle(len(pages_train), reshuffle_each_iteration=True) \
            .map(self._prepare_single_sample_train, num_parallel_calls=tf.data.experimental.AUTOTUNE)
        if use_augmentation:
            train_dataset.map(self._apply_augmentation, num_parallel_calls=tf.data.experimental.AUTOTUNE)
        train_dataset = train_dataset.padded_batch(self.batch_size) \
            .prefetch(buffer_size=tf.data.experimental.AUTOTUNE)

        validation_dataset = tf.data.Dataset.from_tensor_slices(
            (pages_val, seg_maps_val))
        validation_dataset = (
            validation_dataset.shuffle(len(pages_val), reshuffle_each_iteration=True, seed=SEED)
            .map(
                self._prepare_single_sample_train, num_parallel_calls=tf.data.experimental.AUTOTUNE
            )
            .padded_batch(self.batch_size)
            .prefetch(buffer_size=tf.data.experimental.AUTOTUNE)
        )
        return train_dataset, validation_dataset

    def train(self, src_paths, freeze_core_model=False, use_augmentation=True, lr=0.001, label="titles",
              model_name="test.h5", save_model_path=""):

        train_dataset, validation_dataset = self.prepare_datasets(src_paths, label, use_augmentation=use_augmentation)

        es_callback = EarlyStopping(monitor='val_loss', patience=10, verbose=1)
        cp_callback = ModelCheckpoint(filepath=os.path.join(save_model_path, model_name),
                                      save_best_only=True, verbose=1)
        lr_callback = ReduceLROnPlateau(monitor='val_loss', factor=0.5,
                                        patience=3, min_lr=0.00001, verbose=1)
        callbacks = [es_callback, cp_callback, lr_callback]

        self._compile_model(lr=lr, freeze_core_model=freeze_core_model)
        try:
            history = self.model.fit(train_dataset, validation_data=validation_dataset, epochs=500,
                                     verbose=1, callbacks=callbacks)

            epoch_loss = history.history['loss']
            epoch_val_loss = history.history['val_loss']

            plt.figure(figsize=(20, 6))
            plt.subplot(1, 2, 1)
            plt.plot(range(0, len(epoch_loss)), epoch_loss, 'b-', linewidth=2, label='Train Loss')
            plt.plot(range(0, len(epoch_val_loss)), epoch_val_loss, 'r-', linewidth=2, label='Val Loss')
            plt.title('Evolution of loss on train & validation datasets over epochs')
            plt.legend(loc='best')

            plt.show()
        finally:
            print("DONE")
            # don't save the model (last model isn't necessary the best)
            # self.model.save('../../models/segmentation/article_segmentation/ahram/seg_ads_ahram_v2.h5')

    def inspect_dataset(self, src_paths, use_augmentation=False):
        train_dataset, val_dataset = self.prepare_datasets(src_paths, use_augmentation)
        for batch in train_dataset.take(5):
            batch_pages = batch[0]
            batch_seg = batch[1]

            for i in range(batch_pages.shape[0]):
                img = (batch_pages[i] * 255).numpy().astype("uint8")
                plt.figure()
                plt.subplot(1, 2, 1)
                plt.imshow(img, cmap='gray')
                plt.title('GT')

                articles = (batch_seg['articles'][i] * 255).numpy().astype("uint8")
                plt.subplot(1, 2, 2)
                plt.imshow(articles, cmap='gray')
                plt.title('Seg Map')

                plt.show()

    def evaluate(self, img_path, plot=False):
        img = self.process_image(img_path)
        pred = self._segment(img)
        pred = (pred * 255).astype("uint8")
        pred = np.squeeze(pred)
        if plot:
            plt.figure()
            plt.subplot(1, 2, 1)
            plt.imshow(img, cmap='gray')
            plt.title('Page')

            plt.subplot(1, 2, 2)
            plt.imshow(pred, cmap='gray')
            plt.title('Seg Map')

            plt.show()
        return pred

    def evaluate_batch(self, img_list):
        if type(img_list) == str:
            dataset = [self.process_image(os.path.join(img_list, img)) for img in os.listdir(img_list)]
        else:
            dataset = [self.process_image(img) for img in img_list]
        dataset = (tf.data.Dataset.from_tensor_slices(dataset)
                   .padded_batch(batch_size=self.batch_size)
                   .prefetch(buffer_size=tf.data.experimental.AUTOTUNE))
        predictions_all = []
        for batch in dataset.take(-1):
            pred = self.model.predict(batch, batch_size=self.batch_size)
            predictions_all.append(pred)
        return predictions_all

    def evaluate_compare(self, img_path, candidate=None, plot=True):
        img = self.process_image(img_path)
        pred = self._segment(img)
        if plot:
            plt.figure()
            plt.subplot(2, 2, 1)
            plt.imshow(img, cmap='gray')
            plt.title('Page')

            plt.subplot(2, 2, 2)
            plt.imshow(pred, cmap='gray')
            plt.title('Seg Map')

            img_cand = candidate.process_image(img_path)
            pred = candidate._segment(img_cand)

            plt.subplot(2, 2, 2 + 1)
            plt.imshow(img, cmap='gray')
            plt.title('Page')

            plt.subplot(2, 2, 2 + 1)
            plt.imshow(pred, cmap='gray')
            plt.title('candidate')

            plt.show()
        return pred


if __name__ == "__main__":

    # train
    train = False
    if train:
        path = r"D:\data\Al_Mosawer\mosawer_annotation\output_annotation\50s_classes_splitted"
        path2 = r"D:\data\Al_Mosawer\mosawer_annotation\output_annotation\1949_classes_splitted"
        path3 = r"D:\data\Al_Mosawer\mosawer_annotation\output_annotation\60s_all_classes_splitted"
        art_seg = Segmenter_One_Category(img_height=512, img_width=384)  # to train from scratch
        art_seg.train(src_paths=[path, path2, path3], lr=1e-3, use_augmentation=True,label="description",
                      save_model_path=r"D:\gitlab_updated\mosawer-ocr\models\segmentation\article_segmentation\mosawer\single_pages_segmentation",
                      model_name="mosawer_description_seg_single_pages_v2.h5")

    ## tets
    test = True
    if test:
        ds_path = r"D:\data\Al_Mosawer\Test\60s\60s_test_data"
        save_path_all = r"D:\data\Al_Mosawer\Test\60s\60s_test_data_output"
        # for page in list(Path(ds_path).rglob("*.jpg")):
        for image_name in os.listdir(ds_path):
            # image_name="1962_11_09_1987_036.jpg"
            # image_name = page.name
            # year = page.parent
            print(f"processing page {image_name}")
            save_path = os.path.join(save_path_all, image_name)
            # if os.path.exists(save_path):
            #     continue
            # os.makedirs(save_path, exist_ok=True)
            image_original = cv2.imread(os.path.join(ds_path, image_name), 0)
            cv2.imwrite(os.path.join(save_path,image_name), image_original)
            seg_map_article = article_segmenter.evaluate(image_original)["articles"]
            # seg_map_article = (seg_map_article * 255).astype(np.uint8)
            # seg_maps = {"articles": seg_map_article, "bg": np.zeros_like(seg_map_article),
            #             "ads": np.zeros_like(seg_map_article), "images": np.zeros_like(seg_map_article),
            #             "text": np.zeros_like(seg_map_article), "titles": np.zeros_like(seg_map_article)}
            seg_map_classes = image_ads_segmenter.evaluate(image_original)
            seg_maps_images_ads = seg_map_classes["images"]
            seg_maps_text = text_segmenter.evaluate(image_original, plot=False)
            seg_maps_bg = bg_segmenter.evaluate(image_original)
            seg_maps_titles = titles_segmenter.evaluate(image_original)["titles"]
            seg_maps_description = description_segmenter.evaluate(image_original)
            seg_maps_text = cv2.subtract(seg_maps_text, seg_maps_description)

            seg_maps = {"articles": seg_map_article, "bg": seg_maps_bg,
                        "images": seg_maps_images_ads, "text": seg_maps_text, "titles": seg_maps_titles,
                        "description": seg_maps_description}
            # seg_maps["articles"] = seg_map_article
            seg_maps = resize_seg_maps(seg_maps, original_width=image_original.shape[1],
                                       original_height=image_original.shape[0])
            plot = False
            if plot:
                plt.figure()
                plt.subplot(1, 7, 1)
                plt.imshow(image_original, cmap='gray')
                plt.title('Page')

                plt.subplot(1, 7, 2)
                plt.imshow(seg_maps['articles'], cmap='gray')
                plt.title('Articles')

                plt.subplot(1, 7, 3)
                plt.imshow(seg_maps['bg'], cmap='gray')
                plt.title('Background')

                plt.subplot(1, 7, 4)
                plt.imshow(seg_maps['text'], cmap='gray')
                plt.title('Text')

                plt.subplot(1, 7, 5)
                plt.imshow(seg_maps['titles'], cmap='gray')
                plt.title('Titles')

                plt.subplot(1, 7, 6)
                plt.imshow(seg_maps['images'], cmap='gray')
                plt.title('Images')

                plt.subplot(1, 7, 7)
                plt.imshow(seg_maps['description'], cmap='gray')
                plt.title('Description')

                plt.show()
            # cv2.imwrite(os.path.join(save_path, image_name), seg_map_article)
            try:
                article_extractor = ArticleExtractor(seg_maps, image_original=image_original,
                                                     save_path=save_path, debug=True)
                article_extractor.get_polygons(save_polygon_img=True)
            except Exception as e:
                print(f"error in page {image_name}",e)
                continue
