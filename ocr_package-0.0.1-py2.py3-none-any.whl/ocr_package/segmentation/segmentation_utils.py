import cv2
import numpy as np
from shapely.geometry.polygon import Polygon, Point
from PIL import Image, ImageDraw
import matplotlib.pyplot as plt
import os

def highlight_each_article_and_remove_inside_articles(img, points, article_idx,
                                                      polygons_inside_plygons_indices, polygons_list,
                                                      return_full_page=True):
    points = np.array(points).astype(int)
    for p in points:
        p[0] = np.clip(p[0], 0, img.shape[1])
        p[1] = np.clip(p[1], 0, img.shape[0])

    mask = np.zeros_like(img)  # Create mask where white is what we want, black otherwise
    cv2.drawContours(mask, [points], -1, 255, thickness=-1)
    ## check if there is article inside this article and if so remove it
    remove_polygon_inside_polygon = False
    polygons_indices_to_remove = []
    if len(polygons_inside_plygons_indices) > 0:
        ## loop over polygon that contains another polygon/(s) and get indices of polygons to remove them
        for i, j in polygons_inside_plygons_indices:
            if article_idx == i:
                remove_polygon_inside_polygon = True
                polygons_indices_to_remove.append(j)
    if return_full_page:
        if remove_polygon_inside_polygon:
            for remove_polygon_idx in polygons_indices_to_remove:
                polygon_to_remove = np.array(polygons_list[remove_polygon_idx]).astype(int)
                cv2.drawContours(mask, [polygon_to_remove], -1, 0, -1,
                                 cv2.LINE_AA)  # remove polygon that is inside polygon
        out = np.copy(img)  # Extract out the object and place into output image
        out = out * 0.5
        out[mask == 255] = img[mask == 255]
    else:
        rect = cv2.boundingRect(points)
        x, y, w, h = rect
        cropped = img[y:y + h, x:x + w].copy()

        pts = points - points.min(axis=0)

        mask = np.zeros(cropped.shape[:2], np.uint8)
        cv2.drawContours(mask, [pts], -1, (255, 255, 255), -1, cv2.LINE_AA)
        if remove_polygon_inside_polygon:
            for remove_polygon_idx in polygons_indices_to_remove:
                polygon_to_remove = np.array(polygons_list[remove_polygon_idx]).astype(int)
                cv2.drawContours(mask, [polygon_to_remove], -1, 0, -1,
                                 cv2.LINE_AA)  # remove polygon that is inside polygon
        dst = cv2.bitwise_and(cropped, cropped, mask=mask)
        return dst

    return out
def extract_article_img(img, points, return_full_page=True):
    points = np.array(points).astype(int)
    for p in points:
        p[0] = np.clip(p[0], 0, img.shape[1])
        p[1] = np.clip(p[1], 0, img.shape[0])
    if return_full_page:
        mask = np.zeros_like(img)  # Create mask where white is what we want, black otherwise
        cv2.drawContours(mask, [points], -1, 255, thickness=-1)
        out = np.copy(img)  # Extract out the object and place into output image
        out = out * 0.5
        out[mask == 255] = img[mask == 255]
    else:
        rect = cv2.boundingRect(points)
        x, y, w, h = rect
        cropped = img[y:y + h, x:x + w].copy()

        pts = points - points.min(axis=0)

        mask = np.zeros(cropped.shape[:2], np.uint8)
        cv2.drawContours(mask, [pts], -1, (255, 255, 255), -1, cv2.LINE_AA)
        dst = cv2.bitwise_and(cropped, cropped, mask=mask)
        return dst
    return out

def check_if_polygon_is_images_with_description(polygon, dict_seg_maps, image):
        polygon_list = np.array(polygon).astype(int)
        mask = np.zeros(image.shape).astype('uint8')
        mask_white = np.ones(image.shape).astype('uint8') * 255
        cv2.drawContours(mask, [polygon_list], -1, (255, 255, 255), -1, cv2.LINE_AA)
        # result = cv2.bitwise_and(mask, self.image_original)
        result_white = cv2.bitwise_and(mask, mask_white)
        image_text_article = cv2.bitwise_and(mask, dict_seg_maps["text"])
        image_description_article = cv2.bitwise_and(mask, dict_seg_maps["description"])
        # image_bg_article = cv2.bitwise_and(mask, dict_seg_maps["bg"])
        # image_titles_article = cv2.bitwise_and(mask, dict_seg_maps["titles"])
        image_images_and_ads_article = cv2.bitwise_and(mask, dict_seg_maps["images"])
        image_images_and_ads_contour_white_pixels = cv2.countNonZero(image_images_and_ads_article)
        # image_bg_contour_white_pixels = cv2.countNonZero(image_bg_article)
        image_text_contour_white_pixels = cv2.countNonZero(image_text_article)
        image_description_contour_white_pixels = cv2.countNonZero(image_description_article)
        # image_titles_contour_white_pixels = cv2.countNonZero(image_titles_article)
        all_white_pixels_count = cv2.countNonZero(result_white)

        if (image_description_contour_white_pixels / all_white_pixels_count > 0.1 and
                image_images_and_ads_contour_white_pixels / all_white_pixels_count > 0.5 and
                image_text_contour_white_pixels / all_white_pixels_count < 0.2):
            return True
        return False

def check_if_rect_inside_polygon(polygon, rect):
    p1,p2,p3,p4 = rect
    polygon1 = Polygon(polygon).buffer(0)
    polygon2 = Polygon(np.array(rect).astype(int)).buffer(0)
    intersection_area = polygon1.intersection(polygon2).area
    if intersection_area / polygon2.area > 0.8:
        return True
    if polygon1.contains(Point(p1)) and polygon1.contains(Point(p2)) and polygon1.contains(Point(p3)) and polygon1.contains(Point(p4)):
        return True
    return False


def check_if_new_polygon_already_exist( polygon, polygons_list):
    for i in range(len(polygons_list)):

        p1 = Polygon(polygon).buffer(0)
        p2 = Polygon(polygons_list[i]).buffer(0)
        try:
            if p1.intersects(p2) and abs(p1.area - p2.area) / (max(p1.area, p2.area)) < 0.2:
                return True
        except Exception as e:
            print("error in check_if_new_polygon_already_exist ")
            print(e)
            return False

def get_polygons_indices_inside_polygons(polygon_list):  # check if any polygon inside any other polygon
    # new_polygon_list = polygon_list.copy()
    polygons_inside_plygons_indices = []
    for i in range(len(polygon_list)):
        for j in range(len(polygon_list)):
            if i == j:
                continue
            try:
                p1 = Polygon(polygon_list[i]).buffer(0)
                p2 = Polygon(polygon_list[j]).buffer(0)
                if p1.contains(p2):
                    polygons_inside_plygons_indices.append((i,j))
                    # new_polygon_list.remove(polygon_list[j])
            except Exception as e:
                print("error in get_polygons_indices_inside_polygons")
                print(e)
    return polygons_inside_plygons_indices

def remove_doubled_contours(polygons_list):
    new_polygon_list = polygons_list.copy()
    for i in range(len(polygons_list)):
        for j in range(len(polygons_list)):
            if i == j:
                continue
            p1 = Polygon(polygons_list[i]).buffer(0)
            p2 = Polygon(polygons_list[j]).buffer(0)
            try:
                if p1.contains(p2) and abs(p1.area - p2.area)/(max(p1.area,p2.area))<0.3:
                    new_polygon_list.remove(polygons_list[j])
            except Exception as e1:
                try:
                    if p2.contains(p2) and abs(p1.area - p2.area)/(max(p1.area,p2.area))<0.3:
                        new_polygon_list.remove(polygons_list[j])
                except Exception as e:
                    print("error in remove doubled contour")
                    print(e)
                print("error in remove doubled contour")
                print(e1)
                continue
    return new_polygon_list

def extract_line_img(img, line):
    # x is vertical dim, y is horizontal dim
    tl, br = line
    min_x = tl[0]
    max_x = br[0]
    min_y = tl[1]
    max_y = br[1]
    height = max_x - min_x
    width = max_y - min_y
    l_margin = int(0.02 * width)
    r_margin = int(0.05 * width)
    t_margin = int(0.06 * height)
    b_margin = int(0.06 * height)
    t = max(0, min_x-t_margin)
    b = min(img.shape[0], max_x+b_margin)
    l = max(0, min_y-l_margin)
    r = min(img.shape[1], max_y+r_margin)
    out = img[t:b, l:r]
    return out

def save_gifs(article_num, article_img_copy, lines_sorted, color, frames):
    c = 1000
    # os.makedirs(os.path.join(debug_path, "lines_contour"), exist_ok=True)
    for i in range(len(lines_sorted)):
        # box, minAreaRect = titles_sorted[i]
        box = lines_sorted[i]
        # box = add_margin_to_rect(box, 3, 3)
        tl, tr, br, bl = tuple(box[0]), tuple(box[1]), tuple(box[2]), tuple(box[3])
        cv2.line(article_img_copy, tl, tr, color, 2, cv2.LINE_AA)
        cv2.line(article_img_copy, tr, br, color, 2, cv2.LINE_AA)
        cv2.line(article_img_copy, br, bl, color, 2, cv2.LINE_AA)
        cv2.line(article_img_copy, bl, tl, color, 2, cv2.LINE_AA)
        # cv2.drawContours(article_img, [box], -1, (120, 200, 129), 3, cv2.LINE_AA)
        # cv2.imwrite(os.path.join(debug_path, 'lines_contour', f'art{article_num + 1}_'+str(c)+'_title_.jpg'),
        #             cv2.resize(article_img,(1000,1000),interpolation=cv2.INTER_AREA))
        # c+=1
        # cv2.imwrite(os.path.join(debug_path, 'lines_contour', f'art{article_num + 1}_'+str(c)+'_title_.jpg'),article_img[tl[1]:br[1],tl[0]:br[0]])
        # c+=1
        frames.append(Image.fromarray(cv2.resize(article_img_copy, (1000, 1000), interpolation=cv2.INTER_AREA)))

    return frames, article_img_copy

def draw_lines_boxes(contours, image, color):
    '''
    Draw contours of lines text and titles on image
    :param contours: box
    :param image:
    :return: image with drawn contours
    '''
    for i in range(len(contours)):
        box = contours[i]
        tl, tr, br, bl = tuple(box[0]), tuple(box[1]), tuple(box[2]), tuple(box[3])
        cv2.line(image, tl, tr, color, 2, cv2.LINE_AA)
        cv2.line(image, tr, br, color, 2, cv2.LINE_AA)
        cv2.line(image, br, bl, color, 2, cv2.LINE_AA)
        cv2.line(image, bl, tl, color, 2, cv2.LINE_AA)
    return image

def draw_box_on_image(contour, image, color):
    '''
    Draw contour on image
    :param contour: box
    :param image:
    :return: image with drawn contours
    '''
    cv2.drawContours(image,[contour],-1,color,3,cv2.LINE_AA)
    return image

def extract_line_img_from_rect_pillow(img, box, minAreaRect, add_margin, margin_x, margin_y): # box -> tl_tr_br_bl
    if add_margin:
        box = add_margin_to_rect(box,margin_x, margin_y)
    box_x1 = max(0,box[0][0])
    box_y1 = max(0,box[0][1])
    box_x2 = max(0,box[1][0])
    box_y2 = max(0,box[1][1])
    box_x3 = max(0,box[2][0])
    box_y3 = max(0,box[2][1])
    box_x4 = max(0,box[3][0])
    box_y4 = max(0,box[3][1])

    min_x = min(box_x1, box_x2, box_x3, box_x4)
    max_x = max(box_x1, box_x2, box_x3, box_x4)
    min_y = min(box_y1, box_y2, box_y3, box_y4)
    max_y = max(box_y1, box_y2, box_y3, box_y4)

    mask = np.zeros(img.shape).astype('uint8')
    cv2.rectangle(mask,(min_x,min_y),(max_x,max_y,),(255,255,255),-1)
    # cv2.rectangle(mask,tl,br,(255,255,255),-1)
    # cv2.drawContours(mask, [box], -1, (255, 255, 255), -1, cv2.LINE_AA)
    result_line = cv2.bitwise_and(mask, img)
    # result_line_crop = result_line[tl[1]:br[1], tl[0]:br[0]]
    result_line_crop = result_line[min_y:max_y, min_x:max_x]

    box = sorted(box, key=lambda x: x[0])  # sort x left to right
    box_y3 = box[2][1]
    box_y4 = box[3][1]
    height = max(box_y3, box_y4) - min((box_y3, box_y4))
    angle = minAreaRect[-1]
    if angle > 45:
        angle = angle - 90

    x_top_left = box[0][0]
    x_bottom_right = box[2][0]
    y_top_left = box[0][1]
    y_bottom_right = box[2][1]
    center_x = (x_top_left + x_bottom_right) // 2
    center_y = (y_top_left + y_bottom_right) // 2
    result_line_crop = Image.fromarray(result_line_crop)
    draw = ImageDraw.Draw(result_line_crop)
    draw.rectangle([(min_x, min_y), (max_x, max_y)], outline="black")
    result_line_crop = result_line_crop.rotate(angle, center=(center_x, center_y), resample=Image.BILINEAR)



    # (h_rotated, w_rotated) = result_line_crop.shape[:2]
    # center = (w_rotated // 2, h_rotated // 2)
    # M = cv2.getRotationMatrix2D(center, angle, 1.0)
    # result_line_crop = cv2.warpAffine(result_line_crop, M, (w_rotated, h_rotated),
    #                                   flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT, borderValue=0)

    # x_rotated = int(center[0] - w_rotated / 2)
    # y_rotated = int(center[1] - height / 2)

    # result_line_crop = result_line_crop[y_rotated:y_rotated + height, x_rotated:x_rotated + w_rotated]
    result_line_crop = np.array(result_line_crop)
    return result_line_crop

def extract_line_img_from_rect(img, box, minAreaRect, add_margin=False, margin_x=0,margin_y=0):
    # TODO: need to speed time
    if add_margin:
        box = add_margin_to_rect(box,margin_x,margin_y)  # to be dynamic
    box_x1 = max(0,box[0][0])
    box_y1 = max(0,box[0][1])
    box_x2 = max(0,box[1][0])
    box_y2 = max(0,box[1][1])
    box_x3 = max(0,box[2][0])
    box_y3 = max(0,box[2][1])
    box_x4 = max(0,box[3][0])
    box_y4 = max(0,box[3][1])

    min_x = min(box_x1, box_x2, box_x3, box_x4)
    max_x = max(box_x1, box_x2, box_x3, box_x4)
    min_y = min(box_y1, box_y2, box_y3, box_y4)
    max_y = max(box_y1, box_y2, box_y3, box_y4)

    # tl, tr, br, bl = tuple(box[0]), tuple(box[1]), tuple(box[2]), tuple(box[3])

    mask = np.zeros(img.shape).astype('uint8')
    cv2.rectangle(mask,(min_x,min_y),(max_x,max_y,),(255,255,255),-1)
    # cv2.rectangle(mask,tl,br,(255,255,255),-1)
    # cv2.drawContours(mask, [box], -1, (255, 255, 255), -1, cv2.LINE_AA)
    result_line = cv2.bitwise_and(mask, img)
    # result_line_crop = result_line[tl[1]:br[1], tl[0]:br[0]]
    result_line_crop = result_line[min_y:max_y, min_x:max_x]

    box = sorted(box, key=lambda x: x[0])  # sort x left to right
    box_y3 = box[2][1]
    box_y4 = box[3][1]
    height = max(box_y3, box_y4) - min((box_y3, box_y4))
    angle = minAreaRect[-1]
    if angle > 45:
        angle = angle - 90

    (h_rotated, w_rotated) = result_line_crop.shape[:2]
    center = (w_rotated // 2, h_rotated // 2)
    M = cv2.getRotationMatrix2D(center, angle, 1.0)
    result_line_crop = cv2.warpAffine(result_line_crop, M, (w_rotated, h_rotated),
                                      flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT, borderValue=0)

    x_rotated = int(center[0] - w_rotated / 2)
    y_rotated = int(center[1] - height / 2)

    result_line_crop = result_line_crop[y_rotated:y_rotated + height, x_rotated:x_rotated + w_rotated]

    return result_line_crop

def resize_seg_maps(seg_maps, original_width, original_height):
    '''
    Resize all seg maps to size of original image
    :param seg_maps: dict{"articles":img, "images":img, "text":img, "titles":img, "bg":img}
    :param original_width:
    :param original_height:
    :return: seg_maps -> resized segmentation maps with passed size
    '''
    seg_maps["articles"] = cv2.resize(seg_maps["articles"], (original_width, original_height),
                                      interpolation=cv2.INTER_AREA)
    seg_maps["images"] = cv2.resize(seg_maps["images"], (original_width, original_height), interpolation=cv2.INTER_AREA)
    seg_maps["titles"] = cv2.resize(seg_maps["titles"], (original_width, original_height), interpolation=cv2.INTER_AREA)
    seg_maps["text"] = cv2.resize(seg_maps["text"], (original_width, original_height), interpolation=cv2.INTER_AREA)
    seg_maps["bg"] = cv2.resize(seg_maps["bg"], (original_width, original_height), interpolation=cv2.INTER_AREA)
    seg_maps["description"] = cv2.resize(seg_maps["description"], (original_width, original_height), interpolation=cv2.INTER_AREA)
    # seg_maps["subtitles"] = cv2.resize(seg_maps["subtitles"], (original_width, original_height), interpolation=cv2.INTER_AREA)
    return seg_maps

def split_merged_image(image_path: str, original_path: str):
    '''
    Take merged image path and get the name of left and right image and read them from original path
    :param image_path: path of merged image
    :param original_path: path of all data, structure -> year, month, day, issue, "JPG"
    :return: image_merged, right_image, left_image, right_image_name, left_image_name
    '''
    image_merged = cv2.imread(image_path, 0)
    image_name = os.path.split(image_path)[-1]
    image_name_split = image_name.split("_")
    right_image_name = "_".join([image_name_split[0], image_name_split[1], image_name_split[2], image_name_split[3],
                                 image_name_split[4]]) + ".jpg"
    right_image = cv2.imread(os.path.join(original_path, image_name_split[0], image_name_split[1], image_name_split[2],
                                          image_name_split[3], "JPG", right_image_name), 0)
    left_image_name = "_".join([image_name_split[0], image_name_split[1], image_name_split[2], image_name_split[3],
                                image_name_split[5].split('.')[0]]) + ".jpg"
    left_image = cv2.imread(os.path.join(original_path, image_name_split[0], image_name_split[1], image_name_split[2],
                                         image_name_split[3], "JPG", left_image_name), 0)
    return image_merged, right_image, left_image, right_image_name, left_image_name

def rotate_box(x_top_left, y_top_left, x_bottom_right, y_bottom_right, image, rotate_angle):
    rotate_angle = 360 - rotate_angle

    center_x = (x_top_left + x_bottom_right) // 2
    center_y = (y_top_left + y_bottom_right) // 2
    image = Image.fromarray(image)
    draw = ImageDraw.Draw(image)
    draw.rectangle([(x_top_left, y_top_left), (x_bottom_right, y_bottom_right)], outline="black")
    rotated_rectangle = image.rotate(rotate_angle, center=(center_x, center_y), resample=Image.BILINEAR)

    return rotated_rectangle

def sort_tl_tr_br_bl(box):
    box = sorted(box, key=lambda x: x[0])
    left = [box[0], box[1]]
    left = sorted(left, key=lambda x: x[1])
    tl = left[0]
    bl = left[1]

    right = [box[2], box[3]]
    right = sorted(right, key=lambda x: x[1])
    tr = right[0]
    br = right[1]
    box = [tl, tr, br, bl]
    return box

def add_margin_to_rect(box, margin_x, margin_y):
    box_original = box.copy()
    box_copy = box.copy()
    box = [(xb, yb) for xb, yb in box_original]
    box_indices = np.argsort(np.array(box, dtype=[('x', '<i4'), ('y', '<i4')]), order=('x', 'y')) #sort left to right #i means signed integer, 4 means a 4-byte size
    if box_copy[box_indices[0]][0] - margin_x*2 > 0 and box_copy[box_indices[1]][0] - margin_x*2>0:
        box_copy[box_indices[0]][0] = box_copy[box_indices[0]][0] - margin_x*2  # add margin to left x
        box_copy[box_indices[1]][0] = box_copy[box_indices[1]][0] - margin_x*2

    box_copy[box_indices[2]][0] = box_copy[box_indices[2]][0] + margin_x*2  # add margin to right x
    box_copy[box_indices[3]][0] = box_copy[box_indices[3]][0] + margin_x*2

    box_indices = np.argsort(np.array(box, dtype=[('x', '<i4'), ('y', '<i4')]),
                             order=('y', 'x'))  # sort left to right #i means signed integer, 4 means a 4-byte size
    if box_copy[box_indices[0]][1] - margin_y > 0 and box_copy[box_indices[1]][1] - margin_y > 0:
        box_copy[box_indices[0]][1] = box_copy[box_indices[0]][1] - margin_y   # add margin to top y
        box_copy[box_indices[1]][1] = box_copy[box_indices[1]][1] - margin_y

    box_copy[box_indices[2]][1] = box_copy[box_indices[2]][1] + margin_y  # add margin to bottom y
    box_copy[box_indices[3]][1] = box_copy[box_indices[3]][1] + margin_y

    return box_copy

def remove_seg_map_from_another(polygon_to_remove, seg_map_remove_from):
    '''
    Take polygon coordinates that want to remove it and segmentation map want to remove polygon from it
    :param polygon_to_remove:
    :param seg_map_remove_from:
    :return: segmentation map after removing the polygon
    '''
    mask = np.zeros(seg_map_remove_from.shape).astype('uint8')
    cv2.drawContours(mask, [polygon_to_remove], -1, (255, 255, 255), -1,
                     cv2.LINE_AA)  # the mask now has the polygon shape in white pixels
    image = cv2.bitwise_and(mask, seg_map_remove_from)  # make and operation to get lines instead of block
    return image

def display(image, title=""):
    plt.figure(figsize=(20, 20))
    plt.imshow(image)
    plt.title(title)
    plt.show()

def add_margin_box(box, margin_h, margin_v):
    x1,y1,w1,h1 = box
    if x1 - margin_h < 0:
        margin_h = 0
    if y1 - margin_v < 0:
        margin_v = 0
    x1 = x1 - margin_h
    w1 = w1 + margin_h * 2
    y1 = y1 - margin_v
    h1 = h1 + margin_v * 2
    return [x1,y1,w1,h1]