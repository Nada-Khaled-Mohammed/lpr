# path =r"D:\gitlab_updated\ocr_package\ocr_package\generators\test_data"
import os

from ocr_package.segmentation.line_segmenter import Line_segmenter
path = r"D:\data\car_licence"

line_seg = Line_segmenter(model_path='D:\All_Models\Segmentation\Line_segmentation\Ids\line_seg_revisit_v10.h5'
                          , img_width=512, img_height=384)  # to train from scratch

for image in os.listdir(path):
    line_seg.evaluate(os.path.join(path, image),plot=True)