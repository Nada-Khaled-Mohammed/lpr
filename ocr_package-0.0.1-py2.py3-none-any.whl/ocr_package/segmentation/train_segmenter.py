# path =r"D:\gitlab_updated\ocr_package\ocr_package\generators\test_data"

# line_seg = Line_segmenter(img_width=384, img_height=512)  # to train from scratch
line_seg = Line_segmenter(model_path='D:/All_Models/Segmentation/Line_segmentation/Court/line_seg_court_augraphy_v5.h5'
                          , img_width=384, img_height=512)  # to train from scratch

for denoised_image, clean_image in lines_generator.generate_images():
    line_seg.inspect_augmentation(denoised_image, clean_image)

line_seg.train(train_paths=None, generator=lines_generator, lr=1e-3, use_augmentation=True,
               model_save_path='D:/All_Models/Segmentation/Line_segmentation/Court/line_seg_court_augraphy_v6.h5')
