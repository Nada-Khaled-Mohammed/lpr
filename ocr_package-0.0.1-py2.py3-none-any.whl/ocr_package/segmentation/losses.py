import tensorflow.keras.backend as K
import numpy as np
import tensorflow as tf
from scipy.ndimage import distance_transform_edt as distance


def calc_dist_map(seg):
    res = np.zeros_like(seg)
    posmask = seg.astype(np.bool)

    if posmask.any():
        negmask = ~posmask
        res = distance(negmask) * negmask - (distance(posmask) - 1) * posmask

    return res


def calc_dist_map_batch(y_true):
    y_true_numpy = y_true.numpy()
    return np.array([calc_dist_map(y)
                     for y in y_true_numpy]).astype(np.float32)

@tf.keras.utils.register_keras_serializable()
def surface_loss_keras(y_true, y_pred):
    y_true_dist_map = tf.py_function(func=calc_dist_map_batch,
                                     inp=[y_true],
                                     Tout=tf.float32)
    multipled = y_pred * y_true_dist_map
    return K.mean(multipled)

def dice_coef(y_true, y_pred, smooth=1):
    y_true_f = K.flatten(y_true)
    y_pred_f = K.flatten(y_pred)
    intersection = K.sum(y_true_f * y_pred_f)
    return (2. * intersection + smooth) / (K.sum(y_true_f) + K.sum(y_pred_f) + smooth)

@tf.keras.utils.register_keras_serializable()
def dice_coef_loss(y_true, y_pred):
    return 1 - dice_coef(y_true, y_pred)

def DiceBCELoss(targets, inputs, smooth=1e-6):
    # flatten label and prediction tensors
    inputs = K.flatten(inputs)
    targets = K.flatten(targets)

    BCE = tf.keras.losses.binary_crossentropy(targets, inputs)
    intersection = K.sum(K.dot(targets, inputs))
    dice_loss = 1 - (2 * intersection + smooth) / (K.sum(targets) + K.sum(inputs) + smooth)
    Dice_BCE = BCE + dice_loss

    return Dice_BCE

def tversky(y_true, y_pred, smooth=1e-6, alpha=0.85):
    y_true_pos = K.flatten(y_true)
    y_pred_pos = K.flatten(y_pred)
    true_pos = K.sum(y_true_pos * y_pred_pos)
    false_neg = K.sum(y_true_pos * (1 - y_pred_pos))
    false_pos = K.sum((1 - y_true_pos) * y_pred_pos)
    return (true_pos + smooth) / (true_pos + alpha * false_neg + (1 - alpha) * false_pos + smooth)

@tf.keras.utils.register_keras_serializable()
def tversky_loss(y_true, y_pred):
    return 1 - tversky(y_true, y_pred)

@tf.keras.utils.register_keras_serializable()
def focal_tversky_loss(y_true, y_pred, gamma=1.1, smooth=1e-6, alpha=0.85):
    tv = tversky(y_true, y_pred, smooth=smooth, alpha=alpha)
    return K.pow((1 - tv), gamma)

@tf.keras.utils.register_keras_serializable()
def loss_art_seg(y_true, y_pred, gamma=1.2, alpha=0.85):
    return focal_tversky_loss(y_true, y_pred, gamma=gamma, smooth=1e-6, alpha=alpha)

@tf.keras.utils.register_keras_serializable()
def loss_line_seg(y_true, y_pred):
    return focal_tversky_loss(y_true, y_pred, gamma=1.8, smooth=1e-6, alpha=0.5)

@tf.keras.utils.register_keras_serializable()
def FocalDiceBCE(inputs, targets, gamma=2.0, smooth=1e-6):
    inputs = K.flatten(inputs)
    targets = K.flatten(targets)

    BCE = tf.keras.losses.binary_crossentropy(targets, inputs)
    intersection = K.sum(targets * inputs)
    dice_loss = 1 - (2 * intersection + smooth) / (K.sum(targets) + K.sum(inputs) + smooth)
    Focal_Dice_BCE = K.pow((1 - (BCE + dice_loss)), gamma)

    return Focal_Dice_BCE

@tf.keras.utils.register_keras_serializable()
def log_cosh_dice_loss(y_true, y_pred):
    x = dice_coef_loss(y_true, y_pred)
    return tf.math.log((tf.exp(x) + tf.exp(-x)) / 2.0)

@tf.keras.utils.register_keras_serializable()
def SSIM(y_true, y_pred):
    return tf.reduce_mean(tf.image.ssim(y_true, y_pred, 1.0))

@tf.keras.utils.register_keras_serializable()
def SSIMLoss(y_true, y_pred):
    return 1 - tf.reduce_mean(tf.image.ssim(y_true, y_pred, 1.0))

@tf.keras.utils.register_keras_serializable()
def PSNR(y_true, y_pred):
    psnr_value = tf.image.psnr(y_true, y_pred, max_val=255)[0]
    return psnr_value

@tf.keras.utils.register_keras_serializable()
def mae_ssim_loss(y_true, y_pred, gamma=0.5):
    mae = tf.keras.losses.MeanAbsoluteError()
    ssim = SSIMLoss(y_true, y_pred)
    return (mae(y_true, y_pred) * gamma) + (ssim * (1 - gamma))

@tf.keras.utils.register_keras_serializable()
def MS_SSIM(y_true, y_pred):
    return 1 - tf.reduce_mean(tf.image.ssim_multiscale(y_true, y_pred, 1.0))