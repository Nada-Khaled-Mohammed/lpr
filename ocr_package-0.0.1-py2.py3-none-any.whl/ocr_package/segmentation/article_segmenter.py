import numpy as np
import matplotlib.pyplot as plt
import os
import cv2
import tensorflow as tf

from tensorflow.keras.models import Model, load_model
from tensorflow.keras import layers
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Input, AveragePooling2D, Dropout
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint, ReduceLROnPlateau
from tensorflow.keras.optimizers import Adam
from PIL import Image
from pathlib import Path
import random as pyrandom
from ocr_package.segmentation.losses import dice_coef_loss, loss_art_seg
import tensorflow_addons as tfa
from ocr_package.image_utils.add_noise import add_noise

SEED = 1
np.random.seed(SEED)
pyrandom.seed(SEED)



class DSV:
    def __init__(self, scale_factor=1, use_classes=False):
        self.scale_factor = scale_factor
        if use_classes:
            self.classes = 4
        else:
            self.classes = 32

    def upsample_layer(self, inputs):
        # self.conv = tf.keras.layers.Conv2D(self.classes, kernel_size=1, padding="same",kernel_initializer="he_uniform")
        # self.upsample = tf.keras.layers.UpSampling2D([self.scale_factor, 1])
        # x = self.conv(inputs)
        # x = tf.keras.layers.Conv2D(self.classes, kernel_size=1, padding="same",kernel_initializer="he_uniform")(inputs)
        x = tf.keras.layers.UpSampling2D([self.scale_factor, 1])(inputs)
        return x

class Article_segmenter:
    def __init__(self, model_path=None, img_height=512, img_width=384):
        self.img_height = img_height
        self.img_width = img_width
        self.batch_size = 4
        self.use_articles = True  # whether to train on article seg data
        self.use_classes = True  # whether to train on classes seg data
        self.use_ads = True  # whether to train on ads seg data
        if model_path is not None:
            self.model = load_model(model_path)
        else:
            self.model = self._create_model()
            # self.model = self._create_model_scAG()
        # self.model.summary()

    def _create_model(self):
        def conv_block(x, num_filters=64, name=None):
            # Second conv block
            x = layers.Conv2D(
                num_filters,
                (3, 3),
                kernel_initializer="he_normal",
                padding="same",
                name=name + 'conv1'
            )(x)
            x = tfa.layers.InstanceNormalization(axis=3,
                                                 center=True,
                                                 scale=True,
                                                 beta_initializer="random_uniform",
                                                 gamma_initializer="random_uniform")(x)
            x = layers.Activation('relu')(x)
            x = Dropout(0.2)(x)
            # Third conv block
            x = layers.Conv2D(
                num_filters,
                (3, 3),
                kernel_initializer="he_normal",
                padding="same",
                name=name + 'conv2'
            )(x)
            x = tfa.layers.InstanceNormalization(axis=3,
                                                 center=True,
                                                 scale=True,
                                                 beta_initializer="random_uniform",
                                                 gamma_initializer="random_uniform")(x)
            x = layers.Activation('relu', name=name + 'last_activation')(x)
            x = Dropout(0.2)(x)
            return x

        input_layer = Input(shape=(None, None, 1), name='page_in')
        x = input_layer
        # encoding
        residuals = []
        for num_filters in [32, 64, 128, 256]:
            x = conv_block(x, num_filters=num_filters, name='down_path' + str(num_filters))
            residuals.append(x)
            x = MaxPooling2D((2, 2), padding='same')(x)

        x = conv_block(x, num_filters=512, name='bottleneck' + str(512))

        for num_filters in [256, 128, 64]:
            x = layers.Conv2DTranspose(num_filters, (3, 3), strides=(2, 2), padding='same')(x)
            x = layers.Concatenate()([x, residuals.pop()])
            x = conv_block(x, num_filters=num_filters, name='up_path' + str(num_filters))
        x = layers.Conv2DTranspose(32, (3, 3), strides=(2, 2), padding='same', name='last_upsample')(x)
        x = layers.Concatenate(name='last_concat')([x, residuals.pop()])
        # output heads
        class_ouput = conv_block(x, num_filters=32, name='classes_head')
        class_output = Conv2D(4, (1, 1), padding='same', activation='softmax', name='classes')(class_ouput)
        article_output = conv_block(x, num_filters=32, name='articles_head')
        article_output = Conv2D(1, (1, 1), padding='same', activation='sigmoid', name='articles')(article_output)
        ads_output = conv_block(x, num_filters=32, name='ads_head')
        ads_output = Conv2D(1, (1, 1), padding='same', activation='sigmoid', name='ads')(ads_output)

        model = Model(inputs=[input_layer], outputs=[article_output, class_output, ads_output])
        return model

    def _create_model_scAG(self):
        def conv_block(x, num_filters=64, name=None):
            # Second conv block
            x = layers.Conv2D(
                num_filters,
                (3, 3),
                kernel_initializer="he_normal",
                padding="same",
                name=name + 'conv1'
            )(x)
            x = tfa.layers.InstanceNormalization(axis=3,
                                                 center=True,
                                                 scale=True,
                                                 beta_initializer="random_uniform",
                                                 gamma_initializer="random_uniform")(x)

            x = layers.Activation('relu')(x)

            # Third conv block
            x = layers.Conv2D(
                num_filters,
                (3, 3),
                kernel_initializer="he_normal",
                padding="same",
                name=name + 'conv2'
            )(x)
            x = tfa.layers.InstanceNormalization(axis=3,
                                                 center=True,
                                                 scale=True,
                                                 beta_initializer="random_uniform",
                                                 gamma_initializer="random_uniform")(x)
            x = layers.Activation('relu', name=name + 'last_activation')(x)

            return x

        def sAG(x):
            avg_pool = AveragePooling2D((1, 1), padding='same')(x)
            max_pool = MaxPooling2D((1, 1), padding='same')(x)
            conv_layer = Conv2D(1, (1, 1), kernel_initializer="he_normal",padding="same",)(x)
            concat = layers.Concatenate()([avg_pool, max_pool,conv_layer])
            output = Conv2D(1, (7, 7),strides=1, padding='same',
                       kernel_initializer='he_normal')(concat) #use bias = False

            return output

        def cAG(x,num_filters):
            shared_layer_one = Conv2D(num_filters//16,1, activation='relu')
            shared_layer_two = Conv2D(num_filters,1)
            avg_pool = AveragePooling2D((1, 1), padding='same')(x)
            max_pool = MaxPooling2D((1, 1), padding='same')(x)
            avg_pool = shared_layer_one(avg_pool)
            avg_pool = shared_layer_two(avg_pool)
            max_pool = shared_layer_one(max_pool)
            max_pool = shared_layer_two(max_pool)
            output_shared = layers.Add()([avg_pool,max_pool])
            # output_shared = layers.Activation('sigmoid')(output_shared)
            # return layers.Multiply()([output_shared,x])
            return output_shared

        def scAG(x,num_filters):
            x_s = sAG(x)
            x_c = cAG(x,num_filters)
            return layers.Multiply()([x_s,x_c])

        input_layer = Input(shape=(None, None, 1), name='page_in')
        x = input_layer
        # encoding
        # residuals = []
        gate_output = []
        dsv_outputs = []
        for num_filters in [32, 64, 128, 256]:
            x = conv_block(x, num_filters=num_filters, name='down_path' + str(num_filters))
            gate_output.append(scAG(x,num_filters))
            # residuals.append(x)
            x = MaxPooling2D((2, 2), padding='same')(x)

        x = conv_block(x, num_filters=512, name='bottleneck' + str(512))

        # decoding
        filters = [256, 128, 64]
        for i,num_filters in enumerate(filters):
            x = layers.Conv2DTranspose(num_filters, (3, 3), strides=(2, 2), padding='same')(x)
            x = layers.Concatenate()([x, gate_output.pop()])
            x = conv_block(x, num_filters=num_filters, name='up_path' + str(num_filters))
            x_dsv = x
            for j in range(len(filters)-i-1):
                # x_dsv = tf.keras.layers.UpSampling2D([256 // filters[j+i+1], 1])(x_dsv)
                x_dsv = layers.Conv2DTranspose(filters[j+i+1], (3, 3), strides=(2, 2), padding='same')(x_dsv)
            # x_dsv = DSV(scale_factor=num_filters).upsample_layer(x)
            # x_dsv = layers.Conv2DTranspose(32, (3, 3), strides=(2, 2), padding='same')(x)
            # x_dsv = tf.keras.layers.UpSampling2D([256//num_filters, 1])(x)
            # x_dsv = tf.keras.layers.UpSampling3D(size=(1, 1,256//num_filters))(x)
            x_dsv = layers.Conv2DTranspose(32, (3, 3), strides=(2, 2), padding='same')(x_dsv)
            dsv_outputs.append(x_dsv)

        x = layers.Conv2DTranspose(32, (3, 3), strides=(2, 2), padding='same', name='last_upsample')(x)
        x = layers.Add(name='last_concat')([x,gate_output.pop()])
        concat_layer = tf.keras.layers.Add()(dsv_outputs)
        # concat_layer = layers.Conv2DTranspose(32, (3, 3), strides=(2, 2), padding='same')(concat_layer)
        x = conv_block(x, num_filters=32, name='fusion_module')
        x = tf.keras.layers.Concatenate()([concat_layer,x])
        # output heads
        class_ouput = conv_block(x, num_filters=32, name='classes_head')
        class_output = Conv2D(4, (1, 1), padding='same', activation='softmax', name='classes')(class_ouput)
        article_output = conv_block(x, num_filters=32, name='articles_head')
        article_output = Conv2D(1, (1, 1), padding='same', activation='sigmoid', name='articles')(article_output)
        ads_output = conv_block(x, num_filters=32, name='ads_head')
        ads_output = Conv2D(1, (1, 1), padding='same', activation='sigmoid', name='ads')(ads_output)

        model = Model(inputs=[input_layer], outputs=[article_output, class_output, ads_output])
        return model

    def _compile_model(self, lr=0.001, freeze_core_model=False, articles_weight=1.0, classes_weight=1.0,
                       ads_weight=1.0):
        losses = {
            "articles": loss_art_seg,
            "classes": dice_coef_loss,
            "ads": dice_coef_loss,
        }
        loss_weights = {"articles": articles_weight * int(self.use_articles),
                        "classes": classes_weight * int(self.use_classes),
                        "ads": ads_weight * int(self.use_ads)
                        }
        optimizer = Adam(lr=lr)
        if freeze_core_model:
            for layer in self.model.layers:
                # core_model = Model(self.model.get_layer('page_in'), self.model.get_layer('core_model_out'))
                # core_model.trainable = False
                layer.trainable = False
                if self.use_articles:
                    if 'article' in layer.name:
                        layer.trainable = True
                if self.use_classes:
                    if 'class' in layer.name:
                        layer.trainable = True
                if self.use_ads:
                    if 'ads' in layer.name:
                        layer.trainable = True
        self.model.compile(optimizer=optimizer, loss=losses, loss_weights=loss_weights)
        self.model.summary()

    def _segment(self, img):
        if isinstance(img, str):
            img = self.process_image(img)
        if len(img.shape) < 4:
            img = img[np.newaxis, :, :]
        input = img.reshape((-1, self.img_height, self.img_width, 1))
        out = self.model.predict(input, batch_size=8)
        return out

    def process_image(self, path):
        if isinstance(path, str):
            # img = cv2.imread(path,0)
            # img = cv2.resize(img, (self.img_width, self.img_height), interpolation=cv2.INTER_AREA)
            img = Image.open(path)
            img = img.convert(mode='L')
            img = img.resize((self.img_width, self.img_height), resample=Image.LANCZOS)
            img = np.array(img, dtype="float32")
        else:
            img = cv2.resize(path, (self.img_width, self.img_height), interpolation=cv2.INTER_AREA)
        if len(img.shape) == 3:
            img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        img = img / 255.0
        img = img.reshape((img.shape[0], img.shape[1], 1))
        return img

    def _prepare_single_sample_train(self, page_path, articles_path, bg_path, text_path, titles_path, images_path,
                                     ads_path):

        def read_prep_image(img_path):
            img = tf.io.read_file(img_path)
            img = tf.io.decode_png(img, channels=1)
            img = tf.image.convert_image_dtype(img, tf.float32)
            img = tf.image.resize(img, [self.img_height, self.img_width], method=tf.image.ResizeMethod.AREA)
            return img

        page = read_prep_image(page_path)
        if self.use_articles:
            articles = read_prep_image(articles_path)
        else:
            articles = tf.zeros_like(page)
        if self.use_classes:
            bg = read_prep_image(bg_path)
            text = read_prep_image(text_path)
            titles = read_prep_image(titles_path)
            images = read_prep_image(images_path)
        else:
            bg = tf.zeros_like(page)
            text = tf.zeros_like(page)
            titles = tf.zeros_like(page)
            images = tf.zeros_like(page)
        if self.use_ads:
            ads = read_prep_image(ads_path)
        else:
            ads = tf.zeros_like(page)

        classes = tf.stack([tf.squeeze(x) for x in (bg, text, titles, images)], axis=-1)  # stack along the channel axis
        return page, {'articles': articles, 'classes': classes, 'ads': ads}

    def _apply_augmentation(self, page, label_dict):
        def tf_augment_image(image):
            im_shape = image.shape
            [image, ] = tf.py_function(self._augment_image, [image], [tf.float32])
            image.set_shape(im_shape)
            return image

        # augmentation ops that run on just the page input
        brightness_factor = tf.random.uniform(shape=[], minval=-0.3, maxval=0.3)
        page = tf.image.adjust_brightness(page, brightness_factor)
        page = tf.image.random_contrast(page, lower=0.5, upper=1.5, seed=SEED)
        page = tf.clip_by_value(page, 0, 1)
        # perform augmentation ops that run on outputs as well
        all_stacked = tf.stack([tf.squeeze(page),
                                tf.squeeze(label_dict['articles']),
                                label_dict['classes'][:, :, 0],
                                label_dict['classes'][:, :, 1],
                                label_dict['classes'][:, :, 2],
                                label_dict['classes'][:, :, 3],
                                tf.squeeze(label_dict['ads'])
                                ], axis=-1)
        all_stacked = tf_augment_image(all_stacked)
        all_stacked = tf.image.resize(all_stacked, [self.img_height, self.img_width],
                                      method=tf.image.ResizeMethod.AREA)
        all_stacked = tf.image.random_flip_left_right(all_stacked, seed=SEED)

        page = tf.expand_dims(all_stacked[..., 0], axis=-1)
        articles = tf.expand_dims(all_stacked[..., 1], axis=-1)
        classes = all_stacked[..., 2:6]
        ads = tf.expand_dims(all_stacked[..., 6], axis=-1)
        return page, {'articles': articles, 'classes': classes, 'ads': ads}

    def _augment_image(self, all_stacked):
        all_stacked = all_stacked.numpy() * 255
        all_stacked = all_stacked.astype('uint8')
        if np.random.random() <= 0.1:
            page = add_noise(all_stacked[:, :, 0])
            all_stacked[:, :, 0] = page

        # Add white borders of random length in each direction
        # if np.random.random() <= 0.3:
        #     base_border_size = np.random.randint(0, 20)
        #     border_range = 5
        #     top_border = max(0, np.random.randint(base_border_size - border_range, base_border_size + border_range))
        #     bottom_border = max(0, np.random.randint(base_border_size - border_range, base_border_size + border_range))
        #     left_border = max(0, np.random.randint(base_border_size - border_range, base_border_size + border_range))
        #     right_border = max(0, np.random.randint(base_border_size - border_range, base_border_size + border_range))
        #     all_stacked = cv2.copyMakeBorder(all_stacked, top_border, bottom_border, left_border, right_border, cv2.BORDER_REPLICATE, 0)
        if np.random.random() <= 0.5:
            all_stacked = tf.keras.preprocessing.image.random_shift(
                all_stacked, 0.02, 0.03, row_axis=1, col_axis=0, channel_axis=2,
                fill_mode='nearest', cval=0.0, interpolation_order=1
            )
        else:
            all_stacked = tf.keras.preprocessing.image.random_rotation(
                all_stacked, 1, row_axis=1, col_axis=0, channel_axis=2,
                fill_mode='nearest', cval=0.0, interpolation_order=1
            )
        if np.random.random() <= 0.1:
            all_stacked[..., 0] = cv2.bitwise_not(all_stacked[..., 0])
        # if np.random.random() <= 0.3:
        #     filter_size = np.random.choice([3, 5, 7])
        #     articles = cv2.GaussianBlur(all_stacked[:, :, 1], (filter_size, filter_size), 0)
        #     all_stacked[:, :, 1] = articles

        # else:
        #     image = cv2.adaptiveThreshold(image, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2)
        # image = image[..., np.newaxis]
        image = tf.convert_to_tensor(all_stacked / 255, dtype=tf.float32)
        return image

    def prepare_datasets(self, src_paths, use_augmentation=True):
        pages = []
        for src_path in src_paths:
            pages_path = Path(os.path.join(src_path, 'pages'))
            ds_pages = sorted(list(map(str, list(pages_path.rglob("*.jpg")))))
            pages += ds_pages
            print(f'Found {len(ds_pages)} samples in {src_path}.')
        print(f'Found a total of {len(pages)} samples.')

        def split_data(images, train_size=0.9, shuffle=True):
            # 1. Get the total size of the dataset
            size = len(images)
            # 2. Make an indices array and shuffle it, if required
            indices = np.arange(size)
            if shuffle:
                np.random.seed(SEED)
                np.random.shuffle(indices)
            # 3. Get the size of training samples
            train_samples = int(size * train_size)
            # 4. Split data into training and validation sets
            x_train = images[indices[:train_samples]]
            x_valid = images[indices[train_samples:]]
            return x_train, x_valid

        # Splitting data into training and validation sets
        pages_train, pages_val = split_data(np.array(pages))
        articles_train = [page.replace('pages', 'articles') for page in pages_train]
        articles_val = [page.replace('pages', 'articles') for page in pages_val]
        bg_train = [page.replace('pages', 'bg') for page in pages_train]
        bg_val = [page.replace('pages', 'bg') for page in pages_val]
        text_train = [page.replace('pages', 'text') for page in pages_train]
        text_val = [page.replace('pages', 'text') for page in pages_val]
        titles_train = [page.replace('pages', 'titles') for page in pages_train]
        titles_val = [page.replace('pages', 'titles') for page in pages_val]
        images_train = [page.replace('pages', 'ads_images') for page in pages_train]
        images_val = [page.replace('pages', 'ads_images') for page in pages_val]
        ads_train = [page.replace('pages', 'ads') for page in pages_train]
        ads_val = [page.replace('pages', 'ads') for page in pages_val]

        # images_ads_train = [page.replace('pages', 'ads_images') for page in pages_train]
        # images_ads_val = [page.replace('pages', 'ads_images') for page in pages_val]
        # description_train = [page.replace('pages', 'description') for page in pages_train]
        # description_val = [page.replace('pages', 'description') for page in pages_val]
        # other_train = [page.replace('pages', 'other') for page in pages_train]
        # other_val = [page.replace('pages', 'other') for page in pages_val]


        train_dataset = tf.data.Dataset.from_tensor_slices(
            (pages_train, articles_train, bg_train, text_train, titles_train, images_train, ads_train))
        train_dataset = train_dataset.shuffle(len(pages_train), reshuffle_each_iteration=True)\
            .map(self._prepare_single_sample_train, num_parallel_calls=tf.data.experimental.AUTOTUNE)
        if use_augmentation:
            train_dataset.map(self._apply_augmentation, num_parallel_calls=tf.data.experimental.AUTOTUNE)
        train_dataset = train_dataset.padded_batch(self.batch_size) \
            .prefetch(buffer_size=tf.data.experimental.AUTOTUNE)

        validation_dataset = tf.data.Dataset.from_tensor_slices(
            (pages_val, articles_val, bg_val, text_val, titles_val, images_val, ads_val))
        validation_dataset = (
            validation_dataset.shuffle(len(pages_val), reshuffle_each_iteration=True, seed=SEED)
                .map(
                self._prepare_single_sample_train, num_parallel_calls=tf.data.experimental.AUTOTUNE
            )
                .padded_batch(self.batch_size)
                .prefetch(buffer_size=tf.data.experimental.AUTOTUNE)
        )
        return train_dataset, validation_dataset

    def train(self, src_paths, freeze_core_model=False, use_augmentation=True, lr=0.001, use_articles=True,
              use_ads=True, use_classes=True, model_path=""):
        self.use_articles = use_articles
        self.use_classes = use_classes
        self.use_ads = use_ads
        train_dataset, validation_dataset = self.prepare_datasets(src_paths, use_augmentation=use_augmentation)

        es_callback = EarlyStopping(monitor='val_loss', patience=20, verbose=1)
        cp_callback = ModelCheckpoint(filepath=model_path,
                                      save_best_only=True, verbose=1)
        lr_callback = ReduceLROnPlateau(monitor='val_loss', factor=0.5,
                                        patience=3, min_lr=0.00001, verbose=1)
        callbacks = [es_callback, cp_callback, lr_callback]

        self._compile_model(lr=lr, freeze_core_model=freeze_core_model)
        try:
            history = self.model.fit(train_dataset, validation_data=validation_dataset, epochs=500,
                                     verbose=1, callbacks=callbacks)

            epoch_loss = history.history['loss']
            epoch_val_loss = history.history['val_loss']

            plt.figure(figsize=(20, 6))
            plt.subplot(1, 2, 1)
            plt.plot(range(0, len(epoch_loss)), epoch_loss, 'b-', linewidth=2, label='Train Loss')
            plt.plot(range(0, len(epoch_val_loss)), epoch_val_loss, 'r-', linewidth=2, label='Val Loss')
            plt.title('Evolution of loss on train & validation datasets over epochs')
            plt.legend(loc='best')

            plt.show()
        finally:
            print("DONE")
            # don't save the model (last model isn't necessary the best)
            # self.model.save('../../models/segmentation/article_segmentation/mosawer/single_pages_segmentation/mosawer_articles_seg_splitted_pages_v6_final.h5')

    def inspect_dataset(self, src_paths, use_augmentation=False):
        train_dataset, val_dataset = self.prepare_datasets(src_paths, use_augmentation)
        for batch in train_dataset.take(5):
            batch_pages = batch[0]
            batch_seg = batch[1]

            for i in range(batch_pages.shape[0]):
                img = (batch_pages[i] * 255).numpy().astype("uint8")
                plt.figure()
                plt.subplot(1, 7, 1)
                plt.imshow(img, cmap='gray')
                plt.title('GT')

                articles = (batch_seg['articles'][i] * 255).numpy().astype("uint8")
                plt.subplot(1, 7, 2)
                plt.imshow(articles, cmap='gray')
                plt.title('Articles')

                bg = (batch_seg['classes'][i, ..., 0] * 255).numpy().astype("uint8")
                plt.subplot(1, 7, 3)
                plt.imshow(bg, cmap='gray')
                plt.title('Background')

                text = (batch_seg['classes'][i, ..., 1] * 255).numpy().astype("uint8")
                plt.subplot(1, 7, 4)
                plt.imshow(text, cmap='gray')
                plt.title('Text')

                titles = (batch_seg['classes'][i, ..., 2] * 255).numpy().astype("uint8")
                plt.subplot(1, 7, 5)
                plt.imshow(titles, cmap='gray')
                plt.title('Titles')

                images = (batch_seg['classes'][i, ..., 3] * 255).numpy().astype("uint8")
                plt.subplot(1, 7, 6)
                plt.imshow(images, cmap='gray')
                plt.title('Images')

                ads = (batch_seg['ads'][i, ...] * 255).numpy().astype("uint8")
                plt.subplot(1, 7, 7)
                plt.imshow(ads, cmap='gray')
                plt.title('Ads')

                plt.show()

    def evaluate(self, img_path, plot=False):
        img = self.process_image(img_path)
        preds = self._segment(img)
        out = {
            'articles': (preds[0][0, ...] * 255).astype("uint8"),
            'bg': (preds[1][0, ..., 0] * 255).astype("uint8"),
            'text': (preds[1][0, ..., 1] * 255).astype("uint8"),
            'titles': (preds[1][0, ..., 2] * 255).astype("uint8"),
            'images': (preds[1][0, ..., 3] * 255).astype("uint8"),
            'ads': (preds[2][0, ...] * 255).astype("uint8")
        }
        if plot:
            plt.figure()
            plt.subplot(1, 7, 1)
            plt.imshow(img, cmap='gray')
            plt.title('Page')

            plt.subplot(1, 7, 2)
            plt.imshow(out['articles'], cmap='gray')
            plt.title('Articles')

            plt.subplot(1, 7, 3)
            plt.imshow(out['bg'], cmap='gray')
            plt.title('Background')

            plt.subplot(1, 7, 4)
            plt.imshow(out['text'], cmap='gray')
            plt.title('Text')

            plt.subplot(1, 7, 5)
            plt.imshow(out['titles'], cmap='gray')
            plt.title('Titles')

            plt.subplot(1, 7, 6)
            plt.imshow(out['images'], cmap='gray')
            plt.title('Images')

            plt.subplot(1, 7, 7)
            plt.imshow(out['ads'], cmap='gray')
            plt.title('Ads')

            plt.show()
        return out
    def evaluate_batch(self, img_list):
        if type(img_list) == str:
            dataset = [self.process_image(os.path.join(img_list,img)) for img in os.listdir(img_list)]
        else:
            dataset = [self.process_image(img) for img in img_list]
        dataset = (tf.data.Dataset.from_tensor_slices(dataset)
                   .padded_batch(batch_size=self.batch_size)
                   .prefetch(buffer_size=tf.data.experimental.AUTOTUNE))
        predictions_all = []
        for batch in dataset.take(-1):
            preds = self.model.predict(batch, batch_size=self.batch_size)
            for i in range(len(preds[0])):
                out = {
                    'articles': (preds[0][i, ...] * 255).astype("uint8"),
                    'bg': (preds[1][i, ..., 0] * 255).astype("uint8"),
                    'text': (preds[1][i, ..., 1] * 255).astype("uint8"),
                    'titles': (preds[1][i, ..., 2] * 255).astype("uint8"),
                    'images': (preds[1][i, ..., 3] * 255).astype("uint8"),
                    'ads': (preds[2][i, ...] * 255).astype("uint8")
                }
                predictions_all.append(out)
        return predictions_all

    def evaluate_compare(self, img_path, candidate=None, plot=True):
        img = self.process_image(img_path)
        preds = self._segment(img)
        out = {
            'articles': (preds[0][0, ...] * 255).astype("uint8"),
            'bg': (preds[1][0, ..., 0] * 255).astype("uint8"),
            'text': (preds[1][0, ..., 1] * 255).astype("uint8"),
            'titles': (preds[1][0, ..., 2] * 255).astype("uint8"),
            'images': (preds[1][0, ..., 3] * 255).astype("uint8"),
            'ads': (preds[2][0, ...] * 255).astype("uint8")
        }
        if plot:
            plt.figure()
            plt.subplot(2, 7, 1)
            plt.imshow(img, cmap='gray')
            plt.title('Page')

            plt.subplot(2, 7, 2)
            plt.imshow(out['articles'], cmap='gray')
            plt.title('Articles')

            plt.subplot(2, 7, 3)
            plt.imshow(out['bg'], cmap='gray')
            plt.title('Background')

            plt.subplot(2, 7, 4)
            plt.imshow(out['text'], cmap='gray')
            plt.title('Text')

            plt.subplot(2, 7, 5)
            plt.imshow(out['titles'], cmap='gray')
            plt.title('Titles')

            plt.subplot(2, 7, 6)
            plt.imshow(out['images'], cmap='gray')
            plt.title('Images')

            plt.subplot(2, 7, 7)
            plt.imshow(out['ads'], cmap='gray')
            plt.title('Ads')

            img_cand = candidate.process_image(img_path)
            preds = candidate._segment(img_cand)
            out = {
                'articles': (preds[0][0, ...] * 255).astype("uint8"),
                'bg': (preds[1][0, ..., 0] * 255).astype("uint8"),
                'text': (preds[1][0, ..., 1] * 255).astype("uint8"),
                'titles': (preds[1][0, ..., 2] * 255).astype("uint8"),
                'images': (preds[1][0, ..., 3] * 255).astype("uint8"),
                'ads': (preds[2][0, ...] * 255).astype("uint8") if len(preds) == 3 else np.zeros_like(img)
            }
            plt.subplot(2, 7, 7 + 1)
            plt.imshow(img, cmap='gray')
            plt.title('Page')

            plt.subplot(2, 7, 8 + 1)
            plt.imshow(out['articles'], cmap='gray')
            plt.title('candidate')

            plt.subplot(2, 7, 9 + 1)
            plt.imshow(out['bg'], cmap='gray')
            plt.title('candidate')

            plt.subplot(2, 7, 10 + 1)
            plt.imshow(out['text'], cmap='gray')
            plt.title('candidate')

            plt.subplot(2, 7, 11 + 1)
            plt.imshow(out['titles'], cmap='gray')
            plt.title('candidate')

            plt.subplot(2, 7, 12 + 1)
            plt.imshow(out['images'], cmap='gray')
            plt.title('candidate')

            plt.subplot(2, 7, 13 + 1)
            plt.imshow(out['ads'], cmap='gray')
            plt.title('candidate')

            plt.show()
        return out

    def evaluate_data(self, src_path):
        pages_path = os.path.join(src_path, "pages")
        pages = [os.path.join(pages_path, page) for page in os.listdir(pages_path)]
        articles = [page.replace('pages', 'articles') for page in pages]
        bg = [page.replace('pages', 'bg') for page in pages]
        text = [page.replace('pages', 'text') for page in pages]
        titles = [page.replace('pages', 'titles') for page in pages]
        images = [page.replace('pages', 'images') for page in pages]
        ads = [page.replace('pages', 'ads') for page in pages]

        result = {}
        for i in range(len(pages)):
            data = tf.data.Dataset.from_tensor_slices(
                ([pages[i]], [articles[i]], [bg[i]], [text[i]], [titles[i]], [images[i]], [ads[i]]))
            data = data.map(self._prepare_single_sample_train, num_parallel_calls=tf.data.experimental.AUTOTUNE)
            data = data.padded_batch(1).prefetch(buffer_size=tf.data.experimental.AUTOTUNE)
            loss = self.model.evaluate(data, verbose=0)
            out = self.evaluate(pages[i])
            result[os.path.split(pages[i])[-1]] = {'articles_loss': loss[1], 'classes_loss': loss[2],
                                                   'ads_loss': loss[3],
                                                   'articles': out['articles'], 'bg': out['bg'], 'text': out['text'],
                                                   'titles': out['titles'], 'images': out['images'], 'ads': out['ads']}
        return result
