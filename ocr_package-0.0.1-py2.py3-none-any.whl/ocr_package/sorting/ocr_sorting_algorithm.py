from PIL import Image
from itertools import combinations
import numpy as np
import cv2
import matplotlib.pyplot as plt
from ocr_package.ocr.ocr_utils import convert_t0_2_points, convert_
import statistics
from operator import itemgetter

def display(image):
    plt.figure(figsize=(20, 20))
    plt.imshow(image)
    plt.show()

def is_there_h_iou(point_1, point_2, respect_to_min=False, v_iou=True):
    if v_iou:
        # print('pt1',point_1)
        # print('pt2',point_2)
        p1_x_0 = point_1.max(axis=0)[1]
        p1_x_1 = point_1.min(axis=0)[1]
        # print('p1_x_0',p1_x_0)
        # print('p1_x_1',p1_x_1)
        w_0 = p1_x_0 - p1_x_1

        p2_x_0 = point_2.max(axis=0)[1]
        p2_x_1 = point_2.min(axis=0)[1]

        w_1 = p2_x_0 - p2_x_1

        left_p = min(p1_x_0, p2_x_0)
        right_p = max(p1_x_1, p2_x_1)

        iou = max(0, left_p - right_p)
        if not respect_to_min:
            iou = iou / ((w_0 + w_1) - iou)
        else:
            iou = iou / min(w_0, w_1)

        if iou < .1:
            return False, iou
        else:
            return True, iou

    else:
        # print(point_1)
        # print(point_2)
        p1_x_0 = point_1.max(axis=0)[0]
        p1_x_1 = point_1.min(axis=0)[0]

        h_0 = p1_x_0 - p1_x_1

        p2_x_0 = point_2.max(axis=0)[0]
        p2_x_1 = point_2.min(axis=0)[0]

        h_1 = p2_x_0 - p2_x_1

        down_p = min(p1_x_0, p2_x_0)
        up_p = max(p1_x_1, p2_x_1)

        iou = max(0, down_p - up_p)
        if not respect_to_min:
            iou = iou / ((h_0 + h_1) - iou)
        else:
            iou = iou / min(h_0, h_1)

        if iou < .1:
            return False, iou
        else:
            return True, iou

def overlapping_clustering(art_points):
    # new update i want to check not only the last one but i want to check the last 2 boxes at the cluster
    """
    steps :
    - select the top line from list of input all lines " line is represented by 2 points top left and top right y , x "
    - take this box at hand
    - put it in the cluster you want to fill and remove it from the sorted line list .
    - stretch the box at hand with some ratio ex 1.2 of the height of that box
    - iterate over all boxes to get the box which has min y in the interval < less that y_min + 1.2 h of the boxt at
      and and max_y greater than max y of the box at hand  and the right x of the box greater than the center x of the box at hand > .

    - if number of selected boxes greater than zero
        - check the iou and take only the boxes which has iou greater than .5 with the box at hand respect to min

        - if the selected box greater than 1 take the top one .
        - then find the boxes with has h_iou with it .
        - if there are and boxes has h_iou with it " from the boxes selected boxes "
            break and dont select that box as next one .
            and iterate from the first step .
        - else :
            select it as a next box .
            remove it from list .

    """

    sorted_points = sorted(art_points, key=lambda p: p[0][0])  # respect to y_min each line ((y,x),(y,x))
    clusters = []
    for _ in range(1000):
        cluster = []
        if len(sorted_points) == 0:
            break
        box_at_hand = sorted_points[0] # efred feh 2 points fo2 ganb ba3d hate3mel eh ? haymsek wa7da we yekamel beha el clustering beta3o we ba3deen yeshel el cluster da we yob2a yerga3 yebtedy bel tanya
        indices = []
        indices.append(0)
        cluster.append(box_at_hand)
        while True:
            next_box = []
            for idx, b in enumerate(sorted_points):
                # if min((box_height(box_at_hand) , box_height(b))) / max((box_height(box_at_hand) , box_height(b))) > .92 :
                if (b[0][0] <= (box_at_hand[1][0] + 0.5 * box_height(box_at_hand))):
                    if (b[0][0] > (box_at_hand[1][0] - box_height(box_at_hand))): # hena 3shan akid law 3andy box fo2 elle m3aya haystawfy el shart elle fat fa beyt2aked eno ta7t el box elle m3aya mesh fo2eh we gayly mn cluster tany maslan
                        if b[1][1] >= (box_at_hand[0][1] + (box_at_hand[1][1] - box_at_hand[0][1]) / 2): # ya3ny el x beta3 el point elle ta7t fe tany box akbar mn el center beta3 el x beta3 el point elle fo2
                            next_box.append([b, idx])
            # print(next_box)
            if len(next_box) > 0:
                next_box = [b for b in next_box if is_there_h_iou(box_at_hand, b[0], respect_to_min=True)[-1] > .5] #hena beygeb el intersection bel 3ard ya3ny ka x we ye2semo 3la el width el as8ar mn el 2 boxes
                if len(next_box) > 1:
                    next_box = sorted(next_box, key=lambda b: b[0][0][0]) # hena law 3andy aktar mn box moshtarek m3 elle m3aya ba3melohom sort 3shan maslan law satr kebir ta7teh 3 setor so8ayara
                    upper_box = next_box[0][0] # we ba5od awel box fo2 fehom
                    next_box = [b for b in next_box if
                                is_there_h_iou(upper_box, b[0], respect_to_min=True, v_iou=False)[-1] > .1] # hena awel wa7ed fel kza next box beya5do we yeda5alo m3 ba2y el next boxes
                    # we el mra dy beygeb el intersection bs bel tool mesh bel 3rd we ye2semo 3la el height el as8ar we 2alelt el threshold
                    # beygeb el iou m3 elle ganbo 3shan ye3raf m3ah kam wa7ed  ganb ba3d
            if len(next_box) != 1: # hena law 3andy aktar mn wa7ed ganb ba3d ta7t el satr beta3y hay5rog mn el lopp we ye2fel el shewaya elle ablo ka cluster we ye3ed mn el awel tany
                break
            else: #tayeb law how satr wa7ed hayd5ol hena we yedef el index beta3 el satr da fel indeces 3shan fel a5er yeshel el cluster kolaha mn el lines beta3ty
                _, iou = is_there_h_iou(box_at_hand, next_box[0][0], respect_to_min=True) # hena beygeb el intersection bel 3rd tany we el iou we mogarad beyt2aked eno akbar mn
                # el threshold ell 3amlo 3shan yedef b2a el line da m3ah

                if iou > .15:

                    box_at_hand = next_box[0][0]
                    cluster.append(box_at_hand)
                    indices.append(next_box[0][1])
                else:
                    break

        sorted_points = remove_boxes(sorted_points, indices) # hena beyshel mn el sorted list el indices beta3et el setor elle fel cluster beta3y we yappend el cluster we yekamel el process mn el awel tany
        clusters.append(cluster)
    return clusters

def remove_dublications(art_points):
    filtered_art_points = []
    for b in art_points:
        if len(filtered_art_points) == 0:
            filtered_art_points.append(b)
        else:
            sim = [are_2_boxes_the_same(b, b2) for b2 in filtered_art_points]
            if np.sum(sim) > 0:
                pass
            else:
                filtered_art_points.append(b)

    return np.array(filtered_art_points)

def are_2_boxes_the_same(box_1, box_2):
    return np.all(np.reshape(box_1, (-1,)) == np.reshape(box_2, (-1,)))

def get_next_clusters(remaining_clusters, current_cluster):
    next_cluster = [(c, i) for i, c in enumerate(remaining_clusters) if
                    get_vertical_line_overlapping(c[-1][:4], current_cluster[-1][:4], thr=.1)] #hena beyshof el overlapping bel tol m3 awel cluster fel sorting aw el cluster elle 3aleh el dor fel sorting
    width_of_current_cluster = max(current_cluster[-1][3] - current_cluster[-1][2], 0) #(cluster, (min_y, max_y, left_x, right_x, center))
    next_cluster = [c for c in next_cluster if c[0][-1][3] < current_cluster[-1][2] and c[0][-1][3] > (
            current_cluster[-1][2] - .5 * width_of_current_cluster)] #hena beyt2aked en el cluster elle ha5taro eno yekon el next beta3y eno yob2a 3la shemal el cluster elle 3andy
    #bs fe nafs el wa2t mayob2ash b3ed 3no yob2a fe range nos el width beta3o
    return next_cluster

def initial_sorting_step(clusters, orignial_image=None):
    current_cluster, current_idx, clusters = get_upper_right_cluster(clusters, orignial_image) #keda keda el clusters metrateba fel list bel miny fa howa bey3ady 3alehom we yeshel menhom el
    remaining_clusters = [c for i, c in enumerate(clusters) if i != current_idx] #right cluster elle gabo elle howa el index beta3o metrateb 3la asas el miny bardo
    return current_cluster, current_idx, remaining_clusters #hena beyraga3 el right cluster elle howa awel wa7ed fel sorting we el index beta3o sorted 3la el ymin we ba2y el clusters elle howa delwa2ty mesh fehom

def get_upper_right_cluster(clusters, orignial_image=None):
    # return sorted clusters too to avoid eliminated issues

    """
    #(cluster, (min_y, max_y, left_x, right_x, center)) el cluster el wa7ed gayely keda
    """
    clusters = sorted(clusters, key=lambda c: c[1][3])[::-1]  # sorting respect to right_x_point of the cluster ya3ny ab3ad cluster 3l yemen haygely awel wa7ed le7ad a5er cluster 3l shemal
    #7ta howa hena 3amel [::-1] 3shan elle hayrga3 mn as8ar x 3al yemen le akbar x 3l yemen ya3ny haygebly el clusters mn na7yet el shemal fna 3ayez 23keshom we agebhom mn 3l yemen
    cluster_at_hand = clusters[0]  # taking the right one. hena beymsek awel wa7ed fehom aksa el yemen
    at_hand_indx = 0

    clusters_has_iou_with_me = []
    searching_clusters = [cluster_at_hand]  # for a  series of overlapping ...
    while True:
        len_ = len(clusters_has_iou_with_me)
        for i, c in enumerate(clusters):
            # if len(c[0]) > 1 :
            for c_hand in searching_clusters: # c[-1][:4] dy ya3ny tany element fel tuple we ba5od menha min_y, max_y, left_x, right_x
                #hena beycheck en el cluster elle m3aya m3 kol el clusters el ba2ya we yeshof anhy fehom beyo2a3 fel 7ayez beta3y aw bey3mel intersect m3aya bel 3rd 3shan el h_iou=False
                if get_vertical_line_overlapping(c[-1][:4], c_hand[-1][:4], h_iou=False, thr=0.2,
                                                 resplect_to_min=True) and c[-1][0] != c_hand[-1][0]: #tany condition da beykaren el min_y beta3 el etnen we enohom mesh equal eno mn el a5er maykonsh nafs el cluster elle in hand howa elle bakarno bel cluster elle fel clusters list
                    #mn el a5er ana hena bashof feh cluster fo2 aw ta7t el cluster beta3y beyo2a3 fel 7ayez beta3y wla la2

                    #delwa2ty ba7ot goz2 gedid 3n goz2 agamy
                    #tayeb ana hena be basata bashof law 3andy cluster metkawen mn 2 lines aw 2a2al we fo2 el cluster beta3y elle in hand fa bageb kol el clusters elle ta7teh
                    # we hena bashof hl el x right beta3to akbar mn el x right we el x left el etnen beto3 ay cluster mn kol el clusters elle 3ando we ba3mel el 3ks m3 el xleft we enaha
                    # as8ar mn el x right we el x left beta3 ay cluster mn elle ta7to we mezawed threshold elle howa rob3 el width beta3 el mean cluster width elle 3andy we sa3etha beykoon el 2 flags be true
                    #we sa3etha bashel el cluster da mn el 7esban we mesh ba7sebo
                    # tayeb leh ba3mel keda asasan 3shan law 3andy makal we fe nosha el kateb 7atet esmo (بقلم عباس الملواني) fna bakoon 3ayez dy tetla3 bra el tarteb we dont interfere bel right cluster beta3y
                    # we el 7aga elle zy dy betkoon gaya fel nos between 2 columns wa5da nos mn da we nos mn da fa ba3mel keda to handle this situation
                    if (len(c[0]) <= 2 and (c[-1][0] < c_hand[-1][0])):
                        down_cluster_in_the_current_row = get_down_clusters_to_the_current_cluster(clusters, c)
                        down_canditates = sorted(down_cluster_in_the_current_row, key=lambda cand: cand[0][-1][0]) #sorted by ymin
                        down_canditates = [c for c in down_canditates if len(c[0][0]) > 2] #23taked el satr da mesh hayfre2 now bs 5alena neshof

                        if len(down_canditates) > 0:
                            first_flag = False
                            second_Flag = False

                            all_cluster_widths = [int(cluster[0][-1][3] - cluster[0][-1][2]) for cluster in
                                                  down_canditates]
                            median_of_all_widths = statistics.median(all_cluster_widths)
                            threshold_for_flags = int(np.floor(median_of_all_widths * 0.25))

                            clusters_for_first_flag = [clust for clust in down_canditates if c[-1][3] > (clust[0][-1][3] + threshold_for_flags) and c[-1][3] > (clust[0][-1][2] + threshold_for_flags)]
                            if len(clusters_for_first_flag) > 0:
                                first_flag = True

                            clusters_for_second_flag = [clust for clust in down_canditates if
                                                       c[-1][2] < (clust[0][-1][3]-threshold_for_flags) and c[-1][2] < (clust[0][-1][2]-threshold_for_flags) ]

                            if len(clusters_for_second_flag) > 0:
                                second_Flag = True

                            if first_flag and second_Flag:
                                break

                    #hena bey5las el goz2 el gedid
                    if len(clusters_has_iou_with_me) == 0:

                        clusters_has_iou_with_me.append((c, i)) #hena bey7ot el cluster elle la2eto fel list law heya fadya
                    else: #tb lw el list feha clusters we say ana kont fel cluster elle ta7t we ba3deen mesekt elle fo2eh fel loop fa elle ta7teh elle already kan m3aya mn shewaya
                        # hala2eh fel list fa 5las mesh ha7oto tany fa hena beygeb kol el indices elle 3andy we yeshof law el cluster index elle ana 3aleh already mawgod fel list mesh bey7ot el cluster
                        indices = [c[1] for c in clusters_has_iou_with_me]
                        if i not in indices:
                            clusters_has_iou_with_me.append((c, i))
        # clusters_has_iou_with_me dy keda gowaha tuple ( (cluster, (min_y, max_y, left_x, right_x, center)), i)
        # clusters_has_iou_with_me = [c for c in clusters_has_iou_with_me if len(c[0][0]) > 1 ]
        len_after = len(clusters_has_iou_with_me)
        if len_after == len_: #hena 3ayez ye2ol eny madam ma3amltesh edafa fel list we el length abl howa howa el length ba3d fna keda 5las gebt kol el clusters el moshtareka m3aya
            break

        searching_clusters += [c[0] for c in clusters_has_iou_with_me]  # update searhing clusters
        #delwa2ty say 3andy cluster ta7t 5ales we kol wa7ed fo2eh yetshafet shemal we yetla3 bra el 7ayez beta3o we 3andy maslan 10 fo2eh fa lazem mn el a5er 23mel recursion ageb
        #elle fo2eh da we a7oto fel search we ashta8al 3aleh lewa7do we hakaza we 3la fekra awel wa7ed elle in hand hayd5ol el list m3aya fe tany iteration fa keda kolo hayob2a fel list
        #tab3an hena el complexity kebira shewaya we can be refactored in more smart way bs dy el tare2a

        #tab3an hena feh so2al mohem gedan mdam keda keda kol elle fo2 ba3d da5leen fa mafesh eno yekon len(clusters_has_iou_with_me) == 1 fel condition elle ta7t da 3shan 2a2al 7aga haya5od 2

    # clusters_has_iou_with_me = [(c , i) for  i , c in enumerate(clusters) if get_vertical_line_overlapping(c[-1][:4] , cluster_at_hand[-1][:4] , h_iou = False , thr= 0.1)  ]
    if not isinstance(orignial_image, type(None)):
        img_0 = draw_cluster([c[0] for c in clusters_has_iou_with_me], orignial_image.copy())
        display(img_0)

    if len(clusters_has_iou_with_me) == 0: #law mafesh wla cluster moshtarek m3aya
        return cluster_at_hand, at_hand_indx, clusters
    if len(clusters_has_iou_with_me) == 1: #law feh cluster wa7ed bs moshtarek m3aya

        return clusters_has_iou_with_me[0][0], clusters_has_iou_with_me[0][1], clusters  # hena beyrga3 el cluster elle fel list we el index beta3o we kol el clusters

    else: #law feh aktar mn cluster moshtarek m3aya we mawgod fel list we dol moshtarkeen bel 3rd ya3ny mn el a5er el clusters elle fo2 ba3d we kol wa7ed menhom moshtarek m3 elle ta7to
        #aw fo2eh le7ad ma newsal le awel wa7ed elle howa 3la aksa el yemen
        # clusters_has_iou_with_me dy keda gowaha tuple ( (cluster, (min_y, max_y, left_x, right_x, center)), i)
        clusters_has_iou_with_me = sorted(clusters_has_iou_with_me, key=lambda c: c[0][1][0])  # respect to y_min . hena beyratebhom bel tol
        for k in range(1000): #ezay bete3mel 1000 loop 3la 7aga mafhash 1000 asln ???
            right_cluster = clusters_has_iou_with_me[k]  # take the upper one. hena beya5od awel wa7ed fo2 5ales fe awel iteration lma el k = 0 we el tany lma el k = 1 we hakaza

            # iterate here till u catch the right top one isa .
            # get all the boxes which has left x greater than me
            clusters_has_x_greater_than_me = [c for c in clusters_has_iou_with_me if
                                              c[0][1][3] > right_cluster[0][1][3]] #hena beygeb kol el clusters elle 3la yemen el cluster elle m3aya
            #ya3ny say ana 3andy 15 cluster fo2 ba3d we zy ma 2olna fo2 feh one in hand elle maslan awel wa7ed ta7t 5ales elle howa kan aksa el yemen zy ma 3amalna fo2 5ales
            # ba3daha 7atena el 14 el tanyeen fel list beta3et clusters_has_iou_with_me we ratebnahom mn fo2 le ta7t we delwa2ty mesekna awel wa7ed fo2 5ales
            if len(clusters_has_x_greater_than_me) > 0:
                # now right_cluster should overlapp with all
                #hena beygeb el clusters elle beyoverlapo m3ah bel 3rd 3shan law elle 3la yemeno ad elle ta7to yob2a keda da awel wa7ed 3ndy fe3lan
                clusters_has_iou_with_right_cluster_top = [c for c in clusters_has_x_greater_than_me if
                                                           get_vertical_line_overlapping(c[0][-1][:4],
                                                                                         right_cluster[0][-1][:4],
                                                                                         h_iou=False, thr=.1,
                                                                                         resplect_to_min=True)]
                if len(clusters_has_iou_with_right_cluster_top) == len(clusters_has_x_greater_than_me):
                    break
                else:
                    right_cluster = clusters_has_iou_with_me[k] # tayeb delwa2ty howa 8arado eno yegeb awel cluster fo2 elle haya5od rakam wa7ed fel sorting fa beyshof
            else:
                break

        # get all clusters in clusters_has_iou_with_me which has v_iou with it to sort respect to right ...
        # hena mn el a5er lma ana bageb el right cluster elle howa awel wa7ed habtedy beh sorting beyt2aked eno aksa wa7ed 3l yemen
        #3shan momken gedan yekon feh etnen clusters gowa ba3d aw interfering ba3d fa hena beygeb el 7yaza bel tol b2a mesh bel 3rd 3shan h_iou = true
        #we ba3deen ye2om meratebhom be 23la x we yegeb elle howa aksa el yemen
        clusters_has_iou_with_right_cluster = [c for c in clusters_has_iou_with_me if
                                               get_vertical_line_overlapping(c[0][-1][:4], right_cluster[0][-1][:4],
                                                                             thr=.1, resplect_to_min=True)]
        if len(clusters_has_iou_with_right_cluster) > 0:
            #hena bey3mel keda beyratebhom be 23la x aksa el yemen we ya5od awel wa7ed
            clusters_has_iou_with_right_cluster = sorted(clusters_has_iou_with_right_cluster, key=lambda c: c[0][1][3])[
                                                  ::-1]  # respect to x_right
            right_cluster = clusters_has_iou_with_right_cluster[0]

        # now get the clusters which has iou with me in the same row and take the upper one
        # hena b2a beyt2aked eno e5tar sa7 aw bey3mel 3amalyet ta2ked eno yegeb kol el overlapping bel 3rd fa yego kolohom including 7ta elle 3amlen overlapping m3ah bel tol
        # we b3adaha yeshel menhom elle 3amlen overlapping m3aya bel tol we ba3daha yeratebhom bel nesba lel ymin we ya5od awel wa7ed fo2 elle howa fe3lan el right cluster
        clusters_has_iou_with_right_cluster = [c for c in clusters_has_iou_with_me if
                                               get_vertical_line_overlapping(c[0][-1][:4], right_cluster[0][-1][:4],
                                                                             h_iou=False, thr=.1,
                                                                             resplect_to_min=True) and not get_vertical_line_overlapping(
                                                   c[0][-1][:4], right_cluster[0][-1][:4], h_iou=True, thr=.1,
                                                   resplect_to_min=True)]
        clusters_has_iou_with_right_cluster += [right_cluster] #hena beyzawed el right cluster fel list dy we ba3deen yeratebhom we ya5do
        if len(clusters_has_iou_with_right_cluster) > 0:
            clusters_has_iou_with_right_cluster = sorted(clusters_has_iou_with_right_cluster,
                                                         key=lambda c: c[0][1][0])  # respect to y_min
            right_cluster = clusters_has_iou_with_right_cluster[0]  # take the upper one in that row
        #hena beyraga3 el cluster el awlany (cluster, (min_y, max_y, left_x, right_x, center)) we el index beta3o 7asab tartebhom bel ymin elle kan 3amlo fel awel 5ales we kol el clusters elle kanet da5lalo beterga3 bema fehom el cluster da nafso
        return right_cluster[0], right_cluster[1], clusters

def get_vertical_line_overlapping(line_1, line_2, h_iou=True, thr=0.0, resplect_to_min=False):
    # line in that format (min_y , max_y , left_x , rightx )
    # line1 we line2 gayenly keda (min_y, max_y, left_x, right_x)
    # mn el a5er fel function dy howa beyshof feh interference aw goz2 moshtarak ben el 2 clusters swa2 toly aw 3ardy we yekarno be threshold we law feh beyraga3 true we law mafesh beyraga3 false
    # print(line_1)
    if h_iou: #hena beyshta8al bel tol
        h1 = line_1[1] - line_1[0] #beygeb height cluster 1
        h2 = line_2[1] - line_2[0] #beygeb height cluster 2

        up_point = max(line_1[0], line_2[0]) #beygeb 23la no2ta fel 2 clusters
        down_point = min(line_1[1], line_2[1]) #beygeb awta no2ta fel 2 clusters

        iou = max(0, down_point - up_point) #beygeb height el etnen 3la ba3d
        if resplect_to_min:
            iou = iou / max(min(h1, h2), .0000001) #bey2sem el total height 3la el height el as8ar fel 2 clusters
        else:
            iou = iou / max((h1 + h2 - iou), 0.0000001) #hena law maslan el 2 clusters ta7t ba3d haya5od el threshold 3shan el iou haykoon akbar mn h1 + h2 we sa3etha yerga3 be false
            #laken law el 2 clusters ganb ba3d el iou hayob2a as8ar mn h1 + h2 we sa3etha mesh haya5od el threshold
        if iou > thr:
            return True
        return False
    else: #hena beyshta8al bel 3rd
        w1 = line_1[3] - line_1[2] #el width beta3 awel cluster
        w2 = line_2[3] - line_2[2] #el width beta3 tany cluster
        left_point = max(line_1[2], line_2[2]) #beygeb aksa point shemal fel 2 clusters
        right_point = min(line_1[3], line_2[3]) #beygeb aksa point yemen fel 2 clusters

        iou = max(0, right_point - left_point) # beygeb el total width
        if resplect_to_min:
            iou = iou / max(min(w1, w2), .0000001) #bey2sem el total width 3la width el cluster el as8ar
        else:
            iou = iou / (w1 + w2 - iou) #hena bey2sem el total 3la gam3ohom we bashel el iou 3la asas eno metkarar bs da mesh dayman bey7sal
        if iou > thr:
            return True
        return False

def get_Area_iou(line_1, line_2, thr=0.0, resplect_to_min=False):
    h1 = line_1[1] - line_1[0]
    h2 = line_2[1] - line_2[0]

    up_point = max(line_1[0], line_2[0])
    down_point = min(line_1[1], line_2[1])

    h_iou = max(0, down_point - up_point)

    w1 = line_1[3] - line_1[2]
    w2 = line_2[3] - line_2[2]
    left_point = max(line_1[2], line_2[2])
    right_point = min(line_1[3], line_2[3])

    v_iou = max(0, right_point - left_point)

    intersection_area = h_iou * v_iou

    A_1 = (h1 * w1)
    A_2 = (h2 * w2)

    if resplect_to_min:
        A_iou = intersection_area / min(A_1, A_2)
    else:
        A_iou = intersection_area / (A_1 + A_2 - intersection_area)

    if A_iou > thr:
        return True
    return False

def represent_cluster_as_a_vertical_line(clusters, img=None):
    """
    input cluster is a list of lines .
    we want to represt it with some additional propertes
     out is :
     (input cluster , (min_y , min_x , max_y , max_x  , center ))
     min_y  : min( all min_y of all lines )
     min_x  : min( all min_x of all lines )
     max_y  : max( all max_y of all lines )
     max_x  : max( all max_x of all lines )
     center : ( min_y + (max_y - min_y) // 2 , left_x + (right_x - left_x) // 2 )

    """
    new_clusters = []
    for cluster in clusters:
        cluster = sorted(cluster, key=lambda c: c[0][0]) # beysort with respect to min y
        new_clusters.append(cluster)

    final_clusters = []
    for cluster in new_clusters:
        min_y, max_y = cluster[0][0][0], cluster[-1][1][0] #beygeb awel point fel cluster kolaha mn 3al shemal fo2 we a5er point 5ales mn 3al yemen ta7t
        H = max(max_y - min_y, 0) # el height beta3 el cluster kolaha
        min_y = min_y + H * 0.05 # hena beyrfa3 el min y fo2 shewaya benebset 5% mn el height kolo laken leh ???
        min_y = int(min_y) # beyshel el kasr
        max_y = max_y - H * 0.05 # hena beynazel el max y ta7t shewaya benesbet 5% mn el total height kolo laken leh bardo ??
        max_y = int(max_y)

        # print(cluster)
        # print(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        cluster_ = sorted([reduce_box_width(c) for c in cluster], key=lambda c: c[1][1]) #hena ba3d ma bey3mel shrink lel boxes elle gowa el cluster beysortohom bona2an 3la el x mn na7yet el yemen fa keda as8ar line width hayob2a fo2 we atwal line width hayob2a ta7t
        cluster_ = np.array(cluster_, dtype=np.int32)
        # print(cluster_)
        right_x = cluster_[-1][1][1] #hena bey5tar b2a ab3ad x 3l yemen elle heya a5er 7aga fel sorted cluster
        cluster_ = sorted([reduce_box_width(c) for c in cluster], key=lambda c: c[0][1]) #hena ba3d ma bey3mel shrink lel boxes elle gowa el cluster beysortohom bona2an 3la el x mn na7yet el shemal fa keda as8ar line width hayob2a ta7t we atwal line width hayob2a fo2 3shan el x kol ma teb3ed mn el shemal kol ma tob2a as8ar we el 3ks
        cluster_ = np.array(cluster_, dtype=np.int32)
        left_x = cluster_[0][0][1] #beygeb ab3ad x mn ne7yet el shemal keda
        color_0, color_1 = generate_random_color(), generate_random_color() # hena beygenerate alwan yasta mesh 3ayza shar7 dy kman

        center = (min_y + (max_y - min_y) // 2, left_x + (right_x - left_x) // 2) #bey7seb el center bona2an 3la kol el no2at elle gabha dy we tab3an betkoon y,x point
        if not isinstance(img, type(None)): #hena mn el a5er beygeb 7edod el cluster mn el yemen we el shemal we el center ya3ny bey7ot 5t yemen el cluster we 5t shemal el cluster el center m3ak 3shan ba3d keda ye3mel sorting lel clusters zat nafsohom b2a odam
            img[min_y:max_y, right_x - 20:right_x] = color_0
            img[min_y:max_y, left_x:left_x + 20] = color_1

            img[center[0] - 20:center[0] + 20, center[1] - 20:center[1] + 20] = color_1

        final_clusters.append((cluster, (min_y, max_y, left_x, right_x, center))) #beyraga3 tuple feh el cluster elle heya sorted bel min y we m3aha el 5 no2at dol 3shan yeshta8al behom ba3d keda fel cluster sorting nafso

    return img, final_clusters

def draw_cluster(clusters, img):
    # clusters dy gaya keda (cluster, (min_y, max_y, left_x, right_x, center))
    #hena beylawen el cluster mn el yemen we el nos
    for c in clusters:
        _, param = c
        min_y, max_y, left_x, right_x, center = param

        color = generate_random_color()

        img[min_y:max_y, right_x - 20:right_x] = color
        # img[min_y :max_y , left_x  :left_x + 20] = color

        img[center[0] - 20:center[0] + 20, center[1] - 20:center[1] + 20] = color
    return img

def generate_random_color():
    return (np.random.randint(100, 255), np.random.randint(0, 255), np.random.randint(0, 255))

def remove_boxes(boxes, indices):
    new_boxes = []
    for idx, b in enumerate(boxes):
        if idx not in indices:
            new_boxes.append(b)
    return new_boxes

def box_height(box):
    return max(box[1][0] - box[0][0], 0)

def is_this_point_inside(box, point):
    # point (x , y )
    # box [ [y_min , x_min ] , [y_max , x_max] ]

    if point[0] >= box[0][1] and point[0] <= box[1][1]:
        if point[1] >= box[0][0] and point[1] <= box[1][0]:
            return True
    return False

def box_width(box):
    return max(box[1][1] - box[0][1], 0)

def reduce_box_width(box, ratio=.1):
    # print(box)
    h = box_height(box)
    w = box_width(box)

    r = ratio / 2
    # box[0][1] = box[0][1] + r * w
    # box[1][1] = box[1][1] - r * w
    # print(box)
    #how hena mesh beygy ganb el y la2eno 5las zabatha bra abl ma yenady el function laken howa hena bey5aly el x elle mn 3l shemal te5osh gowa yemen shewaya we
    # el x elle mn 3l yemen te5osh gow shemal shewaya bs leh ??
    box = [[box[0][0], box[0][1] + r * w], [box[1][0], box[1][1] - r * w]]

    return box

def draw_seg_line(image, box):
    start_point = (int(box[1][1]), int(box[1][0]))
    end_point = (int(box[0][1]), int(box[1][0]))
    color = (255, 0, 0)
    thickness = 9
    image = cv2.line(image, start_point, end_point, color, thickness)
    return image

def draw_seg_box(image, box):
    start_point = (int(box[1][1]), int(box[1][0]))
    end_point = (int(box[0][1]), int(box[1][0]))
    color = (255, 0, 0)
    thickness = 9
    image = cv2.line(image, start_point, end_point, color, thickness)
    return image

def get_down_clusters_to_the_current_cluster(remaining_clusters, current_cluster):
    """
    get down clusters in the current row respect to v_iou
    #(cluster, (min_y, max_y, left_x, right_x, center))

    """
    # down_cluster = [(c , i) for i , c in enumerate(remaining_clusters) if c[-1][3] > right_x_of_next_clusters and c[-1][3] > current_cluster[1][4][-1]]
    #hena beygeb kol el clusters el overlapping bel 3rd m3 el cluster beta3y we beyshel menhom elle fo2eh we beyraga3 elle ta7teh bs 3shan elle fo2eh 5las gebto abl keda
    down_cluster = [(c, i) for i, c in enumerate(remaining_clusters) if
                    get_vertical_line_overlapping(c[-1][:4], current_cluster[-1][:4], h_iou=False, thr=0.0)]

    down_cluster = [c for c in down_cluster if c[0][-1][0] >= current_cluster[-1][0]]
    return down_cluster

def SORTING_ALGORITHEM(lines_array, lines_title, orignial_image=None):
    if len(lines_array) < 1:
        return lines_array, []

    art_points = [line for line, _ in lines_array]
    art_points_titles = [line for line, _ in lines_title]
    # art_points = remove_dublications(art_points)
    art_points = np.array(art_points)
    art_points_titles = np.array(art_points_titles)
    art_points = convert_t0_2_points(art_points)

    # art_points = [b for b in art_points if box_width(b) < .4 * orignial_image.shape[1]]

    art_points = remove_dublications(art_points)
    # print("before : "  , len(art_points))
    # if len(list_to_eliminate) != 0:
    #     art_points = [b for b in art_points if not any([is_this_point_inside(b, point) for point in list_to_eliminate])]

    # print(art_points[0])
    # art_points = [reduce_box_width(b) for b in art_points ]
    # art_points = np.array(art_points , dtype = np.int32)
    # print("after : "  , len(art_points))
    # print(art_points[0])

    art_points_titles = convert_t0_2_points(art_points_titles) if not len(art_points_titles) == 0 else art_points_titles
    expected_titles = art_points_titles if len(art_points_titles) > 0 else []

    clusters = overlapping_clustering(art_points)
    _, clusters = represent_cluster_as_a_vertical_line(clusters, None)
    # clusters       = update_clusters_using_titles_between(clusters , expected_titles) if len(expected_titles) != 0 else clusters
    # clusters       = refine_connected_clusters(clusters) # by stretching .
    #     clusters       = refine_inside_clusters(clusters)

    #     if len(clusters_inside_each_others) > 0:
    #         if not isinstance(orignial_image , type(None)):
    #             #print(current_cluster)
    #             img_0 = draw_cluster(clusters_inside_each_others ,orignial_image.copy() )
    #             display(img_0)

    # if not isinstance(orignial_image, type(None)):
    #     # print(current_cluster)
    #     img_0 = draw_cluster(clusters, orignial_image.copy())
    #     display(img_0)

    sorted_clusters = []
    small_lines_at_the_end_clusters = []
    # sort by min y with represent top point of vertical line of each cluster
    current_cluster, current_idx, remaining_clusters = initial_sorting_step(clusters, None) # current cluster gy keda (cluster, (min_y, max_y, left_x, right_x, center))
    #remaining_clusters dy feha kol el clusters ma 3da el clusters elle 3amaltelhom sorting 5las we el current cluster elle ana wa2ef 3aleh we gaya keda (cluster, (min_y, max_y, left_x, right_x, center))
    #     if not isinstance(orignial_image , type(None)):
    #         #print(current_cluster)
    #         img_0 = draw_cluster([current_cluster] ,orignial_image.copy() )
    #         display(img_0)

    # hena ha7ot goz2 gedid ana elle katbo
    # ana hena bashof el common width of columns 3andy be kam we law la2et cluster ye3mel 1.5 * el width da ya3ny da large width cluster ba5aleh yet7at el awel fel sort
    # we da tab3an ba3d ma 23mel sort lel large cluster to according to ymin
    #hena ana momken yekon 3andy 7agat me3adeya el threshold 3shan shakl el saf7a 8areb we yekon column kamel we ya5do fa badtar bel mra ageb kol elle fo2eh we ta7to overlapping m3ah
    # we ba3den bardo ataba2 nafs fekret ta7t we a7ot threshold 3shan adman en elle beytshal howa fe3lan el setor el 3areda elle mesh fe column 3ared extra la2 tekon setor bra column
    #stor zy elle fe nos el gornan bete3mel summary keda
    all_clusters = []
    all_clusters.append(current_cluster)
    all_clusters = all_clusters + remaining_clusters
    all_cluster_widths = [int(cluster[1][3] - cluster[1][2]) for cluster in all_clusters]
    median_of_all_widths = statistics.median(all_cluster_widths)
    threshold_for_large_lines = int(np.floor(median_of_all_widths * 1.5))

    large_clusters = []
    indices_to_be_removed = []
    for index, cluster in enumerate(all_clusters):
        if int(cluster[1][3] - cluster[1][2]) > threshold_for_large_lines:
            vertical_overlapping_clusters = [(c, i) for i, c in enumerate(remaining_clusters) if
                                             (c[-1][:4] != cluster[-1][:4]) and
                                             (get_vertical_line_overlapping(c[-1][:4], cluster[-1][:4], h_iou=False,
                                                                            thr=0.0))]  # bageb kol elle fo2eh we ta7to
            vertical_overlapping_clusters = sorted(vertical_overlapping_clusters,
                                                   key=lambda cand: cand[0][-1][0])  # sorting by ymin

            # vertical_overlapping_clusters = [one_c for one_c in vertical_overlapping_clusters if len(one_c[0][0]) > 1]

            if len(vertical_overlapping_clusters) > 0:
                large_first_flag = False
                large_second_flag = False

                threshold_for_large_flags = int(np.floor(median_of_all_widths * 0.20))

                clusters_for_large_first_flag = [clust for clust in vertical_overlapping_clusters if
                                                 cluster[-1][3] > (clust[0][-1][3] + threshold_for_large_flags) and
                                                 cluster[-1][3] > (
                                                         clust[0][-1][2] + threshold_for_large_flags)]

                if len(clusters_for_large_first_flag) > 0:
                    large_first_flag = True

                clusters_for_large_second_flag = [clust for clust in vertical_overlapping_clusters if
                                                  cluster[-1][2] < (clust[0][-1][3] + threshold_for_large_flags) and
                                                  cluster[-1][2] < (
                                                          clust[0][-1][2] + threshold_for_large_flags)]

                if len(clusters_for_large_second_flag) > 0:
                    large_second_flag = True

                if large_first_flag and large_second_flag:
                    large_clusters.append(cluster)


    large_clusters = sorted(large_clusters, key=lambda c: c[1][0])
    if len(large_clusters) > 0:
        #hena el indices beta3et el remaning clusters betebtedy mn 1 not 0 we enumerate betebtedy mn zero so we remove by value not pop by index
        for cluster_index, x in enumerate(remaining_clusters):
            for y in large_clusters:
                if (x[-1][:4]) == (y[-1][:4]):
                    indices_to_be_removed.append(cluster_index)
                    # remaining_clusters.pop(cluster_index) #lma te pop keda el indices betet8ayar fa mesh bete3raf teshelha kolaha sa7 fel a5er
                    break
        remaining_clusters = [i for j, i in enumerate(remaining_clusters) if j not in indices_to_be_removed]
        current_cluster_flag = False
        for simple_cluster in large_clusters:
            if current_cluster[-1][:4] == simple_cluster[-1][:4]:
                current_cluster_flag = True
                break

        if current_cluster_flag:
            for c in large_clusters:
                sorted_clusters.append(c)
            current_cluster, current_idx, remaining_clusters = get_upper_right_cluster(remaining_clusters)
        else:
            for c in large_clusters:
                sorted_clusters.append(c)
            sorted_clusters.append(current_cluster)
    else:
        sorted_clusters.append(current_cluster)

    #el goz2 beta3y finish here
    count = 0
    while len(remaining_clusters) > 0:
        #hena ha7ot goz2 gedid
        continue_flag = True
        if (len(current_cluster[0]) <= 2):
            down_cluster_in_the_current_row = get_down_clusters_to_the_current_cluster(all_clusters, current_cluster)
            down_canditates = sorted(down_cluster_in_the_current_row, key=lambda cand: cand[0][-1][0])  # sorted by ymin
            down_canditates = [c for c in down_canditates if
                               len(c[0][0]) > 2]

            if len(down_canditates) > 0:
                first_flag = False
                second_Flag = False

                threshold_for_flags = int(np.floor(median_of_all_widths * 0.25))

                clusters_for_first_flag = [clust for clust in down_canditates if
                                           current_cluster[-1][3] > (clust[0][-1][3] + threshold_for_flags) and current_cluster[-1][3] > (
                                                       clust[0][-1][2] + threshold_for_flags)]
                if len(clusters_for_first_flag) > 0:
                    first_flag = True

                clusters_for_second_flag = [clust for clust in down_canditates if
                                            current_cluster[-1][2] < (clust[0][-1][3] - threshold_for_flags) and current_cluster[-1][2] < (
                                                        clust[0][-1][2] - threshold_for_flags)]

                if len(clusters_for_second_flag) > 0:
                    second_Flag = True

                if first_flag and second_Flag:
                    small_lines_at_the_end_clusters.append(current_cluster)
                    remaining_clusters = [c for i, c in enumerate(remaining_clusters) if c[-1][:4] != current_cluster[-1][:4]]
                    current_cluster, current_idx, remaining_clusters = get_upper_right_cluster(remaining_clusters)
                    continue_flag = False

        # hena bey5las el goz2 el gedid
        if continue_flag:
            for _ in range(100):
                if len(remaining_clusters) > 0:
                    next_cluster = get_next_clusters(remaining_clusters, current_cluster) #( (cluster, (min_y, max_y, left_x, right_x, center)) , index) hena beygeb kol el clusters elle 3la shemal el current cluster
                    if len(next_cluster) > 0:
                        right_x_of_next_clusters = sorted([c[0][-1][3] for c in next_cluster])[-1]
                        nearest_next = sorted(next_cluster, key=lambda c: c[0][1][3])[-1] #hena beygeb 2a2rab wa7ed 3la shemalo fehom kolohom
                        # down_cluster_in_the_current_row = [(c , i) for i , c in enumerate(remaining_clusters) if c[-1][3] > right_x_of_next_clusters and c[-1][3] > current_cluster[1][4][-1]]
                        down_cluster_in_the_current_row = get_down_clusters_to_the_current_cluster(remaining_clusters,
                                                                                                   current_cluster) #beygeb kol el clsuters elle ta7t el current cluster
                        down_canditates = sorted(down_cluster_in_the_current_row,
                                                 key=lambda cand: cand[0][-1][0])  # respect to y_min hena beyratebhom mn 2a2rab wa7ed ta7to lel ab3ad

                        # hena beyshel mn elle ta7to el clusters elle 3adad setorha 2a2al mn 3
                        #ana 3amalt ta3deel hena we gebtaha fo2 el if we heya kanet ta7t el if
                        down_canditates = [c for c in down_canditates if
                                           len(c[0][0]) > 2]  # accept only clusters which has num of lines greater than 2 . but why ??? array of cluster length > 2

                        if len(down_canditates) > 0:
                            nearest_down_canditates = down_canditates[0] # hena beygeb awel wa7ed ta7to 3la tol

                        #                     if not isinstance(orignial_image , type(None)):
                        #                         #print(current_cluster)
                        #                         img_0 = draw_cluster(remaining_clusters ,orignial_image.copy() )
                        #                         display(img_0)
                        #                     if not isinstance(orignial_image , type(None)):
                        #                         #print(current_cluster)
                        #                         img_0 = draw_cluster([c[0] for c in down_cluster_in_the_current_row] ,orignial_image.copy() )
                        #                         display(img_0)

                        # down_canditates = [c for c in down_cluster_in_the_current_row if any([get_vertical_line_overlapping(c[0][-1][:4] , c_next[-1][:4]) for c_next in next_cluster])]
                        extend_v = 0 #hena beya5od el height el as8ar mn el cluster elle m3aya we elle 3la shemalo 3la el height el akbar fel etnen we yeshof howa akbar mn 90% wla la2
                        if min((current_cluster[1][1] - current_cluster[1][0]),
                               (nearest_next[0][1][1] - nearest_next[0][1][0])) / max(
                            (current_cluster[1][1] - current_cluster[1][0]),
                            (nearest_next[0][1][1] - nearest_next[0][1][0])) >= .9:
                            if len(down_canditates) > 0:
                                upper_canditate = down_canditates[0] #awel wa7ed ta7to 3la tol
                                overlapping_with_upper_canditates = [
                                    get_vertical_line_overlapping(c[0][-1][:4], upper_canditate[0][-1][:4], thr=0.5,
                                                                  resplect_to_min=True) for c in down_canditates] #hena beygeb law feh overlapping bel tol ben el clusters elle ta7t el current cluster we da 3shan law feh etnen gowa ba3d
                                #aw law el current cluster 3ared shewaya we ta7to etnen fe wesh ba3d we tab3an hena 3shan el upper candidate metkarar fe list el down candidates fa ta7t haycheck en el length akbar mn 1

                                if len(overlapping_with_upper_canditates) > 1:
                                    extend_v = .3 * (current_cluster[1][3] - current_cluster[1][2]) #hena beygeb 30% mn 3rd el current cluster

                        if len(down_cluster_in_the_current_row) > 0: #law feh clusters ta7t el current cluster

                            next_line = nearest_next[0][-1][:4] #(min_y, max_y, left_x, right_x, center) #da el cluster elle 3la shemalo
                            next_line = (next_line[0], next_line[1], next_line[2], next_line[3] + extend_v) #beyzawed el width beta3o be 2emet el 30 % dol
                            # iou_with_next = [get_vertical_line_overlapping(c[0][-1][:4] , next_line  , h_iou= False, thr=0.1 , resplect_to_min= True )  for c in  down_canditates ]
                            iou_with_next = []
                            if len(down_canditates) > 0:
                                iou_with_next = [get_vertical_line_overlapping(c[0][-1][:4], next_line, h_iou=False, thr=0.3,
                                                                               resplect_to_min=True) for c in
                                                 [nearest_down_canditates]] #hena beygeb law feh overlapping ben elle 3la shemalo ba3d ma kabarto we awel wa7ed ta7t el current cluster 3la tol bel 3rd

                            if any(iou_with_next): #law tele3 feh beyshafet el current cluster lel cluster elle 3la shemalo
                                # print("yes") #( (cluster, (min_y, max_y, left_x, right_x, center)) , index)
                                current_cluster = nearest_next[0] # (cluster, (min_y, max_y, left_x, right_x, center))
                                current_idx = nearest_next[1]  # index
                            else:
                                break

                            #                         else :
                            #                             current_cluster = down_canditates[0][0]
                            #                             current_idx     = down_canditates[0][1]

                            #                         elif len(down_canditates) > 1 :
                            #                             # here i have to start checking if there is any overlapping with that canditates or not
                            #                             clusters_has_iou_current_canditate = [ c for c in down_canditates if get_vertical_line_overlapping(c[0][-1][:4] , current_cluster[-1][:4])  ]
                            #                             clusters_has_iou_current_canditate = sorted(clusters_has_iou_current_canditate , key=lambda c: c[0][1][3])[::-1] # respect to right x

                            #                             # here i will check if they have overlapping with the next or not if # take the next one first
                            #                             iou_with_next = [get_vertical_line_overlapping(c[0][-1][:4] , nearest_next[0][-1][:4] , h_iou= False )  for c in  clusters_has_iou_current_canditate ]

                            #                             if any(iou_with_next):
                            #                                 current_cluster  = nearest_next[0]
                            #                                 current_idx      = nearest_next[1]

                            #                             else :
                            #                                 if len(clusters_has_iou_current_canditate) > 0 :
                            #                                     current_cluster  = clusters_has_iou_current_canditate[0][0]
                            #                                     current_idx      = clusters_has_iou_current_canditate[0][1]
                            #                                 else :
                            #                                     break

                            remaining_clusters = [c for i, c in enumerate(remaining_clusters) if i != current_idx] # law shafet el cluster zy ma shofna fo2 beyshelo mn el remaining cluster list we ye7oto fel sorted clusters list bs el so2al hena el already kan current cluster bey3mel feh eh ?
                            sorted_clusters.append(current_cluster)

                        else:
                            break
                    else: #hena law mn el awel 5ales mafesh asln clusters 3la shemalo haybreak
                        break
            # hena beyro7 yegeb awel wa7ed fo2 mn el reamining clusters
            current_cluster, current_idx, remaining_clusters = get_upper_right_cluster(remaining_clusters) # current cluster shayla (cluster, (min_y, max_y, left_x, right_x, center))
            #         if isinstance(current_cluster  , type(None)) :
            #             continue
            sorted_clusters.append(current_cluster) #we bey7to el current fel sorted list
            remaining_clusters = [c for i, c in enumerate(remaining_clusters) if i != current_idx] #azon dy zeyadet ta2ked mesh aktar
        count += 1
    #     if not isinstance(orignial_image , type(None)):
    #         img_0 = draw_cluster(sorted_clusters ,orignial_image.copy() )
    #         display(img_0)

    #hakamel el goz2 beta3y
    if len(small_lines_at_the_end_clusters) > 0:
        small_lines_at_the_end_clusters = sorted(small_lines_at_the_end_clusters, key=lambda cls: cls[1][0])
        sorted_clusters = small_lines_at_the_end_clusters + sorted_clusters
        # for one_cluster in small_lines_at_the_end_clusters:
        #     sorted_clusters.append(one_cluster)
    #hena ye5las el goz2 beta3y

    sorted_lines = []
    for cl in sorted_clusters: # cl = (cluster, (min_y, max_y, left_x, right_x, center))
        #         boxes = cl[0]
        #         boxes = sorted(boxes , key= lambda b : b[0][0]) # respect_to_y_min

        #         new_boxes = []
        #         indices = []
        #         box_at_hand_top = boxes[0] # first top_box
        #         idx             = 0
        #         line_0 = [box_at_hand_top[0][0] ,box_at_hand_top[1][0] , box_at_hand_top[0][1] , box_at_hand_top[1][1] ]
        #         boxes_has_h_iou_with_top_at_hand = []
        #         for i , b in enumerate(boxes):
        #             line_1 = [b[0][0] ,b[1][0] , b[0][1] , b[1][1] ]
        #             if get_vertical_line_overlapping( line_0 , line_1 ,  h_iou= True , thr= .5 , resplect_to_min= True) :
        #                 boxes_has_h_iou_with_top_at_hand.append((b , i ))

        #         if len(boxes_has_h_iou_with_top_at_hand) > 0 :
        #             boxes_has_h_iou_with_top_at_hand = sorted(boxes_has_h_iou_with_top_at_hand , key= lambda b : b[0][1][1]) # respect_to_x_max
        #             box_at_hand_top = boxes_has_h_iou_with_top_at_hand[-1][0]
        #             idx             = boxes_has_h_iou_with_top_at_hand[-1][1]

        #         while len(boxes) > 0  :
        #             new_boxes.append(box_at_hand_top)
        #             indices.append(idx)
        #             line_0 = [box_at_hand_top[0][0] ,box_at_hand_top[1][0] , box_at_hand_top[0][1] , box_at_hand_top[1][1] ]
        #             boxes_at_the_same_row = []
        #             for i , b in enumerate(boxes):
        #                 if i not in  indices :
        #                     line_1 = [b[0][0] ,b[1][0] , b[0][1] , b[1][1] ]
        #                     if get_vertical_line_overlapping( line_0 , line_1 ,  h_iou= False , thr= .5 , resplect_to_min= True) :
        #                         if b[0][0] > box_at_hand_top[0][0] :

        #                             canditate_b = b
        #                             # check if there is any boxes between ....
        #                             min_x_left = min(canditate_b[0][1] , box_at_hand_top[0][1])
        #                             max_x_right = max(canditate_b[1][1] , box_at_hand_top[1][1])

        #                             boxes_in_between = [(b_ , j) for j ,  b_ in enumerate(boxes) if b_[0][0] > box_at_hand_top[1][0] and b_[0][0] < canditate_b[1][0] and b_[0][1] >= min_x_left and b_[1][1] <= max_x_right and j not in (indices + [i])]
        #                             if len(boxes_in_between) > 0 :
        #                                 #if len(boxes_in_between) == 1 :
        #                                 boxes_at_the_same_row.append((boxes_in_between[0][0] ,  boxes_in_between[0][1]))

        #                             else :
        #                                 boxes_at_the_same_row.append((b , i ))

        #             if len(boxes_at_the_same_row) > 0 :
        #                 boxes_at_the_same_row = sorted(boxes_at_the_same_row , key= lambda b : b[0][0][0]) # respect_to_y_min
        #                 box_at_hand_top = boxes_at_the_same_row[0][0]
        #                 idx             = boxes_at_the_same_row[0][1]
        #             else :
        #                 re_boxes = [ (b , i) for i , b in enumerate(boxes) if i not in indices ]
        #                 if len(re_boxes) > 0 :
        #                     box_at_hand_top = re_boxes[0][0]
        #                     idx             = re_boxes[0][1]
        #                 else :
        #                     break

        cl = cl[0] #hena beygeb el cluster lines list nafsaha mn el tuple
        cl = sorted(cl, key=lambda c: c[0][0]) #hena fe kol element fel tuple beysort 3la el ymin
        # sorted_lines.extend(new_boxes)
        sorted_lines.extend(cl) #bey7ot b2a kol cluster metrateba fel list we ta7teha el cluster elle ba3daha fa yob2a kolo lines wra ba3d mn el a5er
    # return sorted_lines
    boxes_text_original = [box for box, _ in lines_array] #hena dy kol el setor elle 3andy elle gaya lel function
    boxes_text_original = convert_t0_2_points(np.array(boxes_text_original)) #beygeb bs le kol satr awel no2ta fo2 3l shemal we a5er no2ta ta7t 3la yemen (y,x)

    sorted_indices = [] #hena bey3mel array lel sorted indices ya3ny delwa2ty law el satr kan gayely fel lines array nemra 10 fel list we ana ba3d el sorting 5aleto nemra wa7ed fa hay3mel list gedida awelha 10 we ba3deha 6 we ba3deha 3 we hakaza
    for i in range(len(sorted_lines)): #be7es el indices el gedida lel setor elle kanet fel lines_array terga3 fa maslan ye3melhom access we yeratebhom bel indices elle rag3a dy
        for j in range(len(boxes_text_original)):#example hategy tegeb lines_array[10] we te5aly da awel satr we ba3daha lines_array[6] we da tany satr we hakaza
            if are_2_boxes_the_same(sorted_lines[i], boxes_text_original[j]):
                sorted_indices.append(j)
                break

    return sorted_lines, sorted_indices

    # original_sorted_lines = []
    # org_sorted = []
    # for s_line in sorted_lines:
    #     for i, org_line in enumerate(convert_t0_2_points(original_art_points)):
    #         if are_2_boxes_the_same(org_line, s_line):
    #             original_sorted_lines.append(original_art_points[i])
    #             org_sorted.append(s_line)
    #
    # return original_sorted_lines, org_sorted

    # return None , None

def get_title_between_2_clusters(upper_cluster, down_cluster, expected_titles):
    min_th_y = upper_cluster[-1][1]
    max_th_y = down_cluster[-1][0]
    min_th_x = min(upper_cluster[-1][2], down_cluster[-1][2])
    max_th_x = max(upper_cluster[-1][3], down_cluster[-1][3])

    title_between = []
    for exp_title in expected_titles:
        x_min, y_min = exp_title[0][1], exp_title[0][0]
        x_max, y_max = exp_title[1][1], exp_title[1][0]

        if y_min > min_th_y and y_min < max_th_y:
            if y_max > min_th_y and min_th_y < max_th_y:
                if x_min >= min_th_x and x_min < max_th_x:
                    if x_max > min_th_x and x_max <= max_th_x:
                        title_between.append(exp_title)

    return title_between

def check_overlapping_by_stretching(upper_cluster, down_cluster, factor=3.2):
    # stretch down the upper cluster by factor to the mean height of its boxes ....

    min_th_y = upper_cluster[-1][1]
    upper_mean_boxes_hight = np.mean([box_height(c) for c in upper_cluster[0]])  # mean hight
    min_th_y += factor * upper_mean_boxes_hight
    max_th_y = down_cluster[-1][0]

    # mean_upper_width =

    if max_th_y <= min_th_y:
        return True
    else:
        return False

def update_clusters_using_titles_between(clusters, expected_titles):
    """
    we want to connect the 2 cluster together if there is any suptitle between them
    steps :
    - sort cluster respect to y_min of the cluster
    - take the top one
    - search for cluster overlappend with me and down me . and has overlap greater tha .8 v iou
    - if there is many take the top one .
    - then check if there is any title between them if there connect them as one cluster if not break .
    - and select the next cluster at hand and start from step 3 .... .



    """
    while True:
        clusters = sorted(clusters, key=lambda c: c[1][0])
        couples = []
        couples_indices = []
        for i, cls in enumerate(clusters):
            # img_0 = draw_cluster([cls] ,orignial_image.copy() )
            clusters_over_lapped_with_me = [(cl_, j) for j, cl_ in enumerate(clusters) if
                                            get_vertical_line_overlapping(cl_[-1][:4], cls[-1][:4], h_iou=False,
                                                                          thr=0.8, resplect_to_min=True) and i != j and
                                            cl_[-1][0] > cls[-1][1]]
            if len(clusters_over_lapped_with_me) > 0:
                if len(clusters_over_lapped_with_me) > 1:
                    clusters_over_lapped_with_me = sorted(clusters_over_lapped_with_me, key=lambda c: c[0][1][0])
                    clusters_over_lapped_with_me = [clusters_over_lapped_with_me[0]]
                title_between = get_title_between_2_clusters(cls, clusters_over_lapped_with_me[0][0], expected_titles)
                if len(title_between) > 0:
                    couples.append((clusters_over_lapped_with_me[0][0], cls, title_between))
                    couples_indices.append((i, clusters_over_lapped_with_me[0][1]))

        if len(couples) > 0:
            clusters = connect_clusters(clusters, couples, couples_indices)

        else:
            break

    return clusters

def refine_connected_clusters(clusters):  # by stretching .....
    """
    the same idea as in connecting 2 cluster with title between
    idea her we stretch cluter alittle bit to down and
    find all clusters overlapped with it and
    check if itersect with and one if there we connect them if not iterate with another cluster at hand

    """
    while True:
        clusters = sorted(clusters, key=lambda c: c[1][0])
        couples = []
        couples_indices = []
        for i, cls in enumerate(clusters):

            clusters_over_lapped_with_me = [(cl_, j) for j, cl_ in enumerate(clusters) if
                                            get_vertical_line_overlapping(cl_[-1][:4], cls[-1][:4], h_iou=False,
                                                                          thr=.8) and i != j and cl_[-1][0] > cls[-1][
                                                1]]
            if len(clusters_over_lapped_with_me) > 0:
                if len(clusters_over_lapped_with_me) > 1:
                    clusters_over_lapped_with_me = sorted(clusters_over_lapped_with_me,
                                                          key=lambda c: c[0][1][0])  # respect to y_min
                    clusters_over_lapped_with_me = [clusters_over_lapped_with_me[0]]

                    # check titles here .....

                # title_between = get_title_between_2_clusters(cls , clusters_over_lapped_with_me[0][0] ,expected_titles )
                over_by_stretching = check_overlapping_by_stretching(cls, clusters_over_lapped_with_me[0][0])

                if over_by_stretching:
                    # img_0 = draw_seg_line(img_0  , title_between[0])
                    couples.append((clusters_over_lapped_with_me[0][0], cls, []))
                    couples_indices.append((i, clusters_over_lapped_with_me[0][1]))

        if len(couples) > 0:
            clusters = connect_clusters(clusters, couples, couples_indices)

        else:
            break

    return clusters

def get_unique_couples_indices(couples_indices):
    re_couple_indices = couples_indices
    unique_couples_indices = []
    while len(re_couple_indices) > 0:
        c_ind_at_hand = re_couple_indices[0]
        re_couple_indices = [couple_id for couple_id in re_couple_indices if
                             not any([idx in c_ind_at_hand for idx in couple_id])]

        unique_couples_indices.append(c_ind_at_hand)
    return unique_couples_indices

def connect_clusters(clusters, couples, couples_indices):
    unique_couples_indices = get_unique_couples_indices(couples_indices)
    new_clusters = []
    remove_indices = []
    for c_indices in unique_couples_indices:
        c_index = couples_indices.index(c_indices)
        connected_cluster = connect_2_clusters(couples[c_index][0], couples[c_index][1], couples[c_index][2])
        new_clusters.append(connected_cluster)
        remove_indices += [c_indices[0], c_indices[1]]

    new_clusters += [c for i, c in enumerate(clusters) if i not in remove_indices]

    return new_clusters

def connect_2_clusters(cls_1, cls_2, title_between):
    points_1, points_2 = cls_1[0], cls_2[0]
    all_points = points_1 + title_between + points_2
    min_y = min(cls_1[1][0], cls_2[1][0])
    max_y = max(cls_1[1][1], cls_2[1][1])
    left_x = min(cls_1[1][2], cls_2[1][2])
    right_x = max(cls_1[1][3], cls_2[1][3])

    center = (min_y + (max_y - min_y) // 2, left_x + (right_x - left_x) // 2)
    return (all_points, (min_y, max_y, left_x, right_x, center))

def generate_gif(sorted_lines, image, path):
    frames = []
    for i, l in enumerate(sorted_lines):
        image = draw_seg_line(image, l)
        frames.append(cv2.resize(image.copy(), (2 * 600, 2 * 800)))

    frames = [Image.fromarray(frame) for frame in frames]
    frames[0].save(path, format='GIF', append_images=frames[1:], save_all=True, duration=100, loop=0)

def is_cluster_inside_that_cluster(cls1, cls2):
    # check for y
    if cls1[1][0] >= cls2[1][0] and cls1[1][0] < cls2[1][1] and cls1[1][1] > cls2[1][0] and cls1[1][1] <= cls2[1][1]:
        # check for x
        if cls1[1][2] >= cls2[1][2] and cls1[1][2] < cls2[1][3] and cls1[1][3] > cls2[1][2] and cls1[1][3] <= cls2[1][
            3]:
            return True

    return False

def refine_inside_clusters(clusters):
    while True:
        clusters_inside_each_others = []
        if len(clusters) > 1:
            for couples in list(combinations(range(len(clusters)), 2)):
                if is_cluster_inside_that_cluster(clusters[couples[0]],
                                                  clusters[couples[1]]) or is_cluster_inside_that_cluster(
                    clusters[couples[1]], clusters[couples[0]]) or get_Area_iou(clusters[couples[0]][1][:4],
                                                                                clusters[couples[1]][1][:4],
                                                                                thr=0.1, resplect_to_min=True):
                    clusters_inside_each_others.append(couples)
                    break


        else:
            break

        if len(clusters_inside_each_others) > 0:
            new_clusters = []
            indices = []
            for couples in clusters_inside_each_others:
                idx_0 = couples[0]
                idx_1 = couples[1]
                indices.append(idx_0)
                indices.append(idx_1)
                cls_0 = clusters[idx_0]
                cls_1 = clusters[idx_1]

                y_min_new_cluster = min(cls_0[1][0], cls_1[1][0])
                y_max_new_cluster = max(cls_0[1][1], cls_1[1][1])
                x_left_new_cluster = min(cls_0[1][2], cls_1[1][2])
                x_right_new_cluster = max(cls_0[1][3], cls_1[1][3])

                new_center = cls_0[1][-1] if (cls_0[1][3] - cls_0[1][2]) > (cls_1[1][3] - cls_1[1][2]) else cls_1[1][-1]

                new_cluster = [cls_0[0] + cls_1[0], (
                    y_min_new_cluster, y_max_new_cluster, x_left_new_cluster, x_right_new_cluster, new_center)]

                new_clusters.append(new_cluster)

            new_clusters += [c for i, c in enumerate(clusters) if i not in indices]
            clusters = new_clusters

        else:
            break

    return clusters