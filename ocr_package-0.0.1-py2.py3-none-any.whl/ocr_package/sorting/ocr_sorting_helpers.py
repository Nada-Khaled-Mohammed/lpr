import numpy as np

def merge_title_with_text_according_to_size(titles_array, text_array):
    merge_title_with_text = []
    text_array = list(text_array)
    for i in range(len(titles_array)):
        if len(text_array) ==0 or len(text_array[0]) == 0:
            break
        box_title = titles_array[i][0]
        box_title_sort = np.sort(np.array([(xb, yb) for xb, yb in box_title], dtype=[('x', '<i4'), ('y', '<i4')]),order=('x', 'y'))
        right_x_title = box_title_sort[-1][0]
        left_x_title = box_title_sort[0][0]
        y_title = box_title_sort[0][1]

        y1_title = box_title[0][1]
        y2_title = box_title[1][1]
        y3_title = box_title[2][1]
        y4_title = box_title[3][1]
        min_y_title = min([y1_title, y2_title, y3_title, y4_title])
        max_y_title = max([y1_title, y2_title, y3_title, y4_title])
        h_title = max_y_title - min_y_title
        text_widths = []
        for j in range(1,len(text_array)):
            text_box_line_0 = text_array[j-1][0]
            text_box_line_1 = text_array[j][0]
            text_box_0_sorted = np.sort(np.array([(xb, yb) for xb, yb in text_box_line_0], dtype=[('x', '<i4'), ('y', '<i4')]),order=('x', 'y'))  # sort left to right
            text_box_1_sorted = np.sort(np.array([(xb, yb) for xb, yb in text_box_line_1], dtype=[('x', '<i4'), ('y', '<i4')]),order=('x', 'y'))  # sort left to right
            x_left_text_0 = text_box_0_sorted[0][0]
            x_right_text_0 = text_box_0_sorted[-1][0]
            width_text_0 = x_right_text_0 - x_left_text_0
            text_widths.append(width_text_0)

            x_left_text_1 = text_box_1_sorted[0][0]
            x_right_text_1 = text_box_1_sorted[-1][0]
            width_text_1 = x_right_text_1 - x_left_text_1

            y_text_0 = text_box_0_sorted[0][1]
            y_text_1 = text_box_1_sorted[0][1]
            y1 = text_box_1_sorted[0][1]
            y2 = text_box_1_sorted[1][1]
            y3 = text_box_1_sorted[2][1]
            y4 = text_box_1_sorted[3][1]
            min_y = min([y1,y2,y3,y4])
            max_y = max([y1,y2,y3,y4])
            h_line = max_y - min_y

            text_box_1_y = max([y1,y2,y3,y4])
            y1 = text_box_0_sorted[0][1]
            y2 = text_box_0_sorted[1][1]
            y3 = text_box_0_sorted[2][1]
            y4 = text_box_0_sorted[3][1]
            text_box_0_y = min([y1,y2,y3,y4])

            # x_right_all = []
            # x_left_all = []
            # boxes_text = [box[0] for box in text_array[j]]
            # for box in boxes_text:
            #     box_sorted = np.sort(np.array([(xb, yb) for xb, yb in box], dtype=[('x', '<i4'), ('y', '<i4')]),order=('x', 'y'))  # sort left to right
            #     x_right_all.append(box_sorted[-1][0])
            #     x_left_all.append(box_sorted[0][0])
            # left_x_text_avg = min(x_left_all)
            # right_x_text_avg = max(x_right_all)
            #
            # last_box_text = boxes_text[-1]
            # last_y_text = last_box_text[0][1]
            # first_y_text = boxes_text[0][1][1]
            # if ((right_x_title < x_right_text_0 and left_x_title > x_left_text_0) or (right_x_title < x_right_text_1 and left_x_title > x_left_text_1))\
            #         and y_title > y_text_0 and y_title < y_text_1:
            if abs(h_title-h_line) < h_line*2  and y_title > text_box_0_y and y_title < text_box_1_y\
                    and (abs(right_x_title - x_right_text_1)<(np.average(text_widths)*0.5)
                    and abs(left_x_title - x_left_text_1)< np.average(text_widths)*0.5):
                merge_title_with_text.append([i, j])
                text_array.insert(j,titles_array[i])
                break
    text_array_copy = list(text_array.copy())
    title_array_copy = titles_array.copy()
    remove_title_indices = []
    # text_array_indices_mark_title = [] # 1 = title , 0 = text
    # for i in range(len(text_array_copy)):
    #     text_array_indices_mark_title.append(np.zeros(len(text_array_copy[i])))

    for i in range(len(merge_title_with_text)):
        title_idx = merge_title_with_text[i][0]
        remove_title_indices.append(title_idx)
        # text_idx = merge_title_with_text[i][1]
        # text_array_copy.insert(text_idx,titles_array[title_idx])
        # text_array_copy[text_idx] = np.append(text_array_copy[text_idx], titles_array[title_idx]).reshape(-1,2)
        # text_array_indices_mark_title_paragraph = np.append(text_array_indices_mark_title[text_idx],1)
        # # sort based on y
        # # text_array_indices_mark_title_paragraph, text_array_copy[text_idx] = sorted(list(zip(text_array_indices_mark_title_paragraph,text_array_copy[text_idx])), key= lambda line:line[1][0][0][1]) # sort text again based on y
        # # text_array_copy[text_idx] = sorted(text_array_copy[text_idx], key= lambda line:line[0][0][1]) # sort text again based on y
        # text_array_and_indices_mark_title_paragraph = sorted(list(zip(text_array_indices_mark_title_paragraph, text_array_copy[text_idx])),key=lambda line: line[1][0][0][1])  # sort text again based on y
        # text_array_indices_mark_title[text_idx] = [item for item, _ in text_array_and_indices_mark_title_paragraph]
        # text_array_copy[text_idx] = [item for _, item in text_array_and_indices_mark_title_paragraph]

    for i in reversed(remove_title_indices):
        del title_array_copy[i]


    # title_array_copy, text_array_copy = check_if_title_at_bottom_of_articles(title_array_copy, text_array_copy)

    # text_array_final = []
    # for i in range(len(text_array_copy)):
    #     for j in range(len(text_array_copy[i])):
    #         text_array_final.append(text_array_copy[i][j])
    # title_array_final = sorted(title_array_copy, key=lambda line: line[0][0][1])
    return title_array_copy, text_array_copy
