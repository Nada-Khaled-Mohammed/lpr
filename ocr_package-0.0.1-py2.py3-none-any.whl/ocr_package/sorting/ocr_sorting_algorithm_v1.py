from PIL import Image
from itertools import combinations
import numpy as np
import cv2
import matplotlib.pyplot as plt
from ocr_package.ocr.ocr_utils import convert_t0_2_points, convert_

def display(image):
    plt.figure(figsize=(20, 20))
    plt.imshow(image)
    plt.show()

def is_there_h_iou(point_1, point_2, respect_to_min=False, v_iou=True):
    if v_iou:

        p1_x_0 = point_1.max(axis=0)[1]
        p1_x_1 = point_1.min(axis=0)[1]

        w_0 = p1_x_0 - p1_x_1

        p2_x_0 = point_2.max(axis=0)[1]
        p2_x_1 = point_2.min(axis=0)[1]

        w_1 = p2_x_0 - p2_x_1

        left_p = min(p1_x_0, p2_x_0)
        right_p = max(p1_x_1, p2_x_1)

        iou = max(0, left_p - right_p)
        if not respect_to_min:
            iou = iou / ((w_0 + w_1) - iou)
        else:
            iou = iou / min(w_0, w_1)

        if iou < .1:
            return False, iou
        else:
            return True, iou

    else:
        p1_x_0 = point_1.max(axis=0)[0]
        p1_x_1 = point_1.min(axis=0)[0]

        h_0 = p1_x_0 - p1_x_1

        p2_x_0 = point_2.max(axis=0)[0]
        p2_x_1 = point_2.min(axis=0)[0]

        h_1 = p2_x_0 - p2_x_1

        down_p = min(p1_x_0, p2_x_0)
        up_p = max(p1_x_1, p2_x_1)

        iou = max(0, down_p - up_p)
        if not respect_to_min:
            iou = iou / ((h_0 + h_1) - iou)
        else:
            iou = iou / min(h_0, h_1)

        if iou < .1:
            return False, iou
        else:
            return True, iou

def overlapping_clustering(art_points):
    # new update i want to check not only the last one but i want to check the last 2 boxes at the cluster
    """
    steps :
    - select the top line from list of input all lines " line is represented by 2 points top left and top right y , x "
    - take this box at hand
    - put it in the cluster you want to fill and remove it from the sorted line list .
    - stretch the box at hand with some ratio ex 1.2 of the height of that box
    - iterate over all boxes to get the box which has min y in the interval < less that y_min + 1.2 h of the boxt at
      and and max_y greater than max y of the box at hand  and the right x of the box greater than the center x of the box at hand > .

    - if number of selected boxes greater than zero
        - check the iou and take only the boxes which has iou greater than .5 with the box at hand respect to min

        - if the selected box greater than 1 take the top one .
        - then find the boxes with has h_iou with it .
        - if there are and boxes has h_iou with it " from the boxes selected boxes "
            break and dont select that box as next one .
            and iterate from the first step .
        - else :
            select it as a next box .
            remove it from list .

    """

    sorted_points = sorted(art_points, key=lambda p: p[0][0])  # respect to y_min
    clusters = []
    for _ in range(1000):
        cluster = []
        if len(sorted_points) == 0:
            break
        box_at_hand = sorted_points[0]
        indices = []
        indices.append(0)
        cluster.append(box_at_hand)
        while True:
            next_box = []
            for idx, b in enumerate(sorted_points):
                # if min((box_height(box_at_hand) , box_height(b))) / max((box_height(box_at_hand) , box_height(b))) > .92 :
                if (b[0][0] <= (box_at_hand[1][0] + 0.5 * box_height(box_at_hand))):
                    if (b[0][0] > (box_at_hand[1][0] - box_height(box_at_hand))):
                        if b[1][1] >= (box_at_hand[0][1] + (box_at_hand[1][1] - box_at_hand[0][1]) / 2):
                            next_box.append([b, idx])

            if len(next_box) > 0:
                next_box = [b for b in next_box if is_there_h_iou(box_at_hand, b[0], respect_to_min=True)[-1] > .5]
                if len(next_box) > 1:
                    next_box = sorted(next_box, key=lambda b: b[0][0][0])
                    upper_box = next_box[0][0]
                    next_box = [b for b in next_box if
                                is_there_h_iou(upper_box, b[0], respect_to_min=True, v_iou=False)[-1] > .1]

            if len(next_box) != 1:
                break
            else:
                _, iou = is_there_h_iou(box_at_hand, next_box[0][0], respect_to_min=True)

                if iou > .15:

                    box_at_hand = next_box[0][0]
                    cluster.append(box_at_hand)
                    indices.append(next_box[0][1])
                else:
                    break

        sorted_points = remove_boxes(sorted_points, indices)
        clusters.append(cluster)
    return clusters

def remove_dublications(art_points):
    filtered_art_points = []
    for b in art_points:
        if len(filtered_art_points) == 0:
            filtered_art_points.append(b)
        else:
            sim = [are_2_boxes_the_same(b, b2) for b2 in filtered_art_points]
            if np.sum(sim) > 0:
                pass
            else:
                filtered_art_points.append(b)

    return np.array(filtered_art_points)

def are_2_boxes_the_same(box_1, box_2):
    return np.all(np.reshape(box_1, (-1,)) == np.reshape(box_2, (-1,)))

def get_next_clusters(remaining_clusters, current_cluster):
    next_cluster = [(c, i) for i, c in enumerate(remaining_clusters) if
                    get_vertical_line_overlapping(c[-1][:4], current_cluster[-1][:4], thr=.1)]
    width_of_current_cluster = max(current_cluster[-1][3] - current_cluster[-1][2], 0)
    next_cluster = [c for c in next_cluster if c[0][-1][3] < current_cluster[-1][2] and c[0][-1][3] > (
            current_cluster[-1][2] - .5 * width_of_current_cluster)]

    return next_cluster

def initial_sorting_step(clusters, orignial_image=None):
    current_cluster, current_idx, clusters = get_upper_right_cluster(clusters, orignial_image)
    remaining_clusters = [c for i, c in enumerate(clusters) if i != current_idx]
    return current_cluster, current_idx, remaining_clusters

def get_upper_right_cluster(clusters, orignial_image=None):
    # return sorted clusters too to avoid eliminated issues

    """




    """
    clusters = sorted(clusters, key=lambda c: c[1][3])[::-1]  # sorting respect to right_x_point of the cluster .
    cluster_at_hand = clusters[0]  # taking the right one .
    at_hand_indx = 0

    clusters_has_iou_with_me = []
    searching_clusters = [cluster_at_hand]  # for a  series of overlapping ...
    while True:
        len_ = len(clusters_has_iou_with_me)
        for i, c in enumerate(clusters):
            # if len(c[0]) > 1 :
            for c_hand in searching_clusters:
                if get_vertical_line_overlapping(c[-1][:4], c_hand[-1][:4], h_iou=False, thr=0.2,
                                                 resplect_to_min=True) and c[-1][0] != c_hand[-1][0]:
                    if len(clusters_has_iou_with_me) == 0:

                        clusters_has_iou_with_me.append((c, i))
                    else:
                        indices = [c[1] for c in clusters_has_iou_with_me]
                        if i not in indices:
                            clusters_has_iou_with_me.append((c, i))

        # clusters_has_iou_with_me = [c for c in clusters_has_iou_with_me if len(c[0][0]) > 1 ]

        len_after = len(clusters_has_iou_with_me)
        if len_after == len_:
            break

        searching_clusters += [c[0] for c in clusters_has_iou_with_me]  # update searhing clusters

    # clusters_has_iou_with_me = [(c , i) for  i , c in enumerate(clusters) if get_vertical_line_overlapping(c[-1][:4] , cluster_at_hand[-1][:4] , h_iou = False , thr= 0.1)  ]

    if not isinstance(orignial_image, type(None)):
        img_0 = draw_cluster([c[0] for c in clusters_has_iou_with_me], orignial_image.copy())
        display(img_0)

    if len(clusters_has_iou_with_me) == 0:
        return cluster_at_hand, at_hand_indx, clusters
    if len(clusters_has_iou_with_me) == 1:

        return clusters_has_iou_with_me[0][0], clusters_has_iou_with_me[0][1], clusters  # me

    else:

        clusters_has_iou_with_me = sorted(clusters_has_iou_with_me, key=lambda c: c[0][1][0])  # respect to y_min
        for k in range(1000):
            right_cluster = clusters_has_iou_with_me[k]  # take the upper  one

            # iterate here till u catch the right top one isa .
            # get all the boxes which has left x greater than me
            clusters_has_x_greater_than_me = [c for c in clusters_has_iou_with_me if
                                              c[0][1][3] > right_cluster[0][1][3]]
            if len(clusters_has_x_greater_than_me) > 0:
                # now right_cluster should overlapp with all
                clusters_has_iou_with_right_cluster_top = [c for c in clusters_has_x_greater_than_me if
                                                           get_vertical_line_overlapping(c[0][-1][:4],
                                                                                         right_cluster[0][-1][:4],
                                                                                         h_iou=False, thr=.1,
                                                                                         resplect_to_min=True)]
                if len(clusters_has_iou_with_right_cluster_top) == len(clusters_has_x_greater_than_me):
                    break
                else:
                    right_cluster = clusters_has_iou_with_me[k]
            else:
                break

                # get all clusters in clusters_has_iou_with_me which has v_iou with it to sort respect to right ...
        clusters_has_iou_with_right_cluster = [c for c in clusters_has_iou_with_me if
                                               get_vertical_line_overlapping(c[0][-1][:4], right_cluster[0][-1][:4],
                                                                             thr=.1, resplect_to_min=True)]
        if len(clusters_has_iou_with_right_cluster) > 0:
            clusters_has_iou_with_right_cluster = sorted(clusters_has_iou_with_right_cluster, key=lambda c: c[0][1][3])[
                                                  ::-1]  # respect to x_right
            right_cluster = clusters_has_iou_with_right_cluster[0]

        # now get the clusters which has iou with me in the same row and take the upper one
        clusters_has_iou_with_right_cluster = [c for c in clusters_has_iou_with_me if
                                               get_vertical_line_overlapping(c[0][-1][:4], right_cluster[0][-1][:4],
                                                                             h_iou=False, thr=.1,
                                                                             resplect_to_min=True) and not get_vertical_line_overlapping(
                                                   c[0][-1][:4], right_cluster[0][-1][:4], h_iou=True, thr=.1,
                                                   resplect_to_min=True)]
        clusters_has_iou_with_right_cluster += [right_cluster]
        if len(clusters_has_iou_with_right_cluster) > 0:
            clusters_has_iou_with_right_cluster = sorted(clusters_has_iou_with_right_cluster,
                                                         key=lambda c: c[0][1][0])  # respect to y_min
            right_cluster = clusters_has_iou_with_right_cluster[0]  # take the upper one in that row

        return right_cluster[0], right_cluster[1], clusters

def get_vertical_line_overlapping(line_1, line_2, h_iou=True, thr=0.0, resplect_to_min=False):
    # line in that format (min_y , max_y , left_x , rightx )
    # print(line_1)
    if h_iou:
        h1 = line_1[1] - line_1[0]
        h2 = line_2[1] - line_2[0]

        up_point = max(line_1[0], line_2[0])
        down_point = min(line_1[1], line_2[1])

        iou = max(0, down_point - up_point)
        if resplect_to_min:
            iou = iou / max(min(h1, h2), .0000001)
        else:
            iou = iou / max((h1 + h2 - iou), 0.0000001)
        if iou > thr:
            return True
        return False
    else:
        w1 = line_1[3] - line_1[2]
        w2 = line_2[3] - line_2[2]
        left_point = max(line_1[2], line_2[2])
        right_point = min(line_1[3], line_2[3])

        iou = max(0, right_point - left_point)
        if resplect_to_min:
            iou = iou / max(min(w1, w2), .0000001)
        else:
            iou = iou / (w1 + w2 - iou)
        if iou > thr:
            return True
        return False

def get_Area_iou(line_1, line_2, thr=0.0, resplect_to_min=False):
    h1 = line_1[1] - line_1[0]
    h2 = line_2[1] - line_2[0]

    up_point = max(line_1[0], line_2[0])
    down_point = min(line_1[1], line_2[1])

    h_iou = max(0, down_point - up_point)

    w1 = line_1[3] - line_1[2]
    w2 = line_2[3] - line_2[2]
    left_point = max(line_1[2], line_2[2])
    right_point = min(line_1[3], line_2[3])

    v_iou = max(0, right_point - left_point)

    intersection_area = h_iou * v_iou

    A_1 = (h1 * w1)
    A_2 = (h2 * w2)

    if resplect_to_min:
        A_iou = intersection_area / min(A_1, A_2)
    else:
        A_iou = intersection_area / (A_1 + A_2 - intersection_area)

    if A_iou > thr:
        return True
    return False

def represent_cluster_as_a_vertical_line(clusters, img=None):
    """
    input cluster is a list of lines .
    we want to represt it with some additional propertes
     out is :
     (input cluster , (min_y , min_x , max_y , max_x  , center ))
     min_y  : min( all min_y of all lines )
     min_x  : min( all min_x of all lines )
     max_y  : max( all max_y of all lines )
     max_x  : max( all max_x of all lines )
     center : ( min_y + (max_y - min_y) // 2 , left_x + (right_x - left_x) // 2 )

    """
    new_clusters = []
    for cluster in clusters:
        cluster = sorted(cluster, key=lambda c: c[0][0])
        new_clusters.append(cluster)

    final_clusters = []
    for cluster in new_clusters:
        min_y, max_y = cluster[0][0][0], cluster[-1][1][0]
        H = max(max_y - min_y, 0)
        min_y = min_y + H * 0.05
        min_y = int(min_y)
        max_y = max_y - H * 0.05
        max_y = int(max_y)

        # print(cluster)
        # print(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
        cluster_ = sorted([reduce_box_width(c) for c in cluster], key=lambda c: c[1][1])
        cluster_ = np.array(cluster_, dtype=np.int32)
        # print(cluster_)
        right_x = cluster_[-1][1][1]
        cluster_ = sorted([reduce_box_width(c) for c in cluster], key=lambda c: c[0][1])
        cluster_ = np.array(cluster_, dtype=np.int32)
        left_x = cluster_[0][0][1]
        color_0, color_1 = generate_random_color(), generate_random_color()

        center = (min_y + (max_y - min_y) // 2, left_x + (right_x - left_x) // 2)
        if not isinstance(img, type(None)):
            img[min_y:max_y, right_x - 20:right_x] = color_0
            img[min_y:max_y, left_x:left_x + 20] = color_1

            img[center[0] - 20:center[0] + 20, center[1] - 20:center[1] + 20] = color_1

        final_clusters.append((cluster, (min_y, max_y, left_x, right_x, center)))

    return img, final_clusters

def draw_cluster(clusters, img):
    for c in clusters:
        _, param = c
        min_y, max_y, left_x, right_x, center = param

        color = generate_random_color()

        img[min_y:max_y, right_x - 20:right_x] = color
        # img[min_y :max_y , left_x  :left_x + 20] = color

        img[center[0] - 20:center[0] + 20, center[1] - 20:center[1] + 20] = color
    return img

def generate_random_color():
    return (np.random.randint(100, 255), np.random.randint(0, 255), np.random.randint(0, 255))

def remove_boxes(boxes, indices):
    new_boxes = []
    for idx, b in enumerate(boxes):
        if idx not in indices:
            new_boxes.append(b)
    return new_boxes

def box_height(box):
    return max(box[1][0] - box[0][0], 0)

def is_this_point_inside(box, point):
    # point (x , y )
    # box [ [y_min , x_min ] , [y_max , x_max] ]

    if point[0] >= box[0][1] and point[0] <= box[1][1]:
        if point[1] >= box[0][0] and point[1] <= box[1][0]:
            return True
    return False

def box_width(box):
    return max(box[1][1] - box[0][1], 0)

def reduce_box_width(box, ratio=.1):
    # print(box)
    h = box_height(box)
    w = box_width(box)

    r = ratio / 2
    # box[0][1] = box[0][1] + r * w
    # box[1][1] = box[1][1] - r * w
    # print(box)
    box = [[box[0][0], box[0][1] + r * w], [box[1][0], box[1][1] - r * w]]

    return box

def draw_seg_line(image, box):
    start_point = (int(box[1][1]), int(box[1][0]))
    end_point = (int(box[0][1]), int(box[1][0]))
    color = (255, 0, 0)
    thickness = 9
    image = cv2.line(image, start_point, end_point, color, thickness)
    return image

def draw_seg_box(image, box):
    start_point = (int(box[1][1]), int(box[1][0]))
    end_point = (int(box[0][1]), int(box[1][0]))
    color = (255, 0, 0)
    thickness = 9
    image = cv2.line(image, start_point, end_point, color, thickness)
    return image

def get_down_clusters_to_the_current_cluster(remaining_clusters, current_cluster):
    """
    get down clusters in the current row respect to v_iou


    """
    # down_cluster = [(c , i) for i , c in enumerate(remaining_clusters) if c[-1][3] > right_x_of_next_clusters and c[-1][3] > current_cluster[1][4][-1]]

    down_cluster = [(c, i) for i, c in enumerate(remaining_clusters) if
                    get_vertical_line_overlapping(c[-1][:4], current_cluster[-1][:4], h_iou=False, thr=0.0)]

    down_cluster = [c for c in down_cluster if c[0][-1][0] >= current_cluster[-1][0]]
    return down_cluster

def SORTING_ALGORITHEM(lines_array, lines_title, orignial_image=None):
    if len(lines_array) < 1:
        return lines_array, []

    art_points = [line for line, _ in lines_array]
    art_points_titles = [line for line, _ in lines_title]
    # art_points = remove_dublications(art_points)
    art_points = np.array(art_points)
    art_points_titles = np.array(art_points_titles)
    art_points = convert_t0_2_points(art_points)

    # art_points = [b for b in art_points if box_width(b) < .4 * orignial_image.shape[1]]

    art_points = remove_dublications(art_points)
    # print("before : "  , len(art_points))
    # if len(list_to_eliminate) != 0:
    #     art_points = [b for b in art_points if not any([is_this_point_inside(b, point) for point in list_to_eliminate])]

    # print(art_points[0])
    # art_points = [reduce_box_width(b) for b in art_points ]
    # art_points = np.array(art_points , dtype = np.int32)
    # print("after : "  , len(art_points))
    # print(art_points[0])

    art_points_titles = convert_t0_2_points(art_points_titles) if not len(art_points_titles) == 0 else art_points_titles
    expected_titles = art_points_titles if len(art_points_titles) > 0 else []

    clusters = overlapping_clustering(art_points)
    _, clusters = represent_cluster_as_a_vertical_line(clusters, None)
    # clusters       = update_clusters_using_titles_between(clusters , expected_titles) if len(expected_titles) != 0 else clusters
    # clusters       = refine_connected_clusters(clusters) # by stretching .
    #     clusters       = refine_inside_clusters(clusters)

    #     if len(clusters_inside_each_others) > 0:
    #         if not isinstance(orignial_image , type(None)):
    #             #print(current_cluster)
    #             img_0 = draw_cluster(clusters_inside_each_others ,orignial_image.copy() )
    #             display(img_0)

    # if not isinstance(orignial_image, type(None)):
    #     # print(current_cluster)
    #     img_0 = draw_cluster(clusters, orignial_image.copy())
    #     display(img_0)

    sorted_clusters = []
    # sort by min y with represent top point of vertical line of each cluster
    current_cluster, current_idx, remaining_clusters = initial_sorting_step(clusters, None)

    #     if not isinstance(orignial_image , type(None)):
    #         #print(current_cluster)
    #         img_0 = draw_cluster([current_cluster] ,orignial_image.copy() )
    #         display(img_0)

    sorted_clusters.append(current_cluster)

    while len(remaining_clusters) > 0:

        for _ in range(100):
            if len(remaining_clusters) > 0:
                next_cluster = get_next_clusters(remaining_clusters, current_cluster)
                if len(next_cluster) > 0:
                    right_x_of_next_clusters = sorted([c[0][-1][3] for c in next_cluster])[-1]
                    nearest_next = sorted(next_cluster, key=lambda c: c[0][1][3])[-1]
                    # down_cluster_in_the_current_row = [(c , i) for i , c in enumerate(remaining_clusters) if c[-1][3] > right_x_of_next_clusters and c[-1][3] > current_cluster[1][4][-1]]
                    down_cluster_in_the_current_row = get_down_clusters_to_the_current_cluster(remaining_clusters,
                                                                                               current_cluster)
                    down_canditates = sorted(down_cluster_in_the_current_row,
                                             key=lambda cand: cand[0][-1][0])  # respect to y_min
                    if len(down_canditates) > 0:
                        nearest_down_canditates = down_canditates[0]

                    down_canditates = [c for c in down_canditates if
                                       len(c[0][0]) > 2]  # accept only clusters which has num of lines greater than 2 .

                    #                     if not isinstance(orignial_image , type(None)):
                    #                         #print(current_cluster)
                    #                         img_0 = draw_cluster(remaining_clusters ,orignial_image.copy() )
                    #                         display(img_0)
                    #                     if not isinstance(orignial_image , type(None)):
                    #                         #print(current_cluster)
                    #                         img_0 = draw_cluster([c[0] for c in down_cluster_in_the_current_row] ,orignial_image.copy() )
                    #                         display(img_0)

                    # down_canditates = [c for c in down_cluster_in_the_current_row if any([get_vertical_line_overlapping(c[0][-1][:4] , c_next[-1][:4]) for c_next in next_cluster])]
                    extend_v = 0
                    if min((current_cluster[1][1] - current_cluster[1][0]),
                           (nearest_next[0][1][1] - nearest_next[0][1][0])) / max(
                        (current_cluster[1][1] - current_cluster[1][0]),
                        (nearest_next[0][1][1] - nearest_next[0][1][0])) >= .9:
                        if len(down_canditates) > 0:
                            upper_canditate = down_canditates[0]
                            overlapping_with_upper_canditates = [
                                get_vertical_line_overlapping(c[0][-1][:4], upper_canditate[0][-1][4], thr=0.5,
                                                              resplect_to_min=True) for c in down_canditates]

                            if len(overlapping_with_upper_canditates) > 1:
                                extend_v = .3 * (current_cluster[1][3] - current_cluster[1][2])

                    if len(down_cluster_in_the_current_row) > 0:

                        next_line = nearest_next[0][-1][:4]
                        next_line = (next_line[0], next_line[1], next_line[2], next_line[3] + extend_v)
                        # iou_with_next = [get_vertical_line_overlapping(c[0][-1][:4] , next_line  , h_iou= False, thr=0.1 , resplect_to_min= True )  for c in  down_canditates ]

                        iou_with_next = [get_vertical_line_overlapping(c[0][-1][:4], next_line, h_iou=False, thr=0.3,
                                                                       resplect_to_min=True) for c in
                                         [nearest_down_canditates]]

                        if any(iou_with_next):
                            # print("yes")
                            current_cluster = nearest_next[0]
                            current_idx = nearest_next[1]
                        else:
                            break

                        #                         else :
                        #                             current_cluster = down_canditates[0][0]
                        #                             current_idx     = down_canditates[0][1]

                        #                         elif len(down_canditates) > 1 :
                        #                             # here i have to start checking if there is any overlapping with that canditates or not
                        #                             clusters_has_iou_current_canditate = [ c for c in down_canditates if get_vertical_line_overlapping(c[0][-1][:4] , current_cluster[-1][:4])  ]
                        #                             clusters_has_iou_current_canditate = sorted(clusters_has_iou_current_canditate , key=lambda c: c[0][1][3])[::-1] # respect to right x

                        #                             # here i will check if they have overlapping with the next or not if # take the next one first
                        #                             iou_with_next = [get_vertical_line_overlapping(c[0][-1][:4] , nearest_next[0][-1][:4] , h_iou= False )  for c in  clusters_has_iou_current_canditate ]

                        #                             if any(iou_with_next):
                        #                                 current_cluster  = nearest_next[0]
                        #                                 current_idx      = nearest_next[1]

                        #                             else :
                        #                                 if len(clusters_has_iou_current_canditate) > 0 :
                        #                                     current_cluster  = clusters_has_iou_current_canditate[0][0]
                        #                                     current_idx      = clusters_has_iou_current_canditate[0][1]
                        #                                 else :
                        #                                     break

                        remaining_clusters = [c for i, c in enumerate(remaining_clusters) if i != current_idx]
                        sorted_clusters.append(current_cluster)

                    else:
                        break
                else:
                    break

        current_cluster, current_idx, remaining_clusters = get_upper_right_cluster(remaining_clusters)
        #         if isinstance(current_cluster  , type(None)) :
        #             continue
        sorted_clusters.append(current_cluster)
        remaining_clusters = [c for i, c in enumerate(remaining_clusters) if i != current_idx]

    #     if not isinstance(orignial_image , type(None)):
    #         img_0 = draw_cluster(sorted_clusters ,orignial_image.copy() )
    #         display(img_0)

    sorted_lines = []
    for cl in sorted_clusters:
        #         boxes = cl[0]
        #         boxes = sorted(boxes , key= lambda b : b[0][0]) # respect_to_y_min

        #         new_boxes = []
        #         indices = []
        #         box_at_hand_top = boxes[0] # first top_box
        #         idx             = 0
        #         line_0 = [box_at_hand_top[0][0] ,box_at_hand_top[1][0] , box_at_hand_top[0][1] , box_at_hand_top[1][1] ]
        #         boxes_has_h_iou_with_top_at_hand = []
        #         for i , b in enumerate(boxes):
        #             line_1 = [b[0][0] ,b[1][0] , b[0][1] , b[1][1] ]
        #             if get_vertical_line_overlapping( line_0 , line_1 ,  h_iou= True , thr= .5 , resplect_to_min= True) :
        #                 boxes_has_h_iou_with_top_at_hand.append((b , i ))

        #         if len(boxes_has_h_iou_with_top_at_hand) > 0 :
        #             boxes_has_h_iou_with_top_at_hand = sorted(boxes_has_h_iou_with_top_at_hand , key= lambda b : b[0][1][1]) # respect_to_x_max
        #             box_at_hand_top = boxes_has_h_iou_with_top_at_hand[-1][0]
        #             idx             = boxes_has_h_iou_with_top_at_hand[-1][1]

        #         while len(boxes) > 0  :
        #             new_boxes.append(box_at_hand_top)
        #             indices.append(idx)
        #             line_0 = [box_at_hand_top[0][0] ,box_at_hand_top[1][0] , box_at_hand_top[0][1] , box_at_hand_top[1][1] ]
        #             boxes_at_the_same_row = []
        #             for i , b in enumerate(boxes):
        #                 if i not in  indices :
        #                     line_1 = [b[0][0] ,b[1][0] , b[0][1] , b[1][1] ]
        #                     if get_vertical_line_overlapping( line_0 , line_1 ,  h_iou= False , thr= .5 , resplect_to_min= True) :
        #                         if b[0][0] > box_at_hand_top[0][0] :

        #                             canditate_b = b
        #                             # check if there is any boxes between ....
        #                             min_x_left = min(canditate_b[0][1] , box_at_hand_top[0][1])
        #                             max_x_right = max(canditate_b[1][1] , box_at_hand_top[1][1])

        #                             boxes_in_between = [(b_ , j) for j ,  b_ in enumerate(boxes) if b_[0][0] > box_at_hand_top[1][0] and b_[0][0] < canditate_b[1][0] and b_[0][1] >= min_x_left and b_[1][1] <= max_x_right and j not in (indices + [i])]
        #                             if len(boxes_in_between) > 0 :
        #                                 #if len(boxes_in_between) == 1 :
        #                                 boxes_at_the_same_row.append((boxes_in_between[0][0] ,  boxes_in_between[0][1]))

        #                             else :
        #                                 boxes_at_the_same_row.append((b , i ))

        #             if len(boxes_at_the_same_row) > 0 :
        #                 boxes_at_the_same_row = sorted(boxes_at_the_same_row , key= lambda b : b[0][0][0]) # respect_to_y_min
        #                 box_at_hand_top = boxes_at_the_same_row[0][0]
        #                 idx             = boxes_at_the_same_row[0][1]
        #             else :
        #                 re_boxes = [ (b , i) for i , b in enumerate(boxes) if i not in indices ]
        #                 if len(re_boxes) > 0 :
        #                     box_at_hand_top = re_boxes[0][0]
        #                     idx             = re_boxes[0][1]
        #                 else :
        #                     break

        cl = cl[0]
        cl = sorted(cl, key=lambda c: c[0][0])
        # sorted_lines.extend(new_boxes)
        sorted_lines.extend(cl)
    # return sorted_lines
    boxes_text_original = [box for box, _ in lines_array]
    boxes_text_original = convert_t0_2_points(np.array(boxes_text_original))

    sorted_indices = []
    for i in range(len(sorted_lines)):
        for j in range(len(boxes_text_original)):
            if are_2_boxes_the_same(sorted_lines[i], boxes_text_original[j]):
                sorted_indices.append(j)
                break

    return sorted_lines, sorted_indices

    # original_sorted_lines = []
    # org_sorted = []
    # for s_line in sorted_lines:
    #     for i, org_line in enumerate(convert_t0_2_points(original_art_points)):
    #         if are_2_boxes_the_same(org_line, s_line):
    #             original_sorted_lines.append(original_art_points[i])
    #             org_sorted.append(s_line)
    #
    # return original_sorted_lines, org_sorted

    # return None , None

def get_title_between_2_clusters(upper_cluster, down_cluster, expected_titles):
    min_th_y = upper_cluster[-1][1]
    max_th_y = down_cluster[-1][0]
    min_th_x = min(upper_cluster[-1][2], down_cluster[-1][2])
    max_th_x = max(upper_cluster[-1][3], down_cluster[-1][3])

    title_between = []
    for exp_title in expected_titles:
        x_min, y_min = exp_title[0][1], exp_title[0][0]
        x_max, y_max = exp_title[1][1], exp_title[1][0]

        if y_min > min_th_y and y_min < max_th_y:
            if y_max > min_th_y and min_th_y < max_th_y:
                if x_min >= min_th_x and x_min < max_th_x:
                    if x_max > min_th_x and x_max <= max_th_x:
                        title_between.append(exp_title)

    return title_between

def check_overlapping_by_stretching(upper_cluster, down_cluster, factor=3.2):
    # stretch down the upper cluster by factor to the mean height of its boxes ....

    min_th_y = upper_cluster[-1][1]
    upper_mean_boxes_hight = np.mean([box_height(c) for c in upper_cluster[0]])  # mean hight
    min_th_y += factor * upper_mean_boxes_hight
    max_th_y = down_cluster[-1][0]

    # mean_upper_width =

    if max_th_y <= min_th_y:
        return True
    else:
        return False

def update_clusters_using_titles_between(clusters, expected_titles):
    """
    we want to connect the 2 cluster together if there is any suptitle between them
    steps :
    - sort cluster respect to y_min of the cluster
    - take the top one
    - search for cluster overlappend with me and down me . and has overlap greater tha .8 v iou
    - if there is many take the top one .
    - then check if there is any title between them if there connect them as one cluster if not break .
    - and select the next cluster at hand and start from step 3 .... .



    """
    while True:
        clusters = sorted(clusters, key=lambda c: c[1][0])
        couples = []
        couples_indices = []
        for i, cls in enumerate(clusters):
            # img_0 = draw_cluster([cls] ,orignial_image.copy() )
            clusters_over_lapped_with_me = [(cl_, j) for j, cl_ in enumerate(clusters) if
                                            get_vertical_line_overlapping(cl_[-1][:4], cls[-1][:4], h_iou=False,
                                                                          thr=0.8, resplect_to_min=True) and i != j and
                                            cl_[-1][0] > cls[-1][1]]
            if len(clusters_over_lapped_with_me) > 0:
                if len(clusters_over_lapped_with_me) > 1:
                    clusters_over_lapped_with_me = sorted(clusters_over_lapped_with_me, key=lambda c: c[0][1][0])
                    clusters_over_lapped_with_me = [clusters_over_lapped_with_me[0]]
                title_between = get_title_between_2_clusters(cls, clusters_over_lapped_with_me[0][0], expected_titles)
                if len(title_between) > 0:
                    couples.append((clusters_over_lapped_with_me[0][0], cls, title_between))
                    couples_indices.append((i, clusters_over_lapped_with_me[0][1]))

        if len(couples) > 0:
            clusters = connect_clusters(clusters, couples, couples_indices)

        else:
            break

    return clusters

def refine_connected_clusters(clusters):  # by stretching .....
    """
    the same idea as in connecting 2 cluster with title between
    idea her we stretch cluter alittle bit to down and
    find all clusters overlapped with it and
    check if itersect with and one if there we connect them if not iterate with another cluster at hand

    """
    while True:
        clusters = sorted(clusters, key=lambda c: c[1][0])
        couples = []
        couples_indices = []
        for i, cls in enumerate(clusters):

            clusters_over_lapped_with_me = [(cl_, j) for j, cl_ in enumerate(clusters) if
                                            get_vertical_line_overlapping(cl_[-1][:4], cls[-1][:4], h_iou=False,
                                                                          thr=.8) and i != j and cl_[-1][0] > cls[-1][
                                                1]]
            if len(clusters_over_lapped_with_me) > 0:
                if len(clusters_over_lapped_with_me) > 1:
                    clusters_over_lapped_with_me = sorted(clusters_over_lapped_with_me,
                                                          key=lambda c: c[0][1][0])  # respect to y_min
                    clusters_over_lapped_with_me = [clusters_over_lapped_with_me[0]]

                    # check titles here .....

                # title_between = get_title_between_2_clusters(cls , clusters_over_lapped_with_me[0][0] ,expected_titles )
                over_by_stretching = check_overlapping_by_stretching(cls, clusters_over_lapped_with_me[0][0])

                if over_by_stretching:
                    # img_0 = draw_seg_line(img_0  , title_between[0])
                    couples.append((clusters_over_lapped_with_me[0][0], cls, []))
                    couples_indices.append((i, clusters_over_lapped_with_me[0][1]))

        if len(couples) > 0:
            clusters = connect_clusters(clusters, couples, couples_indices)

        else:
            break

    return clusters

def get_unique_couples_indices(couples_indices):
    re_couple_indices = couples_indices
    unique_couples_indices = []
    while len(re_couple_indices) > 0:
        c_ind_at_hand = re_couple_indices[0]
        re_couple_indices = [couple_id for couple_id in re_couple_indices if
                             not any([idx in c_ind_at_hand for idx in couple_id])]

        unique_couples_indices.append(c_ind_at_hand)
    return unique_couples_indices

def connect_clusters(clusters, couples, couples_indices):
    unique_couples_indices = get_unique_couples_indices(couples_indices)
    new_clusters = []
    remove_indices = []
    for c_indices in unique_couples_indices:
        c_index = couples_indices.index(c_indices)
        connected_cluster = connect_2_clusters(couples[c_index][0], couples[c_index][1], couples[c_index][2])
        new_clusters.append(connected_cluster)
        remove_indices += [c_indices[0], c_indices[1]]

    new_clusters += [c for i, c in enumerate(clusters) if i not in remove_indices]

    return new_clusters

def connect_2_clusters(cls_1, cls_2, title_between):
    points_1, points_2 = cls_1[0], cls_2[0]
    all_points = points_1 + title_between + points_2
    min_y = min(cls_1[1][0], cls_2[1][0])
    max_y = max(cls_1[1][1], cls_2[1][1])
    left_x = min(cls_1[1][2], cls_2[1][2])
    right_x = max(cls_1[1][3], cls_2[1][3])

    center = (min_y + (max_y - min_y) // 2, left_x + (right_x - left_x) // 2)
    return (all_points, (min_y, max_y, left_x, right_x, center))

def generate_gif(sorted_lines, image, path):
    frames = []
    for i, l in enumerate(sorted_lines):
        image = draw_seg_line(image, l)
        frames.append(cv2.resize(image.copy(), (2 * 600, 2 * 800)))

    frames = [Image.fromarray(frame) for frame in frames]
    frames[0].save(path, format='GIF', append_images=frames[1:], save_all=True, duration=100, loop=0)

def is_cluster_inside_that_cluster(cls1, cls2):
    # check for y
    if cls1[1][0] >= cls2[1][0] and cls1[1][0] < cls2[1][1] and cls1[1][1] > cls2[1][0] and cls1[1][1] <= cls2[1][1]:
        # check for x
        if cls1[1][2] >= cls2[1][2] and cls1[1][2] < cls2[1][3] and cls1[1][3] > cls2[1][2] and cls1[1][3] <= cls2[1][
            3]:
            return True

    return False

def refine_inside_clusters(clusters):
    while True:
        clusters_inside_each_others = []
        if len(clusters) > 1:
            for couples in list(combinations(range(len(clusters)), 2)):
                if is_cluster_inside_that_cluster(clusters[couples[0]],
                                                  clusters[couples[1]]) or is_cluster_inside_that_cluster(
                    clusters[couples[1]], clusters[couples[0]]) or get_Area_iou(clusters[couples[0]][1][:4],
                                                                                clusters[couples[1]][1][:4],
                                                                                thr=0.1, resplect_to_min=True):
                    clusters_inside_each_others.append(couples)
                    break


        else:
            break

        if len(clusters_inside_each_others) > 0:
            new_clusters = []
            indices = []
            for couples in clusters_inside_each_others:
                idx_0 = couples[0]
                idx_1 = couples[1]
                indices.append(idx_0)
                indices.append(idx_1)
                cls_0 = clusters[idx_0]
                cls_1 = clusters[idx_1]

                y_min_new_cluster = min(cls_0[1][0], cls_1[1][0])
                y_max_new_cluster = max(cls_0[1][1], cls_1[1][1])
                x_left_new_cluster = min(cls_0[1][2], cls_1[1][2])
                x_right_new_cluster = max(cls_0[1][3], cls_1[1][3])

                new_center = cls_0[1][-1] if (cls_0[1][3] - cls_0[1][2]) > (cls_1[1][3] - cls_1[1][2]) else cls_1[1][-1]

                new_cluster = [cls_0[0] + cls_1[0], (
                    y_min_new_cluster, y_max_new_cluster, x_left_new_cluster, x_right_new_cluster, new_center)]

                new_clusters.append(new_cluster)

            new_clusters += [c for i, c in enumerate(clusters) if i not in indices]
            clusters = new_clusters

        else:
            break

    return clusters