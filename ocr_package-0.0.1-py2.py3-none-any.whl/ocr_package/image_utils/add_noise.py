import numpy as np
import cv2

def _add_noise(noise_typ,image):
    if noise_typ == "gauss":
        row,col= image.shape
        mean = 0
        var = 0.1
        sigma = var**0.5
        gauss = np.random.normal(mean,sigma,(row,col))
        gauss = gauss.reshape(row,col)
        noisy = image + gauss
        return noisy
    elif noise_typ == "s&p":
        row,col = image.shape
        s_vs_p = 0.99
        amount = 0.2
        out = np.copy(image)
        # Salt mode
        num_salt = np.ceil(amount * image.size * s_vs_p)
        coords = [np.random.randint(0, max(i - 1, 1), int(num_salt)) for i in image.shape]
        out[coords[0], coords[1]] = 1.
        # Pepper mode
        num_pepper = np.ceil(amount* image.size * (1. - s_vs_p))
        coords = [np.random.randint(0, max(i - 1, 1), int(num_pepper)) for i in image.shape]
        out[coords[0], coords[1]] = 0
        return out
    elif noise_typ == "poisson":
        vals = len(np.unique(image))
        vals = 2 ** np.ceil(np.log2(vals))
        noisy = np.random.poisson(image * vals) / float(vals)
        return noisy
    elif noise_typ =="speckle":
        row,col = image.shape
        gauss = np.random.randn(row,col)
        gauss = gauss.reshape(row,col)
        noisy = image + image * gauss
        return noisy

def add_s_p(image):
    #s_vs_p = 1.
    s_vs_p = np.random.uniform(0.8, 0.9)
    amount = np.random.uniform(0.01, 0.05)
    #amount = 0.15
    out = np.copy(image)
    # Salt mode
    num_salt = np.ceil(amount * image.size * s_vs_p)
    coords = [np.random.randint(0, max(i - 1, 1), int(num_salt)) for i in image.shape]
    out[coords[0], coords[1]] = 1.

    # Pepper mode
    num_pepper = np.ceil(amount * image.size * (1. - s_vs_p))
    coords = [np.random.randint(0, max(i - 1, 1), int(num_pepper)) for i in image.shape]
    out[coords[0], coords[1]] = 0
    return out

def add_black_blotches(image):
    if image.shape[1] <= image.shape[0]:
        return(image)
    num_blotches = np.ceil(np.random.uniform(0, 4)).astype(int)
    mean_coords = [np.random.randint(0, max(i - 1, 1), int(num_blotches)) for i in image.shape]
    out = np.copy(image)
    for blotch in range(num_blotches):
        pepper_intensity = abs(np.random.normal(0.15, 0.02))
        blotch_size = np.random.uniform([10, 10], [image.shape[0], image.shape[1]//10]).astype(int)
        num_pepper = np.ceil((blotch_size[0] * blotch_size[1]) * pepper_intensity)
        mean = [mean_coords[0][blotch], mean_coords[1][blotch]]
        try:
            coords = [np.random.randint(0, mean[d] - i//2, min(image.shape[d] - 1, mean[d] + i//2), int(num_pepper))
                      for d, i in enumerate(blotch_size)]
        except Exception as e:
            # print(e)
            # print(f'image shape: {image.shape}')
            # print(f'blotch size: {blotch_size}')
            # print(f'mean_coords: {mean_coords}')
            return image
        out[coords[0], coords[1]] = 0
    return out

def add_white_blotches(image):
    if image.shape[1] <= image.shape[0]:
        return(image)
    num_blotches = np.ceil(np.random.uniform(0, 4)).astype(int)
    mean_coords = [np.random.randint(0, max(i - 1, 1), int(num_blotches)) for i in image.shape]
    out = np.copy(image)
    for blotch in range(num_blotches):
        blotch_size = np.random.uniform([10, 10], [image.shape[0], image.shape[1]//10]).astype(int)
        salt_intensity = np.random.uniform(0.1, 0.2)
        num_salt = np.ceil((blotch_size[0] * blotch_size[1]) * salt_intensity)
        mean = [mean_coords[0][blotch], mean_coords[1][blotch]]
        try:
            coords = [
                np.random.randint(0, max(mean[d] - i // 2, 1), min(image.shape[d] - 1, mean[d] + i // 2), int(num_salt))
                for d, i in enumerate(blotch_size)]
        except Exception as e:
            # print(e)
            # print(f'image shape: {image.shape}')
            # print(f'blotch size: {blotch_size}')
            # print(f'mean_coords: {mean_coords}')
            return image
        out[coords[0], coords[1]] = 255
    return out

def add_noise(image):
    image = add_white_blotches(image)
    image = add_black_blotches(image)
    image = add_s_p(image)
    return image

