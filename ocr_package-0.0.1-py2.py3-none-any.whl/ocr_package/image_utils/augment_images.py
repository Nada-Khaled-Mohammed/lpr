import cv2, os
import numpy as np
from os.path import join, isfile, splitext
from shutil import copyfile

dir_path = "../../data/augmentation/"
num_augmented = 20

def augment_image(image):
    dims = image.shape
    print(image)
    if image.shape[2] > 1:
        image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    factor_mean = np.array([1.0, 1.0])
    factor_cov = np.array([[0.05, 0.05], [0.05, 0.05]])
    factor = np.random.multivariate_normal(factor_mean, factor_cov)
    image = cv2.resize(image, (0, 0), fx=max(factor[0], 0.5), fy=max(factor[1], 0.5))
    if np.random.random() <= 0.5:
        image = cv2.resize(image, (dims[1], dims[0]))
    if np.random.random() <= 0.7:
        image = cv2.threshold(image, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
    else:
        image = cv2.adaptiveThreshold(image, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2)

    return image

if __name__ == "__main__":
    files = [f for f in os.listdir(dir_path) if isfile(join(dir_path, f))]
    for f in files:
        image_path = join(dir_path, f)
        basename, ext = splitext(image_path)
        gt_path = basename + ".gt.txt"
        if ext not in [".png", ".tif", ".jpg"]:
            continue
        print(f"Augmenting {f}")
        image = cv2.imread(image_path)
        for i in range(num_augmented):
            rescaled = augment_image(image)
            new_basename = basename + f"_{i+1}"
            cv2.imwrite(new_basename + ext, rescaled)
            copyfile(gt_path, new_basename + ".gt.txt")

