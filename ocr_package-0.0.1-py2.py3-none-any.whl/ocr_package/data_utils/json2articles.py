
import cv2, os
import pandas as pd
from PIL import Image, ImageOps

import numpy as np
from pathlib import Path

def store_jsonFile(data, images_path,image_name_json, target_path, articlesstructre=True):
    images_path = images_path
    if articlesstructre:
        articles_path = os.path.join(target_path,"articles")
        os.makedirs(articles_path, exist_ok=True)
    else:
        ads_path = os.path.join(target_path,"titles")
        os.makedirs(ads_path, exist_ok=True)
    pages_path = os.path.join(target_path,"pages")
    os.makedirs(pages_path,exist_ok=True)
    image_name = image_name_json.split('.')[0]
    image_num = int(image_name.split('_')[-1].split('.')[0])
    # images_path = images_path+str(image_num)
    list_data = []
    art_names = []
    art_num = 1
    # res_path = r'D:\QUpath_Images\result'
    for i in range(0, len(data)):
        art_names.append(art_num)
        list_data.append(data['features'][i]['geometry']['coordinates'])
        art_num += 1
    dic = {"articleName": art_names,
           "coordinates": list_data}
    if os.path.exists(os.path.join(images_path,image_name+".tif")):
        image = Image.open(os.path.join(images_path,image_name+".tif"))
    else:
        image = Image.open(os.path.join(images_path, image_name + ".jpg"))
    image = ImageOps.grayscale(image)
    image = np.array(image)
    image = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
    # w_scale = width / image.shape[1]
    # h_scale = height / image.shape[0]
    w_scale = h_scale = 1
    # image = cv2.resize(image, (width, height), interpolation=cv2.INTER_AREA)
    if articlesstructre:
        articles_out = np.zeros_like(image)
    else:
        ads_out = np.zeros_like(image)
    for j, points in enumerate(dic["coordinates"]):
        if len(points)>1:
            for i in range(len(points)):
                points_i = np.asarray(points[i]).reshape((-1, 1, 2)).astype(int)
                points_i = [(x*w_scale,y*h_scale) for p in points_i for x,y in p]
                points_i = np.asarray(points_i).reshape((-1, 1, 2)).astype(int)
                if articlesstructre:
                    articles_out = cv2.polylines(articles_out, [points_i], isClosed, white, thickness)
                else:
                    ads_out = cv2.fillPoly(ads_out, [points_i], white)
                # x,y,w,h = cv2.boundingRect(points_i)
                # cropped_image = image[y:y+h, x:x+w]
                # cv2.imwrite(os.path.join(r"D:\gitlab\ocr\assets\ahram_images", image_name+"_"+str(j)+".jpg"), cropped_image)
        else:
            points = np.asarray(points).reshape((-1, 1, 2)).astype(int)
            points = [(x * w_scale, y * h_scale) for p in points for x, y in p]
            points = np.asarray(points).reshape((-1, 1, 2)).astype(int)
            if articlesstructre:
                articles_out = cv2.polylines(articles_out, [points], isClosed, white, thickness)
            else:
                ads_out = cv2.fillPoly(ads_out, [points], white)
            # x, y, w, h = cv2.boundingRect(points)
            # cropped_image = image[y:y + h, x:x + w]
            # cv2.imwrite(os.path.join(r"D:\gitlab\ocr\assets\ahram_images", image_name + "_" + str(j) + ".jpg"),
            #             cropped_image)
    if articlesstructre:
        cv2.imwrite(os.path.join(articles_path,image_name+".jpg"),articles_out)
    else:
        cv2.imwrite(os.path.join(ads_path,image_name+".jpg"),ads_out)
    cv2.imwrite(os.path.join(pages_path,image_name+".jpg"),image)


def store_jsonFile_lines(data, images_path,image_name_json, target_path):
    images_path = images_path
    # images_path = Path(images_path).rglob("*.jpg")
    titles_path = os.path.join(target_path,"titles")
    pages_path = os.path.join(target_path,"pages")
    os.makedirs(titles_path, exist_ok=True)
    # os.makedirs(ads_path, exist_ok=True)
    os.makedirs(pages_path,exist_ok=True)
    image_name = image_name_json.split('.')[0]
    image_num = int(image_name.split('_')[-1].split('.')[0])
    name = image_name.split('.')[0].split('_')
    year = name[0]
    month = name[1]
    day = name[2]
    images_path = os.path.join(images_path,year,month,day)
    # images_path = images_path+str(image_num)
    list_data = []
    art_names = []
    art_num = 1
    # res_path = r'D:\QUpath_Images\result'
    for i in range(0, len(data)):
        art_names.append(art_num)
        list_data.append(data['features'][i]['geometry']['coordinates'])
        art_num += 1
    dic = {"articleName": art_names,
           "coordinates": list_data}
    if os.path.exists(os.path.join(images_path,image_name+".tif")):
        image = Image.open(os.path.join(images_path,image_name+".tif"))
    else:
        image = Image.open(os.path.join(images_path, image_name + ".jpg"))
    image = ImageOps.grayscale(image)
    image = np.array(image)
    image = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
    # w_scale = width / image.shape[1]
    # h_scale = height / image.shape[0]
    w_scale = h_scale = 1
    # image = cv2.resize(image, (width, height), interpolation=cv2.INTER_AREA)
    titles_out = np.zeros_like(image)
    # ads_out = np.zeros_like(image)
    for j, points in enumerate(dic["coordinates"]):
        if len(points)>1:
            for i in range(len(points)):
                points_i = np.asarray(points[i]).reshape((-1, 1, 2)).astype(int)
                points_i = [(x*w_scale,y*h_scale) for p in points_i for x,y in p]
                points_i = np.asarray(points_i).reshape((-1, 1, 2)).astype(int)
                titles_out = cv2.fillPoly(titles_out, [points_i], white)
                # x,y,w,h = cv2.boundingRect(points_i)
                # cropped_image = image[y:y+h, x:x+w]
                # cv2.imwrite(os.path.join(r"D:\gitlab\ocr\assets\ahram_images", image_name+"_"+str(j)+".jpg"), cropped_image)
        else:
            points = np.asarray(points).reshape((-1, 1, 2)).astype(int)
            box = [(x * w_scale, y * h_scale) for p in points for x, y in p]
            box_x1 = box[0][0]
            box_y1 = box[0][1]
            box_x2 = box[1][0]
            box_y2 = box[1][1]
            box_x3 = box[2][0]
            box_y3 = box[2][1]
            box_x4 = box[3][0]
            box_y4 = box[3][1]

            unique_x = [box_x1,box_x2,box_x3,box_x4]
            if len(list(set(unique_x))) > 2:
                titles_out = cv2.fillPoly(titles_out, [points], white)
            else:
                xtl = min(box_x1, box_x2, box_x3, box_x4)
                xbr = max(box_x1, box_x2, box_x3, box_x4)
                ytl = min(box_y1, box_y2, box_y3, box_y4)
                ybr = max(box_y1, box_y2, box_y3, box_y4)

                height_box = ybr - ytl
                height_box_ratio = height_box * 0.1
                ytl = ytl + int(height_box_ratio)
                ybr = ybr - int(height_box_ratio)
                cv2.rectangle(titles_out, (xtl, ytl), (xbr, ybr), white, -1)

            # points = np.asarray(points).reshape((-1, 1, 2)).astype(int)
            # titles_out = cv2.fillPoly(titles_out, [points], white)
            # x, y, w, h = cv2.boundingRect(points)
            # cropped_image = image[y:y + h, x:x + w]
            # cv2.imwrite(os.path.join(r"D:\gitlab\ocr\assets\ahram_images", image_name + "_" + str(j) + ".jpg"),
            #             cropped_image)
    cv2.imwrite(os.path.join(titles_path,image_name+".jpg"),titles_out)
    # cv2.imwrite(os.path.join(ads_path,image_name+".jpg"),ads_out)
    cv2.imwrite(os.path.join(pages_path,image_name+".jpg"),image)

def readingJsons(json_path, target_path, images_path):
    for file in os.listdir(images_path):
        file_json = file.split('.')[0]+".geojson"
        # if os.path.exists(os.path.join(json_path,file_json)):
        data = os.path.join(json_path, file_json)
        data = pd.read_json(data)
        print("Processing file: "+file)
        try:
            store_jsonFile(data, images_path, file_json, target_path, articlesstructre=True)
        except Exception as e:
            print(e)
            continue
            # store_jsonFile_lines(data, images_path, file, target_path)
        # else:
        #     pages_path = os.path.join(target_path, "pages")
        #     image = Image.open(os.path.join(images_path,file))
        #     image = ImageOps.grayscale(image)
        #     image = np.array(image)
        #     image = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
        #     cv2.imwrite(os.path.join(pages_path, file), image)
        #     articles_out = np.zeros_like(image)
        #     ads_path = os.path.join(target_path, "titles")
        #     cv2.imwrite(os.path.join(ads_path, file), articles_out)



source_path = r"D:\qupath\mosawer"
target_path = r"D:\data\Al_Mosawer\mosawer_annotation\trial_articles_2_3"
images_path = r"D:\data\Al_Mosawer\mosawer_annotation\trial_articles_2_3\images"
# width = 3000
# height = 5000
isClosed = True
white = (255, 255, 255)
black = (0, 0, 0)
red = (0, 0, 255)
thickness = 20
# src_path = r"D:\data\Al_Ahram\datasets\ahram_pages_types\ads"
# titles_path = r"D:\data\Al_Ahram\datasets\ahram_pages_types\ads_titles"
# for file in os.listdir(src_path):
#     image = Image.open(os.path.join(src_path,file))
#     image = ImageOps.grayscale(image)
#     image = np.array(image)
#     image = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
#     titles_out = np.zeros_like(image)
#     cv2.imwrite(os.path.join(titles_path, file.split('.')[0] + ".jpg"), titles_out)
readingJsons(source_path, target_path, images_path)

# parse_new_format(source_path=source_path, target_path=target_path)
# read_articles(source_path)
