import os
from ocr_package.segmentation.segmentation_utils import extract_line_img_from_rect
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import cv2
import json
from pathlib import Path

jsons_path = r"D:\data\Court\annotation_data\output_jsons"
images_path = r"D:\data\Court\annotation_data\images_to_annotation_shuffled\input_images\all"
save_path_all = r"D:\data\Court\annotation_data\output_from_json_for_training\output_lines"
save_wrong_lines = r"D:\data\Court\annotation_data\output_from_json_for_training\save_wrong"
save_images = r"D:\data\Court\annotation_data\output_from_json_for_training\output_images_with_seg_map"

os.makedirs(save_wrong_lines, exist_ok=True)
files = Path(jsons_path).rglob("*.geojson")
save_line_seg_map = True
erode = True


for file in files:
    save_path_page = os.path.join(save_path_all, file.name.split('.')[0])
    os.makedirs(save_path_page, exist_ok=True)
    # try:
    # if ".geojson" in file:
    print(file)
    try:
        image = cv2.imread(os.path.join(images_path, file.name.split('.')[0])+".jpg")
        if save_line_seg_map:
            seg_map = np.zeros_like(image)
        data = open(os.path.join(jsons_path, file), encoding="utf8")
        data = json.load(data)
        for i, feature in enumerate(data["features"]):
            save_path = save_path_page
            text_out = np.zeros_like(image)
            coords = feature["geometry"]["coordinates"]
            try:
                line_type = feature["properties"]["classification"]["name"]
                text = feature["properties"]["name"]
            except Exception as e:
                text = "no name error"
                save_path = save_wrong_lines
            points = np.asarray(coords).reshape((-1, 1, 2)).astype(int)
            rect = cv2.minAreaRect(points)
            angle = rect[-1]
            box = cv2.boxPoints(rect)
            box = np.int0(box)
            tl,tr,br,bl = box
            height_line = abs(tl[1]-bl[1])
            # cv2.polylines(image, [points], isClosed=True, color=(255, 255, 0), thickness=3)
            x, y, w, h = cv2.boundingRect(points)
            if save_line_seg_map:
                cv2.drawContours(seg_map, [points], -1, (255, 255, 255), -1, cv2.LINE_AA)
            # image_line = cv2.bitwise_and(text_out , image)
            # cropped_line = image_line[y:y + h, x:x + w]
            # cropped_line = rotate_image(angle, cropped_line,height_line)
            cropped_line = extract_line_img_from_rect(image,box,rect)
            save_path_type = os.path.join(save_path,line_type)
            os.makedirs(save_path_type, exist_ok=True)
            cv2.imwrite(os.path.join(save_path_type, file.name.split('.')[0] + f"_{line_type}_line_{i}.png"), cropped_line)
            with open(os.path.join(save_path_type, file.name.split('.')[0] + f"_{line_type}_line_{i}.gt.txt"),
                      'w', encoding='utf-8') as f:
                f.write(text)
        if save_line_seg_map:

            seg_map = cv2.erode(seg_map, cv2.getStructuringElement(cv2.MORPH_RECT,(5,5)), iterations=2)
            cv2.imwrite(os.path.join(save_images, "lines",file.name.split('.')[0] + f".jpg"),
                        seg_map)
            cv2.imwrite(os.path.join(save_images, "pages",file.name.split('.')[0] + f".jpg"),
                        image)

        # plt.figure()
        # plt.imshow(image, cmap='gray')
        # plt.show()
                ##........................................................................

    except Exception as e:
        print("error in ", file)
        print(e)
        continue
