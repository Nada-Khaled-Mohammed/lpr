import os
from pdf2image import convert_from_path


def convert_pdf_to_images(pdf_path="", poppler_path = r"C:\Users\nourhan.emad\Downloads\poppler-22.01.0\Library\bin"):
    images = convert_from_path(pdf_path, poppler_path=poppler_path)

    return images

def convert_pdf_to_images_without_poppler(pdf_path=""):
    images = convert_from_path(pdf_path)
    return images

if __name__ == "__main__":
    pdfs_path_all = r"D:\data\Court\Batch 2\test\pdfs"
    # save_path_all = r"D:\data\Court\justice\data\files_a_images"
    # poppler_path = r"C:\Users\nourhan.emad\PycharmProjects\pdf_to_word\poppler-22.01.0\Library\bin"
    save_path_all = r"D:\data\Court\Batch 2\test\images"
    for file in os.listdir(pdfs_path_all):
        save_path = os.path.join(save_path_all, file.split('.')[0])
        # if os.path.exists(save_path):
        #     continue
        os.makedirs(save_path, exist_ok=True)
        print(file)
        pdf_path = os.path.join(pdfs_path_all, file)
        # pdf_images_path = r"C:\Users\nourhan.emad\Downloads\output"
        # rotate_images()
        # split_pdf(pdf_path)
        images = convert_pdf_to_images(pdf_path)
        for i in range(len(images)):
            # Save pages as images in the pdf
            print(i)
            images[i].save(os.path.join(save_path, str(i+1) + '.jpg'), 'JPEG')