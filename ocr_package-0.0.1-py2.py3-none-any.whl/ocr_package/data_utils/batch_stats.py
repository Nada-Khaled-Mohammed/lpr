'''
This script counts the number of boxes/lines in a given XML as provided by Contalents (the annotation company)
'''

import os
from pathlib import Path
import xml.etree.ElementTree as ET


def count_line_imgs(batch_dir):
    batch_dir = Path(batch_dir)
    imgs_paths = batch_dir.glob('**/*.png')
    count = len(list(imgs_paths))
    return count

def count_boxes_xml(xml_path):
    tree = ET.parse(xml_path)
    root = tree.getroot()
    count = 0
    for image_ele in root.findall("image"):
        box_count = len(list(image_ele.findall("box")))
        polygon_count = len(list(image_ele.findall("polygon")))
        polyline_count = len(list(image_ele.findall("polyline")))
        # print(f'{box_count = }, {polygon_count}, {polyline_count = }')
        count += box_count + polygon_count + polyline_count
    return count


if __name__ == "__main__":
    batch_dir = Path(r'C:\Users\nourhan.emad\Downloads\task_ahram_1900_9_17_6_1974')
    # batch_dir = Path(r'D:\ahram_annotation\batch_sa1')
    xml_paths = batch_dir.glob('**/*annotations.xml')
    count = 0
    for xml_path in xml_paths:
        count += count_boxes_xml(xml_path) # Count boxes inside the XML directly
    # count = count_line_imgs(batch_dir)  # Count line images as produced from the XML
    print(count)