import numpy as np
from PIL import Image
import cv2
import pandas as pd
import os
import shutil
from pathlib import Path

def convert_image_PIL_to_opencv(image_path, image_name, save_path):
    image = Image.open(image_path)
    image = image.convert(mode="L")
    image = np.array(image)
    cv2.imwrite(os.path.join(save_path, image_name), image)


def copy_images_in_csv_from_path(path_csv, path_images, save_path, col_name):
    path = path_images
    df = pd.read_csv(path_csv, index_col=False)
    target_path = save_path
    pages = df[col_name].values
    for image in os.listdir(path):
        if image in pages:
            continue
        print(image)
        shutil.copy(os.path.join(path, image), os.path.join(target_path, image))

def copy_images_from_folder_to_folder_based_on_third_folder(copy_from_folder, copy_to_folder, folder_of_images):
    pages = os.listdir(folder_of_images)
    images_path = copy_from_folder
    save_path = copy_to_folder
    for page in pages:
        shutil.copy(os.path.join(images_path, page), os.path.join(save_path, page))

def count_mosawer_images():
    ds_path = Path(r"G:\darelhelal\magazine\elmosor\09-08-2022")

    pages = []
    for year in os.listdir(ds_path):
        if int(year) > 1973:
            break
        print(year)
        for month in os.listdir(os.path.join(ds_path, year)):
            for day in os.listdir(os.path.join(ds_path, year, month)):
                for number in os.listdir(os.path.join(ds_path, year, month, day)):
                    jpg_folder = os.path.join(ds_path, year, month, day, number, "JPG")
                    pages.extend(list(Path(jpg_folder).rglob("*.jpg")))
    print(len(pages))

def remove_training_data_from_test_data():
    test_dataset = r"D:\data\Al_Mosawer\Test\60s_test_data"
    pages_done = os.listdir(r"D:\data\Al_Mosawer\mosawer_annotation\output_annotation\60s_all_articles_splitted\pages")

    single_pages = []
    for image_name in pages_done:
        if os.path.exists(os.path.join(test_dataset, image_name)):
            print(image_name)
            os.remove(os.path.join(test_dataset, image_name))

def check_arabic_name():
    import unicodedata as ud

    path = r"E:\darelhelal\magazine\elmosor\09-08-2022"
    for year in os.listdir(path):
        for month in os.listdir(os.path.join(path, year)):
            for day in os.listdir(os.path.join(path, year, month)):
                for issue in os.listdir(os.path.join(path, year, month, day)):
                    # print(issue)
                    if issue == "specialissue":
                        jpg_folder = os.path.join(path, year, month, day, issue, "JPG")
                        for image_name in os.listdir(jpg_folder):
                            image_name_split = image_name.split('_')
                            image_number = image_name_split[-1]
                            new_page_name = "_".join([year, month, day, issue, image_number])
                            print(new_page_name)
                            os.rename(os.path.join(jpg_folder, image_name), os.path.join(jpg_folder, new_page_name))


def copy_wrong_pages_annotation():
    save_path = r"D:\data\Al_Mosawer\mosawer_annotation\problem_annotation\80s\classes"
    annotation_path = r"D:\data\Al_Mosawer\mosawer_annotation\output_annotation\80s\merged\80s"

    df = pd.read_csv(os.path.join("D:\data\Al_Mosawer\mosawer_annotation\problem_annotation", "classes_issues_80.csv"),
                     index_col=False)
    pages = df["Page Name"].values

    classes = True
    categories = ["ads_images", "bg", "description", "subtitles", "text", "titles"]
    for image_name in pages:
        image_name = image_name.strip()
        image_name += ".jpg"
        print(image_name)
        os.makedirs(os.path.join(save_path, "pages"), exist_ok=True)
        if classes:
            for category in categories:
                os.makedirs(os.path.join(save_path, category), exist_ok=True)
        else:
            os.makedirs(os.path.join(save_path, "articles"), exist_ok=True)
        shutil.copy(os.path.join(annotation_path, "pages", image_name),
                    os.path.join(os.path.join(os.path.join(save_path, "pages"), image_name)))
        if classes:
            for category in categories:
                shutil.copy(os.path.join(annotation_path, category, image_name),
                            os.path.join(os.path.join(os.path.join(save_path, category), image_name)))
        else:
            shutil.copy(os.path.join(annotation_path, "articles", image_name),
                        os.path.join(os.path.join(save_path, "articles", image_name)))


def create_mosawer_dataset():
    path = r"E:\darelhelal\magazine\elmosor\09-08-2022"
    save_path = r"D:\data\Mosawer\dataset"

    for year in os.listdir(os.path.join(path)):
        # year = "1950"
        print(year)
        for month in os.listdir(os.path.join(path, year)):
            for day in os.listdir(os.path.join(path, year, month)):
                for issue in os.listdir(os.path.join(path, year, month, day)):
                    for image_name in os.listdir(os.path.join(path, year, month, day, issue, "JPG")):
                        try:
                            page_number = image_name.split('_')[-1].split('.')[0]
                            print(image_name)
                            target_path = os.path.join(save_path, year, page_number)
                            os.makedirs(target_path, exist_ok=True)
                            shutil.copy(os.path.join(path, year, month, day, issue, "JPG", image_name),
                                        os.path.join(target_path, image_name))
                        except Exception as e:
                            print(e)
                            pass

def remove_images_issue_with_name():
    import unicodedata as ud
    import os

    path = r"E:\Al-Mosawer_Merged"

    for year in os.listdir(path):
        print(year)
        for folder in os.listdir(os.path.join(path, year)):
            for file in os.listdir(os.path.join(path, year, folder)):
                for char in file:
                    u = ud.bidirectional(char)
                    if u not in ["EN", "L", "CS", "ON"]:
                        print(folder)
                        print(file)
                        try:
                            os.remove(os.path.join(path, year, folder, file))
                            print("removed file ", file)
                        except Exception as e:
                            print(e)
                            print("failed to remove ", file)
