import os
import random
from pathlib import Path
import cv2
from PIL import Image, ImageDraw, ImageFont
import numpy as np

with open(r"ground_truth.txt", "r", encoding="utf-8") as file:
    lines = file.readlines()

def render_lines(fonts_path):

    fonts_path = Path(fonts_path)

    for font_path in fonts_path.glob('**/*tf'):
        try:
            font_name = font_path.name
            print(font_name)
            max_width = 0
            font_size = 40
            font_path = Path(font_path)
            arabic_font = ImageFont.truetype(r"{}".format(font_path), font_size)
            hight = 0
            for line in lines:
                bbox = arabic_font.getbbox(line)
                width, height = (bbox[2]-bbox[0],bbox[3])
                max_width = max(max_width, width)
                hight+= height
            image = Image.new('L', (max_width+60, hight+250), 255)
            image_draw = ImageDraw.Draw(image)
            x = 30
            y = 30
            for line in lines:
                #line = line.decode("utf-16")
                #print(line)
                image_draw.text((x, y), line, fill=0, font=arabic_font)
                box_text = image_draw.textbbox((x, y),line, font=arabic_font) # "\uF2B2"
                y=box_text[3]+10
            image = np.array(image,dtype='uint8')
            output_path = r"D:\All_Assets\Ids\assets_id\test_fonts"
            cv2.imwrite(os.path.join(output_path,font_name+"5555.png"),image)
        except:
            #print(font_name)
            continue


if __name__ == "__main__":
    fonts_path = r"D:\All_Assets\Ids\assets_id\Arabic_Fonts"
    #save_path = r"D:\CyShield Projects\OCR\Fonts_Files\arabic_fonts"
    render_lines(fonts_path)