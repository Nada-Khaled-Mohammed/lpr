import cv2
import random
import numpy as np
import matplotlib.pylab as plt
from PIL import Image, ImageDraw, ImageFont, ImageOps
import os
import gc
# import time
# import imutils
# #from src.generators.generators_helper import draw_lines_seg_map
# import convert_numbers
# import re
# import unicodedata
# from bidi.algorithm import get_display
# from pyarabic import araby
# import pyarabic.trans
# from pathlib import Path
from fontTools.ttLib import TTFont
from random import randint
import time
import datetime


class LinesGenerator():
    def __init__(self, assets_path="/home/administrator/ocr/mosawer-ocr/assets2/", width=2000, height=2200, put_title=True, put_images=True, put_vertical_line=True,
                 put_frames=False, put_subtitle=False,put_mokadma=True,debug=False):

        self.image_mosawer_path = os.path.join(assets_path,"Mosawer", 'mosawer_images')
        self.image_Caricature_path = os.path.join(assets_path, "Mosawer",'Caricature_images_filtered')
        self.ads_and_images_cropped_path = os.path.join(assets_path, "Mosawer",'ads_and_images_cropped_filtered')

        # ..............................................................................................
        self.title_image_path = os.path.join(assets_path,"Mosawer", 'title_images')
        self.titles_bg = os.path.join(assets_path, "Mosawer",'bg_images')



        self.put_title = put_title
        self.put_subtitle = put_subtitle
        self.put_mokadma = put_mokadma
        self.put_images = put_images
        self.put_vertical_line = put_vertical_line
        self.put_frames = put_frames
        self.debug=debug


        self.width_original = width
        self.height_original = height


        self.image_mosawer_filenames = os.listdir(self.image_mosawer_path)
        self.image_Caricature_filenames = os.listdir(self.image_Caricature_path)
        self.ads_and_images_cropped_path_filenames = os.listdir(self.ads_and_images_cropped_path)

        self.title_image_filenames = os.listdir(self.title_image_path)
        self.titles_bg_filenames = os.listdir(self.titles_bg)



        self.arabic_fonts_dir = os.path.join(assets_path,"Mosawer","Mosower_fonts","Arabic")
        self.arabic_fonts_irregular_text_dir = os.path.join(assets_path,"Mosawer","Mosower_fonts","irregular_mosawer_fonts")
        self.english_fonts_dir = os.path.join(assets_path,"Mosawer","Mosower_fonts","English")


        self.arabic_letters = ['آ', 'أ', 'ؤ', 'إ', 'ا', 'ب', 'ت', 'ث', 'ج', 'ح', 'خ', 'د', 'ذ', 'ر', 'ز',
                               'س', 'ش', 'ص', 'ض', 'ط', 'ظ', 'ع', 'غ', 'ف', 'ق', 'ك', 'ل', 'م', 'ن', 'ه', 'و', 'ي',
                               'ـــــ','ــــــــــ','ـــ']


        self.arabic_ending_letters = ['ء', 'ى', 'ة', 'ئ']

        self.arabic_punctuation = ['؟', '؛', '،', '!', '..', '.', ':', '-','/','...','. .','. . .']

        self.english_letters = [ch for ch in "qwertyuiopasdfghjklzxcvbnmABCDEFGHIJKLMNOPQRSTUVWXYZ"]
        self.arabic_numbers = [num for num in '٠١٢٣٤٥٦٧٨٩']
        self.english_numbers = [num for num in '0123456789']



        self.arabic_fonts_path = []
        for font in os.listdir(self.arabic_fonts_dir):
            self.arabic_fonts_path.append(os.path.join(self.arabic_fonts_dir, font))


        self.arabic_fonts_irregular_text_path = []
        for font in os.listdir(self.arabic_fonts_irregular_text_dir):
            self.arabic_fonts_irregular_text_path.append(os.path.join(self.arabic_fonts_irregular_text_dir, font))


        self.english_fonts_path = []
        for font in os.listdir(self.english_fonts_dir):
            self.english_fonts_path.append(os.path.join(self.english_fonts_dir, font))

    # ...........................................................................
    def augment_text(self,img):

        kernel = np.ones((7,7), np.uint8)
        img_erosion = cv2.erode(img, kernel, iterations=1)
        #cv2.imshow('Input', img)
        #cv2.imshow('Erosion', img_erosion)

        blur = cv2.GaussianBlur(img_erosion, (5, 5), 0)
        #ret3, th3 = cv2.threshold(blur, 5, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        ret3, th3 = cv2.threshold(blur,0 , 255, cv2.THRESH_BINARY)
        #plt.imshow(th3, cmap='gray', vmin=0, vmax=255)
        #plt.show()
        '''row, col = th3.shape
        #number_of_pixels = random.randint(1000, 2000)
        number_of_pixels = 2500
        for i in range(number_of_pixels):
            # Pick a random y coordinate
            y_coord = random.randint(0, row - 1)
            # Pick a random x coordinate
            x_coord = random.randint(0, col - 1)
            # Color that pixel to white
            if th3[y_coord][x_coord]== 0:
                #th3[y_coord][x_coord] = 128
                th3[y_coord][x_coord] = random.randint(200, 250)
                th3[y_coord][x_coord] = 250'''

        return th3

    # ...........................................................................

    def rotate_image(self, result_image, result_image_black, width_sub_image, height_sub_image, color):
        rotate_angle = random.randint(-30, 30)
        #print('angle :   ',rotate_angle)
        # rotated_image = imutils.rotate_bound(result_image, angle=rotate_angle)
        (h_rotate, w_rotate) = result_image.shape[:2]
        center = (w_rotate // 2, h_rotate // 2)
        M = cv2.getRotationMatrix2D(center, rotate_angle ,.85)
        rotated_image = cv2.warpAffine(result_image, M, (w_rotate, h_rotate),
                                       flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT, borderValue=color)
        result_image = cv2.resize(rotated_image, (width_sub_image, height_sub_image),
                                  interpolation=cv2.INTER_AREA)

        rotated_image_black = cv2.warpAffine(result_image_black, M, (w_rotate, h_rotate),
                                             flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT, borderValue=0)
        # rotated_image_black = imutils.rotate_bound(result_image_black, angle=rotate_angle)
        result_image_black = cv2.resize(rotated_image_black, (width_sub_image, height_sub_image),
                                        interpolation=cv2.INTER_AREA)
        return result_image, result_image_black

    # ...........................................................................
    def char_in_font(self,unicode_char, font):
        for cmap in font['cmap'].tables:
            if cmap.isUnicode():
                if ord(unicode_char) in cmap.cmap:
                    return True
        return False
    # ...........................................................................
    def draw_line(self, image_draw, x1, y1, x2, y2,thickness):
        line_color = (0,0,0)
        line_thickness = thickness
        image_with_line = cv2.line(image_draw,(x1,y1),(x2,y2),line_color,line_thickness)
        return image_with_line
    # ...........................................................................
    def draw_white_lines_on_seg_map(self, box, segmentation_map,line_percentage):  # draw line of seg map with height of 80& of original height
        # cv2.rectangle(segmentation_map, (x_start_draw, box[1]), (x_start_draw + (box[2] - box[0]), box[3]), (255, 255, 255),-1)
        # left b[0], top b[1], right b[2], bottom b[3]
        y_line = box[1] + (box[3] - box[1]) // 2  # keda el y f nos el box
        height_line_seg_map = int((box[3] - box[1]) * line_percentage)
        y_line = y_line - int(height_line_seg_map // 2)  # keda el y bdaytha 3nd 10%
        for height_count in range(height_line_seg_map):
            cv2.line(segmentation_map, (box[0], y_line + height_count), (box[2], y_line + height_count), 255, 1)
        return segmentation_map
    # ...........................................................................
    def draw_h_line(self,line_text_width,line_text_height):
        COLOR_BG_IMAGE = 145
        image = Image.new('L', (line_text_width, line_text_height), COLOR_BG_IMAGE)
        h_line_x1 = 0
        h_line_y1 = int(line_text_height/2)
        h_line_x2 = h_line_x1 + line_text_width
        h_line_y2 = h_line_y1
        image = np.array(image)
        h_line_thickness = np.random.choice([5,10]) if np.random.rand() < .7 else np.random.choice([1,5])
        image = self.draw_line(image.copy(), int(h_line_x1), int(h_line_y1),
                                       int(h_line_x2), int(h_line_y2), h_line_thickness)

        return image
    # ...........................................................................
    def narrow_white_lines(self,image_black):
        image_black_height = image_black.shape[0]
        image_black_width = image_black.shape[1]

        right = int(image_black_height * .0030)
        left = int(image_black_height * .0030)
        top = int(image_black_width * .0030)
        bottom = int(image_black_width * .0030)

        new_width = image_black_width + right + left
        new_height = image_black_height + top + bottom

        result_image_black = np.zeros((new_height, new_width), dtype='uint8')
        result_image_black[top:new_height - bottom, left:new_width - right] = image_black

        return result_image_black
    # ...........................................................................
    def insert_brackets(self,line,font):
        # add brackets
        if np.random.rand() < .5:
            if len(line) > 2:
                index = np.random.randint(0, len(line) - 2)
            else:
                index = 0

            next_index = index + np.random.randint(2, 5)
            if next_index > len(line) - 1:
                next_index = index + 2

            prob = np.random.rand()
            if prob < .3:
                if self.char_in_font('<', font):
                    line.insert(index, '<')
                    line.insert(next_index, '>')
            elif prob >= .3 and prob <= .7:
                if self.char_in_font('<', font):
                    line.insert(index, '<<')
                    line.insert(next_index, '>>')
            else:
                if self.char_in_font('"', font):
                    line.insert(index, '"')
                    line.insert(next_index, '"')

            # eftkry tzawdy el [] brackets.
        return line
    # ...........................................................................
    def create_line(self,font,LINE_LEN,NUMBER_OF_SPACES_BETWEEN_WORDS):
        line = []
        word = ''
        for _ in range(LINE_LEN):
            word_len = random.randint(2, 6)

            if np.random.rand()<.7:
                # normal text
                word = ''.join(random.choices(self.arabic_letters, k=word_len))
            else:
                if np.random.rand()<.5:
                    # add punctuations
                    punctuaton_char = random.choices(self.arabic_punctuation, k=1)
                    punctuaton_char = ''.join(punctuaton_char)
                    if self.char_in_font(punctuaton_char[0], font):
                        word = punctuaton_char
                else:
                    # add arabic number
                    random_number = random.choices(self.arabic_numbers, k=np.random.randint(1,6))
                    random_number = ''.join(random_number)
                    if self.char_in_font(random_number[0], font):
                        word = random_number


            line.append(word)

        # append tail.
        if np.random.rand()<.5:
            punc = np.random.choice(['.','..','...','. .','. . .','....']+self.arabic_punctuation)
            if self.char_in_font(punc[0], font):
                line.append(punc) if np.random.rand()<.7 else line.insert(0, punc)


        line = self.insert_brackets(line,font) if np.random.rand()<.5 else line

        line = (NUMBER_OF_SPACES_BETWEEN_WORDS*" ").join(line)
        return line
    # ...........................................................................
    def select_random_font(self,is_title):
        if is_title:
            all_fonts = self.arabic_fonts_irregular_text_path
        else:
            all_fonts = self.arabic_fonts_path

        arabic_font_path = random.choice(all_fonts)
        return arabic_font_path
    # ...........................................................................
    def get_font(self, font_size, arabic_font_path):
        font = TTFont(arabic_font_path)
        arabic_font = ImageFont.truetype(arabic_font_path, font_size)
        return arabic_font, font

    # ...........................................................................
    def get_font_before(self,font_size,is_title):
        if is_title:
            all_fonts = self.arabic_fonts_irregular_text_path
        else:
            all_fonts = self.arabic_fonts_path

        arabic_font_path = random.choice(all_fonts)

        ######################
        font = TTFont(arabic_font_path)
        ######################
        arabic_font = ImageFont.truetype(arabic_font_path, font_size)
        ######################
        return arabic_font,font
    # ...........................................................................
    def put_subtitle_on_page(self,number_of_columns,font,NUMBER_OF_SPACES_BETWEEN_WORDS,arabic_font,
                             line_text_width,line_text_height,x_start,y_start):

        WORDS_NUMBER = np.random.randint(2, 6) if number_of_columns > 1 else np.random.randint(5, 10)
        line = self.create_line(font, WORDS_NUMBER, NUMBER_OF_SPACES_BETWEEN_WORDS)
        font_width, font_height = arabic_font.getsize(line)

        COLOR_BG_IMAGE = 0 if np.random.rand() < .2 else 145
        TEXT_COLOR = 200 if COLOR_BG_IMAGE == 0 else 0
        image = Image.new('L', (font_width, font_height), COLOR_BG_IMAGE)
        image_black = np.zeros((font_height, font_width), dtype='uint8')

        x = 0
        y = 0

        image_draw = ImageDraw.Draw(image)
        box = image_draw.textbbox((x, y), line, font=arabic_font, stroke_width=1)

        image_draw.text((x, y), line, fill=TEXT_COLOR, font=arabic_font, stroke_width=1)
        result_image_black = self.draw_white_lines_on_seg_map(box, image_black, 1)
        # image_black = self.draw_white_lines_on_seg_map(box, image_black, 1)
        # result_image_black = self.narrow_white_lines(image_black.copy())

        image = np.array(image)
        # new_width = int(line_text_width*.65)
        new_width = int(line_text_width)  # if np.random.rand()<.7 else int(line_text_width*.7)
        new_height = int(line_text_height)

        image = cv2.resize(image, (new_width, new_height), interpolation=cv2.INTER_AREA)

        image_black = cv2.resize(result_image_black, (new_width, new_height),
                                 interpolation=cv2.INTER_AREA)

        new_start = (line_text_width - new_width) // 2
        new_x_start = x_start + new_start if np.random.rand() < .5 else x_start + (line_text_width - new_width)

        y_start = y_start + 20
        image_main[y_start:y_start + new_height, new_x_start:new_x_start + new_width] = image
        image_black_main[y_start:y_start + new_height, new_x_start:new_x_start + new_width] = image_black
        y_start = y_start + 20


    # ...........................................................................
    def put_lines_text_on_page(self, line_text_width, line_text_height, x_start, y_start, image_main,
                                image_black_main,number_of_columns,arabic_font,font,
                                arabic_font_subtitle, font_subtitle,
                                SPACE_BETWEEN_LINES,NUMBER_OF_SPACES_BETWEEN_WORDS):

        y_initial = 10
        font_type = arabic_font
        while (True):
            add_line_prob = np.random.rand()
            if add_line_prob < .8:
                mn_number_of_words_line = 20
                mx_number_of_words_line = 30
                mn_words = round(mn_number_of_words_line/number_of_columns)
                mx_words = round(mx_number_of_words_line/number_of_columns)
                WORDS_NUMBER = np.random.randint(mn_words, mx_words)


                line = self.create_line(font,WORDS_NUMBER,NUMBER_OF_SPACES_BETWEEN_WORDS)
                font_width, font_height = font_type.getsize(line)

                COLOR_BG_IMAGE = 145
                new_font_width = font_width + int(font_height * .3)
                new_font_height = font_height + int(font_height * .3)
                image = Image.new('L', (new_font_width, new_font_height), COLOR_BG_IMAGE)
                image_black = np.zeros((new_font_height, new_font_width), dtype='uint8')

                x = 20 #if WORDS_NUMBER > 1 else (line_text_width-new_font_width)
                y = 0
                image_draw = ImageDraw.Draw(image)


                box = image_draw.textbbox((x, y), line, font=arabic_font,stroke_width=0)
                image_draw.text((x, y), line, fill=0, font=arabic_font,stroke_width=0)
                image_black = self.draw_white_lines_on_seg_map(box, image_black,.65)
                result_image_black = self.narrow_white_lines(image_black.copy())

                title_image_filename = random.choice(self.title_image_filenames)
                image_path = os.path.join(self.title_image_path, title_image_filename)
                image2 = Image.open(image_path)
                image2 = ImageOps.grayscale(image2)


                image = np.array(image)
                image = cv2.resize(image, (line_text_width, line_text_height), interpolation=cv2.INTER_AREA)
                image_black = cv2.resize(result_image_black, (line_text_width, line_text_height),
                                         interpolation=cv2.INTER_AREA)

                image_main[y_start:y_start + line_text_height, x_start:x_start + line_text_width] = image
                image_black_main[y_start:y_start + line_text_height, x_start:x_start + line_text_width] = image_black


            else:
                # NUMBER_OF_SPACES_BETWEEN_WORDS,arabic_font,line_text_width,line_text_height,x_start,y_start.
                prob = np.random.rand()
                if prob <= .5:
                    # put subtitle
                    WORDS_NUMBER = np.random.randint(2, 6) if number_of_columns > 1 else np.random.randint(5, 10)
                    line = self.create_line(font, WORDS_NUMBER, NUMBER_OF_SPACES_BETWEEN_WORDS)

                    WORDS_NUMBER = np.random.randint(2,6) if number_of_columns > 1 else np.random.randint(5,10)
                    line = self.create_line(font,WORDS_NUMBER,NUMBER_OF_SPACES_BETWEEN_WORDS)
                    font_width, font_height = arabic_font.getsize(line)
                    COLOR_BG_IMAGE = 0 if np.random.rand() <.2 else 145
                    TEXT_COLOR = 200 if COLOR_BG_IMAGE == 0 else 0
                    image = Image.new('L', (font_width, font_height), COLOR_BG_IMAGE)
                    image_draw = ImageDraw.Draw(image)
                    x, y = 0, 0
                    image_draw.text((x, y), line, fill=TEXT_COLOR, font=arabic_font, stroke_width=1)


                    title_image_filename = random.choice(self.title_image_filenames)
                    image_path = os.path.join(self.title_image_path, title_image_filename)
                    image2 = Image.open(image_path)
                    image2 = ImageOps.grayscale(image2)


                    box = image_draw.textbbox((0, 0), line, font=arabic_font, stroke_width=1)
                    image_black = np.zeros((font_height, font_width), dtype='uint8')
                    result_image_black = self.draw_white_lines_on_seg_map(box, image_black, 1)

                    # to choose to put original title from annotation or generate subtitle.
                    image = np.array(image) if np.random.rand()<1 else np.array(image2)
                    new_width = int(line_text_width) if np.random.rand()<.7 else int(line_text_width*.7)
                    new_height = int(line_text_height)
                    image = cv2.resize(image, (new_width, new_height), interpolation=cv2.INTER_AREA)
                    image_black = cv2.resize(result_image_black, (new_width, new_height),
                                             interpolation=cv2.INTER_AREA)
                    new_start = (line_text_width - new_width) // 2
                    new_x_start = x_start + new_start if np.random.rand()<.5 else x_start + (line_text_width - new_width)
                    y_start = y_start + 10
                    image_main[y_start:y_start + new_height, new_x_start:new_x_start + new_width] = image
                    image_black_main[y_start:y_start + new_height, new_x_start:new_x_start + new_width] = image_black
                    y_start = y_start + 10


                elif prob>.5 and prob<=.7:
                    # add horizontal_line
                    image_h_line = self.draw_h_line(line_text_width,line_text_height)
                    image_main[y_start:y_start + line_text_height, x_start:x_start + line_text_width] = image_h_line

                '''elif prob >=.6 and prob <=.9:
                    #if self.char_in_font('□', font):
                    line = '□'
                    #line = '➔'
                    font_width, font_height = font_type.getsize(line)
                    new_width = font_width
                    new_height = font_height
                    image_main_pil = Image.fromarray(image_main.copy())
                    image_draw = ImageDraw.Draw(image_main_pil)
                    new_start = (line_text_width - new_width) // 2
                    new_x_start = x_start + new_start
                    image_draw.text((new_x_start,y_start), line, fill=0, font=arabic_font, stroke_width=0)
                    image_main_arr = np.array(image_main_pil)
                    image_main[:, :] = image_main_arr'''


            y_start = y_start + line_text_height + SPACE_BETWEEN_LINES

            if y_start >= (int(self.height_original) - (y_initial + line_text_height)):
                break

        return image_main, image_black_main

    # ...........................................................................
    def put_bg_image(self,width,height,image,percentage):
        if np.random.rand() < percentage:
            titles_bg_filename = random.choice(self.titles_bg_filenames)
            image_path = os.path.join(self.titles_bg, titles_bg_filename)
            image2 = Image.open(image_path)
            image2 = ImageOps.grayscale(image2)
            image2 = image2.resize((width, height))
            image2 = np.array(image2)
            image = cv2.addWeighted(image, 1, image2, .2, 0)
        return image
    # ...........................................................................
    def put_title_on_page(self,title_width,title_height,title_words_number,image_main,image_black_main,arabic_font_path,
                          x_start,y_start,FONT_SIZE,its_title):

        if np.random.rand()<.3:
            BG_COLOR = 0
            TEXT_COLOR = 145
        elif np.random.rand()<.3:
            BG_COLOR = 45
            TEXT_COLOR = 145
        else:
            BG_COLOR = 145
            TEXT_COLOR = 0

        NUMBER_OF_SPACES_BETWEEN_WORDS = np.random.randint(1,5)

        image = Image.new('L', (title_width, title_height), BG_COLOR)

        image_black = np.zeros((title_height, title_width), dtype='uint8')

        image_draw = ImageDraw.Draw(image)

        if np.random.rand()<.5:
            number_of_lines = 1
        else:
            number_of_lines = 2

        if its_title:
            FONT_SIZE = int(title_height // (number_of_lines+1)) if number_of_lines == 1 else int(title_height // (number_of_lines+2))

        #TITLE_WORDS_NUM = np.random.randint(1, 10)

        for i in range(number_of_lines):
            if i == 0:
                if its_title:
                    stroke_width = np.random.randint(3,6) if np.random.rand()<.9 else np.random.randint(2, 3)
                else:
                    stroke_width =  np.random.randint(1, 3)

                FONT_SIZE_1 = FONT_SIZE if np.random.rand()<.9 else int(FONT_SIZE * .7)
                arabic_font, font = self.get_font(FONT_SIZE_1, arabic_font_path)

            elif i == 1:
                if its_title:
                    stroke_width = np.random.randint(2,3) if np.random.rand()<.9 else np.random.randint(3, 6)
                else:
                    stroke_width = np.random.randint(1, 3)


                FONT_SIZE_2 = FONT_SIZE if np.random.rand() < .9 else int(FONT_SIZE * .7)
                arabic_font, font = self.get_font(FONT_SIZE_2, arabic_font_path)


            line = self.create_line(font,title_words_number,NUMBER_OF_SPACES_BETWEEN_WORDS)
            font_width, font_height = arabic_font.getsize(line)


            #x_text = (title_width - font_width) // 2
            #x_text = (title_width - font_width - 10) if np.random.rand()<.2 else (title_width - font_width) // 2

            # El Kalam bade2 mnen ya3ny fel swora
            if i==0:
                if its_title:
                    if np.random.rand()<.2:
                        x_text = (title_width - font_width - 10)
                    elif np.random.rand()<.4:
                        x_text = 10
                    else:
                        x_text = (title_width - font_width) // 2
                else:
                    x_text = (title_width - font_width) // 2


            y_text = (title_height - ((font_height) * (number_of_lines))) // 2 if i==0 else y_text

            image_draw.text((x_text, y_text), line, font=arabic_font, fill=TEXT_COLOR, stroke_width=stroke_width)
            box = image_draw.textbbox((x_text, y_text), line, font=arabic_font)

            image_black = self.draw_white_lines_on_seg_map(box,image_black,.75)

            image_black = self.narrow_white_lines(image_black.copy())

            y_text += (font_height+10)

        # ...........................................................................
        image = np.array(image)
        # ...........................................................................
        if its_title:
            image = self.put_bg_image(title_width, title_height, image, .2)
        # ...........................................................................
        if its_title==False:
            image = self.padding_page(image.copy(), title_width, title_height, right=10, left=10, top=10, bottom=10, bg_color=145)
            image_black = self.padding_page(image_black.copy(), title_width, title_height, right=10, left=10, top=10, bottom=10, bg_color=0)
        # ...........................................................................
        image = cv2.resize(image, (title_width, title_height), interpolation=cv2.INTER_AREA)
        image_black = cv2.resize(image_black, (title_width, title_height), interpolation=cv2.INTER_AREA)
        # ...........................................................................
        # if np.random.rand()<.7:
        #     color = TEXT_COLOR if np.random.rand()<.5 and TEXT_COLOR == 0 else BG_COLOR
        #     image, image_black = self.rotate_image(image, image_black, title_width, title_height, color=color)
        # ...........................................................................
        #x_start = 10 if np.random.rand()<.5 else self.width_original - title_width - 10
        # ...........................................................................
        image_main[y_start:y_start + title_height, x_start:x_start + title_width] = image
        image_black_main[y_start:y_start + title_height, x_start:x_start + title_width] = image_black

        return image_main, image_black_main
    # ...........................................................................
    def put_title_as_image(self,title_width,title_height,image_main,image_black_main):

        title_image_filename = random.choice(self.title_image_filenames)
        image_path = os.path.join(self.title_image_path, title_image_filename)
        image = Image.open(image_path)
        image = ImageOps.grayscale(image)
        image = image.resize((title_width, title_height))
        image_black = np.zeros((title_height, title_width), dtype='uint8')
        #box = (-40, 20, 2037, 238) # left, top, right, bottom
        #box = (198, 33, 1782, 297)
        #box = (0, 20, 2037, 238)
        #box = (148, 3 , 1832, 327) if np.random.rand()<.5 else (0, 20, 2037, 238)
        #box = (100, -30, 1880, 360) if np.random.rand() < .5 else (0, -50, 2037, 308)
        box = (10,10,1970,320)

        image_black = self.draw_white_lines_on_seg_map(box, image_black, .8)
        image = np.array(image)

        image = cv2.resize(image, (title_width, title_height), interpolation=cv2.INTER_AREA)
        image_black = cv2.resize(image_black, (title_width, title_height), interpolation=cv2.INTER_AREA)

        #x_start = (self.width_original - title_width)//2
        x_start = (self.width_original - title_width - 10)
        y_start = 10
        image_main[y_start:y_start + title_height, x_start:x_start + title_width] = image
        image_black_main[y_start:y_start + title_height, x_start:x_start + title_width] = image_black

        return image_main, image_black_main

    def put_title_as_image2(self, title_width, title_height, image_main, image_black_main):

        #number_of_lines = np.random.choice([1,2,3])
        number_of_lines = 3
        y_start = 10
        new_title_height = title_height//number_of_lines
        for i in range(number_of_lines):
            title_image_filename = random.choice(self.title_image_filenames)
            image_path = os.path.join(self.title_image_path, title_image_filename)
            image = Image.open(image_path)
            image = ImageOps.grayscale(image)
            image_black = np.zeros((new_title_height, title_width), dtype='uint8')
            box = (-58, 57, 2037, 238)
            image_black = self.draw_white_lines_on_seg_map(box, image_black, .4)
            image = np.array(image)

            image = cv2.resize(image, (title_width, new_title_height), interpolation=cv2.INTER_AREA)
            image_black = cv2.resize(image_black, (title_width, new_title_height), interpolation=cv2.INTER_AREA)

            x_start = (self.width_original - title_width) // 2

            image_main[y_start:y_start + new_title_height, x_start:x_start + title_width] = image
            image_black_main[y_start:y_start + new_title_height, x_start:x_start + title_width] = image_black
            y_start = y_start + new_title_height

        return image_main, image_black_main


    def put_image_on_page(self,width_sub_image,height_sub_image,x_start,y_start,page_original,page_seg_map,regular_irregular_arabic_font_path,number_of_columns):
        '''
        if np.random.rand()<.3:
            image_Caricature_file = random.choice(self.image_Caricature_filenames)
            image_path = os.path.join(self.image_Caricature_path, image_Caricature_file)
        #elif np.random.rand()>=.3 and np.random.rand()<.6:
        elif np.random.rand() >= .3 and np.random.rand() <.9:
            image_mosawer_file = random.choice(self.image_mosawer_filenames)
            image_path = os.path.join(self.image_mosawer_path, image_mosawer_file)
        else:
            image_ad_file = random.choice(self.ads_and_images_cropped_path_filenames)
            image_path = os.path.join(self.ads_and_images_cropped_path, image_ad_file)
        '''
        if np.random.rand()<.5:
            image_mosawer_file = random.choice(self.image_mosawer_filenames)
            image_path = os.path.join(self.image_mosawer_path, image_mosawer_file)
        else:
            image_ad_file = random.choice(self.ads_and_images_cropped_path_filenames)
            image_path = os.path.join(self.ads_and_images_cropped_path, image_ad_file)

        image = Image.open(image_path)
        image = image.resize((width_sub_image, height_sub_image))
        image = ImageOps.grayscale(image)

        image_blank = np.zeros((height_sub_image, width_sub_image), dtype='uint8')
        #image_blank = np.full((100, 100, 3), (200, 100, 255), np.uint8) # fill a color as replacement of removed image.
        padded_image_prob = np.random.rand()
        if padded_image_prob<.7:
            right = 100
            left = 100
            top = 100
            bottom = 100
        else:
            right = 5
            left = 5
            top = 5
            bottom = 5

        new_width = width_sub_image + right + left
        new_height = height_sub_image + top + bottom
        color_main = 145

        result_image = np.ones((new_height, new_width), dtype='uint8') * color_main
        result_image[top:(new_height - bottom), left:(new_width - right)] = image

        result_image = cv2.resize(result_image, (width_sub_image, height_sub_image), interpolation=cv2.INTER_AREA)

        if padded_image_prob < .7:
            if np.random.rand() < .7:
                image = Image.fromarray(np.uint8(result_image)).convert('L')
                image_draw = ImageDraw.Draw(image)
                # WORDS_NUMBER = np.random.randint(1,3)

                if number_of_columns == 2:
                    WORDS_NUMBER = np.random.randint(5, 10)
                elif number_of_columns ==1:
                    WORDS_NUMBER = np.random.randint(15, 30)
                else:
                    WORDS_NUMBER = np.random.randint(1, 5)


                NUMBER_OF_SPACES_BETWEEN_WORDS = np.random.randint(1,3)
                '''
                arabic_font,font = self.get_font(int(height_sub_image*0.05),is_title=False)
                '''
                FONT_SIZE = int(height_sub_image*0.05)
                #arabic_font_path = self.select_random_font(is_title=False)
                arabic_font, font = self.get_font(FONT_SIZE, regular_irregular_arabic_font_path)

                line = self.create_line(font,WORDS_NUMBER, NUMBER_OF_SPACES_BETWEEN_WORDS)
                font_width, _ = arabic_font.getsize(line)

                x = (width_sub_image - font_width) // 2
                y = height_sub_image - int(height_sub_image*.095)



                box = image_draw.textbbox((x, y), line, font=arabic_font)
                image_draw.text((x,y), line, fill=0, font=arabic_font, stroke_width=1)
                image_blank = self.draw_white_lines_on_seg_map(box, image_blank,.7)
                result_image = np.array(image)


        page_original[y_start:y_start + height_sub_image, x_start:x_start + width_sub_image] = result_image
        page_seg_map[y_start:y_start + height_sub_image, x_start:x_start + width_sub_image] = image_blank
        #page_seg_map[y_start:y_start + height_sub_image, x_start:x_start + width_sub_image] = result_image

        return page_original,page_seg_map
    # ...........................................................................
    def put_frame_on_page(self,page_original,x1,y1,x2,y2,frame_thickness):
        # Horizontal_lines
        page_original = self.draw_line(page_original.copy(), int(x1), int(y1), int(x2),
                                       int(y1), frame_thickness)
        page_original = self.draw_line(page_original.copy(), int(x1), int(y2), int(x2),
                                       int(y2), frame_thickness)

        # Vertical_lines
        page_original = self.draw_line(page_original.copy(), int(x1), int(y1), int(x1),
                                       int(y2), frame_thickness)
        page_original = self.draw_line(page_original.copy(), int(x2), int(y1), int(x2),
                                       int(y2), frame_thickness)
        return page_original
    # ...........................................................................
    def create_images(self):
        BACK_GROUND_COLOR = 145
        #image_original = Image.new('L', (self.width_original, self.height_original), BACK_GROUND_COLOR)
        if np.random.rand()<1:
            image_original = np.ones((self.height_original, self.width_original), dtype='uint8') * BACK_GROUND_COLOR
        else:
            folder = self.image_mosawer_path
            random_image = random.choice(os.listdir(folder))
            file = folder + '\\' + random_image
            img = cv2.imread(file, cv2.IMREAD_GRAYSCALE)
            imgA = cv2.addWeighted(img, .5, img, .5, 50)
            image_original = cv2.resize(imgA, (self.width_original, self.height_original), interpolation=cv2.INTER_AREA)


        image_seg_map = np.zeros((self.height_original, self.width_original), dtype='uint8')
        return image_original, image_seg_map
    # ...........................................................................
    def set_column_structure(self,image_main,image_black_main,irregular_arabic_font_path,regular_arabic_font_path,same_font_path):

        number_of_columns = np.random.randint(1,7) if np.random.rand()<.8 else 1

        if np.random.rand()<.7:
            number_of_columns = np.random.randint(2, 7)
        else:
            number_of_columns = 1

        COL_WIDTH = self.width_original//number_of_columns
        COL_HEIGHT = self.height_original
        RIGHT_MARGIN = 10
        LEFT_MARGIN = 10
        #LEFT_MARGIN = np.random.randint(0, 10)
        TOP_MARGIN = 10
        BOTTOM_MARGIN = 10

        LINE_TEXT_WIDTH = COL_WIDTH - RIGHT_MARGIN - LEFT_MARGIN
        #LINE_TEXT_HEIGHT = np.random.randint(int(self.height_original * 0.025), int(self.height_original * 0.026))
        #LINE_TEXT_HEIGHT = np.random.randint(int(self.height_original * 0.020), int(self.height_original * 0.030))
        if np.random.rand()<.9:
            #LINE_TEXT_HEIGHT = np.random.randint(int(self.height_original * 0.025), int(self.height_original * 0.030))
            LINE_TEXT_HEIGHT = np.random.randint(int(self.height_original * 0.020), int(self.height_original * 0.030))
        else:
            LINE_TEXT_HEIGHT = np.random.randint(80,200)



        FONT_SIZE = int(LINE_TEXT_HEIGHT * .8)
        arabic_font, font = self.get_font(FONT_SIZE,same_font_path)


        FONT_SIZE = int(LINE_TEXT_HEIGHT * .8)
        arabic_font_subtitle, font_subtitle = self.get_font(FONT_SIZE, same_font_path)

        x_start = LEFT_MARGIN
        y_start = TOP_MARGIN
        SPACE_BETWEEN_LINES = np.random.randint(-10, 0)
        #NUMBER_OF_SPACES_BETWEEN_WORDS = 1 if np.random.rand()<.5 else np.random.randint(2,4)
        NUMBER_OF_SPACES_BETWEEN_WORDS = np.random.randint(1,6)


        for i in range(number_of_columns):
            x_start = COL_WIDTH * i + LEFT_MARGIN
            page_original, page_seg_map = self.put_lines_text_on_page(LINE_TEXT_WIDTH, LINE_TEXT_HEIGHT,
                                                                       x_start ,y_start,image_main, image_black_main,
                                                                       number_of_columns,arabic_font,font,
                                                                       arabic_font_subtitle, font_subtitle,
                                                                       SPACE_BETWEEN_LINES,
                                                                       NUMBER_OF_SPACES_BETWEEN_WORDS,
                                                                       )

        return page_original, page_seg_map , number_of_columns , LINE_TEXT_WIDTH ,FONT_SIZE
    # ...........................................................................
    def padding_page(self,image,width_sub_image,height_sub_image,right,left,top,bottom,bg_color):
        # print('width_sub_image : ',width_sub_image)
        # print('height_sub_image : ',height_sub_image)
        image = cv2.resize(image, (width_sub_image, height_sub_image), interpolation=cv2.INTER_AREA)
        new_width = width_sub_image + right + left
        new_height = height_sub_image + top + bottom
        result_image = np.ones((new_height, new_width), dtype='uint8') * bg_color
        # print('result_image.shape : ',result_image.shape)
        # print('image.shape : ',image.shape)
        result_image[top:(new_height - bottom), left:(new_width - right)] = image
        return result_image

    def generate_images(self):
        while True:
            try:
                irregular_arabic_font_path = self.select_random_font(is_title=True)
                regular_arabic_font_path = self.select_random_font(is_title=False)
                same_font_path = regular_arabic_font_path if np.random.rand()<.5 else irregular_arabic_font_path


                page_original, page_seg_map = self.create_images()
                st = time.time()
                page_original, page_seg_map, number_of_columns ,LINE_WIDTH ,font_size = self.set_column_structure(page_original.copy(), page_seg_map.copy(),
                                                                                           irregular_arabic_font_path,regular_arabic_font_path,same_font_path)

                et = time.time()
                elapsed_time = et - st
                if self.debug:
                    print('lines Execution time:', elapsed_time, 'seconds')

                if self.put_title:
                    put_title_prob = np.random.rand()
                    if put_title_prob < .5:
                        RIGHT_MARGIN = 10
                        LEFT_MARGIN = 10

                        TITLE_WIDTH= self.width_original - RIGHT_MARGIN - LEFT_MARGIN

                        if number_of_columns == 2 and np.random.rand()<.5:
                            TITLE_WIDTH = TITLE_WIDTH//2

                        if number_of_columns == 3 and np.random.rand()<.5:
                            TITLE_WIDTH = (TITLE_WIDTH//3)*2

                        if number_of_columns == 4 and np.random.rand()<.5:
                            TITLE_WIDTH = (TITLE_WIDTH // 4) * 3

                        #TITLE_HEIGHT = int(self.height_original * 0.18)
                        mn = int(self.height_original * 0.10)
                        mx = int(self.height_original * 0.20)
                        TITLE_HEIGHT =  np.random.randint(mn,mx)


                        st = time.time()
                        if np.random.rand()<1:
                            # generate title.
                            x_start = 10 if np.random.rand() < .5 else self.width_original - TITLE_WIDTH - 10
                            y_start = 10
                            TITLE_WORDS_NUM = np.random.randint(1, 10)
                            page_original, page_seg_map = self.put_title_on_page(TITLE_WIDTH, TITLE_HEIGHT,TITLE_WORDS_NUM,page_original.copy(), page_seg_map.copy(),
                                                                             same_font_path,x_start,y_start,FONT_SIZE=None,its_title=True)
                        else:
                            # put original title.
                            page_original, page_seg_map = self.put_title_as_image(TITLE_WIDTH, TITLE_HEIGHT, page_original.copy(), page_seg_map.copy(),
                                                                                  )
                        et = time.time()
                        elapsed_time = et - st
                        if self.debug:
                            print('title Execution time:', elapsed_time, 'seconds')

                if self.put_images:
                    put_image_prob = .7

                    if np.random.rand() < put_image_prob:
                        st = time.time()
                        RIGHT_MARGIN = 10
                        LEFT_MARGIN = 10
                        BOTTOM_MARGIN = 10
                        COL_WIDTH=self.width_original//number_of_columns
                        WIDTH_SUB_IMAGE = COL_WIDTH - RIGHT_MARGIN - LEFT_MARGIN
                        HEIGHT_SUB_IMAGE = np.random.randint(int(self.height_original * .25),int(self.height_original * .5))

                        for i in range(number_of_columns):
                            if np.random.rand() < .7:

                                number_of_images_in_col = np.random.randint(1, 4)
                                if put_title_prob>.5:
                                    img_y_start = np.random.randint(0,500)
                                else:
                                    img_y_start = int(self.height_original * .25)

                                for _ in range(number_of_images_in_col):

                                    while (True):
                                        if img_y_start + HEIGHT_SUB_IMAGE <= self.height_original:
                                            # kda tmam ya3ny
                                            break
                                        else:
                                            HEIGHT_SUB_IMAGE = self.height_original - img_y_start - BOTTOM_MARGIN

                                    img_x_start = COL_WIDTH * i + LEFT_MARGIN

                                    if HEIGHT_SUB_IMAGE > 0:
                                        page_original, page_seg_map = self.put_image_on_page(WIDTH_SUB_IMAGE,
                                                                                             HEIGHT_SUB_IMAGE, img_x_start,
                                                                                             img_y_start,
                                                                                             page_original.copy(),
                                                                                             page_seg_map.copy(),
                                                                                             same_font_path,number_of_columns)


                                    img_y_start = img_y_start + HEIGHT_SUB_IMAGE
                            else:
                                if self.put_frames:
                                    if np.random.rand()<.5:

                                        frame_height = np.random.randint(int(self.height_original*.1),int(self.height_original*.3))
                                        frame_margin = 5
                                        frame_width = (COL_WIDTH - RIGHT_MARGIN - LEFT_MARGIN) + frame_margin + frame_margin
                                        x1 = (COL_WIDTH * i + LEFT_MARGIN) - frame_margin

                                        y1 = int(self.height_original*.5)
                                        x2 = x1 + frame_width
                                        y2 = y1 + frame_height
                                        frame_thickness = np.random.randint(1,2)
                                        page_original = self.put_frame_on_page(page_original.copy(), x1, y1, x2, y2,frame_thickness)



                        et = time.time()
                        elapsed_time = et - st
                        if self.debug:
                            print('images Execution time:', elapsed_time, 'seconds')

                if self.put_vertical_line:
                    st = time.time()
                    TOP_MARGIN = TITLE_HEIGHT+10 if put_title_prob<.5 else 0

                    LINE_LEN = self.height_original - TOP_MARGIN
                    LEFT_MARGIN = 10
                    line_y1 = TOP_MARGIN
                    line_y2 = LINE_LEN + line_y1
                    COL_WIDTH = self.width_original // number_of_columns
                    if np.random.rand()<.9:
                        for i in range(number_of_columns - 1):
                            if np.random.rand()<.5:
                                line_x1 = COL_WIDTH * (i + 1) + 2
                                #line_x1 = COL_WIDTH * (i+1) + LEFT_MARGIN + LEFT_MARGIN//3
                                v_line_thickness = np.random.randint(5,10) if np.random.rand()<.7 else np.random.randint(1,5)
                                page_original = self.draw_line(page_original.copy(), int(line_x1), int(line_y1),
                                                               int(line_x1), int(line_y2),v_line_thickness)
                    et = time.time()
                    elapsed_time = et - st
                    if self.debug:

                        print('ver-line Execution time:', elapsed_time, 'seconds')
                # ......................................................................................................
                if self.put_mokadma:

                    COL_WIDTH = self.width_original//number_of_columns
                    mokadma_width = int(COL_WIDTH *.3)
                    #mokadma_height = int(self.height_original * .03)
                    mokadma_height = np.random.randint(100,200)
                    words_number = np.random.randint(1,3)
                    for i in range(number_of_columns):
                        # a7ot fel col wala la2
                        if np.random.rand()<.2:
                            number_of_mokadmat_in_col = 1
                            if put_title_prob > .5:
                                # Law mafeesh title
                                y_start = 10
                            else:
                                y_start = TITLE_HEIGHT + 10

                            for _ in range(number_of_mokadmat_in_col):

                                while (True):
                                    if y_start + mokadma_height <= self.height_original:
                                        # kda tmam ya3ny
                                        break
                                    else:
                                        mokadma_height = self.height_original - y_start - 10

                                x_start = (COL_WIDTH * i + LEFT_MARGIN) + (COL_WIDTH-mokadma_width-10)


                                if mokadma_height > 0:
                                    page_original, page_seg_map = self.put_title_on_page(mokadma_width,mokadma_height,words_number,page_original.copy(),
                                                                             page_seg_map.copy(),same_font_path, x_start, y_start,font_size,its_title=False)

                                y_start = y_start + int(mokadma_height*3)
                # ......................................................................................................


                if self.put_subtitle:
                    #new_title_height = TITLE_HEIGHT
                    if np.random.rand() < .8:
                        number_of_subtitles = np.random.randint(1, 4)
                        for _ in range(1):
                            sampl = np.random.uniform(low=0.1, high=.15)
                            TITLE_HEIGHT2 = int(self.height_original * sampl)
                            if TITLE_HEIGHT < 0:
                                TITLE_HEIGHT = 0

                            TITLE_WIDTH2 = LINE_WIDTH if np.random.rand()<.5 else TITLE_WIDTH

                            if self.height_original - TITLE_HEIGHT2 > TITLE_HEIGHT:
                                x_start = 10 if np.random.rand() < .5 else self.width_original - TITLE_WIDTH - 10
                                y_start = np.random.randint(TITLE_HEIGHT, self.height_original - TITLE_HEIGHT2)
                                TITLE_HEIGHT = y_start + TITLE_HEIGHT2
                                TITLE_WORDS_NUM = np.random.randint(1,10)
                                page_original, page_seg_map = self.put_title_on_page(TITLE_WIDTH2, TITLE_HEIGHT2,TITLE_WORDS_NUM,
                                                                                     page_original.copy(), page_seg_map.copy(),
                                                                                     same_font_path,x_start,y_start,FONT_SIZE=None,its_title=False)

                #page_original_ = self.augment_text(page_original.copy())

                if np.random.rand()<.1:

                    page_original, page_seg_map = self.rotate_image(page_original, page_seg_map, self.width_original,
                                                                    self.height_original, color=145)

                    # padding_value = 100
                    # padded_page_original = self.padding_page(page_original, self.width_original, self.height_original,
                    #                                          right=padding_value,left=padding_value, top=padding_value, bottom=padding_value,bg_color=145)
                    #
                    # padded_seg_map = self.padding_page(page_seg_map, self.width_original, self.height_original,
                    #                                          right=padding_value,left=padding_value, top=padding_value, bottom=padding_value,bg_color=0)
                    # if np.random.rand()<0:
                    #     page_original = padded_page_original
                    #     page_seg_map = padded_seg_map

                    page_original = cv2.resize(page_original, (self.width_original, self.height_original), interpolation=cv2.INTER_AREA)
                    page_seg_map = cv2.resize(page_seg_map, (self.width_original, self.height_original), interpolation=cv2.INTER_AREA)


                gc.collect() ## TODO...? Garbage Collection??

                yield np.array(page_original, dtype='uint8')[..., np.newaxis], \
                      np.array(page_seg_map, dtype='uint8')[..., np.newaxis]

            except Exception as e:
                print(e)
                continue


if __name__ == '__main__':
    # 384 512
    # 2000 2200
    lines_generator = LinesGenerator(assets_path="D:/All_Assets",width=2000,height=2200,put_title=True,put_images=True,
                                     put_vertical_line=True,debug=False)

    lines_image = lines_generator.generate_images()
    img_num = 1
    for image_main, image_black_main in lines_image:
        plt.figure(figsize=(80, 60))
        #plt.figure()
        plt.subplot(1, 2, 1)
        plt.imshow(image_main, cmap='gray', vmin=0, vmax=255)
        plt.title('Image')

        plt.subplot(1, 2, 2)
        plt.imshow(image_black_main, cmap='gray')
        plt.title('Segmentation Map')

        plt.show()


        #out_path =  r"C:/Users/omnia.abdelrahman/Documents/mosawer-ocr/generated_images/"
        #cv2.imwrite(out_path + str(img_num)+ '.png', image_main)

        #img_num+=1

        ''' 
        resized_image_main = cv2.resize(image_main, (500,800), interpolation=cv2.INTER_AREA)
        resized_image_black_main = cv2.resize(image_black_main, (500, 800), interpolation=cv2.INTER_AREA)
        im_h = cv2.hconcat([image_main, image_black_main])
        cv2.imshow('man_image.jpeg', im_h)
        '''