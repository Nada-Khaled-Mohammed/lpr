import os
import random
import json
# import string
import convert_numbers
import cv2
import matplotlib.pylab as plt
import numpy as np
# from PIL.features import check_feature
import unicodedata
# import arabic_reshaper
# from bidi.algorithm import get_display
from PIL import Image, ImageDraw, ImageFont
from PIL import ImageEnhance
from shappy_marker import get_pipeline
# from ocr_package.generators.photoshop_fake_detector import analyze_id_illumination, load_segmenter

# person_segmenter = load_segmenter()


class IdLinesGenerator():

    def __init__(self, assets_path=r'../../assets', width=850, height=540, blend_prob=.5, padding_prob=.5,
                 sharp_prob=.5, rotation_prob=.5, resize_prob=.5,
                 save_output=False, output_path=r"D:\Cyshield_projects\ocr_projects\ocr\assets\assets_id\output_test",
                 debug=False):

        path = os.path.join(assets_path,"assets_id","entities.json")
        with open(path) as f:
            data = json.load(f)

        self.names_arabic = []
        for item in data["PERSON"]["human"]:
            self.names_arabic.append(item["name_ar"])
        self.locations = []
        for item in data["LOC"]:
            for subitem in data["LOC"][item]:
                self.locations.append(subitem["name_ar"])

        self.colors = [(73, 72, 72), (74, 74, 74), (49, 44, 38), (108, 106, 109), (72, 72, 70), (80, 72, 54)]
        self.blend_prob = blend_prob
        self.padding_prob = padding_prob
        self.rotation_prob = rotation_prob
        self.sharp_prob = sharp_prob
        self.resize_prob = resize_prob
        self.people_photos = os.path.join(assets_path, 'assets_id', "people_photos", "CropedPeople")
        # self.egypt_republic_photos = os.path.join(assets_path, 'assets_id', "title_egypt","above")
        # self.personal_id_photos = os.path.join(assets_path, 'assets_id', "title_egypt", "below")
        self.barcode = os.path.join(assets_path, 'assets_id', "barcode")
        self.front_background = os.path.join(assets_path, 'assets_id', "front_bg")
        self.back_background = os.path.join(assets_path, 'assets_id', "back_bg")
        self.padding_and_blend_backgrounds = os.path.join(assets_path, 'assets_id', "backgrounds")
        # self.nesr_date = os.path.join(assets_path, 'assets_id', "nesr","nesr4.jpg")
        self.arabic_fonts_dir = os.path.join(assets_path, "assets_id", "fonts")
        self.arabic_corpus_dir = os.path.join(assets_path, "assets_id", "corpus")
        self.width_original = width
        self.height_original = height
        self.id_width_original = 850
        self.id_height_original = 540
        self.save_output = save_output
        self.output_path = output_path
        self.people_photos_filenames = os.listdir(self.people_photos)
        # self.egypt_republic_photos_filenames = os.listdir(self.egypt_republic_photos)
        # self.personal_id_photos_filenames = os.listdir(self.personal_id_photos)
        self.barcode_filenames = os.listdir(self.barcode)
        self.back_background_filenames = os.listdir(self.back_background)
        self.front_background_filenames = os.listdir(self.front_background)
        self.background_padding_and_blend_filenames = os.listdir(self.padding_and_blend_backgrounds)
        self.arabic_fonts_filenames = os.listdir(self.arabic_fonts_dir)
        self.simplified_arabic_font_path = os.path.join(self.arabic_fonts_dir, "Simplified Arabic Bold.ttf")
        self.factory_code_font = os.path.join(self.arabic_fonts_dir, "OCR B Std Medium.otf")
        self.arabic_corpus = os.path.join(self.arabic_corpus_dir, "alwatan_clean.txt")
        # self.arabic_corpus = os.path.join(self.arabic_corpus_dir, np.random.choice(["alwatan_clean.txt","Names.txt","Jobs1.txt","Jobs2.txt"]))
        self.arabic_numbers = "١٢٣٤٥٦٧٨٩٠"
        self.english_numbers = "1234567890"
        self.english_letters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q',
                                'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
        self.days = ["٠١", "٠٢", "٠٣", "٠٤", "٠٥", "٠٦", "٠٧", "٠٨", "٠٩", "١٠"] + [
            str(convert_numbers.english_to_arabic(x)) for x in range(11, 32)]
        self.months = ["٠١", "٠٢", "٠٣", "٠٤", "٠٥", "٠٦", "٠٧", "٠٨", "٠٩", "١٠", "١١", "١٢"]
        self.years = ["١٩", "٢٠"]
        self.raqm_below_nesr = [str(convert_numbers.english_to_arabic(x)) for x in range(1, 99)]
        self.debug = debug

        with open(self.arabic_corpus, "r", encoding="utf-8") as file:
            self.arabic_corpus = file.readlines()

    def remove_control_characters(self, textline):
        return "".join(ch for ch in textline if unicodedata.category(ch)[0] != "C")

    def set_width_and_height(self):
        # region get width and height of main image
        if type(self.width_original) != int:
            self.width = int(random.uniform(self.width_original[0], self.width_original[1]))
        else:
            self.width = self.width_original

        if type(self.height_original) != int:
            self.height = int(random.uniform(self.height_original[0], self.height_original[1]))
        else:
            self.height = self.height_original

        new_width = self.width
        new_height = self.height
        return new_width, new_height

    def put_person_image(self, image_main_front):
        photo_width_ratio = 220 / self.id_width_original
        photo_height_ratio = 290 / self.id_height_original
        photo_left_position_ratio = 20 / self.id_width_original
        photo_top_position_ratio = 40 / self.id_height_original
        width_photo = int(photo_width_ratio * self.width)
        height_photo = int(photo_height_ratio * self.height)
        start_x = int(photo_left_position_ratio * self.width)
        end_x = int(start_x + width_photo)
        start_y = int(photo_top_position_ratio * self.height)
        end_y = start_y + height_photo
        person_image = random.choice(self.people_photos_filenames)
        person_image_path = os.path.join(self.people_photos, person_image)
        # print(person_image_path)
        # segment_face = random.choice([True, False])
        segment_face = False
        if segment_face:
            person_image_mask = analyze_id_illumination(person_image_path, person_segmenter, crop=False)
            person_image = cv2.imread(person_image_path)
            person_image_mask = cv2.resize(person_image_mask, (width_photo, height_photo), interpolation=cv2.INTER_AREA)
            person_image = cv2.resize(person_image, (width_photo, height_photo), interpolation=cv2.INTER_AREA)
            person_photo = cv2.bitwise_and(person_image, person_image, mask=person_image_mask)
            person_photo = cv2.cvtColor(person_photo, cv2.COLOR_BGR2RGBA)
            image_main_front_copy = np.array(image_main_front)
            roi_large = (image_main_front_copy[start_y:start_y + height_photo, start_x:start_x + width_photo]).copy()
            image_main_front_copy[start_y:start_y + height_photo, start_x:start_x + width_photo] = person_photo
            roi_large_person_photo = (
            image_main_front_copy[start_y:start_y + height_photo, start_x:start_x + width_photo]).copy()
            result = cv2.bitwise_or(roi_large, roi_large_person_photo, mask=~person_image_mask)
            result = cv2.add(result, person_photo)
            image_main_front = np.array(image_main_front)
            cropped_photo_position = image_main_front[start_y:start_y + height_photo, start_x:start_x + width_photo]
            random_transparency_level = random.uniform(0, 0.5)
            image_main_front[start_y:start_y + height_photo, start_x:start_x + width_photo] = cv2.addWeighted(
                cropped_photo_position, random_transparency_level, result, 1-random_transparency_level, 0)
            image_main_front = Image.fromarray(image_main_front)


        ######### put image person without segment face
        else:

            if 'png' not in person_image_path:
                photo_image = Image.open(person_image_path)
                photo_image = photo_image.resize((width_photo, height_photo))
                photo_image = photo_image.convert("RGBA")

                transparency_level = random.randint(70, 255)
                overlay_with_alpha = Image.new("RGBA", photo_image.size)

                # # Create a new image with adjusted transparency
                for x in range(photo_image.width):
                    for y in range(photo_image.height):
                        r, g, b, a = photo_image.getpixel((x, y))
                        overlay_with_alpha.putpixel((x, y), (r, g, b, transparency_level))
                image_main_front.paste(overlay_with_alpha, (start_x, start_y))
            else:
                photo_image = Image.open(person_image_path)
                photo_image = photo_image.resize((width_photo, height_photo))
                # plt.imshow(photo_image, cmap='gray')
                # plt.show()
                _, _, _, mask = photo_image.split()
                image_main_front.paste(photo_image, (start_x, start_y), mask)

        ################
        return image_main_front, [start_x, end_x, start_y, end_y]

    def put_nesr_image(self, image_main_front):
        photo_width_ratio = 40 / self.id_width_original
        photo_height_ratio = 65 / self.id_height_original
        photo_left_position_ratio = 210 / self.id_width_original
        photo_top_position_ratio = 400 / self.id_height_original
        width_photo = int(photo_width_ratio * self.width)
        height_photo = int(photo_height_ratio * self.height)
        start_x = int(photo_left_position_ratio * self.width)
        end_x = int(start_x + width_photo)
        start_y = int(photo_top_position_ratio * self.height)
        end_y = start_y + height_photo
        # nesr_image = Image.open(self.nesr_date).convert(mode="1").convert(mode="RGBA")
        # print(nesr_image.mode)
        # newww = Image.new("RGBA",(self.width,self.height),(255,255,255))
        # nesr_image = nesr_image.resize((width_photo, height_photo))
        # nesr_image.putalpha(128)
        # image_main_front.alpha_composite(nesr_image,(start_x,start_y))
        return image_main_front, [start_x, end_x, start_y, end_y]

    def put_pdf417_barcode(self, image_main_back):
        barcode_width_ratio = 750 / self.id_width_original
        barcode_height_ratio = 180 / self.id_height_original
        barcode_left_position_ratio = 50 / self.id_width_original
        barcode_top_position_ratio = 325 / self.id_height_original
        width_barcode = int(barcode_width_ratio * self.width)
        height_barcode = int(barcode_height_ratio * self.height)
        start_x = int(barcode_left_position_ratio * self.width)
        end_x = int(start_x + width_barcode)
        start_y = int(barcode_top_position_ratio * self.height)
        end_y = start_y + height_barcode
        barcode_image = random.choice(self.barcode_filenames)
        barcode_path = os.path.join(self.barcode, barcode_image)
        barcode_pdf417 = Image.open(barcode_path)
        barcode_pdf417 = barcode_pdf417.resize((width_barcode, height_barcode))
        image_main_back.paste(barcode_pdf417, (start_x, start_y))
        return image_main_back, [start_x, end_x, start_y, end_y]

    def put_front_background(self, image):
        width = image.width
        height = image.height
        front_backgroung_image_file = random.choice(self.front_background_filenames)
        background_image_path = os.path.join(self.front_background, front_backgroung_image_file)
        background_image = Image.open(background_image_path).convert("RGBA")
        background_image = background_image.resize((width, height))
        image = Image.blend(image, background_image, 1)
        return image

    def put_back_background(self, image):
        width = image.width
        height = image.height
        back_backgroung_image_file = random.choice(self.back_background_filenames)
        background_image_path = os.path.join(self.back_background, back_backgroung_image_file)
        background_image = Image.open(background_image_path).convert("RGBA")
        background_image = background_image.resize((width, height))
        image = Image.blend(image, background_image, 1)
        return image

    def generate_name_and_adress(self):

        # full_name = random.choices(self.arabic_corpus, k=5)
        # full_name = " ".join(full_name)
        # full_name = self.remove_control_characters(full_name).strip()
        # full_name = full_name.split(" ")
        #
        # first_name = random.choices(full_name, k=random.choices([1, 2, 3], [.8, 0.1, 0.1], k=1)[0])
        # first_name = " ".join(first_name)
        #
        # family_name = random.choices(full_name, k=random.choices([3, 4, 5, 6], [.7, 0.1, 0.1, 0.1], k=1)[0])
        # family_name = " ".join(family_name)

        first_name = random.choice(self.names_arabic).split(" ")[0]
        family_name = random.choice(self.names_arabic)

        # full_address = random.choices(self.arabic_corpus, k=5)
        # full_address = " ".join(full_address)
        # full_address = self.remove_control_characters(full_address).strip()
        # full_address = full_address.split(" ")
        #
        #
        # street = random.choices(full_address, k=random.choices([1, 2, 3], [.8, 0.1, 0.1], k=1)[0])
        # street_num = "".join(
        #     random.choices([x for x in self.arabic_numbers], k=random.choices([1, 2, 3], [.4, .4, .2], k=1)[0]))
        # street = street_num + " ش " + " ".join(street)
        #
        # city_and_gov = random.choices(full_name, k=random.choices([3, 4, 5, 6], [.7, 0.1, 0.1, 0.1], k=1)[0])
        # city_and_gov = " ".join(city_and_gov)

        street = random.choice(self.locations)
        city_and_gov = random.choice(self.locations)

        id_number = random.choices(self.arabic_numbers, k=14)

        id_number = id_number[0] + " " + id_number[1] + id_number[2] + " " + id_number[3] + id_number[4] + " " + \
                    id_number[5] + id_number[6] + " " + id_number[7] + id_number[8] + " " + id_number[9] + id_number[
                        10] + id_number[11] + " " + id_number[12] + id_number[13]
        # id_number = " ".join(id_number)
        id_number = id_number[::-1]
        empty_line = "شؤئو عبد الشئور ع أل م"

        return first_name, family_name, street, city_and_gov, empty_line, id_number

    def generate_birth_date_and_code(self):
        day2 = random.choices(self.days, k=1)[0]
        month2 = random.choices(self.months, k=1)[0]
        year2 = random.choices(self.years, k=1)[0] + "".join(random.choices(self.arabic_numbers, k=2))
        birth_date = year2 + "/" + month2 + "/" + day2
        code = "".join([x.upper() for x in random.choices(self.english_letters, k=2)]) + "".join(
            random.choices(self.english_numbers, k=7))
        empty_line = " cudcuuؤسستهiأ"

        return birth_date, empty_line, code

    def generate_back_information(self):

        back_data = random.choices(self.arabic_corpus, k=5)
        back_data = " ".join(back_data)
        back_data = self.remove_control_characters(back_data).strip()
        back_data = back_data.split(" ")

        id_number = random.choices(self.arabic_numbers, k=14)
        id_number = "".join(id_number)

        month = random.choices(self.months, k=1)[0]
        year = random.choices(self.years, k=1)[0] + "".join(random.choices(self.arabic_numbers, k=2))
        id_creation_date = year + "/" + month
        # id_number_and_date = id_number + "     " + id_creation_date

        position = random.choices(back_data, k=random.choices([1, 2, 3, 4], [.7, 0.1, 0.1, 0.1], k=1)[0])
        position = " ".join(position)

        Employer = random.choices(back_data, k=random.choices([1, 2, 3, 4], [.1, 0.1, 0.4, 0.4], k=1)[0])
        Employer = " ".join(Employer)

        sex = ["ذكر", "أنثى"]
        religion = ["مسلم", "مسيحى"]
        marital_status = ["أعزب", "متزوج", "مطلق", "مطلقة", "أرمل", "أرملة", "متزوجة", "أنسة"]
        sex = random.choices(sex, weights=[1, 1], k=1)[0]
        religion = random.choices(religion, k=1)[0]
        marital_status = random.choices(marital_status, k=1)[0]

        # sex_religion_status = sex + "             " + religion + "             " + marital_status

        # sex_religion_status = [ sex , religion , marital_status ]

        spouse_name = random.choices(back_data, k=random.choices([3, 4, 5, 6], [.7, 0.1, 0.1, 0.1], k=1)[0])
        spouse_name = " ".join(spouse_name)

        day2 = random.choices(self.days, k=1)[0]
        month2 = random.choices(self.months, k=1)[0]
        year2 = random.choices(self.years, k=1)[0] + "".join(random.choices(self.arabic_numbers, k=2))

        id_valid_to = "البطاقة سارية حتى   " + year2 + "/" + month2 + "/" + day2

        raqm_below_nesr = random.choices(self.raqm_below_nesr, k=1)[0]

        return id_number, id_creation_date, position, Employer, sex, religion, marital_status, spouse_name, id_valid_to, raqm_below_nesr

    def draw_back_lines(self, image_main_front, segmentation_map, lines):

        text_area_width_ratio = 480 / self.id_width_original
        text_area_height_ratio = 240 / self.id_height_original

        text_area_left_position_ratio = 170 / self.id_width_original
        text_area_top_position_ratio = 40 / self.id_height_original

        date_text_area_left_position_ratio = 475 / self.id_width_original  # change here to y2rab el tare5 mn el rakm el kawmy.
        religion_text_area_left_position_ratio = 310 / self.id_width_original
        status_text_area_left_position_ratio = 490 / self.id_width_original
        raqm_text_area_left_position_ratio = 60 / self.id_width_original

        width_text_area = int(text_area_width_ratio * self.width)
        height_text_area = int(text_area_height_ratio * self.height)

        start_x = int(text_area_left_position_ratio * self.width)

        date_start_x = int(date_text_area_left_position_ratio * self.width)
        religion_start_x = int(religion_text_area_left_position_ratio * self.width)
        status_start_x = int(status_text_area_left_position_ratio * self.width)
        raqm_start_x = int(raqm_text_area_left_position_ratio * self.width)

        end_x = int(start_x + width_text_area)

        start_y = int(text_area_top_position_ratio * self.height)
        end_y = start_y + height_text_area

        # font_name = random.choice(self.arabic_fonts_filenames)
        # font_name = os.path.join(self.arabic_fonts_dir, font_name)
        font_name = self.simplified_arabic_font_path
        for i in range(len(lines)):
            if i == 0:
                font = ImageFont.truetype(font_name, 30, layout_engine=1)
            else:
                font = ImageFont.truetype(font_name, 30, layout_engine=1)

            line_coordinates = font.getbbox(lines[i])

            image_draw = ImageDraw.Draw(image_main_front)

            if i == 1:
                start_x_final = self.width - line_coordinates[2] - line_coordinates[0] - date_start_x
            elif i == 5:
                start_x_final = self.width - line_coordinates[2] - line_coordinates[0] - religion_start_x
            elif i == 6:
                start_x_final = self.width - line_coordinates[2] - line_coordinates[0] - status_start_x
            elif i == 9:
                start_x_final = self.width - line_coordinates[2] - line_coordinates[0] - raqm_start_x
            else:
                start_x_final = self.width - line_coordinates[2] - line_coordinates[0] - start_x
            text_t_bounders = start_y

            text_b_bounders = start_y + line_coordinates[3] - line_coordinates[1]

            text_l_bounders = start_x_final
            text_r_bounders = start_x_final + line_coordinates[2] - line_coordinates[0]

            if i == 7 or i == 3:
                if random.random() >= .5:
                    image_draw.text((start_x_final, start_y), lines[i], fill=self.fill_text_color, encoding='utf-8', font=font,
                                    anchor="lt")  # ,direction = "rtl",anchor= "mm",align = "right",language= "ara"
                    gt_image_draw = ImageDraw.Draw(segmentation_map)
                    gt_image_draw.rectangle([(text_l_bounders, text_t_bounders), (text_r_bounders, text_b_bounders)],
                                            fill=(255, 255, 255), outline=(255, 255, 255), width=5)
                else:
                    pass
            else:
                image_draw.text((start_x_final, start_y), lines[i], fill=self.fill_text_color, encoding='utf-8', font=font,
                                anchor="lt")  # ,direction = "rtl",anchor= "mm",align = "right",language= "ara"
                gt_image_draw = ImageDraw.Draw(segmentation_map)

                gt_image_draw.rectangle([(text_l_bounders, text_t_bounders), (text_r_bounders, text_b_bounders)],
                                        fill=(255, 255, 255), outline=(255, 255, 255), width=5)

            if i == 0 or i == 4 or i == 5 or i == 8:
                continue
            else:
                start_y += line_coordinates[3] - line_coordinates[1] + 14

        if self.debug:
            check = Image.blend(image_main_front, segmentation_map, .5)
            return image_main_front, segmentation_map, check
        else:
            return image_main_front, segmentation_map

    def draw_front_lines(self, image_main_front, segmentation_map, lines):

        text_area_width_ratio = 550 / self.id_width_original
        text_area_height_ratio = 250 / self.id_height_original
        text_area_left_position_ratio = 50 / self.id_width_original
        text_area_top_position_ratio = 140 / self.id_height_original

        width_text_area = int(text_area_width_ratio * self.width)
        height_text_area = int(text_area_height_ratio * self.height)

        egypt_republic_left_position = int((385 / self.id_width_original) * self.width)
        egypt_republic_top_position = int((20 / self.id_height_original) * self.height)
        egypt_republic_right_position = int((720 / self.id_width_original) * self.width)
        egypt_republic_bottom_position = int((75 / self.id_height_original) * self.height)

        personal_id_left_position = int((440 / self.id_width_original) * self.width)
        personal_id_top_position = int((80 / self.id_height_original) * self.height)
        personal_id_right_position = int((670 / self.id_width_original) * self.width)
        personal_id_bottom_position = int((115 / self.id_height_original) * self.height)

        # egypt_republic_image = random.choice(self.egypt_republic_photos_filenames)
        # egypt_republic_image_path = os.path.join(self.egypt_republic_photos, egypt_republic_image)
        # egypt_republic_image = Image.open(egypt_republic_image_path)
        # egypt_republic_image = egypt_republic_image.resize((egypt_republic_right_position-egypt_republic_left_position, egypt_republic_bottom_position-egypt_republic_top_position))
        # image_main_front.paste(egypt_republic_image, (egypt_republic_left_position, egypt_republic_top_position))

        # personal_id_image = random.choice(self.personal_id_photos_filenames)
        # personal_id_image_path = os.path.join(self.personal_id_photos, personal_id_image)
        # personal_id_image = Image.open(personal_id_image_path)
        # personal_id_image = personal_id_image.resize((personal_id_right_position-personal_id_left_position, personal_id_bottom_position-personal_id_top_position))
        # image_main_front.paste(personal_id_image, (personal_id_left_position, personal_id_top_position))

        start_x = int(text_area_left_position_ratio * self.width)
        end_x = int(start_x + width_text_area)
        start_y = int(text_area_top_position_ratio * self.height)
        end_y = start_y + height_text_area

        # font = random.choice(self.arabic_fonts_filenames)
        # font = os.path.join(self.arabic_fonts_dir,font)
        # font = ImageFont.truetype(font, 40, layout_engine=1)

        for i in range(len(lines)):

            if i == 4:
                # font = random.choice(self.arabic_fonts_filenames)
                # font = os.path.join(self.arabic_fonts_dir, font)
                font = self.simplified_arabic_font_path
                font = ImageFont.truetype(font, 60, layout_engine=1)
            else:
                # font = random.choice(self.arabic_fonts_filenames)
                # font = os.path.join(self.arabic_fonts_dir, font)
                font = self.simplified_arabic_font_path
                font = ImageFont.truetype(font, 40, layout_engine=1)

            line_coordinates = font.getbbox(lines[i])

            image_draw = ImageDraw.Draw(image_main_front)
            start_x_final = self.width - line_coordinates[2] - line_coordinates[0] - start_x
            # image_draw.text((start_x_final , start_y),lines[i], fill=(0, 0, 0), encoding='utf-8',font=font,anchor="lt") #,direction = "rtl",anchor= "mm",align = "right",language= "ara"
            text_t_bounders = start_y
            text_b_bounders = start_y + line_coordinates[3] - line_coordinates[1]
            text_l_bounders = start_x_final
            text_r_bounders = start_x_final + line_coordinates[2] - line_coordinates[0]

            if i == 4:
                pass

            else:
                image_draw.text((start_x_final, start_y), lines[i], fill=self.fill_text_color, encoding='utf-8', font=font,
                                anchor="lt")  # ,direction = "rtl",anchor= "mm",align = "right",language= "ara"
                gt_image_draw = ImageDraw.Draw(segmentation_map)
                gt_image_draw.rectangle([(text_l_bounders, text_t_bounders), (text_r_bounders, text_b_bounders)],
                                        fill=(255, 255, 255), outline=(255, 255, 255), width=5)
                gt_image_draw.rectangle([(egypt_republic_left_position, egypt_republic_top_position),
                                         (egypt_republic_right_position, egypt_republic_bottom_position)],
                                        fill=(255, 255, 255), outline=(255, 255, 255), width=5)
                gt_image_draw.rectangle([(personal_id_left_position, personal_id_top_position),
                                         (personal_id_right_position, personal_id_bottom_position)],
                                        fill=(255, 255, 255), outline=(255, 255, 255), width=5)
            start_y += line_coordinates[3] - line_coordinates[1] + 14
            if i == 1:
                start_y+=15

        if self.debug:
            check = Image.blend(image_main_front, segmentation_map, .5)
            return image_main_front, segmentation_map, check
        else:
            return image_main_front, segmentation_map

    def draw_date_and_code_lines(self, image_main_front, segmentation_map, lines):

        text_area_width_ratio = 220 / self.id_width_original
        text_area_height_ratio = 110 / self.id_height_original
        text_area_left_position_ratio = 570 / self.id_width_original
        text_area_top_position_ratio = 420 / self.id_height_original

        width_text_area = int(text_area_width_ratio * self.width)
        height_text_area = int(text_area_height_ratio * self.height)

        start_x = int(text_area_left_position_ratio * self.width)
        end_x = int(start_x + width_text_area)
        start_y = int(text_area_top_position_ratio * self.height)
        end_y = start_y + height_text_area

        for i in range(len(lines)):

            if i == 4:
                # font = random.choice(self.arabic_fonts_filenames)
                # font = os.path.join(self.arabic_fonts_dir, font)
                font = self.factory_code_font
                font = ImageFont.truetype(font, 50, layout_engine=1)
            else:
                # font = random.choice(self.arabic_fonts_filenames)
                # font = os.path.join(self.arabic_fonts_dir, font)
                font = self.factory_code_font
                font = ImageFont.truetype(font, 34, layout_engine=1)

            line_coordinates = font.getbbox(lines[i])

            image_draw = ImageDraw.Draw(image_main_front)

            start_x_final = self.width - line_coordinates[2] - line_coordinates[0] - start_x
            # image_draw.text((start_x_final , start_y),lines[i], fill=(0, 0, 0), encoding='utf-8',font=font,anchor="lt") #,direction = "rtl",anchor= "mm",align = "right",language= "ara"
            text_t_bounders = start_y

            text_b_bounders = start_y + line_coordinates[3] - line_coordinates[1]

            text_l_bounders = start_x_final
            text_r_bounders = start_x_final + line_coordinates[2] - line_coordinates[0]

            if i == 1:
                pass

            else:
                if i != 0:
                    image_draw.text((start_x_final, start_y+17), lines[i], fill=self.fill_text_color, encoding='utf-8', font=font,
                                    anchor="lt")  # ,direction = "rtl",anchor= "mm",align = "right",language= "ara"
                gt_image_draw = ImageDraw.Draw(segmentation_map)
                gt_image_draw.rectangle([(text_l_bounders, text_t_bounders), (text_r_bounders, text_b_bounders)],
                                        fill=(255, 255, 255), outline=(255, 255, 255), width=5)
            start_y += line_coordinates[3] - line_coordinates[1] + 2

        if self.debug:
            check = Image.blend(image_main_front, segmentation_map, .5)
            return image_main_front, segmentation_map, check
        else:
            return image_main_front, segmentation_map

    def add_blended_image(self, image):

        if random.random() <= self.blend_prob:
            background = random.choice(self.background_padding_and_blend_filenames)
            background_path = os.path.join(self.padding_and_blend_backgrounds, background)
            with Image.open(background_path).convert(mode="RGBA") as imgs:
                blend_image = imgs.resize((self.width, self.height))
                image = Image.blend(image, blend_image, .4)

        return image

    def add_padding(self, images):
        if self.debug:
            image, seg_map, check = images
        else:
            image, seg_map = images
        if random.random() <= self.padding_prob:
            add_width = random.randint(100, 1000)
            add_height = random.randint(100, 1000)
            left = random.randint(0, add_width)
            top = random.randint(0, add_height)

            if random.random() <= .5:
                image1 = Image.new('RGBA', (self.width + add_width, self.height + add_height), (255, 255, 255))
            else:
                background = random.choice(self.background_padding_and_blend_filenames)
                background_path = os.path.join(self.padding_and_blend_backgrounds, background)
                with Image.open(background_path).convert(mode="RGBA") as imgs:
                    image1 = imgs.resize((self.width + add_width, self.height + add_height))

            image1.paste(image, (left, top))
            image = image1

            seg_map1 = Image.new('RGBA', (self.width + add_width, self.height + add_height), (0, 0, 0))
            seg_map1.paste(seg_map, (left, top))
            seg_map = seg_map1

            if self.debug:
                check1 = Image.new('RGBA', (self.width + add_width, self.height + add_height), (255, 255, 255))
                check1.paste(check, (left, top))
                check = check1
                self.width, self.height = image.width, image.height
        if self.debug:
            return image, seg_map, check
        else:
            return image, seg_map

    def sharp_augmentaion(self, image, gt_image):
        if random.random() <= self.sharp_prob:
            value = random.uniform(.25, 1.5)
            image = ImageEnhance.Sharpness(image)
            image = image.enhance(value)
            gt_image = ImageEnhance.Sharpness(gt_image)
            gt_image = gt_image.enhance(value)

        return image, gt_image

    def resize_id(self, images, down_w=.2, down_h=.15, up_w=2, up_h=1.5):
        if self.debug:
            image, gt_image, check = images
        else:
            image, gt_image = images
        if random.random() <= self.resize_prob:
            if random.random() <= .5:
                resize_down = random.uniform(.1, 1)
                resize_down_h, resize_down_w = resize_down + random.uniform(.1, down_h), resize_down + random.uniform(
                    .1, down_w)
                resize_h, resize_w = resize_down_h, resize_down_w
            else:
                resize_up = random.uniform(1, 2)
                resize_up_h, resize_up_w = resize_up + random.uniform(1, up_h), resize_up + random.uniform(1, up_w)
                resize_h, resize_w = resize_up_h, resize_up_w

            image_w, image_h = int(self.width * resize_w), int(self.height * resize_h)
            self.width, self.height = image_w, image_h

            image = image.resize((image_w, image_h))
            gt_image = gt_image.resize((image_w, image_h))

        if self.debug:
            # check = check.resize((image_w, image_h))
            return image, gt_image, check
        else:
            return image, gt_image

    def rotate_id(self, images):
        if self.debug:
            image, gt_image, check = images
        else:
            image, gt_image = images
        if random.random() <= self.rotation_prob:
            theta = random.randint(-10, 10)
            expand = random.randint(0, 1)
            image = image.rotate(angle=theta, resample=3, fillcolor=(255, 255, 255), expand=expand)
            gt_image = gt_image.rotate(angle=theta, resample=3, fillcolor=(0, 0, 0), expand=expand)
            # check = check.rotate(angle=theta, resample = 3, fillcolor=(0, 0, 0), expand=expand)

            # image = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
            # gt_image = cv2.cvtColor(np.array(gt_image), cv2.COLOR_RGB2BGR)
            # check = cv2.cvtColor(np.array(check), cv2.COLOR_RGB2BGR)
            # image, gt_image, check = self.rotate_image(image, gt_image, check, (255, 255, 255))
            if self.debug:
                check = check.rotate(angle=theta, resample=3, fillcolor=(0, 0, 0), expand=expand)

        if self.debug:
            return image, gt_image, check
        else:
            return image, gt_image

    def generate_id_front(self):
        width, height = self.set_width_and_height()
        color = 120
        image_main_front = Image.new("RGBA", (width, height), (color, color, color, 1))
        segmentation_map = Image.new("RGBA", (width, height), (0, 0, 0))
        image_main_front = self.put_front_background(image_main_front)
        image_main_front, coords_photo_person = self.put_person_image(image_main_front)
        # image_main_front, coords_photo = self.put_nesr_image(image_main_front)
        lines = self.generate_name_and_adress()
        birth_date_and_code_lines = self.generate_birth_date_and_code()
        if self.debug:
            image_main_front, segmentation_map, check = self.draw_front_lines(image_main_front, segmentation_map, lines)
            image_main_front, segmentation_map, check = self.draw_date_and_code_lines(image_main_front,
                                                                                      segmentation_map,
                                                                                      birth_date_and_code_lines)
            # image_main_front = self.add_blended_image(image_main_front)
            image_main_front, segmentation_map, check = self.resize_id((image_main_front, segmentation_map, check))
            image_main_front, segmentation_map, check = self.add_padding((image_main_front, segmentation_map, check))
            image_main_front, segmentation_map = self.sharp_augmentaion(image_main_front, segmentation_map)
            image_main_front, segmentation_map, check = self.resize_id((image_main_front, segmentation_map, check), .2,
                                                                       .2, 2, 2)
            image_main_front, segmentation_map, check = self.rotate_id((image_main_front, segmentation_map, check))
        else:
            image_main_front, segmentation_map = self.draw_front_lines(image_main_front, segmentation_map, lines)
            image_main_front, segmentation_map = self.draw_date_and_code_lines(image_main_front, segmentation_map,
                                                                               birth_date_and_code_lines)
            # image_main_front = self.add_blended_image(image_main_front)
            image_main_front, segmentation_map = self.resize_id((image_main_front, segmentation_map))
            image_main_front, segmentation_map = self.add_padding((image_main_front, segmentation_map))
            image_main_front, segmentation_map = self.sharp_augmentaion(image_main_front, segmentation_map)
            image_main_front, segmentation_map = self.resize_id((image_main_front, segmentation_map), .2, .2, 2, 2)
            image_main_front, segmentation_map = self.rotate_id((image_main_front, segmentation_map))
        # put_marker = random.choice([True, False])
        put_marker = False
        if put_marker:
            image_main_front = np.array(image_main_front)
            image_main_front = cv2.cvtColor(image_main_front, cv2.COLOR_RGBA2RGB)
            pipeline = get_pipeline()
            shabby_output = pipeline.augment(image_main_front)
            image_main_front = shabby_output["output"]
            image_main_front = cv2.resize(image_main_front,(width, height))
            image_main_front = cv2.cvtColor(image_main_front, cv2.COLOR_BGR2BGRA)
            image_main_front = Image.fromarray(image_main_front)
        if self.debug:
            return image_main_front, segmentation_map, check
        else:
            return image_main_front, segmentation_map, coords_photo_person

    def generate_id_back(self):
        width, height = self.set_width_and_height()
        color = 255
        image_main_back = Image.new("RGBA", (width, height), (color, color, color, 1))
        segmentation_map_back = Image.new("RGBA", (width, height), (0, 0, 0))
        image_main_back = self.put_back_background(image_main_back)
        image_main_back, coords_photo = self.put_pdf417_barcode(image_main_back)
        back_lines = self.generate_back_information()
        if self.debug:
            image_main_back, segmentation_map_back, check = self.draw_back_lines(image_main_back, segmentation_map_back,
                                                                                 back_lines)
            # image_main_back = self.add_blended_image(image_main_back)
            image_main_back, segmentation_map_back, check = self.resize_id(
                (image_main_back, segmentation_map_back, check))
            image_main_back, segmentation_map_back, check = self.add_padding(
                (image_main_back, segmentation_map_back, check))
            image_main_back, segmentation_map_back = self.sharp_augmentaion(image_main_back, segmentation_map_back)
            image_main_back, segmentation_map_back, check = self.resize_id(
                (image_main_back, segmentation_map_back, check), .2, .2, 2, 2)
            image_main_back, segmentation_map_back, check = self.rotate_id(
                (image_main_back, segmentation_map_back, check))
        else:
            image_main_back, segmentation_map_back = self.draw_back_lines(image_main_back, segmentation_map_back,
                                                                          back_lines)
            # image_main_back = self.add_blended_image(image_main_back)
            image_main_back, segmentation_map_back = self.resize_id((image_main_back, segmentation_map_back))
            image_main_back, segmentation_map_back = self.add_padding((image_main_back, segmentation_map_back))
            image_main_back, segmentation_map_back = self.sharp_augmentaion(image_main_back, segmentation_map_back)
            image_main_back, segmentation_map_back = self.resize_id((image_main_back, segmentation_map_back), .2, .2, 2,
                                                                    2)
            image_main_back, segmentation_map_back = self.rotate_id((image_main_back, segmentation_map_back))
        if self.debug:
            return image_main_back, segmentation_map_back, check
        else:
            return image_main_back, segmentation_map_back

    def generate_images(self):
        self.fill_text_color = random.choice(self.colors)
        s = 0
        while True:
            # s += 1
            try:
                # start = time.time()

                # self.generate_name()
                if random.random() >= 0:
                    if self.debug:
                        image_main, image_black_main, check = self.generate_id_front()
                    else:
                        image_main, image_black_main, coords_photo = self.generate_id_front()
                    # print("front")
                else:
                    if self.debug:
                        image_main, image_black_main, check = self.generate_id_back()
                    else:
                        image_main, image_black_main = self.generate_id_back()
                    # print("back")
                # end = time.time()
                # print(end - start)
                # print('image_main')
                # print(image_main)
                # print("**************************************************")
                if self.save_output:
                    image_main.convert(mode="L").save(
                        "{}/{}.png".format(self.output_path, s))
                    image_black_main.save(
                        "{}/{}_gt.png".format(self.output_path, s))
                    if self.debug:
                        check.save(
                            "{}/{}_check.png".format(self.output_path, s))

                image_main = cv2.cvtColor(np.float32(image_main), cv2.COLOR_BGRA2GRAY)
                # image_main = cv2.cvtColor(np.float32(image_main), cv2.COLOR_BGRA2RGB)
                image_black_main = cv2.cvtColor(np.float32(image_black_main), cv2.COLOR_BGRA2GRAY)
                # check = cv2.cvtColor(np.float32(check), cv2.COLOR_BGRA2GRAY)
                image_main = np.array(image_main, dtype='uint8')
                image_black_main = np.array(image_black_main, dtype='uint8')
                # check = np.array(check, dtype='uint8')

                yield np.array(image_main, dtype='uint8')[..., np.newaxis], \
                    np.array(image_black_main, dtype='uint8')[..., np.newaxis], coords_photo
                # np.array(check           , dtype='uint8')[..., np.newaxis] #[..., np.newaxis]
            except Exception as e:
                print(e)
                continue


if __name__ == '__main__':
    lines_generator = IdLinesGenerator(assets_path='D:/All_Assets/Ids', width=800, height=540, save_output=False,
                                       debug=False,
                                       blend_prob=.5, padding_prob=0,
                                       sharp_prob=.5, rotation_prob=0, resize_prob=0
                                       )
    lines_image = lines_generator.generate_images()
    i = 200
    s = 0

    for image_main, image_black_main, coords_photo in lines_image:  # , check
        s += 1
        if s >= 50:
            break
        start_x, end_x, start_y, end_y = coords_photo
        width = end_x - start_x
        height = end_y - start_y
        center_x = width / 2 + start_x
        center_y = height / 2 + start_y

        # label = "0 " + str(center_x / 800) + " " + str(center_y / 540) + " " + str((width) / 800) + " " + str(
        #     (height) / 540)
        # label = "0 "+str(start_x/800)+" "+str(start_y/540)+" " +str((end_x-start_x)/800)+" "+str((end_y-start_y)/540)

        # with open(os.path.join(r"D:\data\ids\ids_95k\train_yolo\labels\train", str(i)+".txt"),
        #           'w', encoding='utf-8') as f:
        #     f.write(label)

        # image_main = image_main.reshape(image_main.shape[0], image_main.shape[1], 3)
        image_main = image_main.reshape(image_main.shape[0], image_main.shape[1])
        image_black_main = image_black_main.reshape(image_main.shape[0], image_main.shape[1])

        # image_main = cv2.rectangle(image_main,(start_x,start_y),(end_x,end_y),0,15)
        # image_main = cv2.circle(image_main,(int(center_x),int(center_y)),0,0,5)
        # check = check.reshape(check.shape[0], check.shape[1])
        #
        plt.figure(figsize=(60, 80))
        plt.subplot(1, 2, 1)
        plt.imshow(image_main, cmap='gray', vmin=0, vmax=255)
        plt.yticks(range(0, image_main.shape[0], 100))
        # plt.grid(True)
        plt.title('Image')

        plt.subplot(1, 2, 2)
        plt.imshow(image_black_main, cmap='gray')
        plt.yticks(range(0, image_main.shape[0], 100))
        # plt.grid(True)
        plt.title('Segmentation Map')

        cv2.imwrite(os.path.join(r"D:\data\ids\fake_train_data\train_generator_colored_vs_real\validation\fake", str(i) + ".jpg"), image_main)
        # # cv2.imwrite(os.path.join(r"D:\data\ids\generator_data", str(i) + ".jpg"), image_main)
        print(i)
        i += 1
        # cv2.imwrite(os.path.join(r"D:\gitlab_updated\ocr_package\test_data", str(i) + "seg_map.jpg"),
        #             image_black_main_)
        # plt.subplot(2 , 2 ,3)
        # plt.imshow(check, cmap='gray')
        # plt.yticks(range(0,  image_main.shape[0], 100))
        # #plt.grid(True)
        # plt.title('check')
        # plt.show()
