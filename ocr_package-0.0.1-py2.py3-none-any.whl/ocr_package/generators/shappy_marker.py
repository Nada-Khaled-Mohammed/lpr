from augraphy import *
import os
import random
import cv2


def get_pipeline():
    ################################################################################
    # CONTROLLING VARIATION
    #
    # We can control the outputs of the pipeline by setting values here.
    ################################################################################

    markup_p = (random.random() > 0.5) * 1


    # Scribbles.scribbles_type determines the types of scribbles effect
    scribbles_scribbles_type = "lines"
    # Scribbles.scribbles_ink determines the types of scribbles ink
    scribbles_scribbles_ink = "random"
    # Scribbles.scribbles_location determines the location of scribbles effect
    scribbles_scribbles_location = "random"
    # Scribbles.scribbles_size_range determines the size of scribbles to draw
    scribbles_scribbles_size_range = (200, 400)
    # Scribbles.scribbles_count_range determines how many scribbles to draw
    scribbles_scribbles_count_range = (1,1)
    # Scribbles.scribbles_thickness_range determines how thick scribbles are
    scribbles_scribbles_thickness_range = (2, 4)
    # Scribbles.scribbles_brightness_change is the brightness value of each stroke
    scribbles_scribbles_brightness_change = [0]
    # Scribbles.scribbles_pencil_skeletonize enable skeletonization effect in the scribbles
    scribbles_scribbles_skeletonize = 0
    # Scribbles.scribbles_skeletonize_iterations determine the number of skeletonizate iterations
    scribbles_scribbles_skeletonize_iterations = (1, 1)
    # Scribbles.scribbles_color is the  color of scribbles
    scribbles_scribbles_color = (0, 0, 0)
    # Scribbles.scribbles_text is the text value for text based scribbles.
    scribbles_scribbles_text = "random"
    # Scribbles.scribbles_text_font is the font types for text based scribbles.
    scribbles_scribbles_text_font = "random"
    # Scribbles.scribbles_text_rotate_range is the rotation angle of text based scribbles.
    scribbles_scribbles_text_rotate_range = (0, 360)
    # Scribbles.scribbles_lines_stroke_count_range determines how many strokes per line scribble
    scribbles_scribbles_lines_stroke_count_range = (1, 2)
    # Scribbles.p is the probability to run this augmentation
    scribbles_p = (random.random() > 0.5) * 1




    post_phase = [

        Scribbles(
            scribbles_type=scribbles_scribbles_type,
            scribbles_ink=scribbles_scribbles_ink,
            scribbles_location=scribbles_scribbles_location,
            scribbles_size_range=scribbles_scribbles_size_range,
            scribbles_count_range=scribbles_scribbles_count_range,
            scribbles_thickness_range=scribbles_scribbles_thickness_range,
            scribbles_brightness_change=scribbles_scribbles_brightness_change,
            scribbles_skeletonize=scribbles_scribbles_skeletonize,
            scribbles_skeletonize_iterations=scribbles_scribbles_skeletonize_iterations,
            scribbles_color=scribbles_scribbles_color,
            scribbles_text=scribbles_scribbles_text,
            scribbles_text_font=scribbles_scribbles_text_font,
            scribbles_text_rotate_range=scribbles_scribbles_text_rotate_range,
            scribbles_lines_stroke_count_range=scribbles_scribbles_lines_stroke_count_range,

            p=scribbles_p,
        ),

    ]

    return AugraphyPipeline(post_phase=post_phase, save_outputs=False,
                            log=False) # paper_phase=paper_phase,
