import cv2
import matplotlib.pyplot as plt
import numpy as np
import time 
from segmentation_module.yolo8_seg import PersonSegmenter
import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

def crop_upper_left(image):
    image = cv2.resize(image, (800, 540))
    height, width, channels = image.shape
    crop_width = int(0.35 * width)
    crop_height = int(0.7 * height)
    cropped_image = image[:crop_height, :crop_width, :]
    return cropped_image

def load_segmenter(chk_path='./segmentation_module/yolov8x-seg.pt'):
    model = PersonSegmenter(chk_path)
    return model

def analyze_id_illumination(image_path, model, brightness_threshold=250, crop = False):
    original_image = cv2.imread(image_path)
    
    if crop:
        original_image = crop_upper_left(original_image)
    
    try:
        mask = model.predict(original_image)
        inverted_mask = np.where(mask == 255, 255, 0).astype('uint8')
        # person_photo = cv2.bitwise_and(original_image, original_image, mask=inverted_mask)
        # plt.imshow(person_photo, cmap='gray')
        # plt.show()
        return inverted_mask
    #     gray_background = cv2.cvtColor(background, cv2.COLOR_BGR2GRAY)
    #     # Focus on high-intensity values (bright regions)
    #     _, bright_spots_mask = cv2.threshold(gray_background, brightness_threshold, 255, cv2.THRESH_BINARY)
    #     # Calculate the area of the bright spots
    #     bright_spots_area = np.sum(bright_spots_mask == 255)
    #     # Calculate the total area of the background
    #     total_background_area = np.sum(inverted_mask == 255)
    #     # Calculate the ratio of bright spots area to the total background area
    #     bright_spots_ratio = bright_spots_area / total_background_area * 100
    except:
        pass
    #     bright_spots_ratio = 100

    # return bright_spots_ratio

if __name__ == '__main__':
    person_segmenter = load_segmenter()

    brightness_threshold = 250 
    threshold = 0.05
    
    images_folder = r'D:\data\ids\ids_95k_front_yolo_photo_detection_output'
    images_paths = os.listdir(images_folder)
    all_images = len(images_paths)
    fakes = 0
    reals = 0
    not_defined = 0
    for path in images_paths:
        print(path)
        img_path = os.path.join(images_folder, path)
        percent = analyze_id_illumination(img_path, person_segmenter, brightness_threshold, crop=False)
        
        # if percent == 100:
        #     not_defined += 1
        # if (percent < threshold):
        #     reals += 1
        #     print("real")
        # else:
        #     fakes += 1
        #     print("fake")

    print("len of iimages ",all_images)
    print("len of not defined ",not_defined)
    print("len of real images ",reals)
    print("len of fake images ",fakes)