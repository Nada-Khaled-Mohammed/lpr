import cv2
import random
import numpy as np
import matplotlib.pylab as plt
import PIL
from PIL import Image, ImageDraw, ImageFont, ImageEnhance, ImageFilter
import os
import math

class PassportGenerator():
    def __init__(self, assets_path='../../assets', width=384, height=512):
        self.people_photos = os.path.join(assets_path, 'passports', "personImages")
        self.barcode = os.path.join(assets_path, 'passports', "barcode")
        self.background = os.path.join(assets_path, 'passports', "passportImages")
        self.templates = os.path.join(assets_path, 'passports', "templates")
        self.padding_backgrounds = os.path.join(assets_path, 'passports', "backgrounds")
        self.background_padding_filenames = os.listdir(self.padding_backgrounds)
        self.background_images_filnames = os.listdir(self.background)
        self.width_original = width
        self.height_original = height
        self.people_photos_filenames = os.listdir(self.people_photos)
        self.barcode_file_names = os.listdir(self.barcode)
        arabic_fonts_dir = os.path.join(assets_path, "Arabic_Fonts")
        bilingual_fonts_dir = os.path.join(assets_path, "Bilingual_Fonts")
        mrz_fonts_dir = os.path.join(assets_path, "Fonts_MRZ")
        english_fonts_dir = os.path.join(assets_path, "English_Fonts")
        self.months = ["JAN", "FEB", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUG", "SEPT", "OCT", "NOV", "DEC"]
        self.arabic_months = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر',
                              'نوفمبر', 'ديسمبر']
        # self.arabic_letters = "ءآأؤإئابةتثجحخدذرزسشصضطظعغفقكلمنهوىي"
        # self.arabic_letters = ['آ', 'أ', 'ؤ', 'إ', 'ا', 'ب', 'ت', 'ث', 'ج', 'ح', 'خ', 'د', 'ذ', 'ر', 'ز',
        #                        'س', 'ش', 'ص', 'ض', 'ط', 'ظ', 'ع', 'غ', 'ف', 'ق', 'ك', 'ل', 'م', 'ن', 'ه', 'و', 'ي',
        #                        'ـــ', "ــــــ"]
        self.arabic_letters = ['ء', 'آ', 'أ', 'ؤ', 'إ', 'ئ', 'ا', 'ب', 'ة', 'ت', 'ث', 'ج', 'ح', 'خ', 'د', 'ذ', 'ر', 'ز',
                               'س', 'ش', 'ص', 'ض', 'ط', 'ظ', 'ع', 'غ', 'ف', 'ق', 'ك', 'ل', 'م', 'ن', 'ه', 'و', 'ى', 'ي']
        self.arabic_ending_letters = ['ء', 'ى', 'ة', 'ئ']
        self.arabic_punctuation = ['؟', '؛', '،', '!', '...', '.', ':', '-']
        # '٪' '_'
        # self.english_punctuation = ['%', ',', '@', '$', '&', '?', ';', "'", '^', ':-']

        # self.general_punctuation = ['!', '-', '.', '/', ':', '..', '*', '+', '×', '÷', '=']

        # self.any_punctuation = ['؟', '؛', '،', 'ـ', '%', ',', '@', '$', '&', '?', ';', "'", '^', ':-', '!', '-', '.', '/',
        #                    ':', '..', '*', '+', '×', '÷', '=']
        self.chars = ['<']
        self.english_letters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q',
                                'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
        self.text_only_list = ['31.ttf', '35.ttf', "alfont_com_AlFont_com_BJadidBold.ttf",
                               "alfont_com_Sp_Jadid-Bold_p30download.com_.ttf", "ArbFONTS-B-Jadid-Bold.ttf",
                               "Sp_Maryam-Bold_p30download.com_.ttf", "Sp_Jadid-Bold_p30download.com_.ttf"]
        self.arabic_numbers = "١٢٣٤٥٦٧٨٩٠"
        # self.english_numbers = "1234567890"
        self.english_numbers = ['1','2','3','4','5','6','7','8','9','0']
        self.arabic_fonts_path = []
        for font in os.listdir(arabic_fonts_dir):
            self.arabic_fonts_path.append(os.path.join(arabic_fonts_dir, font))

        self.bilingual_fonts_path = []
        for font in os.listdir(bilingual_fonts_dir):
            self.bilingual_fonts_path.append(os.path.join(bilingual_fonts_dir, font))

        self.mrz_fonts_path = []
        for font in os.listdir(mrz_fonts_dir):
            self.mrz_fonts_path.append(os.path.join(mrz_fonts_dir, font))


        self.english_fonts_path = []
        for font in os.listdir(english_fonts_dir):
            self.english_fonts_path.append(os.path.join(english_fonts_dir, font))
            self.bilingual_fonts_path.append(os.path.join(english_fonts_dir, font))

        self.mrz_font_path = random.choice(self.mrz_fonts_path)
    # ...............................................................................................
    def adjust_augmentation_to_image(self, image, seg_map):
        image = PIL.Image.fromarray(np.uint8(image))
        seg_map = PIL.Image.fromarray(np.uint8(seg_map))
        # ***********************************************************
        if random.random() < .2:
            shear_angle = np.random.randint(-5, 5)
            shear_factor = math.tan(math.radians(shear_angle))
            image = image.transform(image.size, Image.AFFINE, (1, shear_factor, 0, 0, 1, 0))
            seg_map = seg_map.transform(seg_map.size, Image.AFFINE, (1, shear_factor, 0, 0, 1, 0))

        if random.random() < .8:
            if random.random()<.2:
                enhancer = ImageEnhance.Contrast(image)
                factor = random.uniform(2, 2.6)
                # factor = 2.5
                image = enhancer.enhance(factor)
            elif random.random()<.2:
                enhancer = ImageEnhance.Brightness(image)
                factor = random.uniform(0.5, 1.2)
                image = enhancer.enhance(factor)
            elif random.random() < .2:
                image = image.filter(ImageFilter.GaussianBlur(2))
            elif random.random() < .2:
                img_noise = Image.effect_noise((image.width, image.height), 25)
                image = Image.blend(image, img_noise, .3)

        # # -----------------------------------------------------------
        # # ApplySaturation
        # if random.random() < 1:
        #     enhancer = ImageEnhance.Color(sheared_image)
        #     saturation_factor = 2
        #     saturated_image = enhancer.enhance(saturation_factor)
        #     print('Saturation')
        # else:
        #     saturated_image = image.copy()
        # # -----------------------------------------------------------
        # ***********************************************************
        adjusted_image = np.array(image)
        adjusted_seg_map = np.array(seg_map)
        return adjusted_image, adjusted_seg_map
    # ...............................................................................................
    def add_noise(self,image):
        image = PIL.Image.fromarray(np.uint8(image))

        image = image.convert("RGBA")
        print(image.mode)
        for i in range(round(image.size[0] * image.size[1] / 5)):
            p1 = random.randint(0, image.size[0] - 1), random.randint(0, image.size[1] - 1)
            p2 = random.randint(100, 200), random.randint(100, 200), random.randint(100, 200)
            image.putpixel(
                (p1),
                (p2)
            )
        image = image.convert("L")
        image = np.array(image)
        return image
    # ...............................................................................................
    def set_width_and_height(self):
        # region get width and height of main image
        if type(self.width_original) != int:
            self.width = int(random.uniform(self.width_original[0], self.width_original[1]))
        else:
            self.width = self.width_original
        if type(self.height_original) != int:
            self.height = int(random.uniform(self.height_original[0], self.height_original[1]))
        else:
            self.height = self.height_original
        new_width = self.width
        new_height = self.height
        # endregion
        return new_width, new_height

    def draw_lines_seg_map(self, box, segmentation_map):  # draw line of seg map with height of 80& of original height
        # cv2.rectangle(segmentation_map, (x_start_draw, box[1]), (x_start_draw + (box[2] - box[0]), box[3]), (255, 255, 255),-1)
        y_line = box[1] + (box[3] - box[1]) // 2  # keda el y f nos el box
        height_line_seg_map = int((box[3] - box[1]) * 0.8)
        y_line = y_line - int(height_line_seg_map // 2)  # keda el y bdaytha 3nd 10%
        for height_count in range(height_line_seg_map):
            cv2.line(segmentation_map, (box[0], y_line + height_count), (box[2], y_line + height_count), 255, 1)
        return segmentation_map
    # ...............................................................................................
    def rotate_image(self,image,gt_image,rotation_angle):
        image = PIL.Image.fromarray(np.uint8(image))
        gt_image = PIL.Image.fromarray(np.uint8(gt_image))
        theta = rotation_angle
        expand = random.randint(0, 1)
        rotated_image = image.rotate(angle=theta, resample=Image.BICUBIC, fillcolor=255, expand=True)
        rotated_gt_image = gt_image.rotate(angle=theta, resample=Image.BICUBIC, fillcolor=0, expand=True)
        rotated_image = np.array(rotated_image)
        rotated_gt_image = np.array(rotated_gt_image)
        return rotated_image, rotated_gt_image

    def add_padding_with_bg(self,image, seg_map):
        image = PIL.Image.fromarray(np.uint8(image))
        seg_map = PIL.Image.fromarray(np.uint8(seg_map))

        if random.random() <= .5:
            add_width = random.randint(50, 500)
            add_height = random.randint(50, 500)
        else:
            add_width = random.randint(1, 10)
            add_height = random.randint(1, 10)

        left = random.randint(0, add_width)
        top = random.randint(0, add_height)

        # image1 = Image.new('L', (image.width + add_width, image.height + add_height), 255)
        if random.random() <= 0.5:
            image1 = Image.new('L', (image.width + add_width, image.height + add_height), 255)
        else:
            background = random.choice(self.background_padding_filenames)
            background_path = os.path.join(self.padding_backgrounds, background)
            with Image.open(background_path).convert(mode="L") as imgs:
                image1 = imgs.resize((image.width + add_width, image.height + add_height))

        image1.paste(image, (left, top))
        image = image1

        seg_map1 = Image.new('L', (seg_map.width + add_width, seg_map.height + add_height), 0)
        seg_map1.paste(seg_map, (left, top))
        seg_map = seg_map1

        image = np.array(image)
        seg_map = np.array(seg_map)

        return image, seg_map
    # ...............................................................................................
    def put_image_background(self, image):
        background_image_path = os.path.join(self.templates, 'template.jpg')
        background_image = Image.open(background_image_path).convert("RGBA")
        background_image = background_image.resize((image.width, image.height))
        image = Image.blend(image, background_image, 1)
        return image

    def draw_mask(self, image_main, segmentation_map,flag):
        x, y, w, h = cv2.boundingRect(image_main)
        y = int(image_main.shape[0]/2) if flag == 'full_passport' else y
        segmentation_map = cv2.rectangle(segmentation_map, (x, y), (x + w, y + h), (255, 255, 255), thickness=-1)
        return segmentation_map

    def add_person_image_to_passport_card(self, image_main):
        image_main_width = image_main.shape[1]
        image_main_height = image_main.shape[0]
        width_photo = int(image_main_width/3.7)
        height_photo = int(image_main_height/2)
        start_x = int(0.03*image_main_width)
        end_x = int(start_x + width_photo)
        start_y = int(0.13*image_main_height)
        end_y = start_y + height_photo
        person_image = random.choice(self.people_photos_filenames)
        person_image_path = os.path.join(self.people_photos, person_image)
        photo_image = cv2.imread(person_image_path)
        photo_image = cv2.resize(photo_image, (width_photo, height_photo))
        photo_image = cv2.cvtColor(photo_image, cv2.COLOR_BGRA2GRAY)
        image_main[start_y:end_y, start_x:end_x] = photo_image
        return image_main, [start_x, start_y, end_x, end_y]

    def add_bright_spot(self, image_main,photo_coords):

        # # x = 0
        # x = int(0.03 * image_main.shape[1])
        # # y = np.random.randint(20, 100)
        # y = np.random.randint(20, int(image_main.shape[0]/2))
        # # radius = np.random.randint(60, 80)
        # radius = np.random.randint(100, 300)

        color = (np.random.randint(100, 150), np.random.randint(100, 150), np.random.randint(100, 150))

        blank_image = np.zeros_like(image_main)
        # cv2.circle(blank_image, (x, y), radius, color, -1)

        cv2.rectangle(blank_image, (photo_coords[0],photo_coords[1]) , (photo_coords[2],photo_coords[3]), color=color, thickness=-1)

        result = cv2.add(image_main, blank_image)
        return result

    def add_bar_code_to_passport_card(self, image_main, photo_coords):
        photo_start_x, photo_start_y, photo_end_x, photo_end_y = photo_coords[0], photo_coords[1], photo_coords[2], photo_coords[3]
        bar_code_height = int(image_main.shape[0]/10)
        bar_code_width = photo_end_x - photo_start_x + 10
        start_x = photo_start_x - 5
        end_x = start_x + bar_code_width
        start_y = photo_end_y + 5
        end_y = start_y + bar_code_height
        barcode_image = random.choice(self.barcode_file_names)
        barcode_image_path = os.path.join(self.barcode, barcode_image)
        barcode_image = cv2.imread(barcode_image_path)
        # barcode_image = cv2.cvtColor(barcode_image, cv2.COLOR_BGR2BGRA)
        barcode_image = cv2.resize(barcode_image, (bar_code_width, bar_code_height))
        barcode_image = cv2.cvtColor(barcode_image, cv2.COLOR_BGRA2GRAY)
        image_main[start_y:end_y, start_x:end_x] = barcode_image
        return image_main

    def generate_random_string(self,lang,word_len):
        if lang == 'english':
            letters = self.english_letters
        elif lang == 'english+numbers':
            letters = self.english_letters + self.english_numbers
        else:
            letters = self.arabic_letters

        word = ''.join(random.choices(letters, k = word_len))

        return word

    def draw_string(self,image_main,word,xy_strat,font_size):
        font_size = font_size
        if word[0] in self.arabic_letters or word[0] in self.arabic_numbers:
            self.arabic_font_path = random.choice(self.arabic_fonts_path)
            font = self.arabic_font_path
        else:
            font = self.mrz_font_path

        font = ImageFont.truetype(font, font_size)
        fill = 0
        pil_image_main = Image.fromarray(image_main)
        image_draw = ImageDraw.Draw(pil_image_main)
        x_start_draw = xy_strat[0]
        y_start_draw = xy_strat[1]
        box = image_draw.textbbox((x_start_draw, y_start_draw), word, font=font, anchor="lt")
        image_draw.text((x_start_draw, box[1]), word, fill=fill, font=font, anchor="lt")
        image_main = np.array(pil_image_main)
        return image_main

    def generate_MRZ(self,image_main):
        y_first_line = image_main.shape[0]/1.23
        font_size = 19
        # -------------------------------------------
        # first line words
        w1 = self.generate_random_string('english',5)
        w1 = w1.upper()
        w1_x_start = image_main.shape[1]/6.8
        image_main = self.draw_string(image_main,w1,[w1_x_start,y_first_line],font_size=font_size)

        w2 = self.generate_random_string('english',5)
        w2 = w2.upper()
        w2_x_start = image_main.shape[1]/3.42
        image_main = self.draw_string(image_main,w2,[w2_x_start,y_first_line],font_size=font_size)

        w3 = self.generate_random_string('english',7)
        w3 = w3.upper()
        w3_x_start = image_main.shape[1]/2.43
        image_main = self.draw_string(image_main,w3,[w3_x_start,y_first_line],font_size=font_size)

        w4 = self.generate_random_string('english',10)
        w4 = w4.upper()
        w4_x_start = image_main.shape[1]/1.75
        image_main = self.draw_string(image_main,w4,[w4_x_start,y_first_line],font_size=font_size)

        w5 = self.generate_random_string('english',3)
        w5 = w5.upper()
        w5_x_start = image_main.shape[1]/1.26
        image_main = self.draw_string(image_main,w5,[w5_x_start,y_first_line],font_size=font_size)

        # -------------------------------------------
        # second line words
        y_second_line = image_main.shape[0]*.88
        w_1 = self.generate_random_string('english+numbers',10)
        w_1 = w_1.upper()
        w_1_x_start = image_main.shape[1]/20.2
        image_main = self.draw_string(image_main,w_1,[w_1_x_start,y_second_line],font_size=font_size)

        w_2 = self.generate_random_string('english+numbers',15)
        w_2 = w_2.upper()
        w_2_x_start = image_main.shape[1]/3.2
        image_main = self.draw_string(image_main,w_2,[w_2_x_start,y_second_line],font_size=font_size)

        w_3 = self.generate_random_string('english+numbers',2)
        w_3 = w_3.upper()
        w_3_x_start = image_main.shape[1]/1.115
        image_main = self.draw_string(image_main,w_3,[w_3_x_start,y_second_line],font_size=font_size)

        return image_main

    def generate_random_date(self,lang):
        if lang == 'arabic':
            numbers = self.arabic_numbers
        else:
            numbers = self.english_numbers
        day = ''.join(random.choices(numbers, k=random.choice([1, 2])))
        year = ''.join(random.choices(numbers, k=4))
        month = ''.join(random.choices(numbers, k=random.choice([1, 2])))
        date = "/".join([day, month, year])
        return date

    def generate_passport_info(self,image_main):
        font_size = 15 #10
        font_size_names = 17
        # -------------------------------------------
        ys_passport_no = image_main.shape[0] / 7.5
        passport_no = self.generate_random_string('english+numbers',9)
        passport_no = passport_no.upper()
        xs_passport_no = image_main.shape[1]*.72
        image_main = self.draw_string(image_main, passport_no, [xs_passport_no, ys_passport_no],font_size=font_size)
        # -------------------------------------------
        ys_ara_name = image_main.shape[0] / 5
        xs_ara_name = image_main.shape[1]*.46
        ara_name = []
        for i in range(5):
            word = self.generate_random_string('arabic', random.randint(3,6))
            ara_name.append(word)
        ara_name = '  '.join(ara_name)
        # ara_name = 'نورهان عماد رمضان سليمان حسن'
        image_main = self.draw_string(image_main, ara_name, [xs_ara_name, ys_ara_name], font_size=font_size_names)
        # -------------------------------------------
        ys_eng_name = image_main.shape[0] / 3.6
        xs_eng_name = image_main.shape[1]*.36
        eng_name = []
        for i in range(5):
            word = self.generate_random_string('english', random.randint(3,7))
            eng_name.append(word)
        eng_name = ' '.join(eng_name).upper()
        image_main = self.draw_string(image_main, eng_name, [xs_eng_name, ys_eng_name], font_size=font_size_names)
        # -------------------------------------------
        ys_eng_dob = image_main.shape[0] / 2.75
        xs_eng_dob = image_main.shape[1]*.36
        eng_dob = self.generate_random_date('english')
        image_main = self.draw_string(image_main, eng_dob, [xs_eng_dob, ys_eng_dob], font_size=font_size)
        # -------------------------------------------
        ys_eng_pob = image_main.shape[0] / 2.75
        xs_eng_pob = image_main.shape[1]*0.514
        eng_pob = self.generate_random_string('english',random.randint(4,8)).upper()
        image_main = self.draw_string(image_main, eng_pob, [xs_eng_pob, ys_eng_pob], font_size=font_size)
        # -------------------------------------------
        ys_ara_pob = image_main.shape[0] / 2.75
        xs_ara_pob = image_main.shape[1]*0.7
        ara_pob = self.generate_random_string('arabic',random.randint(4,8))
        image_main = self.draw_string(image_main, ara_pob, [xs_ara_pob, ys_ara_pob], font_size=font_size)
        # -------------------------------------------
        ys_ara_dob = image_main.shape[0] / 2.75
        xs_ara_dob = image_main.shape[1]*.84
        ara_dob = self.generate_random_date('arabic')
        ara_dob = ara_dob[::-1]
        image_main = self.draw_string(image_main, ara_dob, [xs_ara_dob, ys_ara_dob], font_size=font_size)
        # -------------------------------------------
        ys_eng_sex = image_main.shape[0] / 2.3622
        xs_eng_sex = image_main.shape[1]*0.514
        eng_sex = 'F' if random.choice([True, False]) else 'M'
        image_main = self.draw_string(image_main, eng_sex, [xs_eng_sex, ys_eng_sex], font_size=font_size)
        # -------------------------------------------
        ys_ara_sex = image_main.shape[0] / 2.4
        xs_ara_sex = image_main.shape[1]*0.75
        ara_sex = 'أنثى' if random.choice([True, False]) else 'ذكر'
        image_main = self.draw_string(image_main, ara_sex, [xs_ara_sex, ys_ara_sex], font_size=font_size)
        # -------------------------------------------
        ys_eng_doi = image_main.shape[0] / 2.07
        xs_eng_doi = image_main.shape[1]*.36
        eng_doi = self.generate_random_date('english')
        image_main = self.draw_string(image_main, eng_doi, [xs_eng_doi, ys_eng_doi], font_size=font_size)
        # -------------------------------------------
        ys_eng_doe = image_main.shape[0] / 2.07
        xs_eng_doe = image_main.shape[1]*0.514
        eng_doe = self.generate_random_date('english')
        image_main = self.draw_string(image_main, eng_doe, [xs_eng_doe, ys_eng_doe], font_size=font_size)
        # -------------------------------------------
        ys_ara_doe = image_main.shape[0] / 2.07
        xs_ara_doe = image_main.shape[1]*0.68
        ara_doe = self.generate_random_date('arabic')
        ara_doe = ara_doe[::-1]
        image_main = self.draw_string(image_main, ara_doe, [xs_ara_doe, ys_ara_doe], font_size=font_size)
        # -------------------------------------------
        ys_ara_doi = image_main.shape[0] / 2.07
        xs_ara_doi = image_main.shape[1]*.84
        ara_doi = self.generate_random_date('arabic')
        ara_doi = ara_doi[::-1]
        image_main = self.draw_string(image_main, ara_doi, [xs_ara_doi, ys_ara_doi], font_size=font_size)
        # -------------------------------------------
        ys_eng_issuing_office = image_main.shape[0] / 1.82
        xs_eng_issuing_office = image_main.shape[1]*.36
        eng_issuing_office = ''.join(np.random.choice(self.english_numbers,1))
        image_main = self.draw_string(image_main, eng_issuing_office, [xs_eng_issuing_office, ys_eng_issuing_office], font_size=font_size)
        # -------------------------------------------
        ys_ara_issuing_office = image_main.shape[0] / 1.82
        xs_ara_issuing_office = image_main.shape[1]*.94
        ara_issuing_office = random.choice(self.arabic_numbers)
        image_main = self.draw_string(image_main, ara_issuing_office, [xs_ara_issuing_office, ys_ara_issuing_office], font_size=font_size)
        # -------------------------------------------
        ys_id = image_main.shape[0] / 1.73
        xs_id = image_main.shape[1]*0.65
        # list_of_arabic_numbers = (self.arabic_numbers).split()
        id = ''.join((random.choice(self.arabic_numbers) for i in range(14)))
        image_main = self.draw_string(image_main, id, [xs_id, ys_id],
                                      font_size=font_size)
        # -------------------------------------------
        ys_ara_profession = image_main.shape[0] / 1.67
        xs_ara_profession = image_main.shape[1] * 0.48
        ara_profession = []
        for i in range(random.randint(3,4)):
            word = self.generate_random_string('arabic', random.randint(3,6))
            ara_profession.append(word)
        ara_profession = '  '.join(ara_profession)
        image_main = self.draw_string(image_main, ara_profession, [xs_ara_profession, ys_ara_profession],
                                      font_size=font_size)
        # -------------------------------------------
        ys_eng_profession = image_main.shape[0] / 1.57
        xs_eng_profession = image_main.shape[1] * 0.48
        eng_profession = []
        for i in range(random.randint(1,3)):
            word = self.generate_random_string('english', random.randint(3,6))
            eng_profession.append(word)
        eng_profession = '  '.join(eng_profession).upper()
        image_main = self.draw_string(image_main, eng_profession, [xs_eng_profession, ys_eng_profession],
                                      font_size=font_size)
        # -------------------------------------------
        ys_tagned = image_main.shape[0] / 1.49
        xs_tagned = image_main.shape[1] * 0.65
        tagned = []
        for i in range(random.randint(1, 2)):
            word = self.generate_random_string('arabic', random.randint(3, 4))
            tagned.append(word)
        tagned = '  '.join(tagned)
        image_main = self.draw_string(image_main, tagned, [xs_tagned, ys_tagned],
                                      font_size=font_size)
        # -------------------------------------------
        ys_address = image_main.shape[0] / 1.42
        xs_address = image_main.shape[1] * 0.36
        address = []
        for i in range(random.randint(5, 7)):
            word = self.generate_random_string('arabic', random.randint(3, 5)) if random.random()<.9 else random.choice(self.arabic_numbers)
            address.append(word)
        address = '  '.join(address)
        image_main = self.draw_string(image_main, address, [xs_address, ys_address],
                                      font_size=font_size)
        # -------------------------------------------

        return image_main
    # ...............................................................................................
    def concatenate_images(self,image_main):
        # image_above = Image.new("RGBA", (image_main.shape[1], image_main.shape[0]), (255, 255, 255, 0))
        image_above = Image.new("L", (image_main.shape[1],image_main.shape[0]), color=255)
        background_image_path = os.path.join(self.templates, 'upper_image.jpg')
        bg_image = cv2.imread(background_image_path, 0)
        background_image = cv2.resize(bg_image, (image_above.size[0],image_above.size[1]), interpolation=cv2.INTER_AREA)
        image_above_arr = np.array(image_above, dtype='uint8')
        image_above = cv2.addWeighted(image_above_arr, 0.7, background_image, 0.3, 0)
        # image_main_copy = image_main.copy()
        im_v = cv2.vconcat([image_above, image_main])
        new_image_main = cv2.resize(im_v, (image_main.shape[1],image_main.shape[0]),
                                  interpolation=cv2.INTER_LINEAR)
        return new_image_main
    # ...............................................................................................
    def generate_passport(self):
        width_main, height_main = self.set_width_and_height()
        image_main = Image.new("RGBA", (width_main, height_main), (255, 255, 255, 1))
        segmentation_map = np.zeros((height_main, width_main), dtype='uint8')
        image_main = self.put_image_background(image_main)
        image_main = np.array(image_main, dtype='uint8')
        image_main = image_main[:, :, 0]
        # segmentation_map = self.draw_mask(image_main, segmentation_map)

        image_main ,  photo_coords = self.add_person_image_to_passport_card(image_main)

        image_main = self.add_bright_spot(image_main,photo_coords) if np.random.rand() < .3 else image_main

        image_main = self.add_bar_code_to_passport_card(image_main,photo_coords)

        image_main = self.generate_MRZ(image_main)

        image_main = self.generate_passport_info(image_main)
        # .......................................
        if random.random() < .7:
            image_main = self.concatenate_images(image_main)
            flag = 'full_passport'
        else:
            flag = 'card_only'

        segmentation_map = self.draw_mask(image_main, segmentation_map,flag)
        # .......................................

        rotate_image = random.choices([True, False], k=1, weights=[0.5,0.5])[0]
        if rotate_image:
            rotation_angle = random.randint(-90, 90)
            image_main, segmentation_map = self.rotate_image(image_main,segmentation_map,rotation_angle)

        padding_page = random.choices([True, False], k=1, weights=[0.5, 0.5])[0]
        if padding_page:
            image_main, segmentation_map = self.add_padding_with_bg(image_main,segmentation_map)

        if random.random()<.3:
            image_main, segmentation_map = self.adjust_augmentation_to_image(image_main,segmentation_map)

        return image_main, segmentation_map

    def generate_images(self):
        while True:
            # try:
                image_main, image_black_main = self.generate_passport()
                yield np.array(image_main, dtype='uint8')[..., np.newaxis], \
                      np.array(image_black_main, dtype='uint8')[..., np.newaxis]
            # except Exception as e:
            #     print(e)
            #     continue


if __name__ == '__main__':
    # lines_generator = PassportGenerator(assets_path='../../assets', width=[500, 700], height=[300, 500])
    lines_generator = PassportGenerator(assets_path='D:/All_Assets/passports/new_assets/assets', width=700, height=500)
    lines_image = lines_generator.generate_images()
    i = 0
    for image_main, image_black_main in lines_image:

        plt.figure(figsize=(60,80))
        plt.subplot(1, 2, 1)
        plt.imshow(image_main, cmap='gray', vmin=0, vmax=255)
        plt.title('Image')

        plt.subplot(1, 2, 2)
        plt.imshow(image_black_main, cmap='gray', vmin=0, vmax=255)
        plt.title('Segmentation Map')

        plt.show()

        # saving_name = os.path.join(r"D:\Cyshield_Projects\passports\saving_imgs", str(i)+'.jpg')
        # cv2.imwrite(saving_name, image_main)
        # print(i)

        i += 1
        if i == 50:
            break

        # plt.close()
        # gc.collect()
