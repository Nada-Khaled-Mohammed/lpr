# from .yolo8_detector import PoseDetector
# from .yolo8_detector import Detector
# from .ultralytics.yolo.utils.plotting import Colors,Annotator
# from .seg import Segmenter
import sys
sys.path.insert(0,'./segmentation_module/')