import cv2
import numpy as np
from functools import reduce
from seg import Segmenter


class PersonSegmenter:
    def __init__(self,chk_path):
        self.model = Segmenter(chk_path)

    def predict(self, img):
        res = self.model.detect(img)
        ims =  [i.masks.data[0].cpu().numpy()*255 for i in res if i.boxes.cls== 0]
        mask = reduce(lambda img1, img2: cv2.bitwise_or(img1, img2), ims)
        mask = cv2.resize(mask, (img.shape[1], img.shape[0]))
        return mask

