import cv2 
import numpy as np
from .ultralytics import YoloPose, YoloSegmenter, YoloDetector
from .ultralytics.yolo.utils.plotting import plot_images,Colors,Annotator

class PoseDetector:

    def __init__(self, chk_path, conf_threshold, names,visualize,draw_box, draw_face, draw_kpts,draw_kpts_line, device):
        self.chk_path = chk_path
        self.conf_threshold = conf_threshold
        self.visualize = visualize
        self.draw_box = draw_box
        self.draw_face = draw_face
        self.draw_kpts = draw_kpts
        self.draw_kpts_line = draw_kpts_line
        self.device = device


        self.names = names
        rng = np.random.default_rng()
        self.class_colors = [rng.integers(low=0, high=255, size=3, dtype=np.uint8).tolist() for _ in self.names]
        self.load_detector()
        
        
    def load_detector(self):
        self.model = YoloPose(model=self.chk_path, conf=self.conf_threshold, device = self.device)
                    
    def detect(self, frame):
        results = self.model.predict(source=frame)[0].cpu().numpy()
        detections = results.boxes
        classes = detections.cls
        scores = detections.conf
        bboxes = detections.xyxy
        keypoints = results.keypoints.xy[classes == 0]
        keypoints_score = results.keypoints.conf[classes == 0]
        return classes, scores, bboxes,keypoints,keypoints_score
   
    def visualize_box(self, frame, class_ids, scores, boxes,faces,thickness= 2):
        
        if self.draw_box:
            for cid, score, box in zip(class_ids, scores, boxes):
                    cid = int(cid)
                    x1, y1, x2, y2 = box
                    x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2) 
                    cv2.putText(frame,self.names[int(cid)], (x1, y1), cv2.FONT_HERSHEY_SIMPLEX, 1, self.class_colors[int(cid)],
                                thickness, cv2.LINE_AA)
                    cv2.rectangle(frame, (x1, y1), (x2, y2), self.class_colors[int(cid)], thickness)

                    det = frame[y1:y2, x1:x2]
                    det_mask = np.ones(det.shape, dtype=np.uint8) * np.uint8(self.class_colors[cid])
                    res = cv2.addWeighted(det, 0.6, det_mask, 0.4, 1.0)
                    frame[y1:y2, x1:x2] = res

        if self.draw_face:

            for face in faces:
                if face != []:
                    cid = 1
                    x1, y1, x2, y2 = face
                    x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2) 
                    cv2.putText(frame,self.names[cid], (x1, y1), cv2.FONT_HERSHEY_SIMPLEX, 1, self.class_colors[cid],
                                thickness, cv2.LINE_AA)
                    cv2.rectangle(frame, (x1, y1), (x2, y2), self.class_colors[cid], thickness)
                    
                    det = frame[y1:y2, x1:x2]
                    det_mask = np.ones(det.shape, dtype=np.uint8) * np.uint8(self.class_colors[cid])
                    res = cv2.addWeighted(det, 0.6, det_mask, 0.4, 1.0)
                    frame[y1:y2, x1:x2] = res


    def visualize_kpts(self,im, kpts,kpts_score, radius=5, kpt_line=True):  
        """Plot keypoints on the image.

        Args:
            kpts (tensor): Predicted keypoints with shape [17, 3]. Each keypoint has (x, y, confidence).
            shape (tuple): Image shape as a tuple (h, w), where h is the height and w is the width.
            radius (int, optional): Radius of the drawn keypoints. Default is 5.
            kpt_line (bool, optional): If True, the function will draw lines connecting keypoints
                                        for human pose. Default is True.

        Note: `kpt_line=True` currently only supports human pose plotting.
        """
        shape = (im.shape[0],im.shape[1])
        annotator = Annotator(im=im)
        skeleton = annotator.skeleton 
        limb_color = annotator.limb_color
        kpt_color = annotator.kpt_color
        colors = Colors()
        for kpt,kpt_score in zip(kpts,kpts_score):

            nkpt, ndim = kpt.shape
            is_pose = nkpt == 17 and ndim == 3
            for i, k in enumerate(kpt):
                color_k = [int(x) for x in kpt_color[i]] if is_pose else colors(i)
                x_coord, y_coord = k[0], k[1]
                if x_coord % shape[1] != 0 and y_coord % shape[0] != 0:
                    conf = kpt_score[i]
                    if conf < 0.5:
                        continue
                    cv2.circle(im, (int(x_coord), int(y_coord)), radius, color_k, -1, lineType=cv2.LINE_AA)

            if kpt_line:
                ndim = kpt.shape[-1]
                for i, sk in enumerate(skeleton):
                    pos1 = (int(kpt[(sk[0] - 1), 0]), int(kpt[(sk[0] - 1), 1]))
                    pos2 = (int(kpt[(sk[1] - 1), 0]), int(kpt[(sk[1] - 1), 1]))
                    conf1 = kpt_score[(sk[0] - 1)]
                    conf2 = kpt_score[(sk[1] - 1)]
                    if conf1 < 0.5 or conf2 < 0.5:
                        continue
                    if pos1[0] % shape[1] == 0 or pos1[1] % shape[0] == 0 or pos1[0] < 0 or pos1[1] < 0:
                        continue
                    if pos2[0] % shape[1] == 0 or pos2[1] % shape[0] == 0 or pos2[0] < 0 or pos2[1] < 0:
                        continue
                    cv2.line(im, pos1, pos2, [int(x) for x in limb_color[i]], thickness=3, lineType=cv2.LINE_AA)

    def visualize_detections(self, frame, classes, scores, bboxes,faces,keypoints,keypoints_score):
        self.visualize_box(frame, classes, scores, bboxes,faces)
        if self.draw_kpts:
            self.visualize_kpts(frame,keypoints,keypoints_score,kpt_line=self.draw_kpts_line)

class Detector:

    def __init__(self, chk_path, conf_threshold, visualize, names):
        self.chk_path = chk_path
        self.conf_threshold = conf_threshold
        self.visualize = visualize
        self.names = names
        rng = np.random.default_rng()
        self.class_colors = [rng.integers(low=0, high=255, size=3, dtype=np.uint8).tolist() for _ in self.names]
        self.load_detector()
        
    def load_detector(self):
        self.model = YoloDetector(model=self.chk_path, conf=self.conf_threshold)
                    
    def detect(self, frame):
        results = self.model.predict(source=frame)[0]
        detections = results.boxes.cpu().numpy()
        classes = detections.cls
        scores = detections.conf
        bboxes = detections.xyxy
        return classes, scores, bboxes, None, None

    def visualize_box(self, frame, class_ids, scores, boxes,  thickness= 2):

        for cid, score, box in zip(class_ids, scores, boxes):
                cid = int(cid)
                x1, y1, x2, y2 = box
                x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2) 
                cv2.putText(frame,self.names[int(cid)], (x1, y1), cv2.FONT_HERSHEY_SIMPLEX, 1, self.class_colors[int(cid)],
                            thickness, cv2.LINE_AA)
                cv2.rectangle(frame, (x1, y1), (x2, y2), self.class_colors[int(cid)], thickness)

                det = frame[y1:y2, x1:x2]
                det_mask = np.ones(det.shape, dtype=np.uint8) * np.uint8(self.class_colors[cid])
                res = cv2.addWeighted(det, 0.6, det_mask, 0.4, 1.0)
                frame[y1:y2, x1:x2] = res    

    def visualize_detections(self, frame, classes, scores, bboxes, arg = None, arg2 =  None):
        self.visualize_box(frame, classes, scores, bboxes)







