import cv2 
import numpy as np 
from seg import Segmenter
from functools import reduce
import os 

# if __name__ == '__main__':
        
    # seg = Segmenter("./yolov8x-seg.pt")
    # folder_path = '../data/train/real'
    # dest_path = '../segmented data/train/real'
    # images_paths = os.listdir(folder_path) 
    # for path in images_paths:
    #     try:
    #         img_path = os.path.join(folder_path, path)
    #         img = cv2.imread(img_path)
    #         res = seg.detect(img)
    #         ims =  [i.masks.data[0].cpu().numpy()*255 for i in res if i.boxes.cls== 0]
    #         mask = reduce(lambda img1, img2: cv2.bitwise_or(img1, img2), ims)
    #         mask = cv2.resize(mask, (img.shape[1], img.shape[0]))
    #         # cv2.imshow('img', mask)
    #         # cv2.waitKey(0)
    #         # cv2.destroyAllWindows()
    #         cv2.imwrite(os.path.join(dest_path, path), mask)
    #     except:
    #         print('Error..')
        # print(img.shape, mask.shape)
        
    
    
    
    
    
    
    
    
    
    
    
    # img_path = '../../fake_ids_photoshop2/test.jpeg'
    # background_path = '../../fake_ids_photoshop2/BACKGROUND.jpeg'    # Replace with the path to your mask image
    # img = cv2.imread(img_path)
    # background = cv2.imread(background_path)
    # img = cv2.resize(img,(background.shape[0], background.shape[1])) 
    
    # # res = seg.detect(img)
    # # ims =  [i.masks.data[0].cpu().numpy()*255 for i in res if i.boxes.cls== 0]
    # # mask = reduce(lambda img1, img2: cv2.bitwise_or(img1, img2), ims)
    # # mask = cv2.resize(mask, (background.shape[0], background.shape[1]))
    # mask = cv2.imread('../../fake_ids_photoshop2/mask.jpg')
    # mask = cv2.cvtColor(mask, cv2.COLOR_BGR2GRAY)
    # mask = cv2.resize(mask, (background.shape[0], background.shape[1]))
    # mask = np.where(mask> 250 , 1, 0)
    # # mask = mask.astype('uint8')
    # mask = cv2.convertScaleAbs(mask)
    # # img = img.astype('uint8')
    # # print(mask.shape, img.shape)

    # person = cv2.bitwise_and(img, img, mask = mask)
    
    # cv2.imshow('img', person)
    # cv2.waitKey(0)
    # cv2.destroyAllWindows()


    # # Resize the person image to fit the desired location on the background
    # height, width, _ = person.shape
    # person = cv2.resize(person, (background.shape[1], background.shape[0]))

    # # Create a mask for the person image
    # person_gray = cv2.cvtColor(person, cv2.COLOR_BGR2GRAY)
    # _, person_mask = cv2.threshold(person_gray, 1, 255, cv2.THRESH_BINARY)

    # # Invert the mask (to make the person area white)
    # person_mask_inv = cv2.bitwise_not(person_mask)

    # # Extract the person from the person image using the mask
    # background_roi = cv2.bitwise_and(background, background, mask=person_mask_inv)
    # person = cv2.bitwise_and(person, person, mask=person_mask)

    # # Combine the person and background
    # result = cv2.add(background_roi, person)

    # # Update the background with the combined result
    # # background = result

    # # Save or display the final image
    # # cv2.imwrite('result.jpg', background)
    # cv2.imshow('Result', result)
    # cv2.waitKey(0)
    # cv2.destroyAllWindows()

