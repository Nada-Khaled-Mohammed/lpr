import cv2
import random
import numpy as np
import matplotlib.pylab as plt
from PIL import Image, ImageDraw, ImageFont, ImageOps
import os
import imutils
import gc


class LinesGenerator():
    def __init__(self, assets_path='../../assets', width=384, height=512, booleans=None):
        self.booleans = booleans
        self.image_dataset_path = os.path.join(assets_path, 'images_bg')
        self.image_mosawer_path = os.path.join(assets_path, "Mosawer",'images_mosawer')
        self.titles_mosawer_path = os.path.join(assets_path, "Mosawer",'titles')
        self.width_original = width
        self.height_original = height
        self.image_filenames = os.listdir(self.image_dataset_path)
        self.image_mosawer_filenames = os.listdir(self.image_mosawer_path)
        self.titles_mosawer_filenames = os.listdir(self.titles_mosawer_path)
        # self.width = 1200
        # self.height = 2000
        arabic_fonts_dir = os.path.join(assets_path, "Arabic_Fonts")
        arabic_fonts_large_text_dir = os.path.join(assets_path, "Large_Fonts")
        english_fonts_dir = os.path.join(assets_path, "English_Fonts")
        # self.arabic_letters = "ءآأؤإئابةتثجحخدذرزسشصضطظعغفقكلمنهوىي"
        self.arabic_letters = ['آ', 'أ', 'ؤ', 'إ', 'ا', 'ب', 'ت', 'ث', 'ج', 'ح', 'خ', 'د', 'ذ', 'ر', 'ز',
                               'س', 'ش', 'ص', 'ض', 'ط', 'ظ', 'ع', 'غ', 'ف', 'ق', 'ك', 'ل', 'م', 'ن', 'ه', 'و', 'ي',
                               'ـــ', "ــــــ"]
        # self.arabic_letters = ['ء', 'آ', 'أ', 'ؤ', 'إ', 'ئ', 'ا', 'ب', 'ة', 'ت', 'ث', 'ج', 'ح', 'خ', 'د', 'ذ', 'ر', 'ز',
        #                        'س', 'ش', 'ص', 'ض', 'ط', 'ظ', 'ع', 'غ', 'ف', 'ق', 'ك', 'ل', 'م', 'ن', 'ه', 'و', 'ى', 'ي']
        self.arabic_ending_letters = ['ء', 'ى', 'ة', 'ئ']
        self.arabic_punctuation = ['؟', '؛', '،', '، ،', '(', ')', '_', ' ', '!', ' . . ', ' .. ', '...', '.', '.!',
                                   ' . ', '?', ':',
                                   '-', '...............', '...............   ...............', '..', '.. ..']
        # '٪' '_'
        # self.english_punctuation = ['%', ',', '@', '$', '&', '?', ';', "'", '^', ':-']

        # self.general_punctuation = ['!', '-', '.', '/', ':', '..', '*', '+', '×', '÷', '=']

        # self.any_punctuation = ['؟', '؛', '،', 'ـ', '%', ',', '@', '$', '&', '?', ';', "'", '^', ':-', '!', '-', '.', '/',
        #                    ':', '..', '*', '+', '×', '÷', '=']

        self.english_letters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q',
                                'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
        self.text_only_list = ['31.ttf', '35.ttf', "alfont_com_AlFont_com_BJadidBold.ttf",
                               "alfont_com_Sp_Jadid-Bold_p30download.com_.ttf", "ArbFONTS-B-Jadid-Bold.ttf",
                               "Sp_Maryam-Bold_p30download.com_.ttf", "Sp_Jadid-Bold_p30download.com_.ttf"]
        self.arabic_numbers = "١٢٣٤٥٦٧٨٩٠٠٠٠٠"
        self.english_numbers = "1234567890"
        self.arabic_fonts_path = []
        for font in os.listdir(arabic_fonts_dir):
            self.arabic_fonts_path.append(os.path.join(arabic_fonts_dir, font))
        self.arabic_fonts_large_text_path = []
        for font in os.listdir(arabic_fonts_large_text_dir):
            self.arabic_fonts_large_text_path.append(os.path.join(arabic_fonts_large_text_dir, font))
        self.english_fonts_path = []
        for font in os.listdir(english_fonts_dir):
            self.english_fonts_path.append(os.path.join(english_fonts_dir, font))
        # self.arabic_lines, self.english_lines = self.create_words_and_lines()

    def set_booleans_for_cell(self):
        '''
        Set Booleans values for each cell
        :return:
        '''
        if self.booleans["make_rotation_in_page"]:
            self.booleans["rotate_cell"] = random.choices([True, False], k=1, weights=[0.4, 0.6])[0]

        if self.booleans["put_frame_around_lines_in_page"]:
            self.booleans["put_frame_around_whole_cell"] = random.choice([True, False])
            self.booleans["random_text_lines_in_cell_in_frame"] = random.choice([True, False])
        else:
            self.booleans["put_frame_around_whole_cell"] = False
            self.booleans["random_text_lines_in_cell_in_frame"] = False

        if self.booleans["put_image_in_page"]:
            self.booleans["cell_is_image"] = random.choices([True, False], k=1, weights=[0.2, 0.8])[0]

        if self.booleans["put_inverted_text_in_page"]:
            self.booleans["random_text_lines_in_cell_are_inverted"] = random.choice([True, False])
            self.booleans["cell_is_inverted"] = random.choice([True, False])
        else:
            self.booleans["cell_is_inverted"] = False
            self.booleans["random_text_lines_in_cell_are_inverted"] = False

        if self.booleans["background_main_page_is_image"]:
            self.booleans["background_cell_is_image"] = False
        else:
            self.booleans["background_cell_is_image"] = random.choices([True, False], k=1, weights=[0.2, 0.8])[0]
        if self.booleans["put_english_in_page"]:
            self.booleans["all_tex_lines_in_cell_are_english"] = random.choices([True, False], k=1, weights=[0.2, 0.8])[
                0]
        else:
            self.booleans["all_tex_lines_in_cell_are_english"] = False
        self.booleans["all_lines_same_width"] = random.choice([True, False])
        if self.booleans["put_large_text"]:
            self.booleans["large_text_in_cell"] = random.choices([True, False], k=1, weights=[0.2, 0.8])[0]
        else:
            self.booleans["large_text_in_cell"] = False

        if self.booleans["put_vertical_text_line"]:
            self.booleans["vertical_text_line_in_cell"] = random.choices([True, False], k=1, weights=[0.2, 0.8])[0]
        else:
            self.booleans["vertical_text_line_in_cell"] = False

    def set_colors(self):
        '''
        Set colors for whole page
        :return:
        '''
        self.colors = {}
        self.colors["color_text"] = random.randint(0, 50)
        self.colors["color_main"] = random.randint(127, 256)
        self.colors["color_text_old"] = self.colors["color_text"]

    def create_line(self, font, width, put_more_spaces, put_numbers, line_len):
        '''
        Create arabic text line
        :param font:
        :param width:
        :param put_more_spaces:
        :param put_numbers:
        :param line_len:
        :return: line
        '''
        # numbers_only = random.choices([True, False], k=1, weights=[0.3, 0.7])[0]
        numbers_only = False
        if numbers_only:
            line_len = random.randint(1, 16)
            numbers = random.choices(self.arabic_numbers, k=line_len)
            line = "".join(numbers)
            return line

        if put_numbers:
            put_numbers_english = random.choices([True, False], k=1, weights=[0.2, 0.8])[0]
        else:
            put_numbers_english = False
        # line_len = random.randint(1, 10)
        line = []
        line_w = 0
        for i in range(line_len):
            put_punc = random.choices([True, False], k=1, weights=[0.2, 0.8])[0]
            word_len = random.randint(2, 6)
            word = ''.join(random.choices(self.arabic_letters, k=word_len))
            put_end_letter = random.choice([True, False])
            if put_end_letter:
                word = word + (random.choice(self.arabic_ending_letters))
            line_w += font.getsize(word)[0]
            if line_w > width - 5:
                if i == 0:
                    if word_len // 2 < 2:
                        word = ''.join(random.choices(self.arabic_letters, k=2))
                    else:
                        word = ''.join(random.choices(self.arabic_letters, k=word_len // 2))
                    # reshaped_text = arabic_reshaper.reshape(word)
                    # word = get_display(reshaped_text)
                    return word
                break
            # reshaped_text = arabic_reshaper.reshape(word)
            # word = get_display(reshaped_text)
            line.append(word)
            if put_punc:
                char = random.choices(self.arabic_punctuation, k=1)[0]
                line.append(char)
        if put_numbers:
            number = random.choices(self.arabic_numbers, k=random.randint(1, 4))
            number = "".join(number)
            line.append(number)
        elif put_numbers_english:
            number = random.choices(self.english_numbers, k=random.randint(1, 4))
            number = "".join(number)
            line.append(number)
        new_line = []
        if put_more_spaces:
            for i in range(len(line)):
                if i == len(line) - 1:
                    new_line.append(line[i])
                    break
                spaces = random.choice(["   ", "     "])
                new_line.append(line[i])
                new_line.append(spaces)
            line = "".join(new_line)
        else:
            line = " ".join(line)
        return line

    def create_line_english(self, font, width, line_len):
        '''
        Create english text line
        :param font:
        :param width:
        :param line_len:
        :return:
        '''
        # numbers_only = random.choices([True, False], k=1, weights=[0.3, 0.7])[0]
        numbers_only = False
        if numbers_only:
            line_len = random.randint(1, 10)
            numbers = random.choices(self.english_numbers, k=line_len)
            line = "".join(numbers)
            return line

        put_numbers = random.choice([True, False])
        # line_len = random.randint(1, 10)
        line = []
        line_w = 0
        for i in range(line_len):
            word_len = random.randint(2, 6)
            word = ''.join(random.choices(self.english_letters, k=word_len))
            line_w += font.getsize(word)[0]
            if line_w > width - 5:
                if i == 0:
                    if word_len // 2 < 2:
                        word = ''.join(random.choices(self.english_letters, k=2))
                    else:
                        word = ''.join(random.choices(self.english_letters, k=word_len // 2))
                    return word
                break
            line.append(word)
        if put_numbers:
            number = random.choices(self.english_numbers, k=random.randint(1, 4))
            number = "".join(number)
            line.append(number)
        line = " ".join(line)
        return line

    def put_text_line_below_image(self, width_sub_image, height_sub_image, image):
        '''
        Put small text line below images (description)
        :param width_sub_image:
        :param height_sub_image:
        :param image:
        :return: [width_sub_image, height_sub_image], result_image_final, image_black_new
        '''
        font_size = random.randint(20, 30)
        arabic_font_path = random.choice(self.arabic_fonts_path)
        font_type = ImageFont.truetype(arabic_font_path, font_size)
        line_len = random.randint(2, int(width_sub_image // 4))
        line = self.create_line(font_type, width_sub_image, False, put_numbers=False, line_len=line_len)
        text_size = font_type.getsize(line)
        width_line = text_size[0]
        x1_new = (width_sub_image // 2) - (width_line // 2)
        # region generate new image
        w_h = (width_sub_image, text_size[1])
        image_new = Image.new('L', w_h, self.colors["color_main"])
        image_black_new = np.zeros((height_sub_image + text_size[1], width_sub_image), dtype='uint8')
        image_draw = ImageDraw.Draw(image_new)
        # endregion
        y1_box = height_sub_image
        box_text = image_draw.textbbox((x1_new, y1_box), line, font=font_type, anchor="lt")

        box_rectangle_seg_map = [x1_new - 2, box_text[1], box_text[2] + 4, box_text[3]]

        y_line = box_rectangle_seg_map[1] + (
                box_rectangle_seg_map[3] - box_rectangle_seg_map[1]) // 2  # keda el y f nos el box
        height_line_seg_map = int((box_rectangle_seg_map[3] - box_rectangle_seg_map[1]) * 0.8)
        y_line = y_line - int(height_line_seg_map // 2)  # keda el y bdaytha 3nd 10%
        for height_count in range(height_line_seg_map):
            cv2.line(image_black_new, (box_rectangle_seg_map[0], y_line + height_count),
                     (box_rectangle_seg_map[2], y_line + height_count), 255, 1)
        image_draw.text((x1_new, 0), line, fill=0, font=font_type, anchor="lt")

        result_image_final = np.ones((height_sub_image + text_size[1], width_sub_image), dtype='uint8') * \
                             self.colors["color_main"]
        result_image_final[0:height_sub_image, 0:width_sub_image] = image
        result_image_final[height_sub_image:, 0:width_sub_image] = image_new
        result_image_final = cv2.resize(result_image_final, (width_sub_image, height_sub_image),
                                        interpolation=cv2.INTER_AREA)
        image_black_new = cv2.resize(image_black_new, (width_sub_image, height_sub_image),
                                     interpolation=cv2.INTER_AREA)
        return [width_sub_image, height_sub_image], result_image_final, image_black_new

    def put_image(self, width_sub_image, height_sub_image):
        '''
        Put image on cell
        :param width_sub_image:
        :param height_sub_image:
        :return:
        '''
        put_line_below_image = random.choice([True, False])
        image_file = random.choice(self.image_mosawer_filenames)
        image_path = os.path.join(self.image_mosawer_path, image_file)
        image = Image.open(image_path)
        image = image.resize((width_sub_image, height_sub_image))
        image = ImageOps.grayscale(image)
        image_black = np.zeros((height_sub_image, width_sub_image), dtype='uint8')
        right = 2
        left = 2
        top = 2
        bottom = 2
        new_width = width_sub_image + right + left
        new_height = height_sub_image + top + bottom
        result_image = np.ones((new_height, new_width), dtype='uint8') * self.colors["color_main"]
        result_image[top:new_height - bottom, left:new_width - right] = image
        result_image = cv2.resize(result_image, (width_sub_image, height_sub_image), interpolation=cv2.INTER_AREA)
        # region put text below image (like description in mosawer), can edit to be more than one text line
        if put_line_below_image:
            [width_sub_image, height_sub_image], result_image_final, image_black_new = self.put_text_line_below_image(width_sub_image, height_sub_image, image)
            return [width_sub_image, height_sub_image], result_image_final, image_black_new
        # endregion
        return [width_sub_image, height_sub_image], result_image, image_black

    def get_line(self, fixed_line_len, width, english_font, arabic_font, arabic_font_path):
        '''
        Chcek booleans and decide to create line english or arabic based on booleans and return it with font chose
        :param fixed_line_len: if we want the paragraph with same line width
        :param width: the width of sub image (cell)
        :param english_font:
        :param arabic_font:
        :param arabic_font_path:
        :return: created line, font type
        '''
        # region define font type depend on language and create line
        if self.booleans["all_lines_same_width"]:
            line_len = fixed_line_len
        else:
            line_len = random.randint(1, width // 4)
        if self.booleans["put_english_in_page"]:
            if self.booleans["all_tex_lines_in_cell_are_english"]:
                create_english_line = True
            else:
                create_english_line = random.choice([True, False])
            if create_english_line:
                line = self.create_line_english(english_font, width, line_len)
                font_type = english_font
            else:
                if os.path.split(arabic_font_path)[-1] in self.text_only_list:
                    line = self.create_line(arabic_font, width, self.booleans["one_column_more_spaces"],
                                            put_numbers=False, line_len=line_len)
                else:
                    put_numbers = random.choices([True, False], k=1, weights=[0.1, 0.9])[0]
                    line = self.create_line(arabic_font, width, self.booleans["one_column_more_spaces"],
                                            put_numbers=put_numbers, line_len=line_len)
                font_type = arabic_font
        else:
            if os.path.split(arabic_font_path)[-1] in self.text_only_list:
                line = self.create_line(arabic_font, width, self.booleans["one_column_more_spaces"], put_numbers=False,
                                        line_len=line_len)
            else:
                put_numbers = random.choices([True, False], k=1, weights=[0.1, 0.9])[0]
                line = self.create_line(arabic_font, width, self.booleans["one_column_more_spaces"],
                                        put_numbers=put_numbers, line_len=line_len)
            font_type = arabic_font
        return line, font_type
        # endregion

    def put_text_rtl(self, text_size, vertical_done, w_h, image_draw, image_black, y1_box, line,
                     font_type, make_narrow_spaces, make_more_spaces_between_text,
                     image_vertical_crop=None):
        '''
        Put text right to left alignment

        Note that vertical text line put with right to left alignment only
        :param text_size: size of created text line
        :param vertical_done: boolean to check if we putted vertical line and if so start to write text after it
        :param w_h: width and height of subimage
        :param image_draw: image to draw text on it
        :param image_black: segmentation map
        :param y1_box: y of start line to be drawn on image_draw
        :param line: created text line
        :param font_type: chose font type
        :param make_narrow_spaces: boolean to put narrow spaces between text lines or not
        :param make_more_spaces_between_text: boolean to put more spaces between text lines or not
        :param image_vertical_crop: if we putted vertical text line, pass this vertical image, default is none
        :return: image_draw, image_black, y1_box (new start y of next line)
        '''
        height = w_h[1]
        width_line = text_size[0]
        if vertical_done:
            x = w_h[0] - width_line - 4 - image_vertical_crop.shape[1]
        # elif put_small_title_behind_text and not put_small_title_behind_text_done:
        #     put_small_title_behind_text_done = True
        #     self.generate_small_title_behind_text(text_size, w_h, image_draw, y1_box, booleans, color_text, image,image_black,
        #                          fixed_line_len, english_font, arabic_font,arabic_font_path, color_main)
        else:
            x = w_h[0] - width_line - 4
        box_text = image_draw.textbbox((x, y1_box), line, font=font_type, anchor="lt")

        box_rectangle_seg_map = [box_text[0] - 2, box_text[1], box_text[2] + 4, box_text[3]]
        box_rounded_rectangle = [box_text[0] - 2, box_text[1] - 2,
                                 box_text[2] + 4, box_text[3] + 2]

        # cv2.rectangle(image_black, (box_rectangle_seg_map[0], box_rectangle_seg_map[1]),
        #               (box_rectangle_seg_map[2], box_rectangle_seg_map[3]), 255, -1)
        # cv2.rectangle(image_black, (box_rounded_rectangle[0], box_rounded_rectangle[1]),
        #               (box_rounded_rectangle[2], box_rounded_rectangle[3]), 0, 2)
        y_line = box_rectangle_seg_map[1] + (
                box_rectangle_seg_map[3] - box_rectangle_seg_map[1]) // 2  # keda el y f nos el box
        height_line_seg_map = int((box_rectangle_seg_map[3] - box_rectangle_seg_map[1]) * 0.8)
        y_line = y_line - int(height_line_seg_map // 2)  # keda el y bdaytha 3nd 10%
        for height_count in range(height_line_seg_map):
            cv2.line(image_black, (box_rectangle_seg_map[0], y_line + height_count),
                     (box_rectangle_seg_map[2], y_line + height_count),
                     255,
                     1)
        # cv2.rectangle(image_black,(x,y1_box),(x+width_line,y2_box),0,1)

        # image_draw.rectangle(box_rectangle_seg_map, fill="gray")
        # image_draw.rounded_rectangle(box_rounded_rectangle, outline="white", width=2)
        fill, image_draw = self.get_fill_color(box_rectangle_seg_map, image_draw)

        if self.booleans["random_text_lines_in_cell_in_frame"]:
            put_frame = random.choice([True, False])
            # fill = self.colors["color_text"]
            if put_frame:
                if (x + width_line + 4) >= w_h[0]:
                    if box_text[3] + 2 >= height:
                        self.draw_four_lines(image_draw, box_text[0] - 2, box_text[1] - 1, w_h[0] - 1,
                                             height - 1)
                    else:
                        self.draw_four_lines(image_draw, box_text[0] - 2, box_text[1] - 1, w_h[0] - 1,
                                             box_text[3] + 1)
                else:
                    if box_text[3] + 2 >= height:
                        self.draw_four_lines(image_draw, box_text[0] - 2, box_text[1] - 1,
                                             box_text[2] + 3, height - 1)
                    else:
                        self.draw_four_lines(image_draw, box_text[0] - 2, box_text[1] - 1,
                                             box_text[2] + 4, box_text[3] + 1)

        image_draw.text((x, y1_box), line, fill=fill, font=font_type, anchor="lt")
        if make_narrow_spaces:
            y1_box = box_rounded_rectangle[3] - 2
        elif make_more_spaces_between_text:
            y1_box = box_rounded_rectangle[3] + 10
        else:
            y1_box = box_rounded_rectangle[3] + 2
        return image_draw, image_black, y1_box

    def put_text_ltr(self, text_size, w_h, image_draw, image_black, line, font_type, y1_box,
                     make_narrow_spaces, make_more_spaces_between_text, ):
        '''
        Put text left to right alignment

        :param text_size: size of created text line
        :param w_h: width and height of subimage
        :param image_draw: image to draw text on it
        :param image_black: segmentation map
        :param line: created text line
        :param font_type: chose font type
        :param y1_box: y of start line to be drawn on image_draw
        :param make_narrow_spaces: boolean to put narrow spaces between text lines or not
        :param make_more_spaces_between_text: boolean to put more spaces between text lines or not
        :return: image_draw, image_black, y1_box (new start y of next line)
        '''
        x = 2
        height = w_h[1]
        width_line = text_size[0]

        box_text = image_draw.textbbox((x, y1_box), line, font=font_type, anchor="lt")

        box_rectangle_seg_map = [x - 2, box_text[1], box_text[2] + 4, box_text[3]]
        box_rounded_rectangle = [x - 2, box_text[1] - 2,
                                 box_text[2] + 4, box_text[3] + 2]

        # cv2.rectangle(image_black, (box_rectangle_seg_map[0], box_rectangle_seg_map[1]),
        #               (box_rectangle_seg_map[2], box_rectangle_seg_map[3]), 255, -1)
        # cv2.rectangle(image_black, (box_rounded_rectangle[0], box_rounded_rectangle[1]),
        #               (box_rounded_rectangle[2], box_rounded_rectangle[3]), 0, 2)
        y_line = box_rectangle_seg_map[1] + (
                box_rectangle_seg_map[3] - box_rectangle_seg_map[1]) // 2  # keda el y f nos el box
        height_line_seg_map = int((box_rectangle_seg_map[3] - box_rectangle_seg_map[1]) * 0.8)
        y_line = y_line - int(height_line_seg_map // 2)  # keda el y bdaytha 3nd 10%
        for height_count in range(height_line_seg_map):
            cv2.line(image_black, (box_rectangle_seg_map[0], y_line + height_count),
                     (box_rectangle_seg_map[2], y_line + height_count),
                     255,
                     1)
        # cv2.rectangle(image_black,(x,y1_box),(x+width_line,y2_box),0,1)

        # overlay for test
        # image_draw.rectangle(box_rectangle_seg_map, fill="gray")
        # image_draw.rounded_rectangle(box_rounded_rectangle, outline="white", width=2)
        fill, image_draw = self.get_fill_color(box_rectangle_seg_map, image_draw)

        if self.booleans["random_text_lines_in_cell_in_frame"]:
            put_frame = random.choice([True, False])
            if put_frame:
                if (x + width_line + 4) >= w_h[0]:
                    if box_text[3] + 1 >= height:
                        self.draw_four_lines(image_draw, 0, box_text[1] - 1, w_h[0] - 1, height - 1)
                        # image_draw.rounded_rectangle([0, box_text[1] - 1, w_h[0] - 1, height - 1],
                        #                              outline="black", width=1)
                    else:
                        self.draw_four_lines(image_draw, 0, box_text[1] - 1, w_h[0] - 1, box_text[3] + 1)
                        # image_draw.rounded_rectangle([0, box_text[1] - 1, w_h[0] - 1, box_text[3] + 1],
                        #                              outline="black", width=1)
                else:
                    if box_text[3] + 1 >= height:
                        self.draw_four_lines(image_draw, 0, box_text[1] - 1, x + width_line + 4, height - 1)
                        # image_draw.rounded_rectangle([0, box_text[1] - 1, x + width_line + 4, height - 1],
                        #                              outline="black", width=1)
                    else:
                        self.draw_four_lines(image_draw, 0, box_text[1] - 1, x + width_line + 4,
                                             box_text[3] + 1)
                        # image_draw.rounded_rectangle([0, box_text[1] - 1, x + width_line + 4, box_text[3] + 1],
                        #                              outline="black", width=1)

        image_draw.text((x, y1_box), line, fill=fill, font=font_type, anchor="lt")
        if make_narrow_spaces:
            y1_box = box_rounded_rectangle[3] - 2
        elif make_more_spaces_between_text:
            y1_box = box_rounded_rectangle[3] + 10
        else:
            y1_box = box_rounded_rectangle[3] + 2
        return image_draw, image_black, y1_box

    def put_text_center(self, text_size, w_h, image_draw, image_black, line, font_type, y1_box,
                        make_narrow_spaces, make_more_spaces_between_text):
        '''
        Put text line center alignment

        :param text_size: size of created text line
        :param w_h: width and height of subimage
        :param image_draw: image to draw text on it
        :param image_black: segmentation map
        :param line: created text line
        :param font_type: chose font type
        :param y1_box: y of start line to be drawn on image_draw
        :param make_narrow_spaces: boolean to put narrow spaces between text lines or not
        :param make_more_spaces_between_text: boolean to put more spaces between text lines or not
        :return: image_draw, image_black, y1_box (new start y of next line)
        '''

        height = w_h[1]
        width_line = text_size[0]
        x1_new = (w_h[0] // 2) - (width_line // 2)
        x2_new = (w_h[0] // 2) + (width_line // 2)
        # cv2.rectangle(image_black, (x1_new, y1_box), (x2_new , y2_box), 255, -1)

        box_text = image_draw.textbbox((x1_new, y1_box), line, font=font_type, anchor="lt")

        box_rectangle_seg_map = [x1_new - 2, box_text[1], box_text[2] + 4, box_text[3]]
        box_rounded_rectangle = [x1_new - 2, box_text[1] - 2,
                                 box_text[2] + 4, box_text[3] + 2]

        # cv2.rectangle(image_black, (box_rectangle_seg_map[0], box_rectangle_seg_map[1]),
        #               (box_rectangle_seg_map[2], box_rectangle_seg_map[3]), 255, -1)
        # cv2.rectangle(image_black, (box_rounded_rectangle[0], box_rounded_rectangle[1]),
        #               (box_rounded_rectangle[2], box_rounded_rectangle[3]), 0, 2)
        y_line = box_rectangle_seg_map[1] + (
                box_rectangle_seg_map[3] - box_rectangle_seg_map[1]) // 2  # keda el y f nos el box
        height_line_seg_map = int((box_rectangle_seg_map[3] - box_rectangle_seg_map[1]) * 0.8)
        y_line = y_line - int(height_line_seg_map // 2)  # keda el y bdaytha 3nd 10%
        for height_count in range(height_line_seg_map):
            cv2.line(image_black, (box_rectangle_seg_map[0], y_line + height_count),
                     (box_rectangle_seg_map[2], y_line + height_count),
                     255,
                     1)
        # cv2.rectangle(image_black,(x,y1_box),(x+width_line,y2_box),0,1)

        # overlay for test
        # image_draw.rectangle(box_rectangle_seg_map, fill="gray")
        # image_draw.rounded_rectangle(box_rounded_rectangle, outline="white", width=2)

        # image_black_draw.rectangle([x1_new, y1_box, x2_new, y2_box], fill="white")
        # image_black_draw.rounded_rectangle([x1_new, y1_box, x2_new, y2_box], outline="black", width=2)
        fill, image_draw = self.get_fill_color(box_rectangle_seg_map, image_draw)

        if self.booleans["random_text_lines_in_cell_in_frame"]:
            put_frame = random.choice([True, False])
            # fill = self.colors["color_text"]
            if put_frame:
                if (x2_new + 4) >= w_h[0]:
                    if box_text[3] + 1 >= height:
                        self.draw_four_lines(image_draw, x1_new - 2, box_text[1] - 1, w_h[0] - 1, height - 1)
                        # image_draw.rounded_rectangle([x1_new - 2, box_text[1] - 1, w_h[0] - 1, height - 1],
                        #                              outline="black", width=1)
                    else:
                        self.draw_four_lines(image_draw, x1_new - 2, box_text[1] - 1, w_h[0] - 1,
                                             box_text[3] + 1)
                        # image_draw.rounded_rectangle([x1_new - 2, box_text[1] - 1, w_h[0] - 1, box_text[3] + 1],
                        #                              outline="black", width=1)
                else:
                    if box_text[3] + 1 >= height:
                        self.draw_four_lines(image_draw, x1_new - 2, box_text[1] - 1, x2_new + 4, height - 1)
                        # image_draw.rounded_rectangle([x1_new - 2, box_text[1] - 1, x2_new + 4, height - 1],
                        #                              outline="black", width=1)
                    else:
                        self.draw_four_lines(image_draw, x1_new - 2, box_text[1] - 1, x2_new + 4,
                                             box_text[3] + 1)
                        # image_draw.rounded_rectangle([x1_new - 2, box_text[1] - 1, x2_new + 4, box_text[3] + 1],
                        #                              outline="black", width=1)

        # else:
        #     fill = self.colors["color_text"]
        image_draw.text((x1_new, y1_box), line, fill=fill, font=font_type, anchor="lt")
        if make_narrow_spaces:
            y1_box = box_rounded_rectangle[3] - 2
        elif make_more_spaces_between_text:
            y1_box = box_rounded_rectangle[3] + 10
        else:
            y1_box = box_rounded_rectangle[3] + 2
        return image_draw, image_black, y1_box

    def put_text_vertical(self, text_size, w_h, image_draw, image_black, line, font_type, y1_box, image_draw_vertical,
                          image_vertical, image):
        '''
        Put one vertical text line and not map it ( TODO: map it in segmentation map )
        :param text_size: size of created text line
        :param w_h: width and height of subimage
        :param image_draw: image to draw text on it
        :param image_black: segmentation map
        :param line: created text line
        :param font_type: chose font type
        :param y1_box: y of start line to be drawn on image_draw
        :param image_draw_vertical: created image_draw for vertical text
        :param image_vertical: created image for vertical text
        :param image: original subimage (cell)
        :return:
        '''

        width_line = text_size[0]
        x = w_h[0] - width_line - 4
        box_text = image_draw.textbbox((x, y1_box), line, font=font_type, anchor="lt")

        box_rectangle_seg_map = [box_text[0] - 2, box_text[1], box_text[2] + 4, box_text[3]]

        fill, image_draw = self.get_fill_color(box_rectangle_seg_map, image_draw)

        image_draw_vertical.text((x, y1_box), line, fill=fill, font=font_type, anchor="lt")

        image_vertical = np.array(image_vertical)
        image_vertical = imutils.rotate_bound(image_vertical, angle=90)
        image_vertical_crop = image_vertical[0:image_vertical.shape[0], image_vertical
                                                                        .shape[1] - text_size[1]:
                                                                        image_vertical.shape[1]]
        # image_vertical = cv2.resize(image_vertical,(box_text[3]-box_text[1],box_text[2]-box_text[0]), interpolation=cv2.INTER_AREA)
        image = np.array(image)
        image_vertical_crop = cv2.resize(image_vertical_crop, (image_vertical_crop.shape[1], image.shape[0]),
                                         interpolation=cv2.INTER_AREA)
        image[0:image_vertical_crop.shape[0],
        image.shape[1] - text_size[1]:image.shape[1]] = image_vertical_crop
        image = Image.fromarray(image)
        image_draw = ImageDraw.Draw(image)

        '''
        # add vertical line in segmentation map 
        # image_black_vertical = np.zeros_like(image_vertical)
        # cv2.rectangle(image_black_vertical, (box_rectangle_seg_map[0], box_rectangle_seg_map[1]),
        #               (box_rectangle_seg_map[2], box_rectangle_seg_map[3]), 255, -1)
        # image_black_vertical = imutils.rotate_bound(image_black_vertical, angle=90)
        # image_black_vertical_crop = image_black_vertical[0:image_black_vertical.shape[0], image_black_vertical
        #                                                                 .shape[1] - text_size[1]:
        #                                                                 image_black_vertical.shape[1]]
        # image_black_vertical_crop = cv2.resize(image_black_vertical_crop, (image_black_vertical_crop.shape[1], image_black.shape[0]),
        #                                  interpolation=cv2.INTER_AREA)
        # image_black[0:image_black_vertical_crop.shape[0],
        # image_black.shape[1] - text_size[1]:image_black.shape[1]] = image_black_vertical_crop
        '''
        # image.paste(Image.fromarray(image_vertical), box=(width-text_size[1],0))
        # plt.figure()
        # plt.imshow(image_vertical, cmap='gray', vmin=0, vmax=255)
        # plt.title('image_tmp_vertical')
        # plt.show()
        # plt.figure()
        # plt.imshow(image_vertical_crop, cmap='gray', vmin=0, vmax=255)
        # plt.title('image_tmp_vertical')
        # plt.show()
        # plt.figure()
        # plt.imshow(image, cmap='gray', vmin=0, vmax=255)
        # plt.title('image_tmp_vertical')
        # plt.show()
        return image_draw, image_black, image_vertical_crop, image

    # most important function
    # put text on parameter passed image
    # put line by line, draw.textbox get box for each line
    def put_text_on_sub_image(self, image, image_black, height, width, english_font, arabic_font,
                              direction, arabic_font_path, fixed_line_len=random.randint(1, 20),
                              put_title_done=False):
        '''
        Main function to put paragraph text, all lines in cell
        :param image: subimage
        :param image_black: segmentation map
        :param height: height of subimage
        :param width: width of subimage
        :param english_font:
        :param arabic_font:
        :param direction: alignment of text (rtl, ltr, center)
        :param arabic_font_path:
        :param fixed_line_len: if we want the paragraph with same line width
        :param put_title_done:
        :return:
        '''
        direction_original = direction
        image_draw = ImageDraw.Draw(image)
        image_vertical = image.copy()
        image_draw_vertical = ImageDraw.Draw(image_vertical)
        vertical_done = False
        # put_small_title_behind_text = True
        # put_small_title_behind_text_done = False
        if self.booleans["vertical_text_line_in_cell"]:
            # direction = random.choice([direction,"vertical"])
            direction = "vertical"
        y1_box = 0
        make_narrow_spaces = random.choice([True, False])
        make_more_spaces_between_text = random.choice([True, False])
        w_h = [width, height]
        # put_title_done = False
        # all_lines_same_width = random.choice([True, False])
        # all_lines_same_width = True
        # fixed_line_len = random.randint(3, 10)
        image_vertical_crop = None
        while True:
            # region define font type depend on language and create line
            line, font_type = self.get_line(fixed_line_len, width, english_font, arabic_font,
                                            arabic_font_path)
            # endregion

            put_title = random.choice([True, False])
            # put_title = random.choices([True, False],k=1,weights=[0.1,0.9])
            text_size = font_type.getsize(line)
            y2_box = y1_box + text_size[1]
            if put_title and not put_title_done:
                text_height = random.randint(text_size[1], text_size[1] + 30)
                y2_box = y1_box + text_height
            if y2_box > w_h[1]:
                break
            if put_title and not put_title_done:
                put_title_done = True
                image_title, image_black_title, width_title_image, height_title_image, x_title, y_title = \
                    self.make_title(width, text_height, y1_box)
                x_title_2 = x_title + width_title_image
                if vertical_done and direction_original == "rtl":
                    if width_title_image - image_vertical_crop.shape[1] - 4 > 0:
                        x_title_2 = (x_title + width_title_image) - 4 - image_vertical_crop.shape[1]
                        image_title = cv2.resize(image_title, (
                            width_title_image - 4 - image_vertical_crop.shape[1], height_title_image),
                                                 interpolation=cv2.INTER_AREA)
                        image_black_title = cv2.resize(image_black_title,
                                                       (width_title_image - 4 - image_vertical_crop.shape[1],
                                                        height_title_image),
                                                       interpolation=cv2.INTER_AREA)
                image.paste(Image.fromarray(image_title), [x_title, y_title, x_title_2, y_title + height_title_image])
                image_black[y_title:y_title + height_title_image, x_title:x_title_2] = image_black_title
                y1_box = y_title + height_title_image + 2
                continue
            if direction == "rtl":

                image_draw, image_black, y1_box = self.put_text_rtl(text_size, vertical_done, w_h,
                                                                    image_draw, image_black,
                                                                    y1_box, line, font_type, make_narrow_spaces,
                                                                    make_more_spaces_between_text, image_vertical_crop)
            elif direction == "ltr":
                image_draw, image_black, y1_box = self.put_text_ltr(text_size, w_h, image_draw, image_black,
                                                                    line, font_type, y1_box,
                                                                    make_narrow_spaces, make_more_spaces_between_text)
            elif direction == "center":
                image_draw, image_black, y1_box = self.put_text_center(text_size, w_h, image_draw, image_black,
                                                                       line, font_type, y1_box,
                                                                       make_narrow_spaces,
                                                                       make_more_spaces_between_text)
            elif direction == "vertical" and not vertical_done:
                vertical_done = True
                direction = direction_original
                if direction_original != "rtl":
                    continue
                image_draw, image_black, image_vertical_crop, image = self.put_text_vertical(text_size, w_h, image_draw,
                                                                                      image_black, line, font_type,
                                                                                      y1_box, image_draw_vertical,
                                                                                      image_vertical, image)
        return image, image_black

    def draw_four_lines(self, image_draw, x1, y1, x2, y2):
        '''
        Draw rounded rectangle around text box
        :param image_draw:
        :param x1:
        :param y1:
        :param x2:
        :param y2:
        :return:
        '''
        # image_draw.rounded_rectangle([x1, y1, x2, y1], outline="black", width=1)
        image_draw.line([x1, y1, x2, y1], width=1, fill="black")  # horizontal
        image_draw.line([x1, y2, x2, y2], width=1, fill="black")

        image_draw.line([x1, y1, x1, y2], width=1, fill="black")  # vertical
        image_draw.line([x2, y1, x2, y2], width=1, fill="black")

    def rotate_image(self, result_image, result_image_black, width_sub_image, height_sub_image, color):
        '''
        Rotate image with random angle between -30->30
        :param result_image:
        :param result_image_black:
        :param width_sub_image:
        :param height_sub_image:
        :param color:
        :return: rotated image, rotated segmentation map
        '''
        rotate_angle = random.randint(-30, 30)
        rotate_with_crop = random.choices([True, False], k=1, weights=[0.8, 0.2])[0]
        if rotate_with_crop:
            (h_rotate, w_rotate) = result_image.shape[:2]
            center = (w_rotate // 2, h_rotate // 2)
            M = cv2.getRotationMatrix2D(center, rotate_angle, 1.0)
            rotated_image = cv2.warpAffine(result_image, M, (w_rotate, h_rotate),
                                           flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT,
                                           borderValue=color)
            rotated_image_black = cv2.warpAffine(result_image_black, M, (w_rotate, h_rotate),
                                                 flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT,
                                                 borderValue=0)
        else:
            rotated_image = imutils.rotate_bound(result_image, angle=rotate_angle)
            rotated_image_black = imutils.rotate_bound(result_image_black, angle=rotate_angle)

        result_image = cv2.resize(rotated_image, (width_sub_image, height_sub_image),
                                  interpolation=cv2.INTER_AREA)

        result_image_black = cv2.resize(rotated_image_black, (width_sub_image, height_sub_image),
                                        interpolation=cv2.INTER_AREA)
        return result_image, result_image_black

    # the main function to generate text columns
    def generate_image_column_structure(self, new_width_main, new_height_main):
        '''
        Main function to create subimages (cells) and its features
        :param new_width_main: width of main page
        :param new_height_main: height of main page
        :return: image_main, image_black_main
        '''

        if self.booleans["background_main_page_is_image"]:
            self.colors["color_text"] = 0
        image_main = np.ones((new_height_main, new_width_main), dtype='uint8') * self.colors["color_main"]
        image_black_main = np.zeros((new_height_main, new_width_main), dtype='uint8')
        x_start = 1
        y_start = 1
        y_title = 1

        # region put title
        # make_title = random.choice([True, False])
        make_title = True
        put_second_title = random.choice([True, False])
        # put_second_title = True
        if make_title:
            image, image_black, width, height, x, y = self.make_title(new_width_main, new_height_main, y_start)
            image_main[y:y + height, x:x + width] = image
            image_black_main[y:y + height, x:x + width] = image_black
            y_start += y + height
            y_title += y + height
            if put_second_title:
                image, image_black, width, height, x, y = self.make_title(new_width_main, new_height_main, y_start)
                if y >= new_height_main:
                    return image_main, image_black_main
                if y + height > new_height_main:
                    image = cv2.resize(image, (width, new_height_main - y), interpolation=cv2.INTER_AREA)
                    image_black = cv2.resize(image_black, (width, new_height_main - y), interpolation=cv2.INTER_AREA)
                    height = image_black.shape[0]
                    image_main[y:y + height, x:x + width] = image
                    image_black_main[y:y + height, x:x + width] = image_black
                    return image_main, image_black_main
                image_main[y:y + height, x:x + width] = image
                image_black_main[y:y + height, x:x + width] = image_black
                y_start = y + height
                # y_title = y + height

        # endregion

        # region define fixed font type and size and text direction for all columns.
        # font_size = random.randint(8, 30)
        font_size = random.randint(int(new_width_main * 0.01), int(new_width_main * 0.03))
        arabic_font_path = random.choice(self.arabic_fonts_path)
        arabic_font = ImageFont.truetype(arabic_font_path, font_size)
        english_font_path = random.choice(self.english_fonts_path)
        english_font = ImageFont.truetype(english_font_path, font_size)
        direction = random.choice(["rtl", "ltr", "center"])
        # endregion

        # region define columns and rows numbers
        # if new_width_main * 0.003 < 1:
        #     col_slices = 1
        # else:
        #     try:
        #         col_slices = random.randint(1, int(new_width_main * 0.003))
        #     except:
        #         col_slices = 1
        # if new_height_main * 0.003 < 1:
        #     row_slices = 1
        # else:
        #     row_slices = random.randint(1, int(new_height_main * 0.003))
        # col_slices = 1
        # row_slices = 1
        col_slices = random.randint(1, 5)
        row_slices = random.randint(1, 5)
        # endregion

        width_sub_image = (new_width_main - x_start) // col_slices
        height_sub_image = (new_height_main - y_start) // row_slices
        if height_sub_image == 0 or width_sub_image == 0:
            return image_main, image_black_main
        if y_start > new_height_main:
            row_slices = 0
        all_widths = []
        rotate_segment_done = 0

        for i in range(row_slices):
            while True:
                # region define booleans
                self.set_booleans_for_cell()
                # endregion

                # region generate new sub image
                w_h = (width_sub_image, height_sub_image)
                if self.booleans["random_text_lines_in_cell_are_inverted"] and self.booleans["cell_is_inverted"]:
                    color = 0
                else:
                    color = self.colors["color_main"]
                if self.booleans["background_cell_is_image"] or self.booleans["background_main_page_is_image"]:
                    image = Image.new("RGBA", w_h, (color, color, color, 1))
                else:
                    image = Image.new('L', w_h, color)
                image_black = np.zeros((w_h[1], w_h[0]), dtype='uint8')
                # endregion

                # region if this cell is picture on the sub image, create image and continue
                if self.booleans["cell_is_image"]:
                    w_h, result_image, image_black = self.put_image(width_sub_image,
                                                                    height_sub_image)

                    # self.booleans["put_image_in_page"] = random.choice([True, False])
                    self.booleans["cell_is_image"] = False
                    if x_start + w_h[0] > new_width_main:
                        break
                    image_main[y_start:y_start + w_h[1], x_start:x_start + w_h[0]] = result_image
                    image_black_main[y_start:y_start + w_h[1], x_start:x_start + w_h[0]] = image_black
                    x_start = x_start + w_h[0]
                    all_widths.append(w_h[0])
                    continue
                # endregion

                # region generate structure "text between two columns"
                text_between_two_columns = random.choices([True, False], k=1, weights=[0.3, 0.7])[0]
                if self.booleans["all_page_is_titels_font"]:
                    self.booleans["large_text_in_cell"] = True
                if self.booleans["large_text_in_cell"]:
                    self.booleans["all_tex_lines_in_cell_are_english"] = False
                    # font_size_large = random.randint(20, 80)
                    font_size_large = random.randint(int(new_width_main * 0.02), int(new_width_main * 0.08))
                    arabic_font_path_large = random.choice(self.arabic_fonts_large_text_path)
                    arabic_font_large = ImageFont.truetype(arabic_font_path_large, font_size_large)
                    english_font_large = ImageFont.truetype(english_font_path, font_size_large)
                    image, image_black = self.put_text_on_sub_image(image, image_black, height_sub_image,
                                                                    width_sub_image,
                                                                    english_font_large, arabic_font_large,
                                                                    direction,
                                                                    arabic_font_path_large)
                elif text_between_two_columns:
                    self.booleans["all_tex_lines_in_cell_are_english"] = False
                    self.booleans["all_lines_same_width"] = True
                    image, image_black = self.generate_text_between_two_columns(width_sub_image, height_sub_image)
                # endregion

                # region put text on subimage
                else:
                    image, image_black = self.put_text_on_sub_image(image, image_black, height_sub_image,
                                                                    width_sub_image,
                                                                    english_font, arabic_font,
                                                                    direction, arabic_font_path)
                # endregion

                # region special case for putting subimage on main page
                # check if y2 of sub image is greater than height of main image, if greater -> resize to be fit in main image
                if y_start + w_h[1] > new_height_main:
                    # box = [x_start, y_start, x_start + w_h[0],new_height-1]
                    if x_start + w_h[0] > new_width_main:
                        break
                    image = image.resize((w_h[0], new_height_main - 1 - y_start))
                    image_black = image_black.resize((w_h[0], new_height_main - 1 - y_start))
                    image_main[y_start:y_start + w_h[1], x_start:x_start + w_h[0]] = image
                    image_black_main[y_start:y_start + w_h[1], x_start:x_start + w_h[0]] = image_black
                    if self.booleans["put_frame_around_whole_cell"]:
                        cv2.rectangle(image_main, (x_start + 1, y_start + 1),
                                      (x_start + w_h[0] - 1, y_start + w_h[1] - 3), (0, 0, 0), random.randint(1, 10))
                    x_start = x_start + w_h[0]
                    all_widths.append(w_h[0])
                    continue
                if x_start + w_h[0] > new_width_main:
                    break
                # endregion

                # region put background
                if self.booleans["background_cell_is_image"]:
                    image = self.put_background_on_image(width_sub_image, height_sub_image, image, alpha=0.7,
                                                         beta=0.3)
                # endregion

                # region make border
                border_vertical_size = 8
                border_horizontal_size = 8
                result_image_black = self.make_border(image_black, width_sub_image, height_sub_image,
                                                      border_vertical_size=border_vertical_size,
                                                      border_horizontal_size=border_horizontal_size, seg_map=True)
                if self.booleans["background_main_page_is_image"]:
                    result_image = self.make_border(image, width_sub_image, height_sub_image,
                                                    border_vertical_size=border_vertical_size,
                                                    border_horizontal_size=border_horizontal_size, colored=True,
                                                    color=color)
                else:
                    result_image = self.make_border(image, width_sub_image, height_sub_image,
                                                    border_vertical_size=border_vertical_size,
                                                    border_horizontal_size=border_horizontal_size)

                result_image = cv2.resize(result_image, (width_sub_image, height_sub_image),
                                          interpolation=cv2.INTER_AREA)
                # endregion

                # region make rotation
                if self.booleans["rotate_cell"] and rotate_segment_done < 2:
                    rotate_segment_done += 1
                    result_image, result_image_black = self.rotate_image(result_image, result_image_black,
                                                                         width_sub_image, height_sub_image, color)
                # endregion

                # region put subimage in main page
                image_main[y_start:y_start + height_sub_image, x_start:x_start + width_sub_image] = result_image
                image_black_main[y_start:y_start + height_sub_image,
                x_start:x_start + width_sub_image] = result_image_black
                # endregion

                # region put frame
                if self.booleans["put_frame_around_whole_cell"]:
                    cv2.rectangle(image_main, (x_start + 1, y_start + 1), (x_start + w_h[0] - 1, y_start + w_h[1] - 3),
                                  (0, 0, 0), random.randint(1, 10))
                # endregion

                x_start = x_start + w_h[0]

            y_start = y_start + height_sub_image
            x_start = 1

        # if booleans["put_random_lines_between_cells"]:
        #     image_main = self.put_random_line(booleans, row_slices, col_slices, height_sub_image, all_widths, y_title,
        #                                       image_main)
        if self.booleans["crop_page"]:
            x = (new_width_main - self.width) // 2
            y = (new_height_main - self.height) // 2
            image_main = image_main[y:self.height, x:self.width]
            image_black_main = image_black_main[y:self.height, x:self.width]

        if self.booleans["make_padding_in_page"]:
            self.booleans["padding_page"] = random.choice([True, False])
            if self.booleans["padding_page"]:
                padding_value = 100
                original_height = image_main.shape[0]
                original_width = image_main.shape[1]
                image_main = cv2.copyMakeBorder(image_main, padding_value, padding_value, padding_value, padding_value,
                                                borderType=cv2.BORDER_CONSTANT, value=self.colors["color_main"])
                image_main = cv2.resize(image_main, (original_width, original_height), interpolation=cv2.INTER_AREA)
                image_black_main = cv2.copyMakeBorder(image_black_main, padding_value, padding_value, padding_value,
                                                      padding_value, borderType=cv2.BORDER_CONSTANT, value=0)
                image_black_main = cv2.resize(image_black_main, (original_width, original_height),
                                              interpolation=cv2.INTER_AREA)

        if self.booleans["background_main_page_is_image"]:
            new_image = self.put_background_on_image(image_main.shape[1], image_main.shape[0], image_main, alpha=0.8,
                                                     beta=0.2)
            return new_image, image_black_main

        return image_main, image_black_main

    def make_border(self, image, width, height, border_vertical_size, border_horizontal_size, colored=False, color=255,
                    seg_map=False):
        '''
        Make border
        :param image: original image
        :param width: width of image passed
        :param height: height of image passed
        :param border_vertical_size: size of left and right borders
        :param border_horizontal_size: size of top and bottom borders
        :param colored: boolean to check if image is colored (4 dimensions)
        :param color: color of image to create bigger image with same color (if colored)
        :param seg_map: boolean to check if passed image is segmentation map, if so create new black image bigger
        :return: image with borders
        '''
        # region make border
        right = border_vertical_size
        left = border_vertical_size
        top = border_horizontal_size
        bottom = border_horizontal_size

        new_width = width + right + left
        new_height = height + top + bottom
        if colored:
            result_image = np.ones((new_height, new_width, 4), dtype='uint8') * color
            result_image[top:new_height - bottom, left:new_width - right] = image
            result_image = cv2.resize(result_image, (width, height), interpolation=cv2.INTER_AREA)
            result_image = cv2.cvtColor(result_image, cv2.COLOR_BGRA2GRAY)
        else:
            result_image = np.ones((new_height, new_width), dtype='uint8') * color
            result_image[top:new_height - bottom, left:new_width - right] = image
            result_image = cv2.resize(result_image, (width, height),
                                      interpolation=cv2.INTER_AREA)
        if seg_map:
            result_image = np.zeros((new_height, new_width), dtype='uint8')
            result_image[top:new_height - bottom, left:new_width - right] = image
            result_image = cv2.resize(result_image, (width, height),
                                      interpolation=cv2.INTER_AREA)
        return result_image

    # helper function to generate specific structure for al ahram
    def generate_three_parts_image(self, image, english_font, arabic_font,
                                   direction, arabic_font_path, image_black,
                                   fixed_line_len):
        '''
        Ths function helps for generating "text between two columns structure"

        Pass left or right image and divide it horizontally to three parts (upper, center, bottom)
        :param image: left or right image
        :param english_font:
        :param arabic_font:
        :param direction: ltr or rtl
        :param arabic_font_path:
        :param image_black: segmentation map
        :param fixed_line_len:
        :return: image, image_black
        '''
        # region divide right and left image into 3 parts, to avoid overlapping after putting center image
        height_half_image = image.shape[0]
        width_half_image = image.shape[1]
        part_1_height = int(0.2 * height_half_image)
        part_2_height = int(0.2 * height_half_image)
        part_3_height = int(0.6 * height_half_image)
        part_2_width = int(0.7 * width_half_image)
        image_part_1 = image[0:part_1_height]
        image_part_2 = image_part_1.copy()
        image_part_3 = image[part_1_height + part_2_height:height_half_image]
        image_part_1 = Image.fromarray(image_part_1)
        image_part_2 = Image.fromarray(image_part_2)
        image_part_3 = Image.fromarray(image_part_3)
        image_black_part_1 = np.zeros((image_part_1.height, image_part_1.width), dtype='uint8')
        image_black_part_2 = np.zeros((image_part_2.height, image_part_2.width), dtype='uint8')
        image_black_part_3 = np.zeros((image_part_3.height, image_part_3.width), dtype='uint8')
        # endregion

        # region put text on each part
        # put text on all parts of right and left images
        image_part_1, image_black_part_1 = self.put_text_on_sub_image(image_part_1, image_black_part_1,
                                                                        image_part_1.height,
                                                                        image_part_1.width,
                                                                        english_font, arabic_font,
                                                                        direction, arabic_font_path, fixed_line_len)

        # pass width and height of part 1 then resize
        image_part_2, image_black_part_2 = self.put_text_on_sub_image(image_part_2, image_black_part_2,
                                                                        image_part_1.height,
                                                                        image_part_1.width,
                                                                        english_font, arabic_font,
                                                                        direction, arabic_font_path, fixed_line_len,
                                                                        put_title_done=True)

        image_part_3, image_black_part_3 = self.put_text_on_sub_image(image_part_3, image_black_part_3,
                                                                        image_part_3.height,
                                                                        image_part_3.width,
                                                                        english_font, arabic_font,
                                                                        direction, arabic_font_path, fixed_line_len,
                                                                        put_title_done=True)
        # endregion

        image[0:part_1_height] = image_part_1
        image_black[0:part_1_height] = image_black_part_1

        # resize image part two to fit in image half width "part_2_width"
        if direction == "rtl":
            x_image_part_2 = width_half_image - part_2_width
        elif direction == "ltr":
            x_image_part_2 = part_2_width
        image_part_2 = image_part_2.resize((part_2_width, part_2_height))
        image_black_part_2 = cv2.resize(image_black_part_2, (part_2_width, part_2_height),
                                         interpolation=cv2.INTER_AREA)
        if direction == "rtl":
            image[part_1_height:part_1_height + part_2_height, x_image_part_2:] = image_part_2
            image_black[part_1_height:part_1_height + part_2_height, x_image_part_2:] = image_black_part_2
        elif direction == "ltr":
            image[part_1_height:part_1_height + part_2_height, :x_image_part_2] = image_part_2
            image_black[part_1_height:part_1_height + part_2_height, :x_image_part_2] = image_black_part_2

        image[part_1_height + part_2_height:height_half_image] = image_part_3
        image_black[part_1_height + part_2_height:height_half_image] = image_black_part_3

        return image, image_black

    # generate specific structure for al ahram
    def generate_text_between_two_columns(self, new_width_main, new_height_main):
        '''
        This function to generate specific structure "text between two columns"
        :param new_width_main: width of subimage (cell)
        :param new_height_main: height of subimage (cell)
        :return: image_main_two_columns, image_black_two_columns
        '''
        width_half_image = int(new_width_main * 0.5)
        height_half_image = new_height_main
        # width_image_center = random.randint(int(0.4 * new_width_main), int(0.55 * new_width_main))
        width_image_center = int(0.3 * new_width_main)
        # height_image_center = random.randint(int(0.2 * new_height_main), int(0.3 * new_height_main))
        height_image_center = int(0.2 * new_height_main)
        colored = False
        if self.booleans["background_cell_is_image"] or self.booleans["background_main_page_is_image"]:
            image_right = Image.new("RGBA", (width_half_image, height_half_image),
                                    (
                                    self.colors["color_main"], self.colors["color_main"], self.colors["color_main"], 1))
            image_left = Image.new("RGBA", (width_half_image, height_half_image),
                                   (self.colors["color_main"], self.colors["color_main"], self.colors["color_main"], 1))
            image_center = Image.new("RGBA", (width_image_center, height_image_center),
                                     (self.colors["color_main"], self.colors["color_main"], self.colors["color_main"],
                                      1))
            colored = True
        else:
            image_right = Image.new('L', (width_half_image, height_half_image), self.colors["color_main"])
            image_left = Image.new('L', (width_half_image, height_half_image), self.colors["color_main"])
            image_center = Image.new('L', (width_image_center, height_image_center), self.colors["color_main"])
        image_black_right = np.zeros((height_half_image, width_half_image), dtype='uint8')
        image_black_left = np.zeros((height_half_image, width_half_image), dtype='uint8')
        image_black_center = np.zeros((height_image_center, width_image_center), dtype='uint8')
        image_black_two_columns = np.zeros((new_height_main, new_width_main), dtype='uint8')
        image_main_two_columns = np.ones((new_height_main, new_width_main), dtype='uint8') * self.colors["color_main"]

        # region define fixed font type and size and text direction for all columns.
        # font_size = random.randint(15, 45)
        font_size = random.randint(int(self.width * 0.01), int(self.width * 0.03))
        arabic_font_path = random.choice(self.arabic_fonts_path)
        arabic_font = ImageFont.truetype(arabic_font_path, font_size)
        english_font_path = random.choice(self.english_fonts_path)
        english_font = ImageFont.truetype(english_font_path, font_size)
        # fixed_line_len = random.randint(5, 10)
        fixed_line_len = random.randint(5, width_half_image // 4)
        direction = "rtl"
        # endregion

        image_right = np.array(image_right)
        image_right, image_black_right = \
            self.generate_three_parts_image(image_right, english_font, arabic_font,
                                            direction, arabic_font_path,
                                            image_black_right, fixed_line_len)
        # image_right, image_black_right = self.put_text_on_sub_image(image_right, image_black_right, height_half_image,
        #                                                             width_half_image,
        #                                                             english_font, arabic_font, booleans,
        #                                                             direction, color_text, color_main, arabic_font_path)
        direction = "ltr"
        image_left = np.array(image_left)
        image_left, image_black_left = \
            self.generate_three_parts_image(image_left, english_font, arabic_font,
                                            direction, arabic_font_path,
                                            image_black_left, fixed_line_len)
        direction = "center"
        font_size += random.randint(30, 40)
        # fixed_line_len = random.randint(1, 3)
        fixed_line_len = random.randint(1, width_image_center // 8)
        # font_size += 50
        arabic_font = ImageFont.truetype(arabic_font_path, font_size)
        english_font = ImageFont.truetype(english_font_path, font_size)
        image_center, image_black_center = self.put_text_on_sub_image(image_center, image_black_center,
                                                                      height_image_center, width_image_center,
                                                                      english_font, arabic_font,
                                                                      direction, arabic_font_path, fixed_line_len)
        # region make border
        border_vertical_size = 8
        border_horizontal_size = 8
        image_left = self.make_border(image_left, width_half_image, height_half_image, colored=colored,
                                      color=self.colors["color_main"], border_vertical_size=border_vertical_size,
                                      border_horizontal_size=border_horizontal_size)
        image_right = self.make_border(image_right, width_half_image, height_half_image, colored=colored,
                                       color=self.colors["color_main"], border_vertical_size=border_vertical_size,
                                       border_horizontal_size=border_horizontal_size)
        image_center = self.make_border(image_center, width_image_center, height_image_center,
                                        border_vertical_size=border_vertical_size,
                                        border_horizontal_size=border_horizontal_size,
                                        colored=colored, color=self.colors["color_main"])
        image_black_right = self.make_border(image_black_right, width_half_image, height_half_image, seg_map=True,
                                             border_vertical_size=border_vertical_size,
                                             border_horizontal_size=border_horizontal_size)
        image_black_left = self.make_border(image_black_left, width_half_image, height_half_image, seg_map=True,
                                            border_vertical_size=border_vertical_size,
                                            border_horizontal_size=border_horizontal_size)
        image_black_center = self.make_border(image_black_center, width_image_center, height_image_center,
                                              border_vertical_size=border_vertical_size,
                                              border_horizontal_size=border_horizontal_size, seg_map=True)
        # endregion
        image_main_two_columns[0:height_half_image, 0:width_half_image] = image_left
        image_black_two_columns[0:height_half_image, 0:width_half_image] = image_black_left

        # width_right_image = new_width_main - int(width_half_image*2)
        x_right_image = new_width_main - width_half_image
        # image_right = cv2.resize(image_right, (width_right_image, height_half_image), interpolation=cv2.INTER_AREA)
        # image_black_right = cv2.resize(image_black_right, (width_right_image, height_half_image),
        #                                interpolation=cv2.INTER_AREA)

        image_main_two_columns[0:height_half_image, x_right_image:new_width_main] = image_right
        image_black_two_columns[0:height_half_image, x_right_image:new_width_main] = image_black_right

        # y = random.randint(int(0.1 * new_height_main), int(0.4 * new_height_main))
        y = int(0.2 * new_height_main)
        # x = random.randint(int(0.4 * new_width_main), int(0.6 * new_width_main)-width_image_center)
        x = int(0.35 * new_width_main)
        image_main_two_columns[y:y + height_image_center, x:x + width_image_center] = image_center
        image_black_two_columns[y:y + height_image_center, x:x + width_image_center] = image_black_center
        if colored:
            image_main_two_columns = np.stack((image_main_two_columns,) * 4, axis=-1)
        plot = False
        if plot:
            plt.figure()
            plt.subplot(1, 2, 1)
            plt.imshow(image_main_two_columns, cmap='gray', vmin=0, vmax=255)
            plt.title('Image')
            plt.subplot(1, 2, 2)
            plt.imshow(image_black_two_columns, cmap='gray')
            plt.title('Segmentation Map')
            plt.show()
        return image_main_two_columns, image_black_two_columns

    def get_fill_color(self, box_rectangle_seg_map, image_draw):
        '''
        This function help to get "fill" color of text to be drawn on image
        :param box_rectangle_seg_map:
        :param image_draw:
        :return: fill color, image_draw
        '''
        if self.booleans["random_text_lines_in_cell_are_inverted"] and self.booleans["cell_is_inverted"]:
            if self.booleans["background_cell_is_image"] or self.booleans["background_main_page_is_image"]:
                fill = (255, 255, 255)
            else:
                fill = 255
        elif self.booleans["random_text_lines_in_cell_are_inverted"]:
            put_inverted = random.choice([True, False])
            if put_inverted:
                image_draw.rectangle(box_rectangle_seg_map, fill="black")
                if self.booleans["background_cell_is_image"] or self.booleans["background_main_page_is_image"]:
                    fill = (255, 255, 255)
                else:
                    fill = 255
            else:
                fill = self.colors["color_text"]
        else:
            fill = self.colors["color_text"]
        return fill, image_draw

    '''
    def generate_small_title_behind_text(self, text_size, w_h, image_draw, y1_box, color_text, image,
                                         image_black,
                                         fixed_line_len, english_font, arabic_font, arabic_font_path, color_main):
        width_small_title = int(w_h[0] * 0.1)
        height_small_title = w_h[1] * 3
        line, font_type = self.get_line(fixed_line_len, width_small_title, english_font, arabic_font,
                                        arabic_font_path)
        width_line = text_size[0]
        x = w_h[0] - width_small_title - 4
        box_text = image_draw.textbbox((x, y1_box), line, font=font_type, anchor="lt")

        box_rectangle_seg_map = [box_text[0] - 2, box_text[1], box_text[2] + 4, box_text[3]]
        box_rounded_rectangle = [box_text[0] - 2, box_text[1] - 2,
                                 box_text[2] + 4, box_text[3] + 2]

        fill, image_draw = self.get_fill_color(color_text, box_rectangle_seg_map, image_draw)

        image_draw.text((x, y1_box), line, fill=fill, font=font_type, anchor="lt")

        # image_small_title, image_black_small_title, width_title_image, height_title_image, x, y\
        #     = self.make_title(width_small_title, height_small_title, color_main, color_text, 0)
        #
        # image = np.array(image)
        # image[y1_box:image_small_title.shape[0],
        # image.shape[1] - image_small_title.shape[1]:image.shape[1]] = image_small_title
        #
        # image_black[y1_box:image_small_title.shape[0],
        # image_black.shape[1] - image_small_title.shape[1]:image_black.shape[1]] = image_black_small_title
        #
        # image = Image.fromarray(image)
        # image_draw = ImageDraw.Draw(image)

        width_line = w_h[0] - width_small_title - int(0.05 * (w_h[0]))
        line, font_type = self.get_line(fixed_line_len, width_line, english_font, arabic_font,
                                        arabic_font_path)
        # width_line = text_size[0]
        x = w_h[0] - width_line - 4
        box_text = image_draw.textbbox((x, y1_box), line, font=font_type, anchor="lt")

        box_rectangle_seg_map = [box_text[0] - 2, box_text[1], box_text[2] + 4, box_text[3]]
        box_rounded_rectangle = [box_text[0] - 2, box_text[1] - 2,
                                 box_text[2] + 4, box_text[3] + 2]

        fill, image_draw = self.get_fill_color(color_text, box_rectangle_seg_map, image_draw)

        image_draw.text((x, y1_box), line, fill=fill, font=font_type, anchor="lt")
        plt.figure()
        plt.imshow(image, cmap='gray', vmin=0, vmax=255)
        plt.title('image_new')
        plt.show()

        image_vertical = np.array(image_vertical)
        image_vertical = imutils.rotate_bound(image_vertical, angle=90)
        image_vertical_crop = image_vertical[0:image_vertical.shape[0], image_vertical
                                                                        .shape[1] - text_size[1]:
                                                                        image_vertical.shape[1]]
        # image_vertical = cv2.resize(image_vertical,(box_text[3]-box_text[1],box_text[2]-box_text[0]), interpolation=cv2.INTER_AREA)
        image = np.array(image)
        image_vertical_crop = cv2.resize(image_vertical_crop,
                                         (image_vertical_crop.shape[1], image.shape[0]),
                                         interpolation=cv2.INTER_AREA)
        image[0:image_vertical_crop.shape[0],
        image.shape[1] - text_size[1]:image.shape[1]] = image_vertical_crop
        image = Image.fromarray(image)
        image_draw = ImageDraw.Draw(image)

        x = w_h[0] - width_line - 4 - image_vertical_crop.shape[1]
    '''

    def draw_lines_seg_map(self, box, image_black):
        '''
        Draw text line box in segmentation map but with 80% of original height, to avoid connected boxes
        :param box: box of text line
        :param image_black: segmentation map
        :return: segmentation map drawn on it the box
        '''
        y_line = box[1] + (box[3] - box[1]) // 2  # keda el y f nos el box
        height_line_seg_map = int((box[3] - box[1]) * 0.6)
        y_line = y_line - int(height_line_seg_map // 2)  # keda el y bdaytha 3nd 10%
        for height_count in range(height_line_seg_map):
            cv2.line(image_black, (box[0], y_line + height_count), (box[2], y_line + height_count), 255, 1)
        return image_black

    def put_title_from_annotation_data(self, new_width, new_height):
        '''
        Choose random title from annotation and put it in the image
        :param new_width: width of subimage (cell)
        :param new_height: height of subimage (cell)
        :return: image, image_black, width_title_image, height_title_image, x
        '''
        image_title_file = random.choice(self.titles_mosawer_filenames)
        image_title_path = os.path.join(self.titles_mosawer_path, image_title_file)
        image_title = Image.open(image_title_path).convert(mode="L")
        height_title_image = random.randint(image_title.height // 3, image_title.height // 2)
        width_title_image = random.randint(image_title.width // 2, image_title.width)
        box = [0, 0, width_title_image, height_title_image]
        image_black = np.zeros((height_title_image, width_title_image), dtype='uint8')
        self.draw_lines_seg_map(box, image_black)
        if width_title_image > new_width - 10:
            if new_width - 10 <= 0:
                width_title_image = new_width
            else:
                width_title_image = new_width - 10
        if height_title_image > new_height - 10:
            if new_height - 10 <= 0:
                height_title_image = new_height
            else:
                height_title_image = new_height - 10
        image = image_title.resize((width_title_image, height_title_image))
        image_black = cv2.resize(image_black, (width_title_image, height_title_image), interpolation=cv2.INTER_AREA)
        image = np.array(image)
        x = random.choice(range(2, (new_width - width_title_image)))
        return image, image_black, width_title_image, height_title_image, x

    def put_background_on_image(self, width, height, image, alpha, beta):
        '''
        Choose random picture and put it on image as background
        :param width: width of image
        :param height: height of image
        :param image: image to put background on it
        :param alpha: first parameter to control the transparency of image
        :param beta: second parameter to control the transparency of background
        :return: new_image
        '''
        image_file = random.choice(self.image_filenames)
        image_path = os.path.join(self.image_dataset_path, image_file)
        imagebg = cv2.imread(image_path)
        imagebg = cv2.cvtColor(imagebg, cv2.COLOR_BGR2BGRA)
        imagebg = cv2.resize(imagebg, (width, height))
        image = np.array(image, dtype='uint8')
        if len(image.shape) == 2:
            imagebg = cv2.cvtColor(imagebg, cv2.COLOR_BGRA2GRAY)
        new_image = cv2.addWeighted(image, alpha, imagebg, beta, 0)
        if len(image.shape) == 2:
            return new_image
        new_image = cv2.cvtColor(new_image, cv2.COLOR_BGRA2GRAY)
        return new_image

    def make_title(self, new_width, new_height, y):
        '''
        Generate title with large font and put it on image and return this title to put it on main image
        :param new_width: width of image that we want to put title on it
        :param new_height: height of image that we want to put title on it
        :param y: start y to put title
        :return: image, image_black, width, height, x, y
        '''
        title_from_data = random.choices([True, False], k=1, weights=[0.3, 0.7])[0]
        # title_from_data = False
        if title_from_data:
            image, image_black, width_title_image, height_title_image, x = self.put_title_from_annotation_data(
                new_width, new_height)
            return image, image_black, width_title_image, height_title_image, x, y

        k = random.randint(1, max(int(new_width * 0.03), 2))
        # font_size = random.randint(int(new_width * 0.03), int(new_width * 0.2))
        # font_size = random.randint(20, 60)
        font_size = random.randint(int(new_width * 0.02), int(new_width * 0.14))
        # font_size = 160
        all_fonts = self.arabic_fonts_large_text_path  # + self.arabic_fonts_path
        arabic_font_path = random.choice(all_fonts)
        arabic_font = ImageFont.truetype(arabic_font_path, font_size)
        put_more_spaces = False
        put_numbers = False

        line = self.create_line(arabic_font, new_width, put_more_spaces, put_numbers, k)
        width, height = arabic_font.getsize(line)

        inverted = random.choices([True, False], k=1, weights=[0.2, 0.8])[0]
        frame = random.choices([True, False], k=1, weights=[0.2, 0.8])[0]
        image_background = random.choice([True, False])
        #
        if inverted:
            color = 0
        else:
            color = self.colors["color_main"]
        if image_background:
            color = 255
            # color_text = 0
            image = Image.new("RGBA", (width, height), (color, color, color, 1))
        else:
            image = Image.new('L', (width, height), color)

        image_black = np.zeros((height, width), dtype='uint8')
        image_draw = ImageDraw.Draw(image)
        yb = 5
        box = image_draw.textbbox((0, yb), line, font=arabic_font)

        if type(self.colors["color_text"]) != int:
            if inverted:
                fill = 255
            else:
                fill = 0
            image_draw.text((0, yb), line, fill=fill, font=arabic_font)
        else:
            if inverted:
                fill = 255
            else:
                fill = self.colors["color_text"]
            image_draw.text((0, yb), line, fill=fill, font=arabic_font)

        y_line = box[1] + (box[3] - box[1]) // 2  # keda el y f nos el box
        height_line_seg_map = int((box[3] - box[1]) * 0.8)
        y_line = y_line - int(height_line_seg_map // 2)
        for height_count in range(height_line_seg_map):
            cv2.line(image_black, (box[0], y_line + height_count), (box[2], y_line + height_count), 255, 1)

        if width > new_width - 10:
            if new_width - 10 <= 0:
                width = new_width
            else:
                width = new_width - 10
        if height > new_height - 10:
            if new_height - 10 <= 0:
                height = new_height
            else:
                height = new_height - 10

        image = image.resize((width, height))
        image_black = cv2.resize(image_black, (width, height), interpolation=cv2.INTER_AREA)

        x = random.choice(range(2, (new_width - width)))  # to make sure that small page will fit in main image
        # y = random.choice(range(y, y + 10))
        if image_background:
            new_image = self.put_background_on_image(width, height, image, alpha=0.7, beta=0.3)
            return new_image, image_black, width, height, x, y

        if frame:
            image = np.array(image, dtype='uint8')
            cv2.rectangle(image, (1, 1), (width - 1, height - 1), (0, 0, 0), 1)
        image = np.array(image)
        return image, image_black, width, height, x, y

    def augment_text(self, img):
        '''
        This function help to make augmentation on text line box
        :param img: image
        :return: augmented image
        '''
        # print('augment_text')
        img = np.array(img)
        kernel = np.ones((5, 5), np.uint8)
        img_erosion = cv2.erode(img, kernel, iterations=1)
        # cv2.imshow('Input', img)
        # cv2.imshow('Erosion', img_erosion)

        '''# global thresholding
        ret1, th1 = cv2.threshold(img, 127, 255, cv2.THRESH_BINARY)
        cv2.imshow('th1', th1)'''

        '''# global thresholding
        ret1, th11 = cv2.threshold(img_erosion, 127, 255, cv2.THRESH_BINARY)
        cv2.imshow('th11', th11)'''

        '''ret2, th = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        cv2.imshow('th', th)'''

        '''ret2, th2 = cv2.threshold(img_erosion, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        cv2.imshow('th2', th2)'''

        '''blur = cv2.GaussianBlur(img_erosion, (3, 3), 0)
        ret3, th3 = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        cv2.imshow('threshold(3, 3)', th3)'''

        blur = cv2.GaussianBlur(img, (5, 5), 0)
        ret3, th3 = cv2.threshold(blur, 5, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        # ret3, th3 = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY)
        # cv2.imshow('th3', th3)
        row, col = th3.shape
        # number_of_pixels = random.randint(1000, 2000)
        number_of_pixels = 2500
        for i in range(number_of_pixels):
            # Pick a random y coordinate
            y_coord = random.randint(0, row - 1)
            # Pick a random x coordinate
            x_coord = random.randint(0, col - 1)
            # Color that pixel to white
            if th3[y_coord][x_coord] == 0:
                # th3[y_coord][x_coord] = 128
                th3[y_coord][x_coord] = random.randint(200, 250)
                th3[y_coord][x_coord] = 250

        # th3 = cv2.GaussianBlur(th3, (1, 1), 0)

        '''ret4, th4 = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        img_erosion2 = cv2.erode(th4, kernel, iterations=3)
        cv2.imshow('img_erosion2', img_erosion2)'''

        '''noisy_image = random_noise(th3)
        cv2.imshow('noisy_image', noisy_image)'''

        '''# Apply bilateral filter denoising
        denoised_image = denoise_bilateral(th3)
        cv2.imshow('denoised_image', denoised_image)'''

        '''# Obtain the segmentation with 400 regions
        segments = slic(img, n_segments=400)
        # Put segments on top of original image to compare
        segmented_image = label2rgb(segments, img, kind='avg')
        cv2.imshow('segmented_image', segmented_image)'''

        return th3

    def put_random_line(self, row_slices, col_slices, height_sub_image, all_widths, y_title, image_main):
        '''
        Put line vertical or horizontal between cells
        :param row_slices: row slices of main page
        :param col_slices: column slices of main page
        :param height_sub_image: height for sub image (assumed all cells with same height)
        :param all_widths: list of widths of all cells
        :param y_title: if there is title pass end y of title
        :param image_main: main page
        :return: image_main
        '''
        x_start = 1
        j = 0
        for i in range(row_slices):
            while True:
                vertical_line_length = random.randint(1, height_sub_image)
                horizontal_line_length = random.randint(1, all_widths[j])
                if self.booleans["put_random_lines_between_cells"]:
                    self.booleans["put_vertical_line"] = random.choice([True, False])
                    self.booleans["put_horizontal_line"] = random.choice([True, False])
                if self.booleans["put_horizontal_line"]:
                    put_double = random.choice([True, False])
                    put_trible = random.choice([True, False])
                    put_horizontal_line = random.choice([True, False])
                    # p1 = random.randint(x_start,x_start+width_sub_image)
                    p1 = x_start
                    cv2.line(image_main, (p1, y_title), (p1 + horizontal_line_length, y_title), (0), 1)
                    if put_double and put_trible:
                        cv2.line(image_main, (p1, y_title - 2), (p1 + horizontal_line_length, y_title - 2), (0), 1)
                        cv2.line(image_main, (p1, y_title + 2), (p1 + horizontal_line_length, y_title + 2), (0), 1)
                    elif put_double:
                        cv2.line(image_main, (p1, y_title - 2), (p1 + horizontal_line_length, y_title - 2), (0), 1)
                if self.booleans["put_vertical_line"]:
                    put_double = random.choice([True, False])
                    put_trible = random.choice([True, False])
                    put_vertical_line = random.choice([True, False])
                    # p1 = random.randint(y_title,y_title+height_sub_image)
                    p1 = y_title
                    cv2.line(image_main, (x_start, p1), (x_start, p1 + vertical_line_length), (0), 1)
                    if put_double and put_trible:
                        cv2.line(image_main, (x_start - 2, p1), (x_start - 2, p1 + vertical_line_length), (0), 1)
                        cv2.line(image_main, (x_start + 2, p1), (x_start + 2, p1 + vertical_line_length), (0), 1)
                    elif put_double:
                        cv2.line(image_main, (x_start - 2, p1), (x_start - 2, p1 + vertical_line_length), (0), 1)
                x_start += all_widths[j]
                j += 1
                if j >= col_slices * (i + 1):
                    break
            y_title = y_title + height_sub_image
            x_start = 1
        return image_main

    def set_width_height(self):
        '''
        Set width and height of main page
        :return:
        '''
        if type(self.width_original) != int:
            self.width = int(random.uniform(self.width_original[0], self.width_original[1]))
        else:
            self.width = self.width_original
        if type(self.height_original) != int:
            self.height = int(random.uniform(self.height_original[0], self.height_original[1]))
        else:
            self.height = self.height_original

    # divide main page to cells and call for each cell the choosen function (large text or put image ...)
    def generate_image_slices(self):
        '''
        This function calls main functions to generate cells on page
        :return:
        '''

        # region get width, height and colors of main image
        self.set_width_height()
        self.set_colors()
        # endregion

        # region check if crop page, make width and height bigger than initialized
        if self.booleans["crop_page"]:
            new_width = int(self.width * 1.2)
            new_height = int(self.height * 1.2)
        else:
            new_width = self.width
            new_height = self.height
        # endregion

        # region if page is long title only
        if self.booleans["long_title_only"]:
            new_height_main = random.randint(50, 150)
            new_width_main = random.randint(200, 800)
            image_main = np.ones((new_height_main, new_width_main), dtype='uint8') * self.colors["color_main"]
            image_black_main = np.zeros((new_height_main, new_width_main), dtype='uint8')
            image, image_black, width, height, x, y = self.make_title(new_width_main, new_height_main, 0)
            y = random.randint(0, new_height_main - height)
            image_main[y:y + height, x:x + width] = image
            image_black_main[y:y + height, x:x + width] = image_black
            return image_main, image_black_main
        # endregion

        # region call generate_image_column_structure to generate cells on page
        image_main, image_black_main = self.generate_image_column_structure(new_width, new_height)
        # endregion

        return image_main, image_black_main

    def generate_images(self):
        '''
        This function used in training to generate pages on the fly
        :return:
        '''
        while True:
            try:
                # start = time.time()
                image_main, image_black_main = self.generate_image_slices()
                # end = time.time()
                # print(end - start)
                gc.collect()
                yield np.array(image_main, dtype='uint8')[..., np.newaxis], \
                    np.array(image_black_main, dtype='uint8')[..., np.newaxis]
            except Exception as e:
                print(e)
                continue


if __name__ == '__main__':
    inverted = random.choices([True, False], k=1, weights=[0.3, 0.7])
    frame = random.choices([True, False], k=1, weights=[0.3, 0.7])
    put_image = random.choice([True, False])

    booleans = {}
    # self.booleans["one_column_more_spaces"] = random.choices([True, False], k=1, weights=[0.3, 0.7])[0]
    # self.booleans["background_main_is_image"] = random.choices([True, False], k=1, weights=[0.2, 0.8])[0]
    # all_page_is_titels_font = random.choices([True, False], k=1, weights=[0.4, 0.6])[0]
    booleans["all_page_is_titels_font"] = False

    booleans["put_inverted_text_in_page"] = False
    booleans["cell_is_inverted"] = False  # based on "put_inverted_text_in_page"
    booleans["random_text_lines_in_cell_are_inverted"] = inverted

    booleans["put_image_in_page"] = True
    booleans["cell_is_image"] = False  # based on "put_image_in_page"

    booleans["put_frame_around_lines_in_page"] = False
    booleans["random_text_lines_in_cell_in_frame"] = False  # based on "put_frame_around_lines_in_page"
    booleans["put_frame_around_whole_cell"] = False  # based on "put_frame_around_lines_in_page"

    booleans["background_main_page_is_image"] = True
    booleans["background_cell_is_image"] = False

    booleans["put_english_in_page"] = False
    booleans["all_tex_lines_in_cell_are_english"] = False

    booleans["make_rotation_in_page"] = False
    booleans["rotate_cell"] = False

    booleans["put_large_text"] = True
    booleans["large_text_in_cell"] = False

    booleans["put_vertical_text_line"] = True
    booleans["vertical_text_line_in_cell"] = False

    booleans["make_padding_in_page"] = True
    booleans["padding_page"] = False

    booleans["crop_page"] = False
    booleans["all_lines_same_width"] = False
    booleans["one_column_more_spaces"] = False
    booleans["put_random_lines_between_cells"] = False
    booleans["put_horizontal_line"] = False
    booleans["put_vertical_line"] = False
    booleans["long_title_only"] = False

    lines_generator = LinesGenerator(assets_path='D:/All_Assets', width=1000, height=1200, booleans=booleans)
    # lines_generator = LinesGenerator(assets_path='/media/nourhan-emad/New Volume/gitlab/ocr/assets', width=1000, height=700)
    lines_image = lines_generator.generate_images()
    i = 0
    for image_main_, image_black_main_ in lines_image:
        plt.figure()
        plt.subplot(1, 2, 1)
        plt.imshow(image_main_, cmap='gray', vmin=0, vmax=255)
        plt.title('Image')

        plt.subplot(1, 2, 2)
        plt.imshow(image_black_main_, cmap='gray')
        plt.title('Segmentation Map')

        # plt.subplot(1, 3, 3)
        # plt.imshow(test_img, cmap='gray')
        # plt.title('image test')

        # cv2.imwrite(os.path.join(r"D:\output_generator\img" , str(i) + "_image.jpg"),image_main)
        # cv2.imwrite(os.path.join(r"D:\output_generator\labelcol" , str(i) + "_image.jpg"),image_black_main)
        # plt.savefig(r"D:\output_generator" + str(i) + "_image_text_map.jpg")
        # print(i)
        # i+=1
        plt.show()
        # plt.close()
        # gc.collect()
