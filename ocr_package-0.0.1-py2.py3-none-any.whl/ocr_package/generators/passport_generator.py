import cv2
import random
import numpy as np
import matplotlib.pylab as plt
from PIL import Image, ImageDraw, ImageFont, ImageOps
import os
import imutils
import glob


class LinesGenerator():
    def __init__(self, assets_path='../../assets', width=384, height=512):
        self.people_photos = os.path.join(assets_path, 'passports', "personImages")
        self.barcode = os.path.join(assets_path, 'passports', "barcode")
        self.background = os.path.join(assets_path, 'passports', "passportImages")
        self.background_images_filnames = os.listdir(self.background)
        # self.image_october_path = os.path.join(assets_path, 'October_images_in_line_generator')
        self.width_original = width
        self.height_original = height
        self.people_photos_filenames = os.listdir(self.people_photos)
        self.barcode_file_names = os.listdir(self.barcode)
        arabic_fonts_dir = os.path.join(assets_path, "Arabic_Fonts")
        bilingual_fonts_dir = os.path.join(assets_path, "Bilingual_Fonts")
        # arabic_fonts_large_text_dir = os.path.join(assets_path, "Large_Fonts")
        # english_fonts_large_text_dir = os.path.join(assets_path, "Large_Fonts")
        english_fonts_dir = os.path.join(assets_path, "English_Fonts")
        self.months = ["JAN", "FEB", "MARCH", "APRIL", "MAY", "JUNE", "JULY", "AUG", "SEPT", "OCT", "NOV", "DEC"]
        self.arabic_months = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر',
                              'نوفمبر', 'ديسمبر']
        # self.arabic_letters = "ءآأؤإئابةتثجحخدذرزسشصضطظعغفقكلمنهوىي"
        # self.arabic_letters = ['آ', 'أ', 'ؤ', 'إ', 'ا', 'ب', 'ت', 'ث', 'ج', 'ح', 'خ', 'د', 'ذ', 'ر', 'ز',
        #                        'س', 'ش', 'ص', 'ض', 'ط', 'ظ', 'ع', 'غ', 'ف', 'ق', 'ك', 'ل', 'م', 'ن', 'ه', 'و', 'ي',
        #                        'ـــ', "ــــــ"]
        self.arabic_letters = ['ء', 'آ', 'أ', 'ؤ', 'إ', 'ئ', 'ا', 'ب', 'ة', 'ت', 'ث', 'ج', 'ح', 'خ', 'د', 'ذ', 'ر', 'ز',
                               'س', 'ش', 'ص', 'ض', 'ط', 'ظ', 'ع', 'غ', 'ف', 'ق', 'ك', 'ل', 'م', 'ن', 'ه', 'و', 'ى', 'ي']
        self.arabic_ending_letters = ['ء', 'ى', 'ة', 'ئ']
        self.arabic_punctuation = ['؟', '؛', '،', '!', '...', '.', ':', '-']
        # '٪' '_'
        # self.english_punctuation = ['%', ',', '@', '$', '&', '?', ';', "'", '^', ':-']

        # self.general_punctuation = ['!', '-', '.', '/', ':', '..', '*', '+', '×', '÷', '=']

        # self.any_punctuation = ['؟', '؛', '،', 'ـ', '%', ',', '@', '$', '&', '?', ';', "'", '^', ':-', '!', '-', '.', '/',
        #                    ':', '..', '*', '+', '×', '÷', '=']
        self.chars = ['<']
        self.english_letters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q',
                                'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
        self.text_only_list = ['31.ttf', '35.ttf', "alfont_com_AlFont_com_BJadidBold.ttf",
                               "alfont_com_Sp_Jadid-Bold_p30download.com_.ttf", "ArbFONTS-B-Jadid-Bold.ttf",
                               "Sp_Maryam-Bold_p30download.com_.ttf", "Sp_Jadid-Bold_p30download.com_.ttf"]
        self.arabic_numbers = "١٢٣٤٥٦٧٨٩٠"
        self.english_numbers = "1234567890"
        self.arabic_fonts_path = []
        for font in os.listdir(arabic_fonts_dir):
            self.arabic_fonts_path.append(os.path.join(arabic_fonts_dir, font))

        self.bilingual_fonts_path = []
        for font in os.listdir(bilingual_fonts_dir):
            self.bilingual_fonts_path.append(os.path.join(bilingual_fonts_dir, font))

        # for font in os.listdir(bilingual_fonts):
        #     self.arabic_fonts_path.append(os.path.join(bilingual_fonts, font))
        # self.arabic_fonts_large_text_path = []
        # for font in os.listdir(arabic_fonts_large_text_dir):
        #     self.arabic_fonts_large_text_path.append(os.path.join(arabic_fonts_large_text_dir, font))
        # self.english_fonts_large_text_path = []
        # for font in os.listdir(english_fonts_large_text_dir):
        #     self.english_fonts_large_text_path.append(os.path.join(english_fonts_large_text_dir, font))

        self.english_fonts_path = []
        for font in os.listdir(english_fonts_dir):
            self.english_fonts_path.append(os.path.join(english_fonts_dir, font))
            self.bilingual_fonts_path.append(os.path.join(english_fonts_dir, font))

    def set_width_and_height(self):
        # region get width and height of main image
        if type(self.width_original) != int:
            self.width = int(random.uniform(self.width_original[0], self.width_original[1]))
        else:
            self.width = self.width_original
        if type(self.height_original) != int:
            self.height = int(random.uniform(self.height_original[0], self.height_original[1]))
        else:
            self.height = self.height_original
        new_width = self.width
        new_height = self.height
        # endregion
        return new_width, new_height

    def put_person_image(self, image_main):
        put_barcode = random.choice([True, False])
        width_photo = random.randint(int(0.2 * self.width), int(0.3 * self.width))
        height_photo = random.randint(int(0.5 * self.height), int(0.65 * self.height))
        # start_x = random.randint(int(0.01 * self.width), int(0.05 * self.width))
        start_x = 0
        end_x = int(start_x + width_photo)
        # start_y = random.randint(int(0.1 * self.height), int(0.2 * self.height))
        start_y = 0
        end_y = start_y + height_photo
        person_image = random.choice(self.people_photos_filenames)
        person_image_path = os.path.join(self.people_photos, person_image)
        photo_image = cv2.imread(person_image_path)
        photo_image = cv2.cvtColor(photo_image, cv2.COLOR_BGR2BGRA)
        end_y_final = end_y
        if put_barcode:
            height_barcode = int(0.2 * height_photo)
            width_barcode = width_photo
            barcode_image = random.choice(self.barcode_file_names)
            barcode_image_path = os.path.join(self.barcode, barcode_image)
            barcode_image = cv2.imread(barcode_image_path)
            barcode_image = cv2.cvtColor(barcode_image, cv2.COLOR_BGR2BGRA)
            start_y_barcode = end_y - height_barcode
            end_y_barcode = end_y
            end_y -= height_barcode
            height_photo -= height_barcode
            barcode_image = cv2.resize(barcode_image, (width_barcode, height_barcode))
            image_main[start_y_barcode:end_y_barcode, start_x:end_x] = barcode_image
            end_y_final = end_y_barcode

        photo_image = cv2.resize(photo_image, (width_photo, height_photo))
        image_main[start_y:end_y, start_x:end_x] = photo_image
        # new_image = cv2.addWeighted(image_main, 0.7, imagebg, 0.3, 0)
        image_main = cv2.cvtColor(image_main, cv2.COLOR_BGRA2GRAY)
        plot = False
        if plot:
            plt.figure()
            plt.imshow(image_main, cmap='gray')
            plt.show()
        return image_main, [start_x, end_x, start_y, end_y_final]

    def create_last_two_lines(self, first):
        line = []
        k = random.randint(4, 6)
        for word_num in range(k):
            word_len = random.randint(3, 14)
            char_len = random.randint(1, 14)
            if first:
                numbers_only = False
                number_and_letters = False
            else:
                numbers_only = random.choice([True, False])
                number_and_letters = random.choice([True, False])
            if numbers_only:
                word = ''.join(random.choices(self.english_numbers, k=random.randint(1, 6)))
            elif number_and_letters:
                word = ''.join(random.choices(self.english_letters, k=word_len))
                numbers = ''.join(random.choices(self.english_numbers, k=random.randint(1, 6)))
                word = list(word + numbers)
                random.shuffle(word)
                word = ''.join(word)
            else:
                word = ''.join(random.choices(self.english_letters, k=word_len))
            line.append(word)

            char = ''.join(random.choices(self.chars, k=char_len))
            line.append(char)
        line = ''.join(line[:-1])
        return line

    def draw_lines_seg_map(self, box, segmentation_map):  # draw line of seg map with height of 80& of original height
        # cv2.rectangle(segmentation_map, (x_start_draw, box[1]), (x_start_draw + (box[2] - box[0]), box[3]), (255, 255, 255),-1)
        y_line = box[1] + (box[3] - box[1]) // 2  # keda el y f nos el box
        height_line_seg_map = int((box[3] - box[1]) * 0.8)
        y_line = y_line - int(height_line_seg_map // 2)  # keda el y bdaytha 3nd 10%
        for height_count in range(height_line_seg_map):
            cv2.line(segmentation_map, (box[0], y_line + height_count), (box[2], y_line + height_count), 255, 1)
        return segmentation_map

    def put_last_two_lines(self, image_main, segmentation_map, coords_person_photo, coords_info):
        start_x_photo, end_x_photo, start_y_photo, end_y_photo = coords_person_photo
        start_x_info, end_x_info, start_y_info, end_y_info = coords_info
        start_y = end_y_photo + int(0.001 * self.height)
        # start_x = random.randint(int(0.01 * self.width), int(0.1 * self.width))
        start_x = start_x_photo
        # end_x = self.width - (start_x * 2)
        end_x = end_x_info
        width_two_lines = end_x - start_x
        height_below_photo_to_end = self.height - end_y_photo  # calculate available height to put the two text lines in it
        # height_two_lines = random.randint(int(0.8 * height_below_photo_to_end), int(0.9 * height_below_photo_to_end))
        height_two_lines = height_below_photo_to_end
        end_y = start_y + height_two_lines
        coords_two_lines = [start_x, end_x, start_y, end_y]
        first_line = self.create_last_two_lines(first=True)
        second_line = list(first_line)
        random.shuffle(second_line)
        second_line = ''.join(second_line)
        # second_line = self.create_last_two_lines(first=False)
        font_size = random.randint(10, 20)
        # english_font_path = random.choice(self.english_fonts_path)
        # english_font = ImageFont.truetype(english_font_path, font_size)
        bilingual_font = ImageFont.truetype(self.bilingual_font_path, font_size)
        width_sub_image = max(bilingual_font.getsize(first_line)[0],
                              bilingual_font.getsize(second_line)[0])
        width_sub_image = min(width_two_lines, width_sub_image)
        height_sub_image = max(bilingual_font.getsize(first_line)[1],
                               bilingual_font.getsize(second_line)[1]) * 3
        put_background = random.choice([True, False])
        if put_background:
            image_two_lines_main = Image.new("RGBA", (width_sub_image, height_sub_image), (255, 255, 255, 0))
            fill = (0, 0, 0, 200)
        else:
            image_two_lines_main = Image.new("L", (width_sub_image, height_sub_image), 255)
            fill = 0
        image_two_lines_main_black = np.zeros((height_sub_image, width_sub_image), dtype='uint8')
        image_draw = ImageDraw.Draw(image_two_lines_main)
        # draw first line
        x_start_draw = 5
        y_start_draw = 5
        box = image_draw.textbbox((x_start_draw, y_start_draw), first_line, font=bilingual_font, anchor="lt")
        image_draw.text((x_start_draw, box[1]), first_line, fill=fill, font=bilingual_font, anchor="lt")
        image_two_lines_main_black = self.draw_lines_seg_map(box, image_two_lines_main_black)

        # draw second line
        y_start_draw = box[3] + 2
        box = image_draw.textbbox((x_start_draw, y_start_draw), second_line, font=bilingual_font, anchor="lt")
        image_draw.text((x_start_draw, box[1]), second_line, fill=fill, font=bilingual_font, anchor="lt")
        image_two_lines_main_black = self.draw_lines_seg_map(box, image_two_lines_main_black)

        image_two_lines_main = image_two_lines_main.resize((width_two_lines, height_two_lines))
        image_two_lines_main_black = cv2.resize(image_two_lines_main_black, (width_two_lines, height_two_lines),
                                                interpolation=cv2.INTER_AREA)

        if put_background:
            image_two_lines_main = self.put_background(image_two_lines_main, "color")
        # image_two_lines_main = image_two_lines_main.convert("L")
        image_two_lines_main = np.array(image_two_lines_main)
        image_main[start_y:end_y, start_x:end_x] = image_two_lines_main
        segmentation_map[start_y:end_y, start_x:end_x] = image_two_lines_main_black
        plot = False
        if plot:
            plt.figure()
            plt.subplot(1, 2, 1)
            plt.imshow(image_main, cmap='gray', vmin=0, vmax=255)
            plt.title('Image')

            plt.subplot(1, 2, 2)
            plt.imshow(segmentation_map, cmap='gray')
            plt.title('Segmentation Map')

            plt.show()
        return image_main, segmentation_map, coords_two_lines

    def generate_date(self):
        arabic = random.choice([True, False])
        if arabic:
            numbers = self.arabic_numbers
            months = self.arabic_months
        else:
            numbers = self.english_numbers
            months = self.months

        date_structure_slash = random.choice([True, False])
        day = ''.join(random.choices(numbers, k=random.choice([1, 2])))
        year = ''.join(random.choices(numbers, k=4))
        if date_structure_slash:
            slash = random.choice([True, False])
            month = ''.join(random.choices(numbers, k=random.choice([1, 2])))
            if slash:
                date = "/".join([day, month, year])
            else:
                date = "-".join([day, month, year])
        else:
            month = random.choice(months)
            date = "   ".join([day, month, year])
        return date

    def generate_bilingual_line(self):
        line_len = random.randint(2, 8)
        line = []
        for i in range(line_len):
            arabic = random.choice([True, False])
            word_len = random.randint(2, 6)
            if arabic:
                word = ''.join(random.choices(self.arabic_letters, k=word_len))
            else:
                word = ''.join(random.choices(self.english_letters, k=word_len))
            line.append(word)
        line = "  ".join(line)
        return line

    def generate_name(self):
        arabic = random.choice([True, False])
        if arabic:
            letters = self.arabic_letters
        else:
            letters = self.english_letters

        name_len = random.randint(2, 8)
        name = []
        for i in range(name_len):
            word_len = random.randint(2, 6)
            word = ''.join(random.choices(letters, k=word_len))
            if not arabic:
                word = word.upper()
            name.append(word)
        name = "  ".join(name)
        return name

    def put_information_text_on_image(self, image_information, image_information_segmentation_map):
        font_size = random.randint(10, 20)
        bilingual_font = ImageFont.truetype(self.bilingual_font_path, font_size)

        width_image_information = image_information.width
        height_image_information = image_information.height

        image_draw = ImageDraw.Draw(image_information)
        x_start_draw = 5
        y_start_draw = 5
        while True:
            if y_start_draw > height_image_information - 10:
                break
            lines = [self.generate_name, self.generate_date, self.generate_bilingual_line]
            line = random.choice(lines)()
            text_size = bilingual_font.getsize(line)
            width_line = text_size[0]
            direction = random.choice(["rtl", "ltr", "center"])
            if direction == "rtl":
                x_start_draw = width_image_information - width_line - 4
            elif direction == "center":
                x_start_draw = (width_image_information // 2) - (width_line // 2)
            box_text = image_draw.textbbox((x_start_draw, y_start_draw), line, font=bilingual_font, anchor="lt")
            image_draw.text((x_start_draw, box_text[1]), line, fill=(0, 0, 0, 200), font=bilingual_font, anchor="lt")
            image_information_segmentation_map = self.draw_lines_seg_map(box_text, image_information_segmentation_map)

            y_start_draw = box_text[3] + 4

        plot = False
        if plot:
            plt.figure()
            plt.subplot(1, 2, 1)
            plt.imshow(image_information, cmap='gray', vmin=0, vmax=255)
            plt.title('Image')

            plt.subplot(1, 2, 2)
            plt.imshow(image_information_segmentation_map, cmap='gray')
            plt.title('Segmentation Map')

            plt.show()
        return image_information, image_information_segmentation_map

    def put_background(self, image, color_or_photo):
        width = image.width
        height = image.height
        if color_or_photo == "color":
            color = random.randint(200, 230)
            background_image = Image.new("RGBA", (width, height),
                                         (color, color, color, 0))
        else:
            backgroung_image_file = random.choice(self.background_images_filnames)
            background_image_path = os.path.join(self.background, backgroung_image_file)
            background_image = Image.open(background_image_path).convert("RGBA")
            background_image = background_image.resize((width, height))
        combined = Image.alpha_composite(background_image, image)
        combined = combined.convert("L")
        return combined

    def rotate_image(self, image,seg_map, color):
        rotate_angle = random.randint(-15, 15)
        width = image.shape[1]
        height = image.shape[0]
        (h_rotate, w_rotate) = image.shape[:2]
        center = (w_rotate // 2, h_rotate // 2)
        M = cv2.getRotationMatrix2D(center, rotate_angle, 1.0)
        rotated_image = cv2.warpAffine(image, M, (w_rotate, h_rotate),
                                       flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT, borderValue=color)
        result_image = cv2.resize(rotated_image, (width, height),
                                  interpolation=cv2.INTER_AREA)

        rotated_seg_map = cv2.warpAffine(seg_map, M, (w_rotate, h_rotate),
                                       flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT, borderValue=0)
        result_seg_map = cv2.resize(rotated_seg_map, (width, height),
                                  interpolation=cv2.INTER_AREA)

        return result_image, result_seg_map
    def create_informations_text(self, image_main, segmentation_map, coords_person_photo):
        start_x_photo, end_x_photo, start_y_photo, end_y_photo = coords_person_photo
        width_behind_photo_to_end = self.width - end_x_photo
        # image_information_width = random.randint(int(0.8 * width_behind_photo_to_end),
        #                                          int(width_behind_photo_to_end))
        image_information_width = width_behind_photo_to_end
        image_information_height = end_y_photo - start_y_photo
        start_x_information = end_x_photo
        end_x_information = start_x_information + image_information_width
        start_y_information = start_y_photo
        end_y_information = start_y_information + image_information_height
        coords_info = [start_x_information, end_x_information, start_y_information, end_y_information]
        image_information = Image.new("RGBA", (image_information_width, image_information_height), (255, 255, 255, 0))
        image_information_segmentation_map = np.zeros((image_information_height, image_information_width),
                                                      dtype='uint8')
        # self.create_information_lines()

        image_information, image_information_segmentation_map = self.put_information_text_on_image(image_information,
                                                                                                   image_information_segmentation_map)

        combined = self.put_background(image_information, "bg")

        image_main[start_y_information:end_y_information, start_x_information:end_x_information] = combined
        segmentation_map[start_y_information:end_y_information,
        start_x_information:end_x_information] = image_information_segmentation_map

        plot = False
        if plot:
            plt.figure()
            plt.subplot(1, 2, 1)
            plt.imshow(image_main, cmap='gray', vmin=0, vmax=255)
            plt.title('Image')

            plt.subplot(1, 2, 2)
            plt.imshow(segmentation_map, cmap='gray')
            plt.title('Segmentation Map')

            plt.show()
        return image_main, segmentation_map, coords_info

    def generate_passport(self):
        width, height = self.set_width_and_height()
        color = 255
        image_main = Image.new("RGBA", (width, height), (color, color, color, 1))
        image_main = np.array(image_main, dtype='uint8')
        segmentation_map = np.zeros((height, width), dtype='uint8')
        image_main, coords_photo = self.put_person_image(image_main)
        self.bilingual_font_path = random.choice(self.bilingual_fonts_path)
        image_main, segmentation_map, coords_info = self.create_informations_text(image_main, segmentation_map, coords_photo)
        image_main, segmentation_map, coords_two_lines = self.put_last_two_lines(image_main, segmentation_map, coords_photo, coords_info)
        put_background = random.choice([True, False])
        if put_background:
            color_or_bg = random.choice(["color", "bg"])
            if color_or_bg == "color":
                color = random.randint(150, 200)
                background_image = np.ones_like(image_main) * color
            else:
                backgroung_image_file = random.choice(self.background_images_filnames)
                background_image_path = os.path.join(self.background, backgroung_image_file)
                bg_image = cv2.imread(background_image_path, 0)
                background_image = cv2.resize(bg_image, (width, height), interpolation=cv2.INTER_AREA)

            image_main = cv2.addWeighted(image_main, 0.7, background_image, 0.3, 0)
        rotate_image = random.choices([True, False], k= 1, weights=[0.4,0.6])[0]
        if rotate_image:
            image_main, segmentation_map = self.rotate_image(image_main,segmentation_map, color= color)

        padding_page = random.choices([True, False], k=1, weights=[0.3, 0.7])[0]
        if padding_page:
            padding_value = random.randint(100,200)
            original_height = image_main.shape[0]
            original_width = image_main.shape[1]
            image_main = cv2.copyMakeBorder(image_main, padding_value, padding_value, padding_value, padding_value,
                                            borderType=cv2.BORDER_CONSTANT, value=255)
            image_main = cv2.resize(image_main, (original_width, original_height), interpolation=cv2.INTER_AREA)
            segmentation_map = cv2.copyMakeBorder(segmentation_map, padding_value, padding_value, padding_value,
                                                  padding_value, borderType=cv2.BORDER_CONSTANT, value=0)
            segmentation_map = cv2.resize(segmentation_map, (original_width, original_height),
                                          interpolation=cv2.INTER_AREA)

        return image_main, segmentation_map

    def generate_images(self):
        while True:
            try:
                # start = time.time()
                image_main, image_black_main = self.generate_passport()
                # end = time.time()
                # print(end - start)
                yield np.array(image_main, dtype='uint8')[..., np.newaxis], \
                      np.array(image_black_main, dtype='uint8')[..., np.newaxis]
            except Exception as e:
                print(e)
                continue


if __name__ == '__main__':
    lines_generator = LinesGenerator(assets_path=r'D:\All_Assets\passports\new_assets\assets', width=[500, 700], height=[300, 500])
    # lines_generator = LinesGenerator(assets_path='../../assets', width=500, height=300)
    lines_image = lines_generator.generate_images()
    i = 0
    for image_main, image_black_main in lines_image:
        # print("main_image")
        plt.figure()
        plt.subplot(1, 2, 1)
        plt.imshow(image_main, cmap='gray', vmin=0, vmax=255)
        plt.title('Image')

        plt.subplot(1, 2, 2)
        plt.imshow(image_black_main, cmap='gray')
        plt.title('Segmentation Map')

        # plt.subplot(1, 3, 3)
        # plt.imshow(test_img, cmap='gray')
        # plt.title('image test')

        # cv2.imwrite("../../output/" + str(i) + "_image_text.jpg",image_main)
        # cv2.imwrite("../../output/" + str(i) + "_image_text_map.jpg",image_black_main)
        # plt.savefig(os.path.join(r"D:\data\debug_generator", str(i) + "_image_text_map.jpg"))
        # print(i)
        # i+=1
        plt.show()
        # plt.close()
        # gc.collect()
