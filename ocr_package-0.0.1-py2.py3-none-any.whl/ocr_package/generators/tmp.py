import cv2
import imutils
import matplotlib.pyplot as plt
import numpy as np
# Load the image
image = cv2.imread(r"D:\gitlab_updated\ocr_package\ocr_package\generators\test_data\1_image_text.jpg")

# Define the rotation angle in degrees (replace with your desired angle)
angle = 45

# Rotate the image using imutils.rotate_bound
rotated_image = imutils.rotate_bound(image, angle)

# Get the dimensions of the rotated image

height, width = rotated_image.shape[:2]
tempX = x - cx;
tempY = y - cy;

rotatedX = tempX*cos(theta) - tempY*sin(theta);
rotatedY = tempX*sin(theta) + tempY*cos(theta);

x = rotatedX + cx;
y = rotatedY + cy;

# Print the coordinates of the four corners
print("Top-Left (tl):", tl)
print("Top-Right (tr):", tr)
print("Bottom-Right (br):", br)
print("Bottom-Left (bl):", bl)

cv2.circle(image, tl, 5, (0,0,255), 15)
cv2.circle(image, br, 5, (0,0,255), 15)
cv2.circle(image, tr, 5, 0, 15)
cv2.circle(image, bl, 5, 0, 15)
plt.imshow(rotated_image)
plt.show()