import json
path = r"entities.json"
with open(path) as f:
    data = json.load(f)

names_arabic = []
for item in data["PERSON"]["human"]:
    names_arabic.append(item["name_ar"])
print(names_arabic)
locations = []
for item in data["LOC"]:
    for subitem in data["LOC"][item]:
        locations.append(subitem["name_ar"])


print(locations)