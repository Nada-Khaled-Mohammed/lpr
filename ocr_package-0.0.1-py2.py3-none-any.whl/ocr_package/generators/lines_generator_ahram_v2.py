import cv2
import random
import numpy as np
import matplotlib.pylab as plt
from PIL import Image, ImageDraw, ImageFont, ImageOps
import os
import imutils
import gc


class LinesGenerator():
    def __init__(self, assets_path='../../assets', width=384, height=512):
        self.image_dataset_path = os.path.join(assets_path, 'images_bg')
        self.image_ahram_path = os.path.join(assets_path, 'images_bg')
        self.titles_ahram_path = os.path.join(assets_path, 'images_bg')
        self.width_original = width
        self.height_original = height
        self.image_filenames = os.listdir(self.image_dataset_path)
        self.image_ahram_filenames = os.listdir(self.image_ahram_path)
        self.titles_ahram_filenames = os.listdir(self.titles_ahram_path)
        # self.width = 1200
        # self.height = 2000
        arabic_fonts_dir = os.path.join(assets_path, "Arabic_Fonts")
        arabic_fonts_large_text_dir = os.path.join(assets_path, "Large_Fonts")
        english_fonts_dir = os.path.join(assets_path, "English_Fonts")
        # self.arabic_letters = "ءآأؤإئابةتثجحخدذرزسشصضطظعغفقكلمنهوىي"
        self.arabic_letters = ['آ', 'أ', 'ؤ', 'إ', 'ا', 'ب', 'ت', 'ث', 'ج', 'ح', 'خ', 'د', 'ذ', 'ر', 'ز',
                               'س', 'ش', 'ص', 'ض', 'ط', 'ظ', 'ع', 'غ', 'ف', 'ق', 'ك', 'ل', 'م', 'ن', 'ه', 'و', 'ي',
                               'ـــ', "ــــــ"]
        # self.arabic_letters = ['ء', 'آ', 'أ', 'ؤ', 'إ', 'ئ', 'ا', 'ب', 'ة', 'ت', 'ث', 'ج', 'ح', 'خ', 'د', 'ذ', 'ر', 'ز',
        #                        'س', 'ش', 'ص', 'ض', 'ط', 'ظ', 'ع', 'غ', 'ف', 'ق', 'ك', 'ل', 'م', 'ن', 'ه', 'و', 'ى', 'ي']
        self.arabic_ending_letters = ['ء', 'ى', 'ة', 'ئ']
        self.arabic_punctuation = ['؟', '؛', '،', '!', '...', '.', ':', '-']
        # '٪' '_'
        # self.english_punctuation = ['%', ',', '@', '$', '&', '?', ';', "'", '^', ':-']

        # self.general_punctuation = ['!', '-', '.', '/', ':', '..', '*', '+', '×', '÷', '=']

        # self.any_punctuation = ['؟', '؛', '،', 'ـ', '%', ',', '@', '$', '&', '?', ';', "'", '^', ':-', '!', '-', '.', '/',
        #                    ':', '..', '*', '+', '×', '÷', '=']
        self.chars = ['<']
        self.english_letters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q',
                                'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
        self.text_only_list = ['31.ttf', '35.ttf', "alfont_com_AlFont_com_BJadidBold.ttf",
                               "alfont_com_Sp_Jadid-Bold_p30download.com_.ttf", "ArbFONTS-B-Jadid-Bold.ttf",
                               "Sp_Maryam-Bold_p30download.com_.ttf", "Sp_Jadid-Bold_p30download.com_.ttf"]
        self.arabic_numbers = "١٢٣٤٥٦٧٨٩٠"
        self.english_numbers = "1234567890"
        self.arabic_fonts_path = []
        for font in os.listdir(arabic_fonts_dir):
            self.arabic_fonts_path.append(os.path.join(arabic_fonts_dir, font))
        self.arabic_fonts_large_text_path = []
        for font in os.listdir(arabic_fonts_large_text_dir):
            self.arabic_fonts_large_text_path.append(os.path.join(arabic_fonts_large_text_dir, font))
        self.english_fonts_path = []
        for font in os.listdir(english_fonts_dir):
            self.english_fonts_path.append(os.path.join(english_fonts_dir, font))
        # self.arabic_lines, self.english_lines = self.create_words_and_lines()

    def create_line(self, font, width, put_more_spaces, put_numbers, line_len):
        # numbers_only = random.choices([True, False], k=1, weights=[0.3, 0.7])[0]
        numbers_only = False
        if numbers_only:
            line_len = random.randint(1, 16)
            numbers = random.choices(self.arabic_numbers, k=line_len)
            line = "".join(numbers)
            return line

        if put_numbers:
            put_numbers_english = random.choices([True, False], k=1, weights=[0.2, 0.8])[0]
        else:
            put_numbers_english = False
        # line_len = random.randint(1, 10)
        line = []
        line_w = 0
        for i in range(line_len):
            put_punc = random.choices([True, False], k=1, weights=[0.1, 0.9])[0]
            # put_comma = random.choices([True, False], k=1, weights=[0.1, 0.9])[0]
            # put_dash = random.choices([True, False], k=1, weights=[0.1, 0.9])[0]
            # put_comma = False
            # put_dash = False
            word_len = random.randint(2, 6)
            word = ''.join(random.choices(self.arabic_letters, k=word_len))
            put_end_letter = random.choice([True, False])
            if put_end_letter:
                word = word + (random.choice(self.arabic_ending_letters))
            line_w += font.getsize(word)[0]
            if line_w > width - 5:
                if i == 0:
                    if word_len // 2 < 2:
                        word = ''.join(random.choices(self.arabic_letters, k=2))
                    else:
                        word = ''.join(random.choices(self.arabic_letters, k=word_len // 2))
                    # reshaped_text = arabic_reshaper.reshape(word)
                    # word = get_display(reshaped_text)
                    return word
                break
            # reshaped_text = arabic_reshaper.reshape(word)
            # word = get_display(reshaped_text)
            line.append(word)
            if put_punc:
                char = random.choices(self.arabic_punctuation, k=1)[0]
                line.append(char)
            # elif put_dash:
            #     line.append('-')
        # line = random.choices(self.arabic_words, k=line_len)
        if put_numbers:
            number = random.choices(self.arabic_numbers, k=random.randint(1, 4))
            number = "".join(number)
            line.append(number)
        elif put_numbers_english:
            number = random.choices(self.english_numbers, k=random.randint(1, 4))
            number = "".join(number)
            line.append(number)
        new_line = []
        if put_more_spaces:
            for i in range(len(line)):
                if i == len(line) - 1:
                    new_line.append(line[i])
                    break
                spaces = random.choice(["   ", "    "])
                new_line.append(line[i])
                new_line.append(spaces)
            line = "".join(new_line)
        else:
            line = " ".join(line)
        return line

    def create_line_english(self, font, width, line_len):
        # numbers_only = random.choices([True, False], k=1, weights=[0.3, 0.7])[0]
        numbers_only = False
        if numbers_only:
            line_len = random.randint(1, 10)
            numbers = random.choices(self.english_numbers, k=line_len)
            line = "".join(numbers)
            return line

        put_numbers = random.choice([True, False])
        # line_len = random.randint(1, 10)
        line = []
        line_w = 0
        for i in range(line_len):
            word_len = random.randint(2, 6)
            word = ''.join(random.choices(self.english_letters, k=word_len))
            line_w += font.getsize(word)[0]
            if line_w > width - 5:
                if i == 0:
                    if word_len // 2 < 2:
                        word = ''.join(random.choices(self.english_letters, k=2))
                    else:
                        word = ''.join(random.choices(self.english_letters, k=word_len // 2))
                    return word
                break
            line.append(word)
        if put_numbers:
            number = random.choices(self.english_numbers, k=random.randint(1, 4))
            number = "".join(number)
            line.append(number)
        line = " ".join(line)
        # line_w = font.getsize(line)[0]
        # while line_w > width - 5:
        #     word_len = random.randint(2, 6)
        #     line = ''.join(random.choices(self.english_letters, k=word_len))
        #     line_w = font.getsize(line)[0]
        return line

    def put_image(self, width_sub_image, height_sub_image, color_main):
        put_line_below_image = random.choice([True, False])
        # put_image_ahram = random.choice([True, False])
        # if put_image_ahram:
        image_file = random.choice(self.image_ahram_filenames)
        image_path = os.path.join(self.image_ahram_path, image_file)
        # put_line_below_image = False
        # else:
        #     image_file = random.choice(self.image_filenames)
        #     image_path = os.path.join(self.image_dataset_path, image_file)
        # image = Image.new('RGB', (width_sub_image,height_sub_image), (0, 0, 0))
        image = Image.open(image_path)
        image = image.resize((width_sub_image, height_sub_image))
        image = ImageOps.grayscale(image)
        # image_black = Image.new('RGB', (width_sub_image, height_sub_image), (0, 0, 0))
        image_black = np.zeros((height_sub_image, width_sub_image), dtype='uint8')
        right = 2
        left = 2
        top = 2
        bottom = 2
        new_width = width_sub_image + right + left
        new_height = height_sub_image + top + bottom
        result_image = np.ones((new_height, new_width), dtype='uint8') * color_main
        result_image[top:new_height - bottom, left:new_width - right] = image
        result_image = cv2.resize(result_image, (width_sub_image, height_sub_image), interpolation=cv2.INTER_AREA)

        if put_line_below_image:
            font_size = random.randint(20, 30)
            arabic_font_path = random.choice(self.arabic_fonts_path)
            font_type = ImageFont.truetype(arabic_font_path, font_size)
            line_len = random.randint(2, 12)
            line = self.create_line(font_type, width_sub_image, False, put_numbers=False, line_len=line_len)
            text_size = font_type.getsize(line)
            width_line = text_size[0]
            x1_new = (width_sub_image // 2) - (width_line // 2)
            # region generate new image
            w_h = (width_sub_image, text_size[1])
            image_new = Image.new('L', w_h, color_main)
            image_black_new = np.zeros((height_sub_image + text_size[1], width_sub_image), dtype='uint8')
            image_draw = ImageDraw.Draw(image_new)
            # endregion
            y1_box = height_sub_image
            box_text = image_draw.textbbox((x1_new, y1_box), line, font=font_type, anchor="lt")

            box_rectangle_seg_map = [x1_new - 2, box_text[1], box_text[2] + 4, box_text[3]]

            y_line = box_rectangle_seg_map[1] + (
                    box_rectangle_seg_map[3] - box_rectangle_seg_map[1]) // 2  # keda el y f nos el box
            height_line_seg_map = int((box_rectangle_seg_map[3] - box_rectangle_seg_map[1]) * 0.8)
            y_line = y_line - int(height_line_seg_map // 2)  # keda el y bdaytha 3nd 10%
            for height_count in range(height_line_seg_map):
                cv2.line(image_black_new, (box_rectangle_seg_map[0], y_line + height_count),
                         (box_rectangle_seg_map[2], y_line + height_count), 255, 1)
            image_draw.text((x1_new, 0), line, fill=0, font=font_type, anchor="lt")

            result_image_final = np.ones((height_sub_image + text_size[1], width_sub_image), dtype='uint8') * color_main
            result_image_final[0:height_sub_image, 0:width_sub_image] = image
            result_image_final[height_sub_image:, 0:width_sub_image] = image_new
            result_image_final = cv2.resize(result_image_final, (width_sub_image, height_sub_image),
                                            interpolation=cv2.INTER_AREA)
            image_black_new = cv2.resize(image_black_new, (width_sub_image, height_sub_image),
                                         interpolation=cv2.INTER_AREA)
            return [width_sub_image, height_sub_image], result_image_final, image_black_new

        return [width_sub_image, height_sub_image], result_image, image_black

    # most important function
    # put text on parameter passed image
    # put line by line, draw.textbox get box for each line
    def put_text_on_sub_image(self, image, image_black, height, width, english_font, arabic_font, booleans,
                              direction, color_text,color_main, arabic_font_path,fixed_line_len=random.randint(1, 20), put_title_done = False):
        direction_original = direction
        image_draw = ImageDraw.Draw(image)
        image_vertical = image.copy()
        image_draw_vertical = ImageDraw.Draw(image_vertical)

        # put_vertical_text = random.choice([True, False])
        put_vertical_text = False
        vertical_done = False
        if put_vertical_text:
            # direction = random.choice([direction,"vertical"])
            direction = "vertical"
        y1_box = 0
        make_narrow_spaces = random.choice([True, False])
        make_more_spaces_between_text = random.choice([True, False])
        w_h = [width, height]
        # put_title_done = False
        # all_lines_same_width = random.choice([True, False])
        # all_lines_same_width = True
        # fixed_line_len = random.randint(3, 10)
        while True:
            # region define font type depend on language and create line
            if booleans["all_lines_same_width"]:
                line_len = fixed_line_len
            else:
                line_len = random.randint(1, 20)
            if booleans["all_lines_cell_is_english"]:
                booleans["put_english"] = True
            if booleans["put_english"]:
                if booleans["all_lines_cell_is_english"]:
                    create_english_line = True
                else:
                    create_english_line = random.choice([True, False])
                if create_english_line:
                    line = self.create_line_english(english_font, width, line_len)
                    font_type = english_font
                else:
                    if os.path.split(arabic_font_path)[-1] in self.text_only_list:
                        line = self.create_line(arabic_font, width, booleans["one_column_more_spaces"],
                                                put_numbers=False, line_len=line_len)
                    else:
                        put_numbers = random.choices([True, False], k=1, weights=[0.1, 0.9])[0]
                        line = self.create_line(arabic_font, width, booleans["one_column_more_spaces"],
                                                put_numbers=put_numbers,line_len=line_len)
                    font_type = arabic_font
            else:
                if os.path.split(arabic_font_path)[-1] in self.text_only_list:
                    line = self.create_line(arabic_font, width, booleans["one_column_more_spaces"], put_numbers=False,line_len=line_len)
                else:
                    put_numbers = random.choices([True, False], k=1, weights=[0.1, 0.9])[0]
                    line = self.create_line(arabic_font, width, booleans["one_column_more_spaces"],
                                            put_numbers=put_numbers, line_len=line_len)
                font_type = arabic_font
            # endregion
            # print(line)
            put_title = random.choice([True, False])
            # put_title = random.choices([True, False],k=1,weights=[0.1,0.9])
            text_size = font_type.getsize(line)
            y2_box = y1_box + text_size[1]
            if put_title and not put_title_done:
                text_height = random.randint(text_size[1],text_size[1]+30)
                y2_box = y1_box + text_height
            if y2_box > w_h[1]:
                break
            if put_title and not put_title_done:
                put_title_done = True
                image_title, image_black_title, width_title_image, height_title_image, x_title, y_title = \
                    self.make_title(width, text_height, color_main, color_text, y1_box)
                x_title_2 = x_title+width_title_image
                if vertical_done and direction_original == "rtl":
                    if width_title_image - image_vertical_crop.shape[1] -4 > 0:
                        x_title_2 = (x_title+width_title_image) -4- image_vertical_crop.shape[1]
                        image_title = cv2.resize(image_title, (width_title_image-4-image_vertical_crop.shape[1], height_title_image),
                                                 interpolation=cv2.INTER_AREA)
                        image_black_title = cv2.resize(image_black_title,
                                                 (width_title_image -4- image_vertical_crop.shape[1], height_title_image),
                                                 interpolation=cv2.INTER_AREA)
                image.paste(Image.fromarray(image_title),[x_title,y_title, x_title_2, y_title+height_title_image])
                image_black[y_title:y_title + height_title_image, x_title:x_title_2] = image_black_title
                y1_box = y_title + height_title_image + 2
                continue
            if direction == "rtl":
                width_line = text_size[0]
                if vertical_done:
                    x = w_h[0] - width_line - 4 - image_vertical_crop.shape[1]
                else:
                    x = w_h[0] - width_line - 4
                box_text = image_draw.textbbox((x, y1_box), line, font=font_type, anchor="lt")

                box_rectangle_seg_map = [box_text[0] - 2, box_text[1], box_text[2] + 4, box_text[3]]
                box_rounded_rectangle = [box_text[0] - 2, box_text[1] - 2,
                                         box_text[2] + 4, box_text[3] + 2]

                # cv2.rectangle(image_black, (box_rectangle_seg_map[0], box_rectangle_seg_map[1]),
                #               (box_rectangle_seg_map[2], box_rectangle_seg_map[3]), 255, -1)
                # cv2.rectangle(image_black, (box_rounded_rectangle[0], box_rounded_rectangle[1]),
                #               (box_rounded_rectangle[2], box_rounded_rectangle[3]), 0, 2)
                y_line = box_rectangle_seg_map[1] + (
                        box_rectangle_seg_map[3] - box_rectangle_seg_map[1]) // 2  # keda el y f nos el box
                height_line_seg_map = int((box_rectangle_seg_map[3] - box_rectangle_seg_map[1]) * 0.8)
                y_line = y_line - int(height_line_seg_map // 2)  # keda el y bdaytha 3nd 10%
                for height_count in range(height_line_seg_map):
                    cv2.line(image_black, (box_rectangle_seg_map[0], y_line + height_count),
                             (box_rectangle_seg_map[2], y_line + height_count),
                             255,
                             1)
                # cv2.rectangle(image_black,(x,y1_box),(x+width_line,y2_box),0,1)

                # image_draw.rectangle(box_rectangle_seg_map, fill="gray")
                # image_draw.rounded_rectangle(box_rounded_rectangle, outline="white", width=2)
                if booleans["put_invert"] and booleans["inverted_block"]:
                    if booleans["background_image"] or booleans["background_main_is_image"]:
                        fill = (255, 255, 255)
                    else:
                        fill = 255
                elif booleans["put_invert"]:
                    put_inverted = random.choice([True, False])
                    if put_inverted:
                        image_draw.rectangle(box_rectangle_seg_map, fill="black")
                        if booleans["background_image"] or booleans["background_main_is_image"]:
                            fill = (255, 255, 255)
                        else:
                            fill = 255
                    else:
                        fill = color_text
                elif booleans["put_frame"]:
                    put_frame = random.choice([True, False])
                    fill = color_text
                    if put_frame:
                        if (x + width_line + 4) >= w_h[0]:
                            if box_text[3] + 2 >= height:
                                self.draw_four_lines(image_draw, box_text[0] - 2, box_text[1] - 1, w_h[0] - 1,
                                                     height - 1)
                                # image_draw.rounded_rectangle([box_text[0] - 2, box_text[1] - 1,
                                #                               w_h[0] - 1, height - 1], outline="black", width=1)
                            else:
                                self.draw_four_lines(image_draw, box_text[0] - 2, box_text[1] - 1, w_h[0] - 1,
                                                     box_text[3] + 1)
                                # image_draw.rounded_rectangle([box_text[0] - 2, box_text[1] - 1,
                                #                               w_h[0] - 1, box_text[3] + 1], outline="black", width=1)
                        else:
                            if box_text[3] + 2 >= height:
                                self.draw_four_lines(image_draw, box_text[0] - 2, box_text[1] - 1,
                                                     box_text[2] + 3, height - 1)
                                # image_draw.rounded_rectangle([box_text[0] - 2, box_text[1] - 1,
                                #                               box_text[2] + 3, height - 1], outline="black", width=1)
                            else:
                                self.draw_four_lines(image_draw, box_text[0] - 2, box_text[1] - 1,
                                                     box_text[2] + 4, box_text[3] + 1)
                                # image_draw.rounded_rectangle([box_text[0] - 2, box_text[1] - 1,
                                #                               box_text[2] + 4, box_text[3] + 1], outline="black",
                                #                              width=1)  # normal case
                else:
                    fill = color_text
                image_draw.text((x, y1_box), line, fill=fill, font=font_type, anchor="lt")
                if make_narrow_spaces:
                    y1_box = box_rounded_rectangle[3] - 2
                elif make_more_spaces_between_text:
                    y1_box = box_rounded_rectangle[3] + 10
                else:
                    y1_box = box_rounded_rectangle[3] + 2

            elif direction == "ltr":
                x = 2
                width_line = text_size[0]

                box_text = image_draw.textbbox((x, y1_box), line, font=font_type, anchor="lt")

                box_rectangle_seg_map = [x - 2, box_text[1], box_text[2] + 4, box_text[3]]
                box_rounded_rectangle = [x - 2, box_text[1] - 2,
                                         box_text[2] + 4, box_text[3] + 2]

                # cv2.rectangle(image_black, (box_rectangle_seg_map[0], box_rectangle_seg_map[1]),
                #               (box_rectangle_seg_map[2], box_rectangle_seg_map[3]), 255, -1)
                # cv2.rectangle(image_black, (box_rounded_rectangle[0], box_rounded_rectangle[1]),
                #               (box_rounded_rectangle[2], box_rounded_rectangle[3]), 0, 2)
                y_line = box_rectangle_seg_map[1] + (
                        box_rectangle_seg_map[3] - box_rectangle_seg_map[1]) // 2  # keda el y f nos el box
                height_line_seg_map = int((box_rectangle_seg_map[3] - box_rectangle_seg_map[1]) * 0.8)
                y_line = y_line - int(height_line_seg_map // 2)  # keda el y bdaytha 3nd 10%
                for height_count in range(height_line_seg_map):
                    cv2.line(image_black, (box_rectangle_seg_map[0], y_line + height_count),
                             (box_rectangle_seg_map[2], y_line + height_count),
                             255,
                             1)
                # cv2.rectangle(image_black,(x,y1_box),(x+width_line,y2_box),0,1)

                # overlay for test
                # image_draw.rectangle(box_rectangle_seg_map, fill="gray")
                # image_draw.rounded_rectangle(box_rounded_rectangle, outline="white", width=2)

                if booleans["put_invert"] and booleans["inverted_block"]:
                    if booleans["background_image"] or booleans["background_main_is_image"]:
                        fill = (255, 255, 255)
                    else:
                        fill = 255
                elif booleans["put_invert"]:
                    put_inverted = random.choice([True, False])
                    if put_inverted:
                        image_draw.rectangle(box_rectangle_seg_map, fill="black")
                        if booleans["background_image"] or booleans["background_main_is_image"]:
                            fill = (255, 255, 255)
                        else:
                            fill = 255
                    else:
                        fill = color_text

                elif booleans["put_frame"]:
                    put_frame = random.choice([True, False])
                    if put_frame:
                        if (x + width_line + 4) >= w_h[0]:
                            if box_text[3] + 1 >= height:
                                self.draw_four_lines(image_draw, 0, box_text[1] - 1, w_h[0] - 1, height - 1)
                                # image_draw.rounded_rectangle([0, box_text[1] - 1, w_h[0] - 1, height - 1],
                                #                              outline="black", width=1)
                            else:
                                self.draw_four_lines(image_draw, 0, box_text[1] - 1, w_h[0] - 1, box_text[3] + 1)
                                # image_draw.rounded_rectangle([0, box_text[1] - 1, w_h[0] - 1, box_text[3] + 1],
                                #                              outline="black", width=1)
                        else:
                            if box_text[3] + 1 >= height:
                                self.draw_four_lines(image_draw, 0, box_text[1] - 1, x + width_line + 4, height - 1)
                                # image_draw.rounded_rectangle([0, box_text[1] - 1, x + width_line + 4, height - 1],
                                #                              outline="black", width=1)
                            else:
                                self.draw_four_lines(image_draw, 0, box_text[1] - 1, x + width_line + 4,
                                                     box_text[3] + 1)
                                # image_draw.rounded_rectangle([0, box_text[1] - 1, x + width_line + 4, box_text[3] + 1],
                                #                              outline="black", width=1)
                    fill = color_text
                else:
                    fill = color_text
                image_draw.text((x, y1_box), line, fill=fill, font=font_type, anchor="lt")
                if make_narrow_spaces:
                    y1_box = box_rounded_rectangle[3] - 2
                elif make_more_spaces_between_text:
                    y1_box = box_rounded_rectangle[3] + 10
                else:
                    y1_box = box_rounded_rectangle[3] + 2

            elif direction == "center":
                # x = w_h[0]//2
                width_line = text_size[0]
                x1_new = (w_h[0] // 2) - (width_line // 2)
                x2_new = (w_h[0] // 2) + (width_line // 2)
                # cv2.rectangle(image_black, (x1_new, y1_box), (x2_new , y2_box), 255, -1)

                box_text = image_draw.textbbox((x1_new, y1_box), line, font=font_type, anchor="lt")

                box_rectangle_seg_map = [x1_new - 2, box_text[1], box_text[2] + 4, box_text[3]]
                box_rounded_rectangle = [x1_new - 2, box_text[1] - 2,
                                         box_text[2] + 4, box_text[3] + 2]

                # cv2.rectangle(image_black, (box_rectangle_seg_map[0], box_rectangle_seg_map[1]),
                #               (box_rectangle_seg_map[2], box_rectangle_seg_map[3]), 255, -1)
                # cv2.rectangle(image_black, (box_rounded_rectangle[0], box_rounded_rectangle[1]),
                #               (box_rounded_rectangle[2], box_rounded_rectangle[3]), 0, 2)
                y_line = box_rectangle_seg_map[1] + (
                        box_rectangle_seg_map[3] - box_rectangle_seg_map[1]) // 2  # keda el y f nos el box
                height_line_seg_map = int((box_rectangle_seg_map[3] - box_rectangle_seg_map[1]) * 0.8)
                y_line = y_line - int(height_line_seg_map // 2)  # keda el y bdaytha 3nd 10%
                for height_count in range(height_line_seg_map):
                    cv2.line(image_black, (box_rectangle_seg_map[0], y_line + height_count),
                             (box_rectangle_seg_map[2], y_line + height_count),
                             255,
                             1)
                # cv2.rectangle(image_black,(x,y1_box),(x+width_line,y2_box),0,1)

                # overlay for test
                # image_draw.rectangle(box_rectangle_seg_map, fill="gray")
                # image_draw.rounded_rectangle(box_rounded_rectangle, outline="white", width=2)

                # image_black_draw.rectangle([x1_new, y1_box, x2_new, y2_box], fill="white")
                # image_black_draw.rounded_rectangle([x1_new, y1_box, x2_new, y2_box], outline="black", width=2)
                if booleans["put_invert"] and booleans["inverted_block"]:
                    if booleans["background_image"] or booleans["background_main_is_image"]:
                        fill = (255, 255, 255)
                    else:
                        fill = 255
                    # image_draw.text((x, y1_box + ((y2_box - y1_box) // 2)), all_lines[i][0], fill="white",font=font_type, anchor="ms")
                elif booleans["put_invert"]:
                    put_inverted = random.choice([True, False])
                    if put_inverted:
                        image_draw.rectangle(box_rectangle_seg_map, fill="black")
                        if booleans["background_image"] or booleans["background_main_is_image"]:
                            fill = (255, 255, 255)
                        else:
                            fill = 255
                    else:
                        fill = color_text
                elif booleans["put_frame"]:
                    put_frame = random.choice([True, False])
                    fill = color_text
                    if put_frame:
                        if (x2_new + 4) >= w_h[0]:
                            if box_text[3] + 1 >= height:
                                self.draw_four_lines(image_draw, x1_new - 2, box_text[1] - 1, w_h[0] - 1, height - 1)
                                # image_draw.rounded_rectangle([x1_new - 2, box_text[1] - 1, w_h[0] - 1, height - 1],
                                #                              outline="black", width=1)
                            else:
                                self.draw_four_lines(image_draw, x1_new - 2, box_text[1] - 1, w_h[0] - 1,
                                                     box_text[3] + 1)
                                # image_draw.rounded_rectangle([x1_new - 2, box_text[1] - 1, w_h[0] - 1, box_text[3] + 1],
                                #                              outline="black", width=1)
                        else:
                            if box_text[3] + 1 >= height:
                                self.draw_four_lines(image_draw, x1_new - 2, box_text[1] - 1, x2_new + 4, height - 1)
                                # image_draw.rounded_rectangle([x1_new - 2, box_text[1] - 1, x2_new + 4, height - 1],
                                #                              outline="black", width=1)
                            else:
                                self.draw_four_lines(image_draw, x1_new - 2, box_text[1] - 1, x2_new + 4,
                                                     box_text[3] + 1)
                                # image_draw.rounded_rectangle([x1_new - 2, box_text[1] - 1, x2_new + 4, box_text[3] + 1],
                                #                              outline="black", width=1)

                else:
                    fill = color_text
                image_draw.text((x1_new, y1_box), line, fill=fill, font=font_type, anchor="lt")
                if make_narrow_spaces:
                    y1_box = box_rounded_rectangle[3] - 2
                elif make_more_spaces_between_text:
                    y1_box = box_rounded_rectangle[3] + 10
                else:
                    y1_box = box_rounded_rectangle[3] + 2

            elif direction == "vertical" and not vertical_done:
                vertical_done = True
                direction = direction_original
                if direction_original != "rtl":
                    continue
                width_line = text_size[0]
                x = w_h[0] - width_line - 4
                box_text = image_draw.textbbox((x, y1_box), line, font=font_type, anchor="lt")

                box_rectangle_seg_map = [box_text[0] - 2, box_text[1], box_text[2] + 4, box_text[3]]
                box_rounded_rectangle = [box_text[0] - 2, box_text[1] - 2,
                                         box_text[2] + 4, box_text[3] + 2]

                # cv2.rectangle(image_black,(x,y1_box),(x+width_line,y2_box),0,1)

                # image_draw.rectangle(box_rectangle_seg_map, fill="gray")
                # image_draw.rounded_rectangle(box_rounded_rectangle, outline="white", width=2)
                if booleans["put_invert"] and booleans["inverted_block"]:
                    if booleans["background_image"] or booleans["background_main_is_image"]:
                        fill = (255, 255, 255)
                    else:
                        fill = 255
                elif booleans["put_invert"]:
                    put_inverted = random.choice([True, False])
                    if put_inverted:
                        image_draw.rectangle(box_rectangle_seg_map, fill="black")
                        if booleans["background_image"] or booleans["background_main_is_image"]:
                            fill = (255, 255, 255)
                        else:
                            fill = 255
                    else:
                        fill = color_text
                else:
                    fill = color_text

                image_draw_vertical.text((x, y1_box), line, fill=fill, font=font_type, anchor="lt")
                # plt.figure()
                # plt.imshow(image_vertical, cmap='gray', vmin=0, vmax=255)
                # plt.title('image_tmp_vertical')
                # plt.show()

                image_vertical = np.array(image_vertical)
                image_vertical = imutils.rotate_bound(image_vertical, angle=90)
                image_vertical_crop = image_vertical[0:image_vertical.shape[0], image_vertical
                                                                                .shape[1] - text_size[1]:
                                                                                image_vertical.shape[1]]
                # image_vertical = cv2.resize(image_vertical,(box_text[3]-box_text[1],box_text[2]-box_text[0]), interpolation=cv2.INTER_AREA)
                image = np.array(image)
                image_vertical_crop = cv2.resize(image_vertical_crop, (image_vertical_crop.shape[1], image.shape[0]),
                                                 interpolation=cv2.INTER_AREA)
                image[0:image_vertical_crop.shape[0],
                image.shape[1] - text_size[1]:image.shape[1]] = image_vertical_crop
                image = Image.fromarray(image)
                image_draw = ImageDraw.Draw(image)

                '''
                # add vertical line in segmentation map 
                # image_black_vertical = np.zeros_like(image_vertical)
                # cv2.rectangle(image_black_vertical, (box_rectangle_seg_map[0], box_rectangle_seg_map[1]),
                #               (box_rectangle_seg_map[2], box_rectangle_seg_map[3]), 255, -1)
                # image_black_vertical = imutils.rotate_bound(image_black_vertical, angle=90)
                # image_black_vertical_crop = image_black_vertical[0:image_black_vertical.shape[0], image_black_vertical
                #                                                                 .shape[1] - text_size[1]:
                #                                                                 image_black_vertical.shape[1]]
                # image_black_vertical_crop = cv2.resize(image_black_vertical_crop, (image_black_vertical_crop.shape[1], image_black.shape[0]),
                #                                  interpolation=cv2.INTER_AREA)
                # image_black[0:image_black_vertical_crop.shape[0],
                # image_black.shape[1] - text_size[1]:image_black.shape[1]] = image_black_vertical_crop
                '''
                # image.paste(Image.fromarray(image_vertical), box=(width-text_size[1],0))
                # plt.figure()
                # plt.imshow(image_vertical, cmap='gray', vmin=0, vmax=255)
                # plt.title('image_tmp_vertical')
                # plt.show()
                # plt.figure()
                # plt.imshow(image_vertical_crop, cmap='gray', vmin=0, vmax=255)
                # plt.title('image_tmp_vertical')
                # plt.show()
                # plt.figure()
                # plt.imshow(image, cmap='gray', vmin=0, vmax=255)
                # plt.title('image_tmp_vertical')
                # plt.show()

        return image, image_black

    # draw rounded rectangle (frame) around text
    def draw_four_lines(self, image_draw, x1, y1, x2, y2):

        image_draw.line([x1, y1, x2, y1], width=1, fill="black")  # horizontal
        image_draw.line([x1, y2, x2, y2], width=1, fill="black")

        image_draw.line([x1, y1, x1, y2], width=1, fill="black")  # vertical
        image_draw.line([x2, y1, x2, y2], width=1, fill="black")

    # the main function to generate text columns
    def generate_image_column_structure(self, new_width_main, new_height_main, color_main, color_text_old, color_text,
                                        booleans):

        if booleans["background_main_is_image"]:
            color_text = 0
            color_text_old = color_text
            image_file = random.choice(self.image_filenames)
            image_path = os.path.join(self.image_dataset_path, image_file)
            imagebg = cv2.imread(image_path)
            imagebg = cv2.cvtColor(imagebg, cv2.COLOR_BGR2BGRA)

        image_main = np.ones((new_height_main, new_width_main), dtype='uint8') * color_main
        image_black_main = np.zeros((new_height_main, new_width_main), dtype='uint8')
        x_start = 1
        y_start = 1
        y_title = 1
        # make_title = random.choice([True, False])
        make_title = True
        put_second_title = random.choice([True, False])
        # put_second_title = True
        if make_title:
            image, image_black, width, height, x, y = self.make_title(new_width_main, new_height_main, color_main,
                                                                      color_text, y_start)
            image_main[y:y + height, x:x + width] = image
            image_black_main[y:y + height, x:x + width] = image_black
            y_start += y + height
            y_title += y + height
            if put_second_title:
                image, image_black, width, height, x, y = self.make_title(new_width_main, new_height_main, color_main,
                                                                          color_text, y_start)
                if y >= new_height_main:
                    return image_main, image_black_main
                if y + height > new_height_main:
                    image = cv2.resize(image, (width, new_height_main - y), interpolation=cv2.INTER_AREA)
                    image_black = cv2.resize(image_black, (width, new_height_main - y), interpolation=cv2.INTER_AREA)
                    height = image_black.shape[0]
                    image_main[y:y + height, x:x + width] = image
                    image_black_main[y:y + height, x:x + width] = image_black
                    return image_main, image_black_main
                image_main[y:y + height, x:x + width] = image
                image_black_main[y:y + height, x:x + width] = image_black
                y_start = y + height
                y_title = y + height

        # region define initial values
        booleans["put_image_box"] = False
        booleans["all_lines_same_width"] = False
        booleans["inverted_block"] = False
        booleans["put_vertical_line"] = False
        booleans["put_horizontal_line"] = False
        booleans["put_segment_frame"] = False
        # booleans["put_lines"] = random.choices([True, False], k=1, weights=[0.2, 0.8])[0]
        booleans["put_lines"] = True
        booleans["segment_frame"] = random.choices([True, False], k=1, weights=[0.2, 0.8])[0]

        # endregion

        # region define fixed font type and size and text direction for all columns
        # font_size = random.randint(8, 30)
        font_size = random.randint(int(new_width_main*0.007), int(new_width_main*0.03))
        arabic_font_path = random.choice(self.arabic_fonts_path)
        arabic_font = ImageFont.truetype(arabic_font_path, font_size)
        english_font_path = random.choice(self.english_fonts_path)
        english_font = ImageFont.truetype(english_font_path, font_size)
        direction = random.choice(["rtl", "ltr", "center"])
        # endregion
        # if new_width_main * 0.006 < 1:
        #     col_slices = 1
        # else:
        #     try:
        #         col_slices = random.randint(1, int(new_width_main * 0.003))
        #     except:
        #         col_slices = 1
        # if new_height_main * 0.007 < 1:
        #     row_slices = 1
        # else:
        #     row_slices = random.randint(1, int(new_height_main * 0.003))
        col_slices = random.randint(1, int(3))
        row_slices = random.randint(1, int(3))
        col_slices = random.choice([col_slices, 1])
        row_slices = random.choice([col_slices, 1])
        # col_slices = 1
        # row_slices = 1
        width_sub_image = (new_width_main - x_start) // col_slices
        height_sub_image = (new_height_main - y_start) // row_slices
        if height_sub_image == 0 or width_sub_image == 0:
            return image_main, image_black_main
        if y_start > new_height_main:
            row_slices = 0
        all_widths = []
        rotate_segment_done = False
        all_page_is_titels_font = random.choices([True, False], k=1, weights=[0.3, 0.7])[0]
        for i in range(row_slices):
            white_text = random.choices([True, False], k=1, weights=[0.2, 0.8])[0]
            # white_text = True
            if white_text:
                color_text = random.randint(230, 255)
                color_main = random.randint(180, 200)
                # color_text = 220
                # color_main = 180
            else:
                color_text = random.randint(0, 50)
                color_main = random.randint(127, 256)
            color_text_old = color_text
            while True:
                # region define booleans
                booleans["rotate_segment"] = random.choices([True, False], k=1, weights=[0.2, 0.8])[0]
                if booleans["segment_frame"]:
                    booleans["put_segment_frame"] = random.choices([True, False], k=1, weights=[0.3, 0.7])[0]
                if booleans["put_image"]:
                    booleans["put_image_box"] = random.choice([True, False])
                if booleans["inverted"]:
                    booleans["put_invert"] = random.choice([True, False])
                    booleans["inverted_block"] = random.choice([True, False])
                else:
                    booleans["put_invert"] = False
                if booleans["frame"]:
                    booleans["put_frame"] = random.choice([True, False])
                else:
                    booleans["put_frame"] = False
                booleans["put_english"] = random.choices([True, False], k=1, weights=[0.2, 0.8])[0]

                if booleans["background_main_is_image"]:
                    booleans["background_image"] = False
                else:
                    booleans["background_image"] = random.choices([True, False], k=1, weights=[0.2, 0.8])[0]
                if booleans["background_image"]:
                    # color_text_int = random.randint(0, 255)
                    color_text_int = 0
                    color_text = (color_text_int, color_text_int, color_text_int)
                else:
                    color_text = color_text_old
                booleans["all_lines_same_width"] = random.choice([True, False])
                # endregion

                # region generate new image
                height = height_sub_image
                width = width_sub_image
                w_h = (width_sub_image, height_sub_image)
                if booleans["put_invert"] and booleans["inverted_block"]:
                    color = 0
                else:
                    color = color_main
                if booleans["background_image"] or booleans["background_main_is_image"]:
                    image = Image.new("RGBA", w_h, (color, color, color, 1))
                else:
                    image = Image.new('L', w_h, color)
                image_black = np.zeros((w_h[1], w_h[0]), dtype='uint8')
                # endregion

                # region if this segment is picture on image, create image and continue
                if booleans["put_image_box"]:
                    width_random = random.randint(width_sub_image // 4, width_sub_image)
                    height_random = random.randint(height_sub_image // 4, height_sub_image)
                    if height_random == 0 or width_random == 0:
                        width_random = width_sub_image
                        height_random = height_sub_image
                    w_h, result_image, image_black = self.put_image(width_sub_image,
                                                                    height_sub_image,
                                                                    color_main)

                    booleans["put_image"] = random.choice([True, False])
                    booleans["put_image_box"] = False
                    if x_start + w_h[0] > new_width_main:
                        break
                    image_main[y_start:y_start + w_h[1], x_start:x_start + w_h[0]] = result_image
                    image_black_main[y_start:y_start + w_h[1], x_start:x_start + w_h[0]] = image_black
                    x_start = x_start + w_h[0]
                    all_widths.append(w_h[0])
                    continue
                # endregion

                large_text = random.choices([True, False], k=1, weights=[0.2, 0.8])[0]
                text_between_two_columns = random.choices([True, False], k=1, weights=[0.7, 0.3])[0]
                # text_between_two_columns = random.choice([True, False])
                # text_between_two_columns = True
                # large_text_done = random.choice([True, False])
                # large_text = False
                if all_page_is_titels_font:
                    large_text = True
                if large_text:
                    booleans["all_lines_cell_is_english"] = False
                    # font_size_large = random.randint(20, 80)
                    font_size_large = random.randint(int(new_width_main * 0.02), int(new_width_main * 0.08))
                    arabic_font_path_large = random.choice(self.arabic_fonts_large_text_path)
                    arabic_font_large = ImageFont.truetype(arabic_font_path_large, font_size_large)
                    english_font_large = ImageFont.truetype(english_font_path, font_size_large)
                    image, image_black = self.put_text_on_sub_image(image, image_black, height, width,
                                                                    english_font_large, arabic_font_large,
                                                                    booleans,
                                                                    direction, color_text, color_main,
                                                                    arabic_font_path_large)
                elif text_between_two_columns:
                    booleans["all_lines_cell_is_english"] = False
                    booleans["all_lines_same_width"] = True
                    image, image_black = self.generate_text_between_two_columns(width_sub_image, height_sub_image,
                                                                                color, color_text, booleans)
                else:
                    booleans["all_lines_cell_is_english"] = random.choices([True, False], k=1, weights=[0.2, 0.8])[0]
                    image, image_black = self.put_text_on_sub_image(image, image_black, height, width,
                                                                    english_font, arabic_font, booleans,
                                                                    direction, color_text, color_main, arabic_font_path)
                    # image = self.augment_text(image)
                    # plt.figure()
                    # plt.imshow(image,cmap='gray')
                    # plt.show()
                # check if y2 of sub image is greater than height of main image, if greater -> resize to be fit in main image
                if y_start + w_h[1] > new_height_main:
                    # box = [x_start, y_start, x_start + w_h[0],new_height-1]
                    if x_start + w_h[0] > new_width_main:
                        break
                    image = image.resize((w_h[0], new_height_main - 1 - y_start))
                    image_black = image_black.resize((w_h[0], new_height_main - 1 - y_start))
                    image_main[y_start:y_start + w_h[1], x_start:x_start + w_h[0]] = image
                    image_black_main[y_start:y_start + w_h[1], x_start:x_start + w_h[0]] = image_black
                    if booleans["put_segment_frame"]:
                        cv2.rectangle(image_main, (x_start + 1, y_start + 1),
                                      (x_start + w_h[0] - 1, y_start + w_h[1] - 3), (0, 0, 0), 1)
                    x_start = x_start + w_h[0]
                    all_widths.append(w_h[0])
                    continue
                if x_start + w_h[0] > new_width_main:
                    break

                # region make border
                right = 8
                left = 8
                top = 4
                bottom = 4

                new_width = width_sub_image + right + left
                new_height = height_sub_image + top + bottom
                result_image_black = np.zeros((new_height, new_width), dtype='uint8')
                result_image_black[top:new_height - bottom, left:new_width - right] = image_black
                result_image_black = cv2.resize(result_image_black, (width_sub_image, height_sub_image),
                                                interpolation=cv2.INTER_AREA)

                if booleans["background_main_is_image"]:
                    result_image = np.ones((new_height, new_width, 4), dtype='uint8') * color
                    result_image[top:new_height - bottom, left:new_width - right] = image
                    result_image = cv2.resize(result_image, (width_sub_image, height_sub_image),
                                              interpolation=cv2.INTER_AREA)
                    result_image = cv2.cvtColor(result_image, cv2.COLOR_BGRA2GRAY)
                    # image_main[y_start:y_start + height_sub_image, x_start:x_start + width_sub_image] = result_image
                    # image_black_main[y_start:y_start + height_sub_image,x_start:x_start + width_sub_image] = result_image_black
                    # return image_main, image_black_main

                elif booleans["background_image"]:
                    image_file = random.choice(self.image_filenames)
                    image_path = os.path.join(self.image_dataset_path, image_file)
                    imagebg = cv2.imread(image_path)
                    imagebg = cv2.cvtColor(imagebg, cv2.COLOR_BGR2BGRA)
                    imagebg = cv2.resize(imagebg, (width_sub_image, height_sub_image))
                    image = np.array(image, dtype='uint8')
                    if len(image.shape) == 2:
                        image = np.stack((image,) * 4, axis=-1)
                    new_image = cv2.addWeighted(image, 0.7, imagebg, 0.3, 0)
                    new_image = cv2.cvtColor(new_image, cv2.COLOR_BGRA2GRAY)
                    result_image = np.ones((new_height, new_width), dtype='uint8') * color
                    result_image[top:new_height - bottom, left:new_width - right] = new_image
                    result_image = cv2.resize(result_image, (width_sub_image, height_sub_image),
                                              interpolation=cv2.INTER_AREA)
                else:
                    result_image = np.ones((new_height, new_width), dtype='uint8') * color
                    result_image[top:new_height - bottom, left:new_width - right] = image
                    result_image = cv2.resize(result_image, (width_sub_image, height_sub_image),
                                              interpolation=cv2.INTER_AREA)
                if booleans["rotate_segment"] and not rotate_segment_done:
                    rotate_segment_done = True
                    rotate_angle = random.randint(-5, 5)
                    # rotated_image = imutils.rotate_bound(result_image, angle=rotate_angle)
                    (h_rotate, w_rotate) = result_image.shape[:2]
                    center = (w_rotate // 2, h_rotate // 2)
                    M = cv2.getRotationMatrix2D(center, rotate_angle, 1.0)
                    rotated_image = cv2.warpAffine(result_image, M, (w_rotate, h_rotate),
                                                   flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT,
                                                   borderValue=color)
                    result_image = cv2.resize(rotated_image, (width_sub_image, height_sub_image),
                                              interpolation=cv2.INTER_AREA)

                    rotated_image_black = cv2.warpAffine(result_image_black, M, (w_rotate, h_rotate),
                                                         flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_CONSTANT,
                                                         borderValue=0)
                    # rotated_image_black = imutils.rotate_bound(result_image_black, angle=rotate_angle)
                    result_image_black = cv2.resize(rotated_image_black, (width_sub_image, height_sub_image),
                                                    interpolation=cv2.INTER_AREA)
                # endregion

                image_main[y_start:y_start + height_sub_image, x_start:x_start + width_sub_image] = result_image
                image_black_main[y_start:y_start + height_sub_image,
                x_start:x_start + width_sub_image] = result_image_black

                if booleans["put_segment_frame"]:
                    cv2.rectangle(image_main, (x_start + 1, y_start + 1), (x_start + w_h[0] - 1, y_start + w_h[1] - 3),
                                  (0, 0, 0), 1)
                x_start = x_start + w_h[0]

            y_start = y_start + height_sub_image
            x_start = 1

        # if booleans["put_lines"]:
        #     image_main = self.put_random_line(booleans, row_slices, col_slices, height_sub_image, all_widths, y_title,
        #                                       image_main)
        if booleans["crop_page"]:
            x = (new_width_main - self.width) // 2
            y = (new_height_main - self.height) // 2
            image_main = image_main[y:self.height, x:self.width]
            image_black_main = image_black_main[y:self.height, x:self.width]

        if booleans["padding_page"]:
            padding_value = 100
            original_height = image_main.shape[0]
            original_width = image_main.shape[1]
            image_main = cv2.copyMakeBorder(image_main, padding_value, padding_value, padding_value, padding_value,
                                            borderType=cv2.BORDER_CONSTANT, value=0)
            image_main = cv2.resize(image_main, (original_width, original_height), interpolation=cv2.INTER_AREA)
            image_black_main = cv2.copyMakeBorder(image_black_main, padding_value, padding_value, padding_value,
                                                  padding_value, borderType=cv2.BORDER_CONSTANT, value=0)
            image_black_main = cv2.resize(image_black_main, (original_width, original_height),
                                          interpolation=cv2.INTER_AREA)
        if booleans["background_main_is_image"]:
            imagebg = cv2.resize(imagebg, (image_main.shape[1], image_main.shape[0]))
            image_main = np.array(image_main, dtype='uint8')
            imagebg = cv2.cvtColor(imagebg, cv2.COLOR_BGRA2GRAY)
            new_image = cv2.addWeighted(image_main, 0.8, imagebg, 0.2, 0)
            return new_image, image_black_main

        return image_main, image_black_main

    def make_border(self, image, width, height, border_size=8, colored=False, color=255, seg_map=False):
        # region make border
        right = border_size
        left = border_size
        top = border_size
        bottom = border_size

        new_width = width + right + left
        new_height = height + top + bottom
        if colored:
            result_image = np.ones((new_height, new_width, 4), dtype='uint8') * color
            result_image[top:new_height - bottom, left:new_width - right] = image
            result_image = cv2.resize(result_image, (width, height), interpolation=cv2.INTER_AREA)
            result_image = cv2.cvtColor(result_image, cv2.COLOR_BGRA2GRAY)
        else:
            result_image = np.ones((new_height, new_width), dtype='uint8') * color
            result_image[top:new_height - bottom, left:new_width - right] = image
            result_image = cv2.resize(result_image, (width, height),
                                      interpolation=cv2.INTER_AREA)
        if seg_map:
            result_image = np.zeros((new_height, new_width), dtype='uint8')
            result_image[top:new_height - bottom, left:new_width - right] = image
            result_image = cv2.resize(result_image, (width, height),
                                      interpolation=cv2.INTER_AREA)
        return result_image

    # helper function to generate specific structure for al ahram
    def generate_three_parts_image(self, image, english_font,arabic_font, booleans,
                                   direction, color_text, color_main, arabic_font_path, image_right, image_black_right, fixed_line_len):
        # region divide right and left image into 3 parts, to avoid overlapping after putting center image
        height_half_image = image.shape[0]
        width_half_image = image.shape[1]
        part_1_height = int(0.2*height_half_image)
        part_2_height = int(0.2*height_half_image)
        part_3_height = int(0.6*height_half_image)
        part_2_width = int(0.7*width_half_image)
        image_right_1 = image[0:part_1_height]
        image_right_2 = image_right_1.copy()
        image_right_3 = image[part_1_height+part_2_height:height_half_image]
        image_right_1 = Image.fromarray(image_right_1)
        image_right_2 = Image.fromarray(image_right_2)
        image_right_3 = Image.fromarray(image_right_3)
        image_black_right_1 = np.zeros((image_right_1.height, image_right_1.width), dtype='uint8')
        image_black_right_2 = np.zeros((image_right_2.height, image_right_2.width), dtype='uint8')
        image_black_right_3 = np.zeros((image_right_3.height, image_right_3.width), dtype='uint8')
        # endregion

        # put text on all parts of right and left images
        image_right_1, image_black_right_1 = self.put_text_on_sub_image(image_right_1, image_black_right_1, image_right_1.height,
                                                                    image_right_1.width,
                                                                    english_font, arabic_font, booleans,
                                                                    direction, color_text, color_main, arabic_font_path, fixed_line_len)

        # pass width and height of part 1 then resize
        image_right_2, image_black_right_2 = self.put_text_on_sub_image(image_right_2, image_black_right_2, image_right_1.height,
                                                                    image_right_1.width,
                                                                    english_font, arabic_font, booleans,
                                                                    direction, color_text, color_main, arabic_font_path, fixed_line_len, put_title_done = True)

        image_right_3, image_black_right_3 = self.put_text_on_sub_image(image_right_3, image_black_right_3, image_right_3.height,
                                                                    image_right_3.width,
                                                                    english_font, arabic_font, booleans,
                                                                    direction, color_text, color_main, arabic_font_path,fixed_line_len, put_title_done = True)

        image_right[0:part_1_height] = image_right_1
        image_black_right[0:part_1_height] = image_black_right_1

        # resize image right part two to fit in image right half width "part_2_width"
        if direction == "rtl":
            x_image_right_2 = width_half_image - part_2_width
        elif direction == "ltr":
            x_image_right_2 = part_2_width
        image_right_2 = image_right_2.resize((part_2_width, part_2_height))
        image_black_right_2 = cv2.resize(image_black_right_2, (part_2_width, part_2_height),
                                         interpolation=cv2.INTER_AREA)
        if direction == "rtl":
            image_right[part_1_height:part_1_height + part_2_height, x_image_right_2:] = image_right_2
            image_black_right[part_1_height:part_1_height + part_2_height, x_image_right_2:] = image_black_right_2
        elif direction == "ltr":
            image_right[part_1_height:part_1_height + part_2_height, :x_image_right_2] = image_right_2
            image_black_right[part_1_height:part_1_height + part_2_height, :x_image_right_2] = image_black_right_2

        image_right[part_1_height + part_2_height:height_half_image] = image_right_3
        image_black_right[part_1_height + part_2_height:height_half_image] = image_black_right_3

        return image_right, image_black_right
    # generate specific structure for al ahram
    def generate_text_between_two_columns(self, new_width_main, new_height_main, color_main, color_text, booleans):
        width_half_image = int(new_width_main *0.5)
        height_half_image = new_height_main
        # width_image_center = random.randint(int(0.4 * new_width_main), int(0.55 * new_width_main))
        width_image_center = int(0.3 * new_width_main)
        # height_image_center = random.randint(int(0.2 * new_height_main), int(0.3 * new_height_main))
        height_image_center = int(0.2 * new_height_main)
        colored = False
        if booleans["background_image"] or booleans["background_main_is_image"]:
            image_right = Image.new("RGBA", (width_half_image, height_half_image),
                                    (color_main, color_main, color_main, 1))
            image_left = Image.new("RGBA", (width_half_image, height_half_image),
                                   (color_main, color_main, color_main, 1))
            image_center = Image.new("RGBA", (width_image_center, height_image_center),
                                     (color_main, color_main, color_main, 1))
            colored = True
        else:
            image_right = Image.new('L', (width_half_image, height_half_image), color_main)
            image_left = Image.new('L', (width_half_image, height_half_image), color_main)
            image_center = Image.new('L', (width_image_center, height_image_center), color_main)
        image_black_right = np.zeros((height_half_image, width_half_image), dtype='uint8')
        image_black_left = np.zeros((height_half_image, width_half_image), dtype='uint8')
        image_black_center = np.zeros((height_image_center, width_image_center), dtype='uint8')
        image_black_two_columns = np.zeros((new_height_main, new_width_main), dtype='uint8')
        image_main_two_columns = np.ones((new_height_main, new_width_main), dtype='uint8') * color_main
        # region define fixed font type and size and text direction for all columns
        # font_size = random.randint(15, 45)
        font_size = random.randint(int(self.width * 0.007), int(self.width * 0.03))
        arabic_font_path = random.choice(self.arabic_fonts_path)
        arabic_font = ImageFont.truetype(arabic_font_path, font_size)
        english_font_path = random.choice(self.english_fonts_path)
        english_font = ImageFont.truetype(english_font_path, font_size)
        fixed_line_len = random.randint(5, 10)
        direction = "rtl"
        # endregion

        image_right = np.array(image_right)
        image_right, image_black_right = \
            self.generate_three_parts_image(image_right, english_font,arabic_font, booleans,
                                   direction, color_text, color_main, arabic_font_path, image_right, image_black_right, fixed_line_len)
        # image_right, image_black_right = self.put_text_on_sub_image(image_right, image_black_right, height_half_image,
        #                                                             width_half_image,
        #                                                             english_font, arabic_font, booleans,
        #                                                             direction, color_text, color_main, arabic_font_path)
        direction = "ltr"
        image_left = np.array(image_left)
        image_left, image_black_left = \
            self.generate_three_parts_image(image_left, english_font,arabic_font, booleans,
                                   direction, color_text, color_main, arabic_font_path, image_left, image_black_left, fixed_line_len)
        # image_left, image_black_left = self.put_text_on_sub_image(image_left, image_black_left, height_half_image,
        #                                                           width_half_image,
        #                                                           english_font, arabic_font, booleans,
        #                                                           direction, color_text,color_main, arabic_font_path)
        direction = "center"
        font_size += random.randint(30, 40)
        fixed_line_len = random.randint(1, 3)
        # font_size += 50
        arabic_font = ImageFont.truetype(arabic_font_path, font_size)
        english_font = ImageFont.truetype(english_font_path, font_size)
        image_center, image_black_center = self.put_text_on_sub_image(image_center, image_black_center,
                                                                      height_image_center, width_image_center,
                                                                      english_font, arabic_font, booleans,
                                                                      direction, color_text,color_main, arabic_font_path, fixed_line_len)
        # region make border
        image_left = self.make_border(image_left, width_half_image, height_half_image, colored=colored,
                                      color=color_main)
        image_right = self.make_border(image_right, width_half_image, height_half_image, colored=colored,
                                       color=color_main)
        image_center = self.make_border(image_center, width_image_center, height_image_center, border_size=8,
                                        colored=colored, color=color_main)
        image_black_right = self.make_border(image_black_right, width_half_image, height_half_image, seg_map=True)
        image_black_left = self.make_border(image_black_left, width_half_image, height_half_image, seg_map=True)
        image_black_center = self.make_border(image_black_center, width_image_center, height_image_center,
                                              border_size=4, seg_map=True)
        # endregion
        image_main_two_columns[0:height_half_image, 0:width_half_image] = image_left
        image_black_two_columns[0:height_half_image, 0:width_half_image] = image_black_left

        # width_right_image = new_width_main - int(width_half_image*2)
        x_right_image = new_width_main - width_half_image
        # image_right = cv2.resize(image_right, (width_right_image, height_half_image), interpolation=cv2.INTER_AREA)
        # image_black_right = cv2.resize(image_black_right, (width_right_image, height_half_image),
        #                                interpolation=cv2.INTER_AREA)

        image_main_two_columns[0:height_half_image, x_right_image:new_width_main] = image_right
        image_black_two_columns[0:height_half_image, x_right_image:new_width_main] = image_black_right

        # y = random.randint(int(0.1 * new_height_main), int(0.4 * new_height_main))
        y = int(0.2 * new_height_main)
        # x = random.randint(int(0.4 * new_width_main), int(0.6 * new_width_main)-width_image_center)
        x = int(0.35 * new_width_main)
        image_main_two_columns[y:y + height_image_center, x:x + width_image_center] = image_center
        image_black_two_columns[y:y + height_image_center, x:x + width_image_center] = image_black_center
        if colored:
            image_main_two_columns = np.stack((image_main_two_columns,) * 4, axis=-1)
        plot = False
        if plot:
            plt.figure()
            plt.subplot(1, 2, 1)
            plt.imshow(image_main_two_columns, cmap='gray', vmin=0, vmax=255)
            plt.title('Image')
            plt.subplot(1, 2, 2)
            plt.imshow(image_black_two_columns, cmap='gray')
            plt.title('Segmentation Map')
            plt.show()
        return image_main_two_columns, image_black_two_columns
    def draw_lines_seg_map(self, box, image_black):
        y_line = box[1] + (box[3] - box[1]) // 2  # keda el y f nos el box
        height_line_seg_map = int((box[3] - box[1]) * 0.6)
        y_line = y_line - int(height_line_seg_map // 2)  # keda el y bdaytha 3nd 10%
        for height_count in range(height_line_seg_map):
            cv2.line(image_black, (box[0], y_line + height_count), (box[2], y_line + height_count), 255, 1)
        return image_black

    # put title
    def make_title(self, new_width, new_height, color_main, color_text, y):
        # title_from_data = random.choices([True, False], k=1, weights=[0.3, 0.7])[0]
        title_from_data = False
        if title_from_data:
            image_title_file = random.choice(self.titles_ahram_filenames)
            image_title_path = os.path.join(self.titles_ahram_path, image_title_file)
            image_title = Image.open(image_title_path).convert(mode="L")
            height_title_image = random.randint(image_title.height // 3, image_title.height // 2)
            width_title_image = random.randint(image_title.width // 2, image_title.width)
            box = [0, 0, width_title_image, height_title_image]
            image_black = np.zeros((height_title_image, width_title_image), dtype='uint8')
            self.draw_lines_seg_map(box, image_black)
            if width_title_image > new_width - 10:
                if new_width-10 <=0:
                    width_title_image = new_width
                else:
                    width_title_image = new_width - 10
            if height_title_image > new_height - 10:
                if new_height - 10<=0:
                    height_title_image = new_height
                else:
                    height_title_image = new_height - 10
            image = image_title.resize((width_title_image, height_title_image))
            image_black = cv2.resize(image_black, (width_title_image, height_title_image), interpolation=cv2.INTER_AREA)
            image = np.array(image)
            x = random.choice(range(2, (new_width - width_title_image)))
            return image, image_black, width_title_image, height_title_image, x, y
        k = random.randint(1, max(int(new_width * 0.03),2))
        line = []
        line_w = 0
        # font_size = random.randint(int(new_width * 0.03), int(new_width * 0.2))
        # font_size = random.randint(20, 60)
        font_size = random.randint(int(new_width * 0.02), int(new_width * 0.14))
        # font_size = 160
        all_fonts = self.arabic_fonts_large_text_path # + self.arabic_fonts_path
        arabic_font_path = random.choice(all_fonts)
        arabic_font = ImageFont.truetype(arabic_font_path, font_size)

        for i in range(k):
            put_punc = random.choices([True, False], k=1, weights=[0.1, 0.9])[0]
            word_len = random.randint(2, 6)
            word = ''.join(random.choices(self.arabic_letters, k=word_len))
            put_end_letter = random.choice([True, False])
            put_extend = random.choice([True, False])
            put_numbers = random.choices([True, False], k=1, weights=[0.1, 0.9])[0]
            if put_end_letter:
                word = word + (random.choice(self.arabic_ending_letters))
            if put_extend:
                index = random.randint(1, len(word))
                word = word[:index] + "ــــــــــــــ" + word[index:]
            line_w += arabic_font.getsize(word)[0]
            if line_w > new_width - 5:
                if i == 0:
                    if word_len // 2 < 2:
                        word = ''.join(random.choices(self.arabic_letters, k=2))
                    else:
                        word = ''.join(random.choices(self.arabic_letters, k=word_len // 2))
                    line = word
                break
            line.append(word)
            if put_numbers:
                number = random.choices(self.arabic_numbers, k=random.randint(1, 4))
                number = "".join(number)
                line.append(number)
            if put_punc:
                char = random.choices(self.arabic_punctuation, k=1)[0]
                line.append(char)

        put_more_spaces = False
        new_line = []
        if put_more_spaces:
            for i in range(len(line)):
                if i == len(line) - 1:
                    new_line.append(line[i])
                    break
                spaces = random.choice(["   ", "    "])
                new_line.append(line[i])
                new_line.append(spaces)
            line = "".join(new_line)
        else:
            line = " ".join(line)
        width, height = arabic_font.getsize(line)

        # width = width + 5
        # height = height + 5
        inverted = random.choices([True, False], k=1, weights=[0.2, 0.8])[0]
        frame = random.choices([True, False], k=1, weights=[0.2, 0.8])[0]
        # image_background = random.choices([True, False], k=1, weights=[0.2, 0.8])[0]
        # inverted = False
        # frame = False
        image_background = random.choice([True, False])
        #
        if inverted:
            color = 0
        else:
            color = color_main
        if image_background:
            color = 255
            color_text = 0
            image = Image.new("RGBA", (width, height), (color, color, color, 1))
        else:
            image = Image.new('L', (width, height), color)
        #

        # image = Image.new('L', (width, height), color_main)
        image_black = np.zeros((height, width), dtype='uint8')
        image_draw = ImageDraw.Draw(image)
        yb = 5
        box = image_draw.textbbox((0, yb), line, font=arabic_font)
        # x = width - 3 - (box[2] - box[0])
        x = 2
        if type(color_text) != int:
            if inverted:
                fill = 255
            else:
                fill = 0
            image_draw.text((0, yb), line, fill=fill, font=arabic_font)
        else:
            if inverted:
                fill = 255
            else:
                fill = color_text
            image_draw.text((0, yb), line, fill=fill, font=arabic_font)
        # cv2.rectangle(image_black, (x, box[1]), (x + (box[2] - box[0]), box[3]), (255, 255, 255), -1)

        y_line = box[1] + (box[3] - box[1]) // 2  # keda el y f nos el box
        height_line_seg_map = int((box[3] - box[1]) * 0.8)
        y_line = y_line - int(height_line_seg_map // 2)
        for height_count in range(height_line_seg_map):
            cv2.line(image_black, (box[0], y_line + height_count), (box[2], y_line + height_count), 255, 1)

        if width > new_width - 10:
            if new_width - 10 <=0:
                width = new_width
            else:
                width = new_width - 10
        if height > new_height - 10:
            if new_height - 10 <= 0:
                height = new_height
            else:
                height = new_height - 10

        image = image.resize((width, height))
        image_black = cv2.resize(image_black, (width, height), interpolation=cv2.INTER_AREA)

        x = random.choice(range(2, (new_width - width)))  # to make sure that small page will fit in main image
        # y = random.choice(range(y, y + 10))
        if image_background:
            image_file = random.choice(self.image_filenames)
            image_path = os.path.join(self.image_dataset_path, image_file)
            imagebg = cv2.imread(image_path)
            imagebg = cv2.cvtColor(imagebg, cv2.COLOR_BGR2BGRA)
            imagebg = cv2.resize(imagebg, (width, height))
            image = np.array(image, dtype='uint8')
            new_image = cv2.addWeighted(image, 0.7, imagebg, 0.3, 0)
            new_image = cv2.cvtColor(new_image, cv2.COLOR_BGRA2GRAY)
            return new_image, image_black, width, height, x, y
        if frame:
            image = np.array(image, dtype='uint8')
            cv2.rectangle(image, (1, 1), (width - 1, height - 1), (0, 0, 0), 1)
        image = np.array(image)
        return image, image_black, width, height, x, y

    def augment_text(self, img):

        # print('augment_text')
        img = np.array(img)
        kernel = np.ones((5, 5), np.uint8)
        img_erosion = cv2.erode(img, kernel, iterations=1)
        # cv2.imshow('Input', img)
        # cv2.imshow('Erosion', img_erosion)

        '''# global thresholding
        ret1, th1 = cv2.threshold(img, 127, 255, cv2.THRESH_BINARY)
        cv2.imshow('th1', th1)'''

        '''# global thresholding
        ret1, th11 = cv2.threshold(img_erosion, 127, 255, cv2.THRESH_BINARY)
        cv2.imshow('th11', th11)'''

        '''ret2, th = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        cv2.imshow('th', th)'''

        '''ret2, th2 = cv2.threshold(img_erosion, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        cv2.imshow('th2', th2)'''

        '''blur = cv2.GaussianBlur(img_erosion, (3, 3), 0)
        ret3, th3 = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        cv2.imshow('threshold(3, 3)', th3)'''

        blur = cv2.GaussianBlur(img, (5, 5), 0)
        ret3, th3 = cv2.threshold(blur, 5, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        # ret3, th3 = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY)
        # cv2.imshow('th3', th3)
        row, col = th3.shape
        # number_of_pixels = random.randint(1000, 2000)
        number_of_pixels = 2500
        for i in range(number_of_pixels):
            # Pick a random y coordinate
            y_coord = random.randint(0, row - 1)
            # Pick a random x coordinate
            x_coord = random.randint(0, col - 1)
            # Color that pixel to white
            if th3[y_coord][x_coord] == 0:
                # th3[y_coord][x_coord] = 128
                th3[y_coord][x_coord] = random.randint(200, 250)
                th3[y_coord][x_coord] = 250

        # th3 = cv2.GaussianBlur(th3, (1, 1), 0)

        '''ret4, th4 = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        img_erosion2 = cv2.erode(th4, kernel, iterations=3)
        cv2.imshow('img_erosion2', img_erosion2)'''

        '''noisy_image = random_noise(th3)
        cv2.imshow('noisy_image', noisy_image)'''

        '''# Apply bilateral filter denoising
        denoised_image = denoise_bilateral(th3)
        cv2.imshow('denoised_image', denoised_image)'''

        '''# Obtain the segmentation with 400 regions
        segments = slic(img, n_segments=400)
        # Put segments on top of original image to compare
        segmented_image = label2rgb(segments, img, kind='avg')
        cv2.imshow('segmented_image', segmented_image)'''

        return th3

    def put_random_line(self, booleans, row_slices, col_slices, height_sub_image, all_widths, y_title, image_main):
        x_start = 1
        j = 0
        for i in range(row_slices):
            while True:
                vertical_line_length = random.randint(1, height_sub_image)
                horizontal_line_length = random.randint(1, all_widths[j])
                if booleans["put_lines"]:
                    booleans["put_vertical_line"] = random.choice([True, False])
                    booleans["put_horizontal_line"] = random.choice([True, False])
                if booleans["put_horizontal_line"]:
                    put_double = random.choice([True, False])
                    put_trible = random.choice([True, False])
                    put_horizontal_line = random.choice([True, False])
                    # p1 = random.randint(x_start,x_start+width_sub_image)
                    p1 = x_start
                    cv2.line(image_main, (p1, y_title), (p1 + horizontal_line_length, y_title), (0), 1)
                    if put_double and put_trible:
                        cv2.line(image_main, (p1, y_title - 2), (p1 + horizontal_line_length, y_title - 2), (0), 1)
                        cv2.line(image_main, (p1, y_title + 2), (p1 + horizontal_line_length, y_title + 2), (0), 1)
                    elif put_double:
                        cv2.line(image_main, (p1, y_title - 2), (p1 + horizontal_line_length, y_title - 2), (0), 1)
                if booleans["put_vertical_line"]:
                    put_double = random.choice([True, False])
                    put_trible = random.choice([True, False])
                    put_vertical_line = random.choice([True, False])
                    # p1 = random.randint(y_title,y_title+height_sub_image)
                    p1 = y_title
                    cv2.line(image_main, (x_start, p1), (x_start, p1 + vertical_line_length), (0), 1)
                    if put_double and put_trible:
                        cv2.line(image_main, (x_start - 2, p1), (x_start - 2, p1 + vertical_line_length), (0), 1)
                        cv2.line(image_main, (x_start + 2, p1), (x_start + 2, p1 + vertical_line_length), (0), 1)
                    elif put_double:
                        cv2.line(image_main, (x_start - 2, p1), (x_start - 2, p1 + vertical_line_length), (0), 1)
                x_start += all_widths[j]
                j += 1
                if j >= col_slices * (i + 1):
                    break
            y_title = y_title + height_sub_image
            x_start = 1
        return image_main

    def generate_lines_passport(self):
        image_main = np.ones((self.height, self.width), dtype='uint8') * 255
        image_black_main = np.zeros((self.height, self.width), dtype='uint8')

        k = random.randint(2, 6)
        first_line = []
        for word_num in range(k):
            word_len = random.randint(3, 14)
            char_len = random.randint(1, 10)
            word = ''.join(random.choices(self.english_letters, k=word_len))
            first_line.append(word)
            char = ''.join(random.choices(self.chars, k=char_len))
            first_line.append(char)
        # first_line = ''.join(first_line[:-1])

        second_line = []
        for word_num in range(k):
            word_len = random.randint(3, 14)
            char_len = random.randint(1, 14)
            numbers_only = random.choice([True, False])
            number_and_letters = random.choice([True, False])
            if numbers_only:
                word = ''.join(random.choices(self.english_numbers, k=random.randint(1, 6)))
            elif number_and_letters:
                word = ''.join(random.choices(self.english_letters, k=word_len))
                numbers = ''.join(random.choices(self.english_numbers, k=random.randint(1, 6)))
                word = list(word + numbers)
                random.shuffle(word)
                word = ''.join(word)
            else:
                word = ''.join(random.choices(self.english_letters, k=word_len))
            second_line.append(word)

            char = ''.join(random.choices(self.chars, k=char_len))
            second_line.append(char)
        # second_line = ''.join(second_line[:-1])
        # region define fontsize and font type
        font_size = random.randint(30, 40)
        english_font_path = random.choice(self.english_fonts_path)
        english_font = ImageFont.truetype(english_font_path, font_size)
        # endregion
        width = max(english_font.getsize(''.join(first_line[:-1]))[0],
                    english_font.getsize(''.join(second_line[:-1]))[0]) + 10
        color_text = random.randint(0, 100)
        color_main = random.randint(color_text + 75, 256)
        image = Image.new('L', (width, self.height), color_main)
        image_black = np.zeros((self.height, width), dtype='uint8')
        image_draw = ImageDraw.Draw(image)
        x = 0
        y = 0
        x_start = 5
        y_start = 5
        box_line = image_draw.textbbox((x_start, y_start), ''.join(first_line[:-1]), font=english_font)
        for i in range(0, len(first_line)):
            box = image_draw.textbbox((x_start, y_start), first_line[i], font=english_font)
            image_draw.text((x_start, box_line[1]), first_line[i], fill=0, font=english_font)
            if i % 2 == 0:
                cv2.rectangle(image_black, (x_start, box[1]), (x_start + (box[2] - box[0]), box[3]), (255, 255, 255),
                              -1)
            x_start = box[2]

        x_start = 5
        y_start = box_line[3] + 2
        box_line = image_draw.textbbox((x_start, y_start), ''.join(second_line[:-1]), font=english_font)
        for i in range(0, len(second_line)):
            box = image_draw.textbbox((x_start, y_start), second_line[i], font=english_font)
            image_draw.text((x_start, box_line[1]), second_line[i], fill=0, font=english_font)
            if i % 2 == 0:
                cv2.rectangle(image_black, (x_start, box[1]), (x_start + (box[2] - box[0]), box[3]), (255, 255, 255),
                              -1)
            x_start = box[2]

        # box = image_draw.textbbox((5, box_line[3]+2), second_line, font=english_font)
        # image_draw.text((5, box[1]), second_line, fill=0, font=english_font)
        # cv2.rectangle(image_black, (x, box[1]), (x + (box[2] - box[0]), box[3]), (255, 255, 255), -1)

        image = image.resize((self.width, self.height))
        image_black = cv2.resize(image_black, (self.width, self.height), interpolation=cv2.INTER_AREA)
        image_main[y:y + self.height, x:x + self.width] = image
        image_black_main[y:y + self.height, x:x + self.width] = image_black
        return image_main, image_black_main

    '''
    # def generate_table(self, new_width_main, new_height_main, color_main, color_text_old, color_text, booleans):
    #
    #     image_main = np.ones((new_height_main, new_width_main), dtype='uint8') * color_main
    #     image_black_main = np.zeros((new_height_main, new_width_main), dtype='uint8')
    #     x_start = 1
    #     y_start = 1
    #
    #     # region define initial values
    #     booleans["put_image_box"] = False
    #     booleans["inverted_block"] = False
    #     booleans["put_vertical_line"] = False
    #     booleans["put_horizontal_line"] = False
    #     booleans["put_segment_frame"] = False
    #     booleans["put_lines"] = random.choices([True, False], k=1, weights=[0.2, 0.8])[0]
    #     booleans["segment_frame"] = random.choices([True, False], k=1, weights=[0.2, 0.8])[0]
    #     # endregion
    #
    #     # region define fixed font type and size and text direction for all columns
    #     font_size = random.randint(8, 40)
    #     arabic_font_path = random.choice(self.arabic_fonts_path)
    #     arabic_font = ImageFont.truetype(arabic_font_path, font_size)
    #     english_font_path = random.choice(self.english_fonts_path)
    #     english_font = ImageFont.truetype(english_font_path, font_size)
    #     direction = random.choice(["rtl", "ltr", "center"])
    #     # endregion
    #     if new_width_main * 0.01 < 1:
    #         col_slices = 1
    #     else:
    #         col_slices = random.randint(1, int(new_width_main * 0.01))
    #     if new_height_main * 0.01 < 1:
    #         row_slices = 1
    #     else:
    #         row_slices = random.randint(1, int(new_height_main * 0.01))
    #     width_sub_image = (new_width_main - x_start) // col_slices
    #     height_sub_image = (new_height_main - y_start) // row_slices
    #
    #     for i in range(row_slices):
    #         while True:
    #             # region define booleans
    #             if booleans["segment_frame"]:
    #                 booleans["put_segment_frame"] = random.choices([True, False], k=1, weights=[0.3, 0.7])[0]
    #             if booleans["put_image"]:
    #                 booleans["put_image_box"] = random.choice([True, False])
    #             if booleans["inverted"]:
    #                 booleans["put_invert"] = random.choice([True, False])
    #                 booleans["inverted_block"] = random.choice([True, False])
    #             else:
    #                 booleans["put_invert"] = False
    #             if booleans["frame"]:
    #                 booleans["put_frame"] = random.choice([True, False])
    #             else:
    #                 booleans["put_frame"] = False
    #             booleans["put_english"] = random.choices([True, False], k=1, weights=[0.2, 0.8])[0]
    #
    #             if booleans["background_main_is_image"]:
    #                 booleans["background_image"] = False
    #             else:
    #                 booleans["background_image"] = random.choices([True, False], k=1, weights=[0.2, 0.8])[0]
    #             if booleans["background_image"]:
    #                 # color_text_int = random.randint(0, 255)
    #                 color_text_int = 0
    #                 color_text = (color_text_int, color_text_int, color_text_int)
    #             else:
    #                 color_text = color_text_old
    #             # endregion
    #
    #             # region generate new image
    #             height = height_sub_image
    #             width = width_sub_image
    #             w_h = (width_sub_image, height_sub_image)
    #             if booleans["put_invert"] and booleans["inverted_block"]:
    #                 color = 0
    #             else:
    #                 color = color_main
    #             if booleans["background_image"] or booleans["background_main_is_image"]:
    #                 image = Image.new("RGBA", w_h, (color, color, color, 1))
    #             else:
    #                 image = Image.new('L', w_h, color)
    #             image_black = np.zeros((w_h[1], w_h[0]), dtype='uint8')
    #             image_draw = ImageDraw.Draw(image)
    #             # endregion
    #
    #             # region if this segment is picture on image, create image and continue
    #             if booleans["put_image_box"]:
    #                 width_random = random.randint(width_sub_image // 4, width_sub_image)
    #                 height_random = random.randint(height_sub_image // 4, height_sub_image)
    #                 w_h, image, image_black = self.generate_sub_image(width_random, height_random,
    #                                                                   color_main, color_text, booleans)
    #                 booleans["put_image"] = random.choices([True, False], k=1, weights=[0.2, 0.8])[0]
    #                 booleans["put_image_box"] = False
    #                 if x_start + w_h[0] > new_width_main:
    #                     break
    #                 image_main[y_start:y_start + w_h[1], x_start:x_start + w_h[0]] = image
    #                 image_black_main[y_start:y_start + w_h[1], x_start:x_start + w_h[0]] = image_black
    #                 x_start = x_start + w_h[0]
    #                 continue
    #             # endregion
    #
    #             image_draw, image_black = self.put_text_on_sub_image(image_draw, image_black, height, width,
    #                                                                  english_font, arabic_font, booleans,
    #                                                                  direction, color_text, w_h)
    #
    #             # check if y2 of sub image is greater than height of main image, if greater -> resize to be fit in main image
    #             if y_start + w_h[1] > new_height_main:
    #                 # box = [x_start, y_start, x_start + w_h[0],new_height-1]
    #                 if x_start + w_h[0] > new_width_main:
    #                     break
    #                 image = image.resize((w_h[0], new_height_main - 1 - y_start))
    #                 image_black = image_black.resize((w_h[0], new_height_main - 1 - y_start))
    #                 image_main[y_start:y_start + w_h[1], x_start:x_start + w_h[0]] = image
    #                 image_black_main[y_start:y_start + w_h[1], x_start:x_start + w_h[0]] = image_black
    #                 if booleans["put_segment_frame"]:
    #                     cv2.rectangle(image_main, (x_start + 1, y_start + 1),
    #                                   (x_start + w_h[0] - 1, y_start + w_h[1] - 3), (0, 0, 0), 1)
    #                 x_start = x_start + w_h[0]
    #                 continue
    #             if x_start + w_h[0] > new_width_main:
    #                 break
    #
    #             # region make border
    #             right = 4
    #             left = 4
    #             top = 4
    #             bottom = 4
    #
    #             new_width = width_sub_image + right + left
    #             new_height = height_sub_image + top + bottom
    #             result_image_black = np.zeros((new_height, new_width), dtype='uint8')
    #             result_image_black[top:new_height - bottom, left:new_width - right] = image_black
    #             # print(result_image_black.shape)
    #             # print(width_sub_image)
    #             # print(height_sub_image)
    #             result_image_black = cv2.resize(result_image_black, (width_sub_image, height_sub_image),
    #                                             interpolation=cv2.INTER_AREA)
    #
    #             if booleans["background_main_is_image"]:
    #                 result_image = np.ones((new_height, new_width, 4), dtype='uint8') * color
    #                 result_image[top:new_height - bottom, left:new_width - right] = image
    #                 result_image = cv2.resize(result_image, (width_sub_image, height_sub_image),
    #                                           interpolation=cv2.INTER_AREA)
    #                 result_image = cv2.cvtColor(result_image, cv2.COLOR_BGRA2GRAY)
    #                 # image_main[y_start:y_start + height_sub_image, x_start:x_start + width_sub_image] = result_image
    #                 # image_black_main[y_start:y_start + height_sub_image,x_start:x_start + width_sub_image] = result_image_black
    #                 # return image_main, image_black_main
    #
    #             elif booleans["background_image"]:
    #                 image_file = random.choice(self.image_filenames)
    #                 image_path = os.path.join(self.image_dataset_path, image_file)
    #                 imagebg = cv2.imread(image_path)
    #                 imagebg = cv2.cvtColor(imagebg, cv2.COLOR_BGR2BGRA)
    #                 imagebg = cv2.resize(imagebg, (width_sub_image, height_sub_image))
    #                 image = np.array(image, dtype='uint8')
    #                 new_image = cv2.addWeighted(image, 0.7, imagebg, 0.3, 0)
    #                 new_image = cv2.cvtColor(new_image, cv2.COLOR_BGRA2GRAY)
    #                 result_image = np.ones((new_height, new_width), dtype='uint8') * color
    #                 result_image[top:new_height - bottom, left:new_width - right] = new_image
    #                 result_image = cv2.resize(result_image, (width_sub_image, height_sub_image),
    #                                           interpolation=cv2.INTER_AREA)
    #             else:
    #                 result_image = np.ones((new_height, new_width), dtype='uint8') * color
    #                 result_image[top:new_height - bottom, left:new_width - right] = image
    #                 result_image = cv2.resize(result_image, (width_sub_image, height_sub_image),
    #                                           interpolation=cv2.INTER_AREA)
    #
    #             # endregion
    #
    #             image_main[y_start:y_start + height_sub_image, x_start:x_start + width_sub_image] = result_image
    #             image_black_main[y_start:y_start + height_sub_image,
    #             x_start:x_start + width_sub_image] = result_image_black
    #
    #             if booleans["put_segment_frame"]:
    #                 cv2.rectangle(image_main, (x_start + 1, y_start + 1), (x_start + w_h[0] - 1, y_start + w_h[1] - 3),
    #                               (0, 0, 0), 1)
    #             x_start = x_start + w_h[0]
    #
    #         y_start = y_start + height_sub_image
    #         x_start = 1
    #
    #     return image_main, image_black_main
    '''
    # divide main page to cells and call for each cell the choosen function (large text or put image ...)
    def generate_image_slices(self, inverted, frame, put_image):
        booleans = {}
        booleans["passport_lines"] = False
        booleans["table"] = False
        # region get width and height of main image
        if type(self.width_original) != int:
            self.width = int(random.uniform(self.width_original[0], self.width_original[1]))
        else:
            self.width = self.width_original
        if type(self.height_original) != int:
            self.height = int(random.uniform(self.height_original[0], self.height_original[1]))
        else:
            self.height = self.height_original
        # print(self.width,self.height)
        # endregion

        if booleans["passport_lines"]:
            image_main, image_black_main = self.generate_lines_passport()
            return image_main, image_black_main

        booleans["inverted"] = inverted
        booleans["frame"] = frame
        booleans["put_image"] = put_image

        white_text = random.choices([True, False], k=1, weights=[0.3, 0.7])[0]
        # white_text = True
        if white_text:
            color_text = random.randint(230, 255)
            color_main = random.randint(180, 200)
            # color_text = 220
            # color_main = 180
        else:
            color_text = random.randint(0, 50)
            color_main = random.randint(127, 256)
        color_text_old = color_text
        # booleans["crop_page"] = random.choices([True, False], k=1, weights=[0.3, 0.7])[0]
        # booleans["padding_page"] = random.choices([True, False], k=1, weights=[0.3, 0.7])[0]
        booleans["padding_page"] = False
        booleans["crop_page"] = False
        if booleans["crop_page"]:
            new_width = int(self.width * 1.2)
            new_height = int(self.height * 1.2)
        else:
            new_width = self.width
            new_height = self.height
        booleans["background_main_is_image"] = random.choices([True, False], k=1, weights=[0.2, 0.8])[0]
        # booleans["background_main_is_image"] = True
        if booleans["background_main_is_image"]:
            # booleans["put_image"] = False
            color_text = 0
            color_text_old = color_text
            image_file = random.choice(self.image_filenames)
            image_path = os.path.join(self.image_dataset_path, image_file)
            imagebg = cv2.imread(image_path)
            imagebg = cv2.cvtColor(imagebg, cv2.COLOR_BGR2BGRA)
            # imagebg = cv2.resize(imagebg, (self.width,self.height))

        # booleans["long_title_only"] = random.choices([True, False], k=1, weights=[0.2, 0.8])[0]
        booleans["long_title_only"] = False
        if booleans["long_title_only"]:
            new_height_main = random.randint(50, 150)
            new_width_main = random.randint(200, 800)
            image_main = np.ones((new_height_main, new_width_main), dtype='uint8') * color_main
            image_black_main = np.zeros((new_height_main, new_width_main), dtype='uint8')
            image, image_black, width, height, x, y = self.make_title(new_width_main, new_height_main, color_main,
                                                                      color_text, 0)
            y = random.randint(0, new_height_main - height)
            image_main[y:y + height, x:x + width] = image
            image_black_main[y:y + height, x:x + width] = image_black
            return image_main, image_black_main

        # booleans["one_column_more_spaces"] = random.choices([True, False], k=1, weights=[0.3, 0.7])[0]
        booleans["one_column_more_spaces"] = False
        # booleans["one_column_more_spaces"] = False
        # booleans["columns_structre"] = random.choice([True, False])

        booleans["columns_structre"] = True
        if booleans["columns_structre"]:
            # booleans["one_column_more_spaces"] = False
            image_main, image_black_main = self.generate_image_column_structure(new_width, new_height, color_main,
                                                                                color_text_old, color_text, booleans)
            return image_main, image_black_main

    def generate_images(self):
        while True:
            try:
                inverted = random.choices([True, False], k=1, weights=[0.3, 0.7])
                frame = random.choices([True, False], k=1, weights=[0.3, 0.7])
                put_image = [random.choice([True, False])]
                # put_image = [True]  # always true
                # start = time.time()
                image_main, image_black_main = self.generate_image_slices(inverted[0], frame[0], put_image[0])
                # end = time.time()
                # print(end - start)
                gc.collect()
                yield np.array(image_main, dtype='uint8')[..., np.newaxis], \
                      np.array(image_black_main, dtype='uint8')[..., np.newaxis]
            except Exception as e:
                print(e)
                continue


if __name__ == '__main__':
    lines_generator = LinesGenerator(assets_path='D:/All_Assets', width=1500, height=2000)
    # lines_generator = LinesGenerator(assets_path='/media/nourhan-emad/New Volume/gitlab/ocr/assets', width=1000, height=700)
    lines_image = lines_generator.generate_images()
    i = 0
    for image_main, image_black_main in lines_image:
        plt.figure()
        plt.subplot(1, 2, 1)
        plt.imshow(image_main, cmap='gray', vmin=0, vmax=255)
        plt.title('Image')

        plt.subplot(1, 2, 2)
        plt.imshow(image_black_main, cmap='gray')
        plt.title('Segmentation Map')

        # plt.subplot(1, 3, 3)
        # plt.imshow(test_img, cmap='gray')
        # plt.title('image test')

        cv2.imwrite(os.path.join(r"D:\gitlab_updated\ocr_package\test_data" , str(i) + "_image.jpg"),image_main)
        cv2.imwrite(os.path.join(r"D:\gitlab_updated\ocr_package\test_data" , str(i) + "_image_seg_map.jpg"),image_black_main)
        # plt.savefig(r"D:\output_generator" + str(i) + "_image_text_map.jpg")
        print(i)
        i+=1
        plt.show()
        # plt.close()
        # gc.collect()
